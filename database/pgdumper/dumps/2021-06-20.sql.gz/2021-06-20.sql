--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: checker_log; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.checker_log (
    id bigint NOT NULL,
    current_game_checked_on timestamp without time zone DEFAULT now(),
    current_game_time_spent bigint DEFAULT 0,
    leaderboard_checked_on timestamp without time zone DEFAULT now(),
    leaderboard_time_spent bigint DEFAULT 0,
    subscriber_checked_on timestamp without time zone DEFAULT now(),
    subscriber_time_spent bigint DEFAULT 0,
    unclaim_checked_on timestamp without time zone DEFAULT now(),
    unclaim_time_spent bigint DEFAULT 0
);


ALTER TABLE public.checker_log OWNER TO doadmin;

--
-- Name: checker_log_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.checker_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.checker_log_id_seq OWNER TO doadmin;

--
-- Name: checker_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.checker_log_id_seq OWNED BY public.checker_log.id;


--
-- Name: config; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.config (
    id integer NOT NULL,
    invites integer,
    games_per_ad integer,
    days_to_claim integer,
    game_loader_template character varying(5000),
    freespin_per_day integer,
    gems_per_spins_1 integer,
    ads_per_spins_1 integer,
    gems_per_spins_2 integer,
    ads_per_spins_2 integer
);


ALTER TABLE public.config OWNER TO doadmin;

--
-- Name: current_game; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.current_game (
    id bigint NOT NULL,
    prize_id bigint,
    tour_id bigint,
    set_id bigint,
    tsg_id bigint,
    game_id bigint,
    start_timestamp timestamp without time zone,
    end_timestamp timestamp without time zone,
    is_closed boolean DEFAULT false,
    tickets_collected bigint DEFAULT 0
);


ALTER TABLE public.current_game OWNER TO doadmin;

--
-- Name: current_game_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.current_game_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.current_game_id_seq OWNER TO doadmin;

--
-- Name: current_game_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.current_game_id_seq OWNED BY public.current_game.id;


--
-- Name: error_log; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.error_log (
    id bigint NOT NULL,
    module_id integer,
    detail character varying(200),
    created_on timestamp without time zone DEFAULT now()
);


ALTER TABLE public.error_log OWNER TO doadmin;

--
-- Name: error_log_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.error_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.error_log_id_seq OWNER TO doadmin;

--
-- Name: error_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.error_log_id_seq OWNED BY public.error_log.id;


--
-- Name: game; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.game (
    id bigint NOT NULL,
    title character varying(50),
    subtitle character varying(150),
    img_url character varying(350),
    content character varying(2000),
    type_id integer,
    game_code text,
    engine_id integer,
    version integer,
    status integer,
    score_rule integer,
    watch_ad_get_tickets integer,
    watch_ad_get_exp integer,
    use_gem_get_tickets integer,
    use_gem_get_exp integer,
    use_how_many_gems integer
);


ALTER TABLE public.game OWNER TO doadmin;

--
-- Name: game_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.game_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.game_id_seq OWNER TO doadmin;

--
-- Name: game_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.game_id_seq OWNED BY public.game.id;


--
-- Name: game_leader_rule; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.game_leader_rule (
    game_id bigint,
    tickets integer,
    exp integer,
    rank_from integer,
    rank_to integer
);


ALTER TABLE public.game_leader_rule OWNER TO doadmin;

--
-- Name: gplayer; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.gplayer (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    prize_id bigint,
    game_id bigint NOT NULL,
    enter_timestamp timestamp without time zone,
    leave_timestamp timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone,
    game_score integer DEFAULT 0,
    is_watched_ad boolean DEFAULT false,
    is_used_gem boolean DEFAULT false,
    is_logged_leave boolean DEFAULT false,
    is_closed boolean DEFAULT false,
    closed_timestamp timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone
);


ALTER TABLE public.gplayer OWNER TO doadmin;

--
-- Name: gplayer_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.gplayer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gplayer_id_seq OWNER TO doadmin;

--
-- Name: gplayer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.gplayer_id_seq OWNED BY public.gplayer.id;


--
-- Name: item; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.item (
    id bigint NOT NULL,
    title character varying(50),
    subtitle character varying(150),
    img_url character varying(350),
    content character varying(2000),
    type_id integer DEFAULT 0,
    price double precision DEFAULT 0,
    quantity integer DEFAULT 0,
    status integer DEFAULT 0
);


ALTER TABLE public.item OWNER TO doadmin;

--
-- Name: item_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_id_seq OWNER TO doadmin;

--
-- Name: item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.item_id_seq OWNED BY public.item.id;


--
-- Name: item_type; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.item_type (
    id integer NOT NULL,
    title character varying(100)
);


ALTER TABLE public.item_type OWNER TO doadmin;

--
-- Name: prize; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.prize (
    id bigint NOT NULL,
    title character varying(50),
    subtitle character varying(150),
    img_url character varying(350),
    content character varying(2000),
    type_id integer,
    tickets_required bigint,
    duration_days integer DEFAULT 0,
    duration_hours integer DEFAULT 0,
    timezone double precision DEFAULT 0,
    scheduled_on timestamp without time zone,
    is_repeat boolean,
    repeated_on integer[] DEFAULT '{}'::integer[],
    status integer,
    status_progress integer DEFAULT 0,
    tickets_collected bigint DEFAULT 0,
    scheduled_off timestamp without time zone,
    tickets_collected_on timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone
);


ALTER TABLE public.prize OWNER TO doadmin;

--
-- Name: prize_closed; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.prize_closed (
    id bigint NOT NULL,
    prize_id bigint,
    tickets_collected bigint,
    batch bigint,
    status integer DEFAULT 1,
    created_on timestamp without time zone DEFAULT now()
);


ALTER TABLE public.prize_closed OWNER TO doadmin;

--
-- Name: prize_closed_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.prize_closed_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.prize_closed_id_seq OWNER TO doadmin;

--
-- Name: prize_closed_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.prize_closed_id_seq OWNED BY public.prize_closed.id;


--
-- Name: prize_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.prize_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.prize_id_seq OWNER TO doadmin;

--
-- Name: prize_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.prize_id_seq OWNED BY public.prize.id;


--
-- Name: prize_pool; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.prize_pool (
    id bigint NOT NULL,
    prize_id bigint,
    user_id bigint,
    game_id bigint,
    win_from integer DEFAULT 0,
    tickets integer DEFAULT 0,
    created_on timestamp without time zone DEFAULT now(),
    is_closed boolean DEFAULT false,
    closed_on timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone
);


ALTER TABLE public.prize_pool OWNER TO doadmin;

--
-- Name: prize_pool_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.prize_pool_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.prize_pool_id_seq OWNER TO doadmin;

--
-- Name: prize_pool_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.prize_pool_id_seq OWNED BY public.prize_pool.id;


--
-- Name: prize_tour; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.prize_tour (
    id bigint NOT NULL,
    prize_id bigint,
    tour_id bigint,
    status integer
);


ALTER TABLE public.prize_tour OWNER TO doadmin;

--
-- Name: prize_tour_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.prize_tour_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.prize_tour_id_seq OWNER TO doadmin;

--
-- Name: prize_tour_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.prize_tour_id_seq OWNED BY public.prize_tour.id;


--
-- Name: prize_type; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.prize_type (
    id integer NOT NULL,
    title character varying(100)
);


ALTER TABLE public.prize_type OWNER TO doadmin;

--
-- Name: rank; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.rank (
    id bigint NOT NULL,
    title character varying(50),
    exp integer,
    gem integer,
    multiplier double precision
);


ALTER TABLE public.rank OWNER TO doadmin;

--
-- Name: shop_buy; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.shop_buy (
    id bigint NOT NULL,
    item_type_id integer,
    item_id bigint,
    user_id bigint,
    payment_id character varying(50),
    sub_id character varying(50),
    price double precision DEFAULT 0,
    created_on timestamp without time zone DEFAULT now()
);


ALTER TABLE public.shop_buy OWNER TO doadmin;

--
-- Name: shop_buy_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.shop_buy_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shop_buy_id_seq OWNER TO doadmin;

--
-- Name: shop_buy_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.shop_buy_id_seq OWNED BY public.shop_buy.id;


--
-- Name: spinner_extra_log; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.spinner_extra_log (
    id bigint NOT NULL,
    free_spins integer,
    created_on timestamp without time zone DEFAULT now(),
    user_id bigint
);


ALTER TABLE public.spinner_extra_log OWNER TO doadmin;

--
-- Name: spinner_extra_log_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.spinner_extra_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spinner_extra_log_id_seq OWNER TO doadmin;

--
-- Name: spinner_extra_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.spinner_extra_log_id_seq OWNED BY public.spinner_extra_log.id;


--
-- Name: spinner_log; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.spinner_log (
    id bigint NOT NULL,
    user_id bigint,
    prize_id bigint,
    win_type integer DEFAULT 1,
    win_amount integer DEFAULT 0,
    enter_timestamp timestamp without time zone,
    leave_timestamp timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone,
    is_logged_leave boolean DEFAULT false,
    is_watched_ad boolean DEFAULT false,
    is_used_gem boolean DEFAULT false
);


ALTER TABLE public.spinner_log OWNER TO doadmin;

--
-- Name: spinner_log_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.spinner_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spinner_log_id_seq OWNER TO doadmin;

--
-- Name: spinner_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.spinner_log_id_seq OWNED BY public.spinner_log.id;


--
-- Name: spinner_rule; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.spinner_rule (
    id integer NOT NULL,
    probability double precision,
    win double precision,
    type_id integer
);


ALTER TABLE public.spinner_rule OWNER TO doadmin;

--
-- Name: spinner_rule_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.spinner_rule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spinner_rule_id_seq OWNER TO doadmin;

--
-- Name: spinner_rule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.spinner_rule_id_seq OWNED BY public.spinner_rule.id;


--
-- Name: spinner_win_type; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.spinner_win_type (
    id integer NOT NULL,
    title character varying(100)
);


ALTER TABLE public.spinner_win_type OWNER TO doadmin;

--
-- Name: status_progress_type; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.status_progress_type (
    id integer NOT NULL,
    title character varying(100)
);


ALTER TABLE public.status_progress_type OWNER TO doadmin;

--
-- Name: status_type; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.status_type (
    id integer NOT NULL,
    title character varying(100)
);


ALTER TABLE public.status_type OWNER TO doadmin;

--
-- Name: subscription; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.subscription (
    id bigint NOT NULL,
    title character varying(50),
    subtitle character varying(150),
    img_url character varying(350),
    content character varying(2000),
    type_id integer,
    price double precision DEFAULT 0,
    quantity integer DEFAULT 0,
    status integer,
    one_time_gem integer,
    one_time_multiplier double precision,
    daily_gem integer,
    daily_multiplier double precision,
    one_time_is_firstonly boolean
);


ALTER TABLE public.subscription OWNER TO doadmin;

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subscription_id_seq OWNER TO doadmin;

--
-- Name: subscription_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.subscription_id_seq OWNED BY public.subscription.id;


--
-- Name: subscription_type; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.subscription_type (
    id integer NOT NULL,
    title character varying(100)
);


ALTER TABLE public.subscription_type OWNER TO doadmin;

--
-- Name: timezones; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.timezones (
    id integer NOT NULL,
    "offset" double precision,
    stext character varying(10),
    ltext character varying(100)
);


ALTER TABLE public.timezones OWNER TO doadmin;

--
-- Name: timezones_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.timezones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.timezones_id_seq OWNER TO doadmin;

--
-- Name: timezones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.timezones_id_seq OWNED BY public.timezones.id;


--
-- Name: tour_set; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.tour_set (
    id bigint NOT NULL,
    tour_id bigint,
    set_id bigint,
    status integer
);


ALTER TABLE public.tour_set OWNER TO doadmin;

--
-- Name: tour_set_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.tour_set_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tour_set_id_seq OWNER TO doadmin;

--
-- Name: tour_set_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.tour_set_id_seq OWNED BY public.tour_set.id;


--
-- Name: tournament; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.tournament (
    id bigint NOT NULL,
    title character varying(150),
    status integer
);


ALTER TABLE public.tournament OWNER TO doadmin;

--
-- Name: tournament_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.tournament_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tournament_id_seq OWNER TO doadmin;

--
-- Name: tournament_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.tournament_id_seq OWNED BY public.tournament.id;


--
-- Name: tournament_set; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.tournament_set (
    id bigint NOT NULL,
    title character varying(150),
    duration_days integer DEFAULT 0,
    duration_hours integer,
    is_group boolean
);


ALTER TABLE public.tournament_set OWNER TO doadmin;

--
-- Name: tournament_set_game_rule; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.tournament_set_game_rule (
    id bigint NOT NULL,
    set_id bigint NOT NULL,
    game_id bigint NOT NULL,
    duration_days integer NOT NULL,
    duration_hours integer NOT NULL,
    duration_minutes integer NOT NULL,
    group_id integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.tournament_set_game_rule OWNER TO doadmin;

--
-- Name: tournament_set_game_rule_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.tournament_set_game_rule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tournament_set_game_rule_id_seq OWNER TO doadmin;

--
-- Name: tournament_set_game_rule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.tournament_set_game_rule_id_seq OWNED BY public.tournament_set_game_rule.id;


--
-- Name: tournament_set_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.tournament_set_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tournament_set_id_seq OWNER TO doadmin;

--
-- Name: tournament_set_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.tournament_set_id_seq OWNED BY public.tournament_set.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public."user" (
    id bigint NOT NULL,
    username character varying(128) NOT NULL,
    passhash character varying(2000) NOT NULL,
    email character varying(355) NOT NULL,
    phone character varying(20) NOT NULL,
    firstname character varying(50) NOT NULL,
    lastname character varying(50) NOT NULL,
    created_on timestamp without time zone NOT NULL,
    last_login timestamp without time zone NOT NULL,
    role_id integer NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    gem_balance integer DEFAULT 0,
    social_link_fb character varying(355) DEFAULT ''::character varying,
    social_link_google character varying(355) DEFAULT ''::character varying,
    avatar_url character varying(355) DEFAULT ''::character varying,
    exp integer DEFAULT 0,
    full_name character varying(355) DEFAULT ''::character varying,
    country_code integer DEFAULT 0,
    address character varying(1000) DEFAULT ''::character varying,
    city character varying(355) DEFAULT ''::character varying,
    state character varying(355) DEFAULT ''::character varying,
    zip_code character varying(20) DEFAULT ''::character varying,
    country character varying(355) DEFAULT ''::character varying,
    is_email_confirmed boolean DEFAULT false,
    is_notify_allowed boolean DEFAULT true,
    is_notify_new_reward boolean DEFAULT true,
    is_notify_new_tournament boolean DEFAULT true,
    is_notify_tour_ending boolean DEFAULT true,
    nick_name character varying(50) DEFAULT ''::character varying,
    rank integer DEFAULT 0,
    msg_token character varying(512) DEFAULT ''::character varying,
    subscription_id bigint DEFAULT 0,
    one_time_multiplier double precision DEFAULT 0,
    daily_gem integer DEFAULT 0,
    daily_multiplier double precision DEFAULT 0,
    one_time_is_firstonly boolean DEFAULT false,
    sub_daily_timestamp timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone,
    exp_timestamp timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone,
    msg_token_timestamp timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone,
    sub_id character varying(50) DEFAULT ''::character varying
);


ALTER TABLE public."user" OWNER TO doadmin;

--
-- Name: user_admin_change_log; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.user_admin_change_log (
    id bigint NOT NULL,
    user_id bigint,
    old_status integer,
    new_status integer,
    old_gem_balance integer,
    new_gem_balance integer,
    created_on timestamp with time zone,
    changed_by bigint
);


ALTER TABLE public.user_admin_change_log OWNER TO doadmin;

--
-- Name: user_admin_change_log_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.user_admin_change_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_admin_change_log_id_seq OWNER TO doadmin;

--
-- Name: user_admin_change_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.user_admin_change_log_id_seq OWNED BY public.user_admin_change_log.id;


--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq OWNER TO doadmin;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: user_invites; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.user_invites (
    id bigint NOT NULL,
    user_id bigint,
    invited_by bigint,
    invited_date timestamp without time zone
);


ALTER TABLE public.user_invites OWNER TO doadmin;

--
-- Name: user_invites_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.user_invites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_invites_id_seq OWNER TO doadmin;

--
-- Name: user_invites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.user_invites_id_seq OWNED BY public.user_invites.id;


--
-- Name: user_status_type; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.user_status_type (
    id integer NOT NULL,
    title character varying(100)
);


ALTER TABLE public.user_status_type OWNER TO doadmin;

--
-- Name: winner; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.winner (
    id bigint NOT NULL,
    prize_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_on timestamp without time zone DEFAULT now(),
    status integer DEFAULT 1,
    ship_tracking character varying(255) DEFAULT ''::character varying,
    claimed_on timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone
);


ALTER TABLE public.winner OWNER TO doadmin;

--
-- Name: winner_change_log; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.winner_change_log (
    id bigint NOT NULL,
    winner_id bigint,
    old_status integer,
    new_status integer,
    old_ship_tracking character varying(255),
    new_ship_tracking character varying(255),
    created_on timestamp with time zone,
    changed_by bigint
);


ALTER TABLE public.winner_change_log OWNER TO doadmin;

--
-- Name: winner_change_log_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.winner_change_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.winner_change_log_id_seq OWNER TO doadmin;

--
-- Name: winner_change_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.winner_change_log_id_seq OWNED BY public.winner_change_log.id;


--
-- Name: winner_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.winner_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.winner_id_seq OWNER TO doadmin;

--
-- Name: winner_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.winner_id_seq OWNED BY public.winner.id;


--
-- Name: winner_status_type; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.winner_status_type (
    id integer NOT NULL,
    title character varying(100)
);


ALTER TABLE public.winner_status_type OWNER TO doadmin;

--
-- Name: checker_log id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.checker_log ALTER COLUMN id SET DEFAULT nextval('public.checker_log_id_seq'::regclass);


--
-- Name: current_game id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.current_game ALTER COLUMN id SET DEFAULT nextval('public.current_game_id_seq'::regclass);


--
-- Name: error_log id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.error_log ALTER COLUMN id SET DEFAULT nextval('public.error_log_id_seq'::regclass);


--
-- Name: game id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.game ALTER COLUMN id SET DEFAULT nextval('public.game_id_seq'::regclass);


--
-- Name: gplayer id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.gplayer ALTER COLUMN id SET DEFAULT nextval('public.gplayer_id_seq'::regclass);


--
-- Name: item id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.item ALTER COLUMN id SET DEFAULT nextval('public.item_id_seq'::regclass);


--
-- Name: prize id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.prize ALTER COLUMN id SET DEFAULT nextval('public.prize_id_seq'::regclass);


--
-- Name: prize_closed id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.prize_closed ALTER COLUMN id SET DEFAULT nextval('public.prize_closed_id_seq'::regclass);


--
-- Name: prize_pool id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.prize_pool ALTER COLUMN id SET DEFAULT nextval('public.prize_pool_id_seq'::regclass);


--
-- Name: prize_tour id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.prize_tour ALTER COLUMN id SET DEFAULT nextval('public.prize_tour_id_seq'::regclass);


--
-- Name: shop_buy id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.shop_buy ALTER COLUMN id SET DEFAULT nextval('public.shop_buy_id_seq'::regclass);


--
-- Name: spinner_extra_log id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.spinner_extra_log ALTER COLUMN id SET DEFAULT nextval('public.spinner_extra_log_id_seq'::regclass);


--
-- Name: spinner_log id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.spinner_log ALTER COLUMN id SET DEFAULT nextval('public.spinner_log_id_seq'::regclass);


--
-- Name: spinner_rule id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.spinner_rule ALTER COLUMN id SET DEFAULT nextval('public.spinner_rule_id_seq'::regclass);


--
-- Name: subscription id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.subscription ALTER COLUMN id SET DEFAULT nextval('public.subscription_id_seq'::regclass);


--
-- Name: timezones id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.timezones ALTER COLUMN id SET DEFAULT nextval('public.timezones_id_seq'::regclass);


--
-- Name: tour_set id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.tour_set ALTER COLUMN id SET DEFAULT nextval('public.tour_set_id_seq'::regclass);


--
-- Name: tournament id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.tournament ALTER COLUMN id SET DEFAULT nextval('public.tournament_id_seq'::regclass);


--
-- Name: tournament_set id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.tournament_set ALTER COLUMN id SET DEFAULT nextval('public.tournament_set_id_seq'::regclass);


--
-- Name: tournament_set_game_rule id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.tournament_set_game_rule ALTER COLUMN id SET DEFAULT nextval('public.tournament_set_game_rule_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Name: user_admin_change_log id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.user_admin_change_log ALTER COLUMN id SET DEFAULT nextval('public.user_admin_change_log_id_seq'::regclass);


--
-- Name: user_invites id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.user_invites ALTER COLUMN id SET DEFAULT nextval('public.user_invites_id_seq'::regclass);


--
-- Name: winner id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.winner ALTER COLUMN id SET DEFAULT nextval('public.winner_id_seq'::regclass);


--
-- Name: winner_change_log id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.winner_change_log ALTER COLUMN id SET DEFAULT nextval('public.winner_change_log_id_seq'::regclass);


--
-- Data for Name: checker_log; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.checker_log (id, current_game_checked_on, current_game_time_spent, leaderboard_checked_on, leaderboard_time_spent, subscriber_checked_on, subscriber_time_spent, unclaim_checked_on, unclaim_time_spent) FROM stdin;
1	2021-06-20 05:14:32.966282	2	2021-06-20 05:14:33.048456	2	2021-06-20 05:14:32.942098	1	2021-06-20 05:14:33.035123	3
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.config (id, invites, games_per_ad, days_to_claim, game_loader_template, freespin_per_day, gems_per_spins_1, ads_per_spins_1, gems_per_spins_2, ads_per_spins_2) FROM stdin;
1	10	3	30	0	3	1	0	2	0
\.


--
-- Data for Name: current_game; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.current_game (id, prize_id, tour_id, set_id, tsg_id, game_id, start_timestamp, end_timestamp, is_closed, tickets_collected) FROM stdin;
\.


--
-- Data for Name: error_log; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.error_log (id, module_id, detail, created_on) FROM stdin;
\.


--
-- Data for Name: game; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.game (id, title, subtitle, img_url, content, type_id, game_code, engine_id, version, status, score_rule, watch_ad_get_tickets, watch_ad_get_exp, use_gem_get_tickets, use_gem_get_exp, use_how_many_gems) FROM stdin;
\.


--
-- Data for Name: game_leader_rule; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.game_leader_rule (game_id, tickets, exp, rank_from, rank_to) FROM stdin;
\.


--
-- Data for Name: gplayer; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.gplayer (id, user_id, prize_id, game_id, enter_timestamp, leave_timestamp, game_score, is_watched_ad, is_used_gem, is_logged_leave, is_closed, closed_timestamp) FROM stdin;
\.


--
-- Data for Name: item; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.item (id, title, subtitle, img_url, content, type_id, price, quantity, status) FROM stdin;
\.


--
-- Data for Name: item_type; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.item_type (id, title) FROM stdin;
0	Not Selected
1	Gem
\.


--
-- Data for Name: prize; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.prize (id, title, subtitle, img_url, content, type_id, tickets_required, duration_days, duration_hours, timezone, scheduled_on, is_repeat, repeated_on, status, status_progress, tickets_collected, scheduled_off, tickets_collected_on) FROM stdin;
\.


--
-- Data for Name: prize_closed; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.prize_closed (id, prize_id, tickets_collected, batch, status, created_on) FROM stdin;
\.


--
-- Data for Name: prize_pool; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.prize_pool (id, prize_id, user_id, game_id, win_from, tickets, created_on, is_closed, closed_on) FROM stdin;
\.


--
-- Data for Name: prize_tour; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.prize_tour (id, prize_id, tour_id, status) FROM stdin;
\.


--
-- Data for Name: prize_type; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.prize_type (id, title) FROM stdin;
0	Not Selected
4	Automated Entry
3	Time Sensitive
1	Featured
2	Premium
\.


--
-- Data for Name: rank; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.rank (id, title, exp, gem, multiplier) FROM stdin;
\.


--
-- Data for Name: shop_buy; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.shop_buy (id, item_type_id, item_id, user_id, payment_id, sub_id, price, created_on) FROM stdin;
\.


--
-- Data for Name: spinner_extra_log; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.spinner_extra_log (id, free_spins, created_on, user_id) FROM stdin;
\.


--
-- Data for Name: spinner_log; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.spinner_log (id, user_id, prize_id, win_type, win_amount, enter_timestamp, leave_timestamp, is_logged_leave, is_watched_ad, is_used_gem) FROM stdin;
\.


--
-- Data for Name: spinner_rule; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.spinner_rule (id, probability, win, type_id) FROM stdin;
\.


--
-- Data for Name: spinner_win_type; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.spinner_win_type (id, title) FROM stdin;
1	Tickets
2	Gems
3	Cash
4	Free Spin
\.


--
-- Data for Name: status_progress_type; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.status_progress_type (id, title) FROM stdin;
0	Inactive
1	Running
666	Bad Link
999	Ended
9999	SOS Stopped
\.


--
-- Data for Name: status_type; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.status_type (id, title) FROM stdin;
0	Not Selected
1	Draft
2	Published
3	Archived/Disabled
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.subscription (id, title, subtitle, img_url, content, type_id, price, quantity, status, one_time_gem, one_time_multiplier, daily_gem, daily_multiplier, one_time_is_firstonly) FROM stdin;
\.


--
-- Data for Name: subscription_type; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.subscription_type (id, title) FROM stdin;
0	Not Selected
1	Day
2	Week
3	Month
4	Year
\.


--
-- Data for Name: timezones; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.timezones (id, "offset", stext, ltext) FROM stdin;
1	-12	GMT -12:00	(GMT -12:00) Eniwetok, Kwajalein
2	-11	GMT -11:00	(GMT -11:00) Midway Island, Samoa
3	-10	GMT -10:00	(GMT -10:00) Hawaii
4	-9	GMT -9:00	(GMT -9:00) Alaska
5	-8	GMT -8:00	(GMT -8:00) Pacific Time (US & Canada)
6	-7	GMT -7:00	(GMT -7:00) Mountain Time (US & Canada)
7	-6	GMT -6:00	(GMT -6:00) Central Time (US & Canada), Mexico City
8	-5	GMT -5:00	(GMT -5:00) Eastern Time (US & Canada), Bogota, Lima
9	-4	GMT -4:00	(GMT -4:00) Atlantic Time (Canada), Caracas, La Paz
10	-3.5	GMT -3:30	(GMT -3:30) Newfoundland
11	-3	GMT -3:00	(GMT -3:00) Brazil, Buenos Aires, Georgetown
12	-2	GMT -2:00	(GMT -2:00) Mid-Atlantic
13	-1	GMT -1:00	(GMT -1:00) Azores, Cape Verde Islands
14	0	GMT -0:00	(GMT) Western Europe Time, London, Lisbon, Casablanca
15	1	GMT +1:00	(GMT +1:00) Brussels, Copenhagen, Madrid, Paris
16	2	GMT +2:00	(GMT +2:00) Kaliningrad, South Africa
17	3	GMT +3:00	(GMT +3:00) Baghdad, Riyadh, Moscow, St. Petersburg
18	3.5	GMT +3:30	(GMT +3:30) Tehran
19	4	GMT +4:00	(GMT +4:00) Abu Dhabi, Muscat, Baku, Tbilisi
20	4.5	GMT +4:30	(GMT +4:30) Kabul
21	5	GMT +5:00	(GMT +5:00) Ekaterinburg, Islamabad, Karachi, Tashkent
22	5.5	GMT +5:30	(GMT +5:30) Bombay, Calcutta, Madras, New Delhi
23	5.75	GMT +5:45	(GMT +5:45) Kathmandu
24	6	GMT +6:00	(GMT +6:00) Almaty, Dhaka, Colombo
25	7	GMT +7:00	(GMT +7:00) Bangkok, Hanoi, Jakarta
26	8	GMT +8:00	(GMT +8:00) Beijing, Perth, Singapore, Hong Kong
27	9	GMT +9:00	(GMT +9:00) Tokyo, Seoul, Osaka, Sapporo, Yakutsk
28	9.5	GMT +9:30	(GMT +9:30) Adelaide, Darwin
29	10	GMT +10:00	(GMT +10:00) Eastern Australia, Guam, Vladivostok
30	11	GMT +11:00	(GMT +11:00) Magadan, Solomon Islands, New Caledonia
31	12	GMT +12:00	(GMT +12:00) Auckland, Wellington, Fiji, Kamchatka
\.


--
-- Data for Name: tour_set; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.tour_set (id, tour_id, set_id, status) FROM stdin;
\.


--
-- Data for Name: tournament; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.tournament (id, title, status) FROM stdin;
\.


--
-- Data for Name: tournament_set; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.tournament_set (id, title, duration_days, duration_hours, is_group) FROM stdin;
\.


--
-- Data for Name: tournament_set_game_rule; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.tournament_set_game_rule (id, set_id, game_id, duration_days, duration_hours, duration_minutes, group_id) FROM stdin;
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public."user" (id, username, passhash, email, phone, firstname, lastname, created_on, last_login, role_id, status, gem_balance, social_link_fb, social_link_google, avatar_url, exp, full_name, country_code, address, city, state, zip_code, country, is_email_confirmed, is_notify_allowed, is_notify_new_reward, is_notify_new_tournament, is_notify_tour_ending, nick_name, rank, msg_token, subscription_id, one_time_multiplier, daily_gem, daily_multiplier, one_time_is_firstonly, sub_daily_timestamp, exp_timestamp, msg_token_timestamp, sub_id) FROM stdin;
1	wukong	$argon2id$v=19$m=64,t=1,p=1$pb7+cdRKchBGWxfmx6nHinqmLY4ir5vc4+LSsPwbpDg$kwfH/p8iEmxcTjKqzyWs8sekvIns2Qt4vSvbS/Pxz9U	esmadmin@aadi.my	0188888888	Black	Myth	2020-12-31 15:07:54.239332	2021-05-31 10:28:27.69873	1	1	0				2		0						f	f	f	f	f		0		1	0	0	0	f	2021-05-24 12:07:26.856779	1970-01-01 00:00:00	1970-01-01 00:00:00	
\.


--
-- Data for Name: user_admin_change_log; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.user_admin_change_log (id, user_id, old_status, new_status, old_gem_balance, new_gem_balance, created_on, changed_by) FROM stdin;
\.


--
-- Data for Name: user_invites; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.user_invites (id, user_id, invited_by, invited_date) FROM stdin;
\.


--
-- Data for Name: user_status_type; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.user_status_type (id, title) FROM stdin;
0	Not Selected
1	Active
2	Blocked
3	Pending Delete
4	Archived
\.


--
-- Data for Name: winner; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.winner (id, prize_id, user_id, created_on, status, ship_tracking, claimed_on) FROM stdin;
\.


--
-- Data for Name: winner_change_log; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.winner_change_log (id, winner_id, old_status, new_status, old_ship_tracking, new_ship_tracking, created_on, changed_by) FROM stdin;
\.


--
-- Data for Name: winner_status_type; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.winner_status_type (id, title) FROM stdin;
1	Unclaimed
2	Claimed
3	Delivered
4	Expired
\.


--
-- Name: checker_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.checker_log_id_seq', 1, false);


--
-- Name: current_game_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.current_game_id_seq', 1, false);


--
-- Name: error_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.error_log_id_seq', 1, false);


--
-- Name: game_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.game_id_seq', 1, false);


--
-- Name: gplayer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.gplayer_id_seq', 1, false);


--
-- Name: item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.item_id_seq', 1, false);


--
-- Name: prize_closed_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.prize_closed_id_seq', 1, false);


--
-- Name: prize_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.prize_id_seq', 1, false);


--
-- Name: prize_pool_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.prize_pool_id_seq', 1, false);


--
-- Name: prize_tour_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.prize_tour_id_seq', 1, false);


--
-- Name: shop_buy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.shop_buy_id_seq', 1, false);


--
-- Name: spinner_extra_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.spinner_extra_log_id_seq', 1, false);


--
-- Name: spinner_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.spinner_log_id_seq', 1, false);


--
-- Name: spinner_rule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.spinner_rule_id_seq', 1, false);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.subscription_id_seq', 1, false);


--
-- Name: timezones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.timezones_id_seq', 1, false);


--
-- Name: tour_set_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.tour_set_id_seq', 1, false);


--
-- Name: tournament_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.tournament_id_seq', 1, false);


--
-- Name: tournament_set_game_rule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.tournament_set_game_rule_id_seq', 1, false);


--
-- Name: tournament_set_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.tournament_set_id_seq', 1, false);


--
-- Name: user_admin_change_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.user_admin_change_log_id_seq', 1, false);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.user_id_seq', 1, false);


--
-- Name: user_invites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.user_invites_id_seq', 1, false);


--
-- Name: winner_change_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.winner_change_log_id_seq', 1, false);


--
-- Name: winner_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.winner_id_seq', 1, false);


--
-- Name: checker_log checker_log_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.checker_log
    ADD CONSTRAINT checker_log_pkey PRIMARY KEY (id);


--
-- Name: config config_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.config
    ADD CONSTRAINT config_pkey PRIMARY KEY (id);


--
-- Name: current_game current_game_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.current_game
    ADD CONSTRAINT current_game_pkey PRIMARY KEY (id);


--
-- Name: error_log error_log_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.error_log
    ADD CONSTRAINT error_log_pkey PRIMARY KEY (id);


--
-- Name: game game_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.game
    ADD CONSTRAINT game_pkey PRIMARY KEY (id);


--
-- Name: gplayer gplayer_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.gplayer
    ADD CONSTRAINT gplayer_pkey PRIMARY KEY (id);


--
-- Name: item item_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.item
    ADD CONSTRAINT item_pkey PRIMARY KEY (id);


--
-- Name: item_type item_type_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.item_type
    ADD CONSTRAINT item_type_pkey PRIMARY KEY (id);


--
-- Name: prize_closed prize_closed_log_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.prize_closed
    ADD CONSTRAINT prize_closed_log_pkey PRIMARY KEY (id);


--
-- Name: prize prize_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.prize
    ADD CONSTRAINT prize_pkey PRIMARY KEY (id);


--
-- Name: prize_pool prize_pool_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.prize_pool
    ADD CONSTRAINT prize_pool_pkey PRIMARY KEY (id);


--
-- Name: prize_tour prize_tour_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.prize_tour
    ADD CONSTRAINT prize_tour_pkey PRIMARY KEY (id);


--
-- Name: prize_type prize_type_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.prize_type
    ADD CONSTRAINT prize_type_pkey PRIMARY KEY (id);


--
-- Name: rank rank_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.rank
    ADD CONSTRAINT rank_pkey PRIMARY KEY (id);


--
-- Name: shop_buy shop_buy_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.shop_buy
    ADD CONSTRAINT shop_buy_pkey PRIMARY KEY (id);


--
-- Name: spinner_extra_log spinner_extra_log_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.spinner_extra_log
    ADD CONSTRAINT spinner_extra_log_pkey PRIMARY KEY (id);


--
-- Name: spinner_log spinner_log_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.spinner_log
    ADD CONSTRAINT spinner_log_pkey PRIMARY KEY (id);


--
-- Name: spinner_rule spinner_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.spinner_rule
    ADD CONSTRAINT spinner_rule_pkey PRIMARY KEY (id);


--
-- Name: spinner_win_type spinner_win_type_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.spinner_win_type
    ADD CONSTRAINT spinner_win_type_pkey PRIMARY KEY (id);


--
-- Name: status_progress_type status_progress_type_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.status_progress_type
    ADD CONSTRAINT status_progress_type_pkey PRIMARY KEY (id);


--
-- Name: status_type status_type_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.status_type
    ADD CONSTRAINT status_type_pkey PRIMARY KEY (id);


--
-- Name: subscription subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.subscription
    ADD CONSTRAINT subscription_pkey PRIMARY KEY (id);


--
-- Name: subscription_type subscription_type_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.subscription_type
    ADD CONSTRAINT subscription_type_pkey PRIMARY KEY (id);


--
-- Name: timezones timezones_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.timezones
    ADD CONSTRAINT timezones_pkey PRIMARY KEY (id);


--
-- Name: tour_set tour_set_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.tour_set
    ADD CONSTRAINT tour_set_pkey PRIMARY KEY (id);


--
-- Name: tournament tournament_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.tournament
    ADD CONSTRAINT tournament_pkey PRIMARY KEY (id);


--
-- Name: tournament_set_game_rule tournament_set_game_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.tournament_set_game_rule
    ADD CONSTRAINT tournament_set_game_rule_pkey PRIMARY KEY (id);


--
-- Name: tournament_set tournament_set_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.tournament_set
    ADD CONSTRAINT tournament_set_pkey PRIMARY KEY (id);


--
-- Name: user_admin_change_log user_admin_change_log_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.user_admin_change_log
    ADD CONSTRAINT user_admin_change_log_pkey PRIMARY KEY (id);


--
-- Name: user user_email_key; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_email_key UNIQUE (email);


--
-- Name: user_invites user_invites_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.user_invites
    ADD CONSTRAINT user_invites_pkey PRIMARY KEY (id);


--
-- Name: user_invites user_invites_user_id_key; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.user_invites
    ADD CONSTRAINT user_invites_user_id_key UNIQUE (user_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: user_status_type user_status_type_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.user_status_type
    ADD CONSTRAINT user_status_type_pkey PRIMARY KEY (id);


--
-- Name: user user_username_key; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_username_key UNIQUE (username);


--
-- Name: winner_change_log winner_change_log_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.winner_change_log
    ADD CONSTRAINT winner_change_log_pkey PRIMARY KEY (id);


--
-- Name: winner winner_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.winner
    ADD CONSTRAINT winner_pkey PRIMARY KEY (id);


--
-- Name: winner_status_type winner_status_type_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.winner_status_type
    ADD CONSTRAINT winner_status_type_pkey PRIMARY KEY (id);


--
-- Name: game_lower_idx; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX game_lower_idx ON public.game USING btree (lower((title)::text));


--
-- Name: idx_user_email; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX idx_user_email ON public."user" USING btree (email);


--
-- Name: idx_user_firstname; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX idx_user_firstname ON public."user" USING btree (firstname);


--
-- Name: idx_user_lastname; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX idx_user_lastname ON public."user" USING btree (lastname);


--
-- Name: idx_user_phone; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX idx_user_phone ON public."user" USING btree (phone);


--
-- Name: idx_user_username; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX idx_user_username ON public."user" USING btree (username);


--
-- Name: item_lower_idx; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX item_lower_idx ON public.item USING btree (lower((title)::text));


--
-- Name: prize_lower_idx; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX prize_lower_idx ON public.prize USING btree (lower((title)::text));


--
-- Name: subscription_lower_idx; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX subscription_lower_idx ON public.subscription USING btree (lower((title)::text));


--
-- Name: tournament_lower_idx; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX tournament_lower_idx ON public.tournament USING btree (lower((title)::text));


--
-- Name: tournament_set_lower_idx; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX tournament_set_lower_idx ON public.tournament_set USING btree (lower((title)::text));


--
-- PostgreSQL database dump complete
--

