--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: checker_log; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.checker_log (
    id bigint NOT NULL,
    current_game_checked_on timestamp without time zone DEFAULT now(),
    current_game_time_spent bigint DEFAULT 0,
    leaderboard_checked_on timestamp without time zone DEFAULT now(),
    leaderboard_time_spent bigint DEFAULT 0,
    subscriber_checked_on timestamp without time zone DEFAULT now(),
    subscriber_time_spent bigint DEFAULT 0,
    unclaim_checked_on timestamp without time zone DEFAULT now(),
    unclaim_time_spent bigint DEFAULT 0
);


ALTER TABLE public.checker_log OWNER TO doadmin;

--
-- Name: checker_log_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.checker_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.checker_log_id_seq OWNER TO doadmin;

--
-- Name: checker_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.checker_log_id_seq OWNED BY public.checker_log.id;


--
-- Name: config; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.config (
    id integer NOT NULL,
    invites integer,
    games_per_ad integer,
    days_to_claim integer,
    game_loader_template character varying(5000),
    freespin_per_day integer,
    gems_per_spins_1 integer,
    ads_per_spins_1 integer,
    gems_per_spins_2 integer,
    ads_per_spins_2 integer
);


ALTER TABLE public.config OWNER TO doadmin;

--
-- Name: current_game; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.current_game (
    id bigint NOT NULL,
    prize_id bigint,
    tour_id bigint,
    set_id bigint,
    tsg_id bigint,
    game_id bigint,
    start_timestamp timestamp without time zone,
    end_timestamp timestamp without time zone,
    is_closed boolean DEFAULT false,
    tickets_collected bigint DEFAULT 0
);


ALTER TABLE public.current_game OWNER TO doadmin;

--
-- Name: current_game_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.current_game_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.current_game_id_seq OWNER TO doadmin;

--
-- Name: current_game_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.current_game_id_seq OWNED BY public.current_game.id;


--
-- Name: error_log; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.error_log (
    id bigint NOT NULL,
    module_id integer,
    detail character varying(200),
    created_on timestamp without time zone DEFAULT now()
);


ALTER TABLE public.error_log OWNER TO doadmin;

--
-- Name: error_log_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.error_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.error_log_id_seq OWNER TO doadmin;

--
-- Name: error_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.error_log_id_seq OWNED BY public.error_log.id;


--
-- Name: game; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.game (
    id bigint NOT NULL,
    title character varying(50),
    subtitle character varying(150),
    img_url character varying(350),
    content character varying(2000),
    type_id integer,
    game_code text,
    engine_id integer,
    version integer,
    status integer,
    score_rule integer,
    watch_ad_get_tickets integer,
    watch_ad_get_exp integer,
    use_gem_get_tickets integer,
    use_gem_get_exp integer,
    use_how_many_gems integer
);


ALTER TABLE public.game OWNER TO doadmin;

--
-- Name: game_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.game_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.game_id_seq OWNER TO doadmin;

--
-- Name: game_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.game_id_seq OWNED BY public.game.id;


--
-- Name: game_leader_rule; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.game_leader_rule (
    game_id bigint,
    tickets integer,
    exp integer,
    rank_from integer,
    rank_to integer
);


ALTER TABLE public.game_leader_rule OWNER TO doadmin;

--
-- Name: gplayer; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.gplayer (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    prize_id bigint,
    game_id bigint NOT NULL,
    enter_timestamp timestamp without time zone,
    leave_timestamp timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone,
    game_score integer DEFAULT 0,
    is_watched_ad boolean DEFAULT false,
    is_used_gem boolean DEFAULT false,
    is_logged_leave boolean DEFAULT false,
    is_closed boolean DEFAULT false,
    closed_timestamp timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone
);


ALTER TABLE public.gplayer OWNER TO doadmin;

--
-- Name: gplayer_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.gplayer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gplayer_id_seq OWNER TO doadmin;

--
-- Name: gplayer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.gplayer_id_seq OWNED BY public.gplayer.id;


--
-- Name: item; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.item (
    id bigint NOT NULL,
    title character varying(50),
    subtitle character varying(150),
    img_url character varying(350),
    content character varying(2000),
    type_id integer DEFAULT 0,
    price double precision DEFAULT 0,
    quantity integer DEFAULT 0,
    status integer DEFAULT 0
);


ALTER TABLE public.item OWNER TO doadmin;

--
-- Name: item_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_id_seq OWNER TO doadmin;

--
-- Name: item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.item_id_seq OWNED BY public.item.id;


--
-- Name: item_type; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.item_type (
    id integer NOT NULL,
    title character varying(100)
);


ALTER TABLE public.item_type OWNER TO doadmin;

--
-- Name: prize; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.prize (
    id bigint NOT NULL,
    title character varying(50),
    subtitle character varying(150),
    img_url character varying(350),
    content character varying(2000),
    type_id integer,
    tickets_required bigint,
    duration_days integer DEFAULT 0,
    duration_hours integer DEFAULT 0,
    timezone double precision DEFAULT 0,
    scheduled_on timestamp without time zone,
    is_repeat boolean,
    repeated_on integer[] DEFAULT '{}'::integer[],
    status integer,
    status_progress integer DEFAULT 0,
    tickets_collected bigint DEFAULT 0,
    scheduled_off timestamp without time zone,
    tickets_collected_on timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone
);


ALTER TABLE public.prize OWNER TO doadmin;

--
-- Name: prize_closed; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.prize_closed (
    id bigint NOT NULL,
    prize_id bigint,
    tickets_collected bigint,
    batch bigint,
    status integer DEFAULT 1,
    created_on timestamp without time zone DEFAULT now()
);


ALTER TABLE public.prize_closed OWNER TO doadmin;

--
-- Name: prize_closed_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.prize_closed_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.prize_closed_id_seq OWNER TO doadmin;

--
-- Name: prize_closed_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.prize_closed_id_seq OWNED BY public.prize_closed.id;


--
-- Name: prize_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.prize_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.prize_id_seq OWNER TO doadmin;

--
-- Name: prize_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.prize_id_seq OWNED BY public.prize.id;


--
-- Name: prize_pool; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.prize_pool (
    id bigint NOT NULL,
    prize_id bigint,
    user_id bigint,
    game_id bigint,
    win_from integer DEFAULT 0,
    tickets integer DEFAULT 0,
    created_on timestamp without time zone DEFAULT now(),
    is_closed boolean DEFAULT false,
    closed_on timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone
);


ALTER TABLE public.prize_pool OWNER TO doadmin;

--
-- Name: prize_pool_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.prize_pool_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.prize_pool_id_seq OWNER TO doadmin;

--
-- Name: prize_pool_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.prize_pool_id_seq OWNED BY public.prize_pool.id;


--
-- Name: prize_tour; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.prize_tour (
    id bigint NOT NULL,
    prize_id bigint,
    tour_id bigint,
    status integer
);


ALTER TABLE public.prize_tour OWNER TO doadmin;

--
-- Name: prize_tour_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.prize_tour_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.prize_tour_id_seq OWNER TO doadmin;

--
-- Name: prize_tour_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.prize_tour_id_seq OWNED BY public.prize_tour.id;


--
-- Name: prize_type; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.prize_type (
    id integer NOT NULL,
    title character varying(100)
);


ALTER TABLE public.prize_type OWNER TO doadmin;

--
-- Name: rank; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.rank (
    id bigint NOT NULL,
    title character varying(50),
    exp integer,
    gem integer,
    multiplier double precision
);


ALTER TABLE public.rank OWNER TO doadmin;

--
-- Name: shop_buy; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.shop_buy (
    id bigint NOT NULL,
    item_type_id integer,
    item_id bigint,
    user_id bigint,
    payment_id character varying(50),
    sub_id character varying(50),
    price double precision DEFAULT 0,
    created_on timestamp without time zone DEFAULT now()
);


ALTER TABLE public.shop_buy OWNER TO doadmin;

--
-- Name: shop_buy_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.shop_buy_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shop_buy_id_seq OWNER TO doadmin;

--
-- Name: shop_buy_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.shop_buy_id_seq OWNED BY public.shop_buy.id;


--
-- Name: spinner_extra_log; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.spinner_extra_log (
    id bigint NOT NULL,
    free_spins integer,
    created_on timestamp without time zone DEFAULT now(),
    user_id bigint
);


ALTER TABLE public.spinner_extra_log OWNER TO doadmin;

--
-- Name: spinner_extra_log_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.spinner_extra_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spinner_extra_log_id_seq OWNER TO doadmin;

--
-- Name: spinner_extra_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.spinner_extra_log_id_seq OWNED BY public.spinner_extra_log.id;


--
-- Name: spinner_log; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.spinner_log (
    id bigint NOT NULL,
    user_id bigint,
    prize_id bigint,
    win_type integer DEFAULT 1,
    win_amount integer DEFAULT 0,
    enter_timestamp timestamp without time zone,
    leave_timestamp timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone,
    is_logged_leave boolean DEFAULT false,
    is_watched_ad boolean DEFAULT false,
    is_used_gem boolean DEFAULT false
);


ALTER TABLE public.spinner_log OWNER TO doadmin;

--
-- Name: spinner_log_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.spinner_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spinner_log_id_seq OWNER TO doadmin;

--
-- Name: spinner_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.spinner_log_id_seq OWNED BY public.spinner_log.id;


--
-- Name: spinner_rule; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.spinner_rule (
    id integer NOT NULL,
    probability double precision,
    win double precision,
    type_id integer
);


ALTER TABLE public.spinner_rule OWNER TO doadmin;

--
-- Name: spinner_rule_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.spinner_rule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spinner_rule_id_seq OWNER TO doadmin;

--
-- Name: spinner_rule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.spinner_rule_id_seq OWNED BY public.spinner_rule.id;


--
-- Name: spinner_win_type; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.spinner_win_type (
    id integer NOT NULL,
    title character varying(100)
);


ALTER TABLE public.spinner_win_type OWNER TO doadmin;

--
-- Name: status_progress_type; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.status_progress_type (
    id integer NOT NULL,
    title character varying(100)
);


ALTER TABLE public.status_progress_type OWNER TO doadmin;

--
-- Name: status_type; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.status_type (
    id integer NOT NULL,
    title character varying(100)
);


ALTER TABLE public.status_type OWNER TO doadmin;

--
-- Name: subscription; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.subscription (
    id bigint NOT NULL,
    title character varying(50),
    subtitle character varying(150),
    img_url character varying(350),
    content character varying(2000),
    type_id integer,
    price double precision DEFAULT 0,
    quantity integer DEFAULT 0,
    status integer,
    one_time_gem integer DEFAULT 0,
    one_time_multiplier double precision DEFAULT 0,
    daily_gem integer DEFAULT 0,
    daily_multiplier double precision,
    one_time_is_firstonly boolean DEFAULT false
);


ALTER TABLE public.subscription OWNER TO doadmin;

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subscription_id_seq OWNER TO doadmin;

--
-- Name: subscription_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.subscription_id_seq OWNED BY public.subscription.id;


--
-- Name: subscription_type; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.subscription_type (
    id integer NOT NULL,
    title character varying(100)
);


ALTER TABLE public.subscription_type OWNER TO doadmin;

--
-- Name: timezones; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.timezones (
    id integer NOT NULL,
    "offset" double precision,
    stext character varying(10),
    ltext character varying(100)
);


ALTER TABLE public.timezones OWNER TO doadmin;

--
-- Name: timezones_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.timezones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.timezones_id_seq OWNER TO doadmin;

--
-- Name: timezones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.timezones_id_seq OWNED BY public.timezones.id;


--
-- Name: tour_set; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.tour_set (
    id bigint NOT NULL,
    tour_id bigint,
    set_id bigint,
    status integer
);


ALTER TABLE public.tour_set OWNER TO doadmin;

--
-- Name: tour_set_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.tour_set_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tour_set_id_seq OWNER TO doadmin;

--
-- Name: tour_set_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.tour_set_id_seq OWNED BY public.tour_set.id;


--
-- Name: tournament; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.tournament (
    id bigint NOT NULL,
    title character varying(150),
    status integer
);


ALTER TABLE public.tournament OWNER TO doadmin;

--
-- Name: tournament_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.tournament_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tournament_id_seq OWNER TO doadmin;

--
-- Name: tournament_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.tournament_id_seq OWNED BY public.tournament.id;


--
-- Name: tournament_set; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.tournament_set (
    id bigint NOT NULL,
    title character varying(150),
    duration_days integer DEFAULT 0,
    duration_hours integer,
    is_group boolean
);


ALTER TABLE public.tournament_set OWNER TO doadmin;

--
-- Name: tournament_set_game_rule; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.tournament_set_game_rule (
    id bigint NOT NULL,
    set_id bigint NOT NULL,
    game_id bigint NOT NULL,
    duration_days integer NOT NULL,
    duration_hours integer NOT NULL,
    duration_minutes integer NOT NULL,
    group_id integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.tournament_set_game_rule OWNER TO doadmin;

--
-- Name: tournament_set_game_rule_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.tournament_set_game_rule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tournament_set_game_rule_id_seq OWNER TO doadmin;

--
-- Name: tournament_set_game_rule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.tournament_set_game_rule_id_seq OWNED BY public.tournament_set_game_rule.id;


--
-- Name: tournament_set_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.tournament_set_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tournament_set_id_seq OWNER TO doadmin;

--
-- Name: tournament_set_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.tournament_set_id_seq OWNED BY public.tournament_set.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public."user" (
    id bigint NOT NULL,
    username character varying(128) NOT NULL,
    passhash character varying(2000) NOT NULL,
    email character varying(355) NOT NULL,
    phone character varying(20) NOT NULL,
    firstname character varying(50) NOT NULL,
    lastname character varying(50) NOT NULL,
    created_on timestamp without time zone NOT NULL,
    last_login timestamp without time zone NOT NULL,
    role_id integer NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    gem_balance integer DEFAULT 0,
    social_link_fb character varying(355) DEFAULT ''::character varying,
    social_link_google character varying(355) DEFAULT ''::character varying,
    avatar_url character varying(355) DEFAULT ''::character varying,
    exp integer DEFAULT 0,
    full_name character varying(355) DEFAULT ''::character varying,
    country_code integer DEFAULT 0,
    address character varying(1000) DEFAULT ''::character varying,
    city character varying(355) DEFAULT ''::character varying,
    state character varying(355) DEFAULT ''::character varying,
    zip_code character varying(20) DEFAULT ''::character varying,
    country character varying(355) DEFAULT ''::character varying,
    is_email_confirmed boolean DEFAULT false,
    is_notify_allowed boolean DEFAULT true,
    is_notify_new_reward boolean DEFAULT true,
    is_notify_new_tournament boolean DEFAULT true,
    is_notify_tour_ending boolean DEFAULT true,
    nick_name character varying(50) DEFAULT ''::character varying,
    rank integer DEFAULT 0,
    msg_token character varying(512) DEFAULT ''::character varying,
    subscription_id bigint DEFAULT 0,
    one_time_multiplier double precision DEFAULT 0,
    daily_gem integer DEFAULT 0,
    daily_multiplier double precision DEFAULT 0,
    one_time_is_firstonly boolean DEFAULT false,
    sub_daily_timestamp timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone,
    exp_timestamp timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone,
    msg_token_timestamp timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone,
    sub_id character varying(50) DEFAULT ''::character varying
);


ALTER TABLE public."user" OWNER TO doadmin;

--
-- Name: user_admin_change_log; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.user_admin_change_log (
    id bigint NOT NULL,
    user_id bigint,
    old_status integer,
    new_status integer,
    old_gem_balance integer,
    new_gem_balance integer,
    created_on timestamp with time zone,
    changed_by bigint
);


ALTER TABLE public.user_admin_change_log OWNER TO doadmin;

--
-- Name: user_admin_change_log_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.user_admin_change_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_admin_change_log_id_seq OWNER TO doadmin;

--
-- Name: user_admin_change_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.user_admin_change_log_id_seq OWNED BY public.user_admin_change_log.id;


--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq OWNER TO doadmin;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: user_invites; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.user_invites (
    id bigint NOT NULL,
    user_id bigint,
    invited_by bigint,
    invited_date timestamp without time zone
);


ALTER TABLE public.user_invites OWNER TO doadmin;

--
-- Name: user_invites_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.user_invites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_invites_id_seq OWNER TO doadmin;

--
-- Name: user_invites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.user_invites_id_seq OWNED BY public.user_invites.id;


--
-- Name: user_status_type; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.user_status_type (
    id integer NOT NULL,
    title character varying(100)
);


ALTER TABLE public.user_status_type OWNER TO doadmin;

--
-- Name: winner; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.winner (
    id bigint NOT NULL,
    prize_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_on timestamp without time zone DEFAULT now(),
    status integer DEFAULT 1,
    ship_tracking character varying(255) DEFAULT ''::character varying,
    claimed_on timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone
);


ALTER TABLE public.winner OWNER TO doadmin;

--
-- Name: winner_change_log; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.winner_change_log (
    id bigint NOT NULL,
    winner_id bigint,
    old_status integer,
    new_status integer,
    old_ship_tracking character varying(255),
    new_ship_tracking character varying(255),
    created_on timestamp with time zone,
    changed_by bigint
);


ALTER TABLE public.winner_change_log OWNER TO doadmin;

--
-- Name: winner_change_log_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.winner_change_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.winner_change_log_id_seq OWNER TO doadmin;

--
-- Name: winner_change_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.winner_change_log_id_seq OWNED BY public.winner_change_log.id;


--
-- Name: winner_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.winner_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.winner_id_seq OWNER TO doadmin;

--
-- Name: winner_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.winner_id_seq OWNED BY public.winner.id;


--
-- Name: winner_status_type; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.winner_status_type (
    id integer NOT NULL,
    title character varying(100)
);


ALTER TABLE public.winner_status_type OWNER TO doadmin;

--
-- Name: checker_log id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.checker_log ALTER COLUMN id SET DEFAULT nextval('public.checker_log_id_seq'::regclass);


--
-- Name: current_game id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.current_game ALTER COLUMN id SET DEFAULT nextval('public.current_game_id_seq'::regclass);


--
-- Name: error_log id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.error_log ALTER COLUMN id SET DEFAULT nextval('public.error_log_id_seq'::regclass);


--
-- Name: game id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.game ALTER COLUMN id SET DEFAULT nextval('public.game_id_seq'::regclass);


--
-- Name: gplayer id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.gplayer ALTER COLUMN id SET DEFAULT nextval('public.gplayer_id_seq'::regclass);


--
-- Name: item id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.item ALTER COLUMN id SET DEFAULT nextval('public.item_id_seq'::regclass);


--
-- Name: prize id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.prize ALTER COLUMN id SET DEFAULT nextval('public.prize_id_seq'::regclass);


--
-- Name: prize_closed id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.prize_closed ALTER COLUMN id SET DEFAULT nextval('public.prize_closed_id_seq'::regclass);


--
-- Name: prize_pool id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.prize_pool ALTER COLUMN id SET DEFAULT nextval('public.prize_pool_id_seq'::regclass);


--
-- Name: prize_tour id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.prize_tour ALTER COLUMN id SET DEFAULT nextval('public.prize_tour_id_seq'::regclass);


--
-- Name: shop_buy id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.shop_buy ALTER COLUMN id SET DEFAULT nextval('public.shop_buy_id_seq'::regclass);


--
-- Name: spinner_extra_log id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.spinner_extra_log ALTER COLUMN id SET DEFAULT nextval('public.spinner_extra_log_id_seq'::regclass);


--
-- Name: spinner_log id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.spinner_log ALTER COLUMN id SET DEFAULT nextval('public.spinner_log_id_seq'::regclass);


--
-- Name: spinner_rule id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.spinner_rule ALTER COLUMN id SET DEFAULT nextval('public.spinner_rule_id_seq'::regclass);


--
-- Name: subscription id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.subscription ALTER COLUMN id SET DEFAULT nextval('public.subscription_id_seq'::regclass);


--
-- Name: timezones id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.timezones ALTER COLUMN id SET DEFAULT nextval('public.timezones_id_seq'::regclass);


--
-- Name: tour_set id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.tour_set ALTER COLUMN id SET DEFAULT nextval('public.tour_set_id_seq'::regclass);


--
-- Name: tournament id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.tournament ALTER COLUMN id SET DEFAULT nextval('public.tournament_id_seq'::regclass);


--
-- Name: tournament_set id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.tournament_set ALTER COLUMN id SET DEFAULT nextval('public.tournament_set_id_seq'::regclass);


--
-- Name: tournament_set_game_rule id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.tournament_set_game_rule ALTER COLUMN id SET DEFAULT nextval('public.tournament_set_game_rule_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Name: user_admin_change_log id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.user_admin_change_log ALTER COLUMN id SET DEFAULT nextval('public.user_admin_change_log_id_seq'::regclass);


--
-- Name: user_invites id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.user_invites ALTER COLUMN id SET DEFAULT nextval('public.user_invites_id_seq'::regclass);


--
-- Name: winner id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.winner ALTER COLUMN id SET DEFAULT nextval('public.winner_id_seq'::regclass);


--
-- Name: winner_change_log id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.winner_change_log ALTER COLUMN id SET DEFAULT nextval('public.winner_change_log_id_seq'::regclass);


--
-- Data for Name: checker_log; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.checker_log (id, current_game_checked_on, current_game_time_spent, leaderboard_checked_on, leaderboard_time_spent, subscriber_checked_on, subscriber_time_spent, unclaim_checked_on, unclaim_time_spent) FROM stdin;
1	2021-06-30 23:44:41.588742	104	2021-06-30 23:44:49.054942	4	2021-06-30 23:44:07.067941	2	2021-06-30 23:44:09.896416	3
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.config (id, invites, games_per_ad, days_to_claim, game_loader_template, freespin_per_day, gems_per_spins_1, ads_per_spins_1, gems_per_spins_2, ads_per_spins_2) FROM stdin;
1	5	3	30	0	10	1	0	3	0
\.


--
-- Data for Name: current_game; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.current_game (id, prize_id, tour_id, set_id, tsg_id, game_id, start_timestamp, end_timestamp, is_closed, tickets_collected) FROM stdin;
1	1	1	1	1	1	2021-06-18 12:00:00	2021-06-18 12:30:00	t	500
2	1	1	1	2	2	2021-06-18 12:30:00	2021-06-18 13:00:00	t	0
3	1	1	1	3	3	2021-06-18 13:00:00	2021-06-18 13:30:00	t	0
4	1	1	1	4	4	2021-06-18 13:30:00	2021-06-18 14:00:00	t	0
6	1	1	1	1	1	2021-06-18 14:00:00	2021-06-18 14:30:00	t	0
7	1	1	1	2	2	2021-06-18 14:30:00	2021-06-18 15:00:00	t	0
8	1	1	1	3	3	2021-06-18 15:00:00	2021-06-18 15:30:00	t	0
9	1	1	1	4	4	2021-06-18 15:30:00	2021-06-18 16:00:00	t	0
10	1	1	1	1	1	2021-06-18 16:00:00	2021-06-18 16:30:00	t	0
11	1	1	1	2	2	2021-06-18 16:30:00	2021-06-18 17:00:00	t	0
12	1	1	1	3	3	2021-06-18 17:00:00	2021-06-18 17:30:00	t	0
13	1	1	1	4	4	2021-06-18 17:30:00	2021-06-18 18:00:00	t	0
14	1	1	1	1	1	2021-06-18 18:00:00	2021-06-18 18:30:00	t	0
15	1	1	1	2	2	2021-06-18 18:30:00	2021-06-18 19:00:00	t	0
16	1	1	1	3	3	2021-06-18 19:00:00	2021-06-18 19:30:00	t	0
17	1	1	1	4	4	2021-06-18 19:30:00	2021-06-18 20:00:00	t	0
18	1	1	1	1	1	2021-06-18 20:00:00	2021-06-18 20:30:00	t	0
19	1	1	1	2	2	2021-06-18 20:30:00	2021-06-18 21:00:00	t	0
20	1	1	1	3	3	2021-06-18 21:00:00	2021-06-18 21:30:00	t	0
21	1	1	1	4	4	2021-06-18 21:30:00	2021-06-18 22:00:00	t	0
22	1	1	1	1	1	2021-06-18 22:00:00	2021-06-18 22:30:00	t	0
23	1	1	1	2	2	2021-06-18 22:30:00	2021-06-18 23:00:00	t	0
24	1	1	1	3	3	2021-06-18 23:00:00	2021-06-18 23:30:00	t	0
5	4	0	0	0	0	2021-06-18 12:00:00	2021-06-19 00:00:00	t	0
25	1	1	1	4	4	2021-06-18 23:30:00	2021-06-19 00:00:00	t	0
26	1	1	1	1	1	2021-06-19 00:00:00	2021-06-19 00:30:00	t	0
27	1	1	1	2	2	2021-06-19 00:30:00	2021-06-19 01:00:00	t	0
28	1	1	1	3	3	2021-06-19 01:00:00	2021-06-19 01:30:00	t	0
29	1	1	1	4	4	2021-06-19 01:30:00	2021-06-19 02:00:00	t	0
31	1	1	1	1	1	2021-06-19 02:00:00	2021-06-19 02:30:00	t	0
32	1	1	1	2	2	2021-06-19 02:30:00	2021-06-19 03:00:00	t	0
33	1	1	1	3	3	2021-06-19 03:00:00	2021-06-19 03:30:00	t	0
34	1	1	1	4	4	2021-06-19 03:30:00	2021-06-19 04:00:00	t	0
35	1	1	1	1	1	2021-06-19 04:00:00	2021-06-19 04:30:00	t	0
36	1	1	1	2	2	2021-06-19 04:30:00	2021-06-19 05:00:00	t	0
37	1	1	1	3	3	2021-06-19 05:00:00	2021-06-19 05:30:00	t	0
38	1	1	1	4	4	2021-06-19 05:30:00	2021-06-19 06:00:00	t	0
39	1	1	1	1	1	2021-06-19 06:00:00	2021-06-19 06:30:00	t	0
40	1	1	1	2	2	2021-06-19 06:30:00	2021-06-19 07:00:00	t	0
41	1	1	1	3	3	2021-06-19 07:00:00	2021-06-19 07:30:00	t	0
42	1	1	1	4	4	2021-06-19 07:30:00	2021-06-19 08:00:00	t	0
43	1	1	1	1	1	2021-06-19 08:00:00	2021-06-19 08:30:00	t	0
44	1	1	1	2	2	2021-06-19 08:30:00	2021-06-19 09:00:00	t	0
45	1	1	1	3	3	2021-06-19 09:00:00	2021-06-19 09:30:00	t	0
46	1	1	1	4	4	2021-06-19 09:30:00	2021-06-19 10:00:00	t	0
47	1	1	1	1	1	2021-06-19 10:00:00	2021-06-19 10:30:00	t	0
2315	29	9	6	32	2	2021-06-29 16:10:00	2021-06-29 16:20:00	t	0
48	1	1	1	2	2	2021-06-19 10:30:00	2021-06-19 11:00:00	t	0
49	1	1	1	3	3	2021-06-19 11:00:00	2021-06-19 11:30:00	t	0
30	4	0	0	0	0	2021-06-19 00:00:00	2021-06-19 12:00:00	t	0
50	1	1	1	4	4	2021-06-19 11:30:00	2021-06-19 12:00:00	t	0
52	1	1	1	1	1	2021-06-19 12:00:00	2021-06-19 12:30:00	t	0
53	1	1	1	2	2	2021-06-19 12:30:00	2021-06-19 13:00:00	t	0
54	1	1	1	3	3	2021-06-19 13:00:00	2021-06-19 13:30:00	t	0
55	1	1	1	4	4	2021-06-19 13:30:00	2021-06-19 14:00:00	t	0
56	1	1	1	1	1	2021-06-19 14:00:00	2021-06-19 14:30:00	t	0
57	1	1	1	2	2	2021-06-19 14:30:00	2021-06-19 15:00:00	t	0
58	1	1	1	3	3	2021-06-19 15:00:00	2021-06-19 15:30:00	t	0
59	1	1	1	4	4	2021-06-19 15:30:00	2021-06-19 16:00:00	t	0
60	1	1	1	1	1	2021-06-19 16:00:00	2021-06-19 16:30:00	t	0
61	1	1	1	2	2	2021-06-19 16:30:00	2021-06-19 17:00:00	t	0
62	1	1	1	3	3	2021-06-19 17:00:00	2021-06-19 17:30:00	t	0
63	1	1	1	4	4	2021-06-19 17:30:00	2021-06-19 18:00:00	t	0
64	1	1	1	1	1	2021-06-19 18:00:00	2021-06-19 18:30:00	t	0
65	1	1	1	2	2	2021-06-19 18:30:00	2021-06-19 19:00:00	t	0
66	1	1	1	3	3	2021-06-19 19:00:00	2021-06-19 19:30:00	t	0
67	1	1	1	4	4	2021-06-19 19:30:00	2021-06-19 20:00:00	t	0
68	1	1	1	1	1	2021-06-19 20:00:00	2021-06-19 20:30:00	t	0
69	1	1	1	2	2	2021-06-19 20:30:00	2021-06-19 21:00:00	t	0
71	1	1	1	4	4	2021-06-19 21:30:00	2021-06-19 22:00:00	t	0
72	1	1	1	1	1	2021-06-19 22:00:00	2021-06-19 22:30:00	t	0
73	1	1	1	2	2	2021-06-19 22:30:00	2021-06-19 23:00:00	t	0
70	1	1	1	3	3	2021-06-19 21:00:00	2021-06-19 21:30:00	t	0
74	1	1	1	3	3	2021-06-19 23:00:00	2021-06-19 23:30:00	t	0
51	4	0	0	0	0	2021-06-19 12:00:00	2021-06-20 00:00:00	t	0
75	1	1	1	4	4	2021-06-19 23:30:00	2021-06-20 00:00:00	t	0
77	1	1	1	1	1	2021-06-20 00:00:00	2021-06-20 00:30:00	t	0
78	1	1	1	2	2	2021-06-20 00:30:00	2021-06-20 01:00:00	t	0
79	1	1	1	3	3	2021-06-20 01:00:00	2021-06-20 01:30:00	t	0
80	1	1	1	4	4	2021-06-20 01:30:00	2021-06-20 02:00:00	t	0
81	1	1	1	1	1	2021-06-20 02:00:00	2021-06-20 02:30:00	t	0
82	1	1	1	2	2	2021-06-20 02:30:00	2021-06-20 03:00:00	t	0
83	1	1	1	3	3	2021-06-20 03:00:00	2021-06-20 03:30:00	t	0
84	1	1	1	4	4	2021-06-20 03:30:00	2021-06-20 04:00:00	t	0
85	1	1	1	1	1	2021-06-20 04:00:00	2021-06-20 04:30:00	t	0
86	1	1	1	2	2	2021-06-20 04:30:00	2021-06-20 05:00:00	t	0
87	1	1	1	3	3	2021-06-20 05:00:00	2021-06-20 05:30:00	t	750
88	1	1	1	4	4	2021-06-20 05:30:00	2021-06-20 06:00:00	t	0
90	1	1	1	1	1	2021-06-20 06:00:00	2021-06-20 06:30:00	t	0
91	1	1	1	2	2	2021-06-20 06:30:00	2021-06-20 07:00:00	t	0
92	1	1	1	3	3	2021-06-20 07:00:00	2021-06-20 07:30:00	t	0
93	1	1	1	4	4	2021-06-20 07:30:00	2021-06-20 08:00:00	t	0
94	1	1	1	1	1	2021-06-20 08:00:00	2021-06-20 08:30:00	t	0
95	1	1	1	2	2	2021-06-20 08:30:00	2021-06-20 09:00:00	t	0
96	1	1	1	3	3	2021-06-20 09:00:00	2021-06-20 09:30:00	t	0
97	1	1	1	4	4	2021-06-20 09:30:00	2021-06-20 10:00:00	t	0
98	1	1	1	1	1	2021-06-20 10:00:00	2021-06-20 10:30:00	t	0
99	1	1	1	2	2	2021-06-20 10:30:00	2021-06-20 11:00:00	t	0
100	1	1	1	3	3	2021-06-20 11:00:00	2021-06-20 11:30:00	t	0
76	4	0	0	0	0	2021-06-20 00:00:00	2021-06-20 12:00:00	t	0
101	1	1	1	4	4	2021-06-20 11:30:00	2021-06-20 12:00:00	t	0
102	1	1	1	1	1	2021-06-20 12:00:00	2021-06-20 12:30:00	t	0
103	1	1	1	2	2	2021-06-20 12:30:00	2021-06-20 13:00:00	t	0
104	1	1	1	3	3	2021-06-20 13:00:00	2021-06-20 13:30:00	t	0
105	1	1	1	4	4	2021-06-20 13:30:00	2021-06-20 14:00:00	t	0
106	1	1	1	1	1	2021-06-20 14:00:00	2021-06-20 14:30:00	t	0
107	1	1	1	2	2	2021-06-20 14:30:00	2021-06-20 15:00:00	t	0
108	1	1	1	3	3	2021-06-20 15:00:00	2021-06-20 15:30:00	t	0
109	1	1	1	4	4	2021-06-20 15:30:00	2021-06-20 16:00:00	t	0
110	1	1	1	1	1	2021-06-20 16:00:00	2021-06-20 16:30:00	t	0
111	1	1	1	2	2	2021-06-20 16:30:00	2021-06-20 17:00:00	t	0
112	1	1	1	3	3	2021-06-20 17:00:00	2021-06-20 17:30:00	t	0
113	1	1	1	4	4	2021-06-20 17:30:00	2021-06-20 18:00:00	t	0
114	1	1	1	1	1	2021-06-20 18:00:00	2021-06-20 18:30:00	t	0
115	1	1	1	2	2	2021-06-20 18:30:00	2021-06-20 19:00:00	t	0
116	1	1	1	3	3	2021-06-20 19:00:00	2021-06-20 19:30:00	t	0
117	1	1	1	4	4	2021-06-20 19:30:00	2021-06-20 20:00:00	t	0
118	1	1	1	1	1	2021-06-20 20:00:00	2021-06-20 20:30:00	t	0
119	1	1	1	2	2	2021-06-20 20:30:00	2021-06-20 21:00:00	t	0
120	1	1	1	3	3	2021-06-20 21:00:00	2021-06-20 21:30:00	t	0
121	1	1	1	4	4	2021-06-20 21:30:00	2021-06-20 22:00:00	t	0
122	1	1	1	1	1	2021-06-20 22:00:00	2021-06-20 22:30:00	t	0
124	1	1	1	3	3	2021-06-20 23:00:00	2021-06-20 23:30:00	t	0
89	4	0	0	0	0	2021-06-20 12:00:00	2021-06-21 00:00:00	t	0
125	1	1	1	4	4	2021-06-20 23:30:00	2021-06-21 00:00:00	t	0
127	1	1	1	1	1	2021-06-21 00:00:00	2021-06-21 00:30:00	t	0
128	1	1	1	2	2	2021-06-21 00:30:00	2021-06-21 01:00:00	t	0
129	1	1	1	3	3	2021-06-21 01:00:00	2021-06-21 01:30:00	t	0
130	1	1	1	4	4	2021-06-21 01:30:00	2021-06-21 02:00:00	t	0
131	1	1	1	1	1	2021-06-21 02:00:00	2021-06-21 02:30:00	t	0
132	1	1	1	2	2	2021-06-21 02:30:00	2021-06-21 03:00:00	t	0
133	1	1	1	3	3	2021-06-21 03:00:00	2021-06-21 03:30:00	t	0
134	1	1	1	4	4	2021-06-21 03:30:00	2021-06-21 04:00:00	t	0
135	1	1	1	1	1	2021-06-21 04:00:00	2021-06-21 04:30:00	t	0
136	1	1	1	2	2	2021-06-21 04:30:00	2021-06-21 05:00:00	t	0
137	1	1	1	3	3	2021-06-21 05:00:00	2021-06-21 05:30:00	t	0
138	1	1	1	4	4	2021-06-21 05:30:00	2021-06-21 06:00:00	t	0
139	1	1	1	1	1	2021-06-21 06:00:00	2021-06-21 06:30:00	t	0
140	1	1	1	2	2	2021-06-21 06:30:00	2021-06-21 07:00:00	t	0
141	1	1	1	3	3	2021-06-21 07:00:00	2021-06-21 07:30:00	t	2124
142	1	1	1	4	4	2021-06-21 07:30:00	2021-06-21 08:00:00	t	0
143	1	1	1	1	1	2021-06-21 08:00:00	2021-06-21 08:30:00	t	0
144	1	1	1	2	2	2021-06-21 08:30:00	2021-06-21 09:00:00	t	0
126	4	0	0	0	0	2021-06-21 00:00:00	2021-06-21 12:00:00	t	0
123	1	1	1	2	2	2021-06-20 22:30:00	2021-06-20 23:00:00	t	0
2330	34	13	7	36	7	2021-06-29 16:10:00	2021-06-29 16:20:00	t	0
157	3	4	3	16	3	2021-06-18 12:00:00	2021-06-18 13:00:00	t	0
158	3	4	3	17	4	2021-06-18 13:00:00	2021-06-18 14:00:00	t	0
159	3	4	3	18	6	2021-06-18 13:00:00	2021-06-18 14:00:00	t	0
160	3	4	3	15	1	2021-06-18 14:00:00	2021-06-18 15:00:00	t	0
161	3	4	3	16	3	2021-06-18 14:00:00	2021-06-18 15:00:00	t	0
162	3	4	3	17	4	2021-06-18 15:00:00	2021-06-18 16:00:00	t	0
163	3	4	3	18	6	2021-06-18 15:00:00	2021-06-18 16:00:00	t	0
164	3	4	3	15	1	2021-06-18 16:00:00	2021-06-18 17:00:00	t	0
165	3	4	3	16	3	2021-06-18 16:00:00	2021-06-18 17:00:00	t	0
166	3	4	3	17	4	2021-06-18 17:00:00	2021-06-18 18:00:00	t	0
167	3	4	3	18	6	2021-06-18 17:00:00	2021-06-18 18:00:00	t	0
168	3	4	3	15	1	2021-06-18 18:00:00	2021-06-18 19:00:00	t	0
169	3	4	3	16	3	2021-06-18 18:00:00	2021-06-18 19:00:00	t	0
170	3	4	3	17	4	2021-06-18 19:00:00	2021-06-18 20:00:00	t	0
171	3	4	3	18	6	2021-06-18 19:00:00	2021-06-18 20:00:00	t	0
172	3	4	3	15	1	2021-06-18 20:00:00	2021-06-18 21:00:00	t	0
173	3	4	3	16	3	2021-06-18 20:00:00	2021-06-18 21:00:00	t	0
175	3	4	3	18	6	2021-06-18 21:00:00	2021-06-18 22:00:00	t	0
176	3	4	3	15	1	2021-06-18 22:00:00	2021-06-18 23:00:00	t	0
177	3	4	3	16	3	2021-06-18 22:00:00	2021-06-18 23:00:00	t	0
178	3	4	3	17	4	2021-06-18 23:00:00	2021-06-19 00:00:00	t	0
179	3	4	3	18	6	2021-06-18 23:00:00	2021-06-19 00:00:00	t	0
180	3	4	3	15	1	2021-06-19 00:00:00	2021-06-19 01:00:00	t	0
181	3	4	3	16	3	2021-06-19 00:00:00	2021-06-19 01:00:00	t	0
182	3	4	3	17	4	2021-06-19 01:00:00	2021-06-19 02:00:00	t	0
183	3	4	3	18	6	2021-06-19 01:00:00	2021-06-19 02:00:00	t	0
184	3	4	3	15	1	2021-06-19 02:00:00	2021-06-19 03:00:00	t	0
185	3	4	3	16	3	2021-06-19 02:00:00	2021-06-19 03:00:00	t	0
186	3	4	3	17	4	2021-06-19 03:00:00	2021-06-19 04:00:00	t	0
187	3	4	3	18	6	2021-06-19 03:00:00	2021-06-19 04:00:00	t	0
188	3	4	3	15	1	2021-06-19 04:00:00	2021-06-19 05:00:00	t	0
189	3	4	3	16	3	2021-06-19 04:00:00	2021-06-19 05:00:00	t	0
190	3	4	3	17	4	2021-06-19 05:00:00	2021-06-19 06:00:00	t	0
191	3	4	3	18	6	2021-06-19 05:00:00	2021-06-19 06:00:00	t	0
192	3	4	3	15	1	2021-06-19 06:00:00	2021-06-19 07:00:00	t	0
193	3	4	3	16	3	2021-06-19 06:00:00	2021-06-19 07:00:00	t	0
194	3	4	3	17	4	2021-06-19 07:00:00	2021-06-19 08:00:00	t	0
195	3	4	3	18	6	2021-06-19 07:00:00	2021-06-19 08:00:00	t	0
196	3	4	3	15	1	2021-06-19 08:00:00	2021-06-19 09:00:00	t	0
197	3	4	3	16	3	2021-06-19 08:00:00	2021-06-19 09:00:00	t	0
198	3	4	3	17	4	2021-06-19 09:00:00	2021-06-19 10:00:00	t	0
199	3	4	3	18	6	2021-06-19 09:00:00	2021-06-19 10:00:00	t	0
200	3	4	3	15	1	2021-06-19 10:00:00	2021-06-19 11:00:00	t	0
202	3	4	3	17	4	2021-06-19 11:00:00	2021-06-19 12:00:00	t	0
203	3	4	3	18	6	2021-06-19 11:00:00	2021-06-19 12:00:00	t	0
204	3	4	3	15	1	2021-06-19 12:00:00	2021-06-19 13:00:00	t	0
205	3	4	3	16	3	2021-06-19 12:00:00	2021-06-19 13:00:00	t	0
206	3	4	3	17	4	2021-06-19 13:00:00	2021-06-19 14:00:00	t	0
207	3	4	3	18	6	2021-06-19 13:00:00	2021-06-19 14:00:00	t	0
208	3	4	3	15	1	2021-06-19 14:00:00	2021-06-19 15:00:00	t	0
209	3	4	3	16	3	2021-06-19 14:00:00	2021-06-19 15:00:00	t	0
210	3	4	3	17	4	2021-06-19 15:00:00	2021-06-19 16:00:00	t	0
211	3	4	3	18	6	2021-06-19 15:00:00	2021-06-19 16:00:00	t	0
212	3	4	3	15	1	2021-06-19 16:00:00	2021-06-19 17:00:00	t	0
213	3	4	3	16	3	2021-06-19 16:00:00	2021-06-19 17:00:00	t	0
214	3	4	3	17	4	2021-06-19 17:00:00	2021-06-19 18:00:00	t	0
215	3	4	3	18	6	2021-06-19 17:00:00	2021-06-19 18:00:00	t	0
216	3	4	3	15	1	2021-06-19 18:00:00	2021-06-19 19:00:00	t	0
217	3	4	3	16	3	2021-06-19 18:00:00	2021-06-19 19:00:00	t	0
218	3	4	3	17	4	2021-06-19 19:00:00	2021-06-19 20:00:00	t	0
145	1	1	1	3	3	2021-06-21 09:00:00	2021-06-21 09:30:00	t	0
146	1	1	1	4	4	2021-06-21 09:30:00	2021-06-21 10:00:00	t	0
147	1	1	1	1	1	2021-06-21 10:00:00	2021-06-21 10:30:00	t	0
148	1	1	1	2	2	2021-06-21 10:30:00	2021-06-21 11:00:00	t	0
149	1	1	1	3	3	2021-06-21 11:00:00	2021-06-21 11:30:00	t	0
150	1	1	1	4	4	2021-06-21 11:30:00	2021-06-21 12:00:00	t	0
152	1	1	1	1	1	2021-06-21 12:00:00	2021-06-21 12:30:00	t	0
153	1	1	1	2	2	2021-06-21 12:30:00	2021-06-21 13:00:00	t	0
154	1	1	1	3	3	2021-06-21 13:00:00	2021-06-21 13:30:00	t	0
151	4	0	0	0	0	2021-06-21 12:00:00	2021-06-22 00:00:00	t	0
220	3	4	3	15	1	2021-06-19 20:00:00	2021-06-19 21:00:00	t	0
221	3	4	3	16	3	2021-06-19 20:00:00	2021-06-19 21:00:00	t	0
222	3	4	3	17	4	2021-06-19 21:00:00	2021-06-19 22:00:00	t	0
223	3	4	3	18	6	2021-06-19 21:00:00	2021-06-19 22:00:00	t	0
224	3	4	3	15	1	2021-06-19 22:00:00	2021-06-19 23:00:00	t	0
225	3	4	3	16	3	2021-06-19 22:00:00	2021-06-19 23:00:00	t	0
226	3	4	3	17	4	2021-06-19 23:00:00	2021-06-20 00:00:00	t	0
227	3	4	3	18	6	2021-06-19 23:00:00	2021-06-20 00:00:00	t	0
228	3	4	3	15	1	2021-06-20 00:00:00	2021-06-20 01:00:00	t	0
229	3	4	3	16	3	2021-06-20 00:00:00	2021-06-20 01:00:00	t	0
230	3	4	3	17	4	2021-06-20 01:00:00	2021-06-20 02:00:00	t	0
231	3	4	3	18	6	2021-06-20 01:00:00	2021-06-20 02:00:00	t	0
232	3	4	3	15	1	2021-06-20 02:00:00	2021-06-20 03:00:00	t	0
233	3	4	3	16	3	2021-06-20 02:00:00	2021-06-20 03:00:00	t	0
234	3	4	3	17	4	2021-06-20 03:00:00	2021-06-20 04:00:00	t	0
235	3	4	3	18	6	2021-06-20 03:00:00	2021-06-20 04:00:00	t	0
236	3	4	3	15	1	2021-06-20 04:00:00	2021-06-20 05:00:00	t	0
238	3	4	3	17	4	2021-06-20 05:00:00	2021-06-20 06:00:00	t	0
239	3	4	3	18	6	2021-06-20 05:00:00	2021-06-20 06:00:00	t	0
240	3	4	3	15	1	2021-06-20 06:00:00	2021-06-20 07:00:00	t	0
241	3	4	3	16	3	2021-06-20 06:00:00	2021-06-20 07:00:00	t	0
242	3	4	3	17	4	2021-06-20 07:00:00	2021-06-20 08:00:00	t	0
243	3	4	3	18	6	2021-06-20 07:00:00	2021-06-20 08:00:00	t	0
244	3	4	3	15	1	2021-06-20 08:00:00	2021-06-20 09:00:00	t	0
245	3	4	3	16	3	2021-06-20 08:00:00	2021-06-20 09:00:00	t	0
246	3	4	3	17	4	2021-06-20 09:00:00	2021-06-20 10:00:00	t	0
247	3	4	3	18	6	2021-06-20 09:00:00	2021-06-20 10:00:00	t	0
248	3	4	3	15	1	2021-06-20 10:00:00	2021-06-20 11:00:00	t	0
249	3	4	3	16	3	2021-06-20 10:00:00	2021-06-20 11:00:00	t	0
250	3	4	3	17	4	2021-06-20 11:00:00	2021-06-20 12:00:00	t	0
251	3	4	3	18	6	2021-06-20 11:00:00	2021-06-20 12:00:00	t	0
252	3	4	3	15	1	2021-06-20 12:00:00	2021-06-20 13:00:00	t	0
253	3	4	3	16	3	2021-06-20 12:00:00	2021-06-20 13:00:00	t	0
254	3	4	3	17	4	2021-06-20 13:00:00	2021-06-20 14:00:00	t	0
255	3	4	3	18	6	2021-06-20 13:00:00	2021-06-20 14:00:00	t	0
256	3	4	3	15	1	2021-06-20 14:00:00	2021-06-20 15:00:00	t	0
257	3	4	3	16	3	2021-06-20 14:00:00	2021-06-20 15:00:00	t	0
258	3	4	3	17	4	2021-06-20 15:00:00	2021-06-20 16:00:00	t	0
259	3	4	3	18	6	2021-06-20 15:00:00	2021-06-20 16:00:00	t	0
260	3	4	3	15	1	2021-06-20 16:00:00	2021-06-20 17:00:00	t	0
261	3	4	3	16	3	2021-06-20 16:00:00	2021-06-20 17:00:00	t	0
262	3	4	3	17	4	2021-06-20 17:00:00	2021-06-20 18:00:00	t	0
263	3	4	3	18	6	2021-06-20 17:00:00	2021-06-20 18:00:00	t	0
265	3	4	3	16	3	2021-06-20 18:00:00	2021-06-20 19:00:00	t	0
266	3	4	3	17	4	2021-06-20 19:00:00	2021-06-20 20:00:00	t	0
267	3	4	3	18	6	2021-06-20 19:00:00	2021-06-20 20:00:00	t	0
268	3	4	3	15	1	2021-06-20 20:00:00	2021-06-20 21:00:00	t	0
269	3	4	3	16	3	2021-06-20 20:00:00	2021-06-20 21:00:00	t	0
270	3	4	3	17	4	2021-06-20 21:00:00	2021-06-20 22:00:00	t	0
271	3	4	3	18	6	2021-06-20 21:00:00	2021-06-20 22:00:00	t	0
272	3	4	3	15	1	2021-06-20 22:00:00	2021-06-20 23:00:00	t	0
273	3	4	3	16	3	2021-06-20 22:00:00	2021-06-20 23:00:00	t	0
274	3	4	3	17	4	2021-06-20 23:00:00	2021-06-21 00:00:00	t	0
275	3	4	3	18	6	2021-06-20 23:00:00	2021-06-21 00:00:00	t	0
276	3	4	3	15	1	2021-06-21 00:00:00	2021-06-21 01:00:00	t	0
277	3	4	3	16	3	2021-06-21 00:00:00	2021-06-21 01:00:00	t	0
278	3	4	3	17	4	2021-06-21 01:00:00	2021-06-21 02:00:00	t	0
279	3	4	3	18	6	2021-06-21 01:00:00	2021-06-21 02:00:00	t	0
280	3	4	3	15	1	2021-06-21 02:00:00	2021-06-21 03:00:00	t	0
281	3	4	3	16	3	2021-06-21 02:00:00	2021-06-21 03:00:00	t	0
282	3	4	3	17	4	2021-06-21 03:00:00	2021-06-21 04:00:00	t	0
283	3	4	3	18	6	2021-06-21 03:00:00	2021-06-21 04:00:00	t	0
284	3	4	3	15	1	2021-06-21 04:00:00	2021-06-21 05:00:00	t	500
285	3	4	3	16	3	2021-06-21 04:00:00	2021-06-21 05:00:00	t	0
286	3	4	3	17	4	2021-06-21 05:00:00	2021-06-21 06:00:00	t	0
287	3	4	3	18	6	2021-06-21 05:00:00	2021-06-21 06:00:00	t	0
288	3	4	3	15	1	2021-06-21 06:00:00	2021-06-21 07:00:00	t	0
289	3	4	3	16	3	2021-06-21 06:00:00	2021-06-21 07:00:00	t	0
290	3	4	3	17	4	2021-06-21 07:00:00	2021-06-21 08:00:00	t	0
292	3	4	3	15	1	2021-06-21 08:00:00	2021-06-21 09:00:00	t	0
293	3	4	3	16	3	2021-06-21 08:00:00	2021-06-21 09:00:00	t	0
156	3	4	3	15	1	2021-06-18 12:00:00	2021-06-18 13:00:00	t	0
174	3	4	3	17	4	2021-06-18 21:00:00	2021-06-18 22:00:00	t	0
201	3	4	3	16	3	2021-06-19 10:00:00	2021-06-19 11:00:00	t	0
219	3	4	3	18	6	2021-06-19 19:00:00	2021-06-19 20:00:00	t	0
237	3	4	3	16	3	2021-06-20 04:00:00	2021-06-20 05:00:00	t	0
264	3	4	3	15	1	2021-06-20 18:00:00	2021-06-20 19:00:00	t	0
291	3	4	3	18	6	2021-06-21 07:00:00	2021-06-21 08:00:00	t	950
327	2	1	1	2	2	2021-06-18 12:30:00	2021-06-18 13:00:00	t	0
328	2	1	1	3	3	2021-06-18 13:00:00	2021-06-18 13:30:00	t	0
329	2	1	1	4	4	2021-06-18 13:30:00	2021-06-18 14:00:00	t	0
330	2	1	1	1	1	2021-06-18 14:00:00	2021-06-18 14:30:00	t	0
331	2	1	1	2	2	2021-06-18 14:30:00	2021-06-18 15:00:00	t	0
332	2	1	1	3	3	2021-06-18 15:00:00	2021-06-18 15:30:00	t	0
333	2	1	1	4	4	2021-06-18 15:30:00	2021-06-18 16:00:00	t	0
334	2	1	1	1	1	2021-06-18 16:00:00	2021-06-18 16:30:00	t	0
335	2	1	1	2	2	2021-06-18 16:30:00	2021-06-18 17:00:00	t	0
336	2	1	1	3	3	2021-06-18 17:00:00	2021-06-18 17:30:00	t	0
337	2	1	1	4	4	2021-06-18 17:30:00	2021-06-18 18:00:00	t	0
338	2	1	1	1	1	2021-06-18 18:00:00	2021-06-18 18:30:00	t	0
339	2	1	1	2	2	2021-06-18 18:30:00	2021-06-18 19:00:00	t	0
340	2	1	1	3	3	2021-06-18 19:00:00	2021-06-18 19:30:00	t	0
341	2	1	1	4	4	2021-06-18 19:30:00	2021-06-18 20:00:00	t	0
342	2	1	1	1	1	2021-06-18 20:00:00	2021-06-18 20:30:00	t	0
343	2	1	1	2	2	2021-06-18 20:30:00	2021-06-18 21:00:00	t	0
345	2	1	1	4	4	2021-06-18 21:30:00	2021-06-18 22:00:00	t	0
346	2	1	1	1	1	2021-06-18 22:00:00	2021-06-18 22:30:00	t	0
347	2	1	1	2	2	2021-06-18 22:30:00	2021-06-18 23:00:00	t	0
348	2	1	1	3	3	2021-06-18 23:00:00	2021-06-18 23:30:00	t	0
349	2	1	1	4	4	2021-06-18 23:30:00	2021-06-19 00:00:00	t	0
350	2	1	1	1	1	2021-06-19 00:00:00	2021-06-19 00:30:00	t	0
351	2	1	1	2	2	2021-06-19 00:30:00	2021-06-19 01:00:00	t	0
352	2	1	1	3	3	2021-06-19 01:00:00	2021-06-19 01:30:00	t	0
353	2	1	1	4	4	2021-06-19 01:30:00	2021-06-19 02:00:00	t	0
354	2	1	1	1	1	2021-06-19 02:00:00	2021-06-19 02:30:00	t	0
355	2	1	1	2	2	2021-06-19 02:30:00	2021-06-19 03:00:00	t	0
356	2	1	1	3	3	2021-06-19 03:00:00	2021-06-19 03:30:00	t	0
357	2	1	1	4	4	2021-06-19 03:30:00	2021-06-19 04:00:00	t	0
358	2	1	1	1	1	2021-06-19 04:00:00	2021-06-19 04:30:00	t	0
359	2	1	1	2	2	2021-06-19 04:30:00	2021-06-19 05:00:00	t	0
360	2	1	1	3	3	2021-06-19 05:00:00	2021-06-19 05:30:00	t	0
361	2	1	1	4	4	2021-06-19 05:30:00	2021-06-19 06:00:00	t	0
294	3	4	3	17	4	2021-06-21 09:00:00	2021-06-21 10:00:00	t	2040
295	3	4	3	18	6	2021-06-21 09:00:00	2021-06-21 10:00:00	t	1367
296	3	4	3	15	1	2021-06-21 10:00:00	2021-06-21 11:00:00	t	0
297	3	4	3	16	3	2021-06-21 10:00:00	2021-06-21 11:00:00	t	0
298	3	4	3	17	4	2021-06-21 11:00:00	2021-06-21 12:00:00	t	0
299	3	4	3	18	6	2021-06-21 11:00:00	2021-06-21 12:00:00	t	0
300	3	4	3	15	1	2021-06-21 12:00:00	2021-06-21 13:00:00	t	0
301	3	4	3	16	3	2021-06-21 12:00:00	2021-06-21 13:00:00	t	0
302	3	4	3	17	4	2021-06-21 13:00:00	2021-06-21 14:00:00	t	0
306	1	1	1	1	1	2021-06-21 14:00:00	2021-06-21 14:30:00	t	0
304	3	4	3	17	4	2021-06-21 14:00:00	2021-06-21 15:00:00	t	0
305	3	4	3	18	6	2021-06-21 14:00:00	2021-06-21 15:00:00	t	0
307	1	1	1	2	2	2021-06-21 14:30:00	2021-06-21 15:00:00	t	0
308	1	1	1	3	3	2021-06-21 15:00:00	2021-06-21 15:30:00	t	0
309	1	1	1	4	4	2021-06-21 15:30:00	2021-06-21 16:00:00	t	0
310	3	4	3	17	4	2021-06-21 15:00:00	2021-06-21 16:00:00	t	0
311	3	4	3	18	6	2021-06-21 15:00:00	2021-06-21 16:00:00	t	0
314	1	1	1	1	1	2021-06-21 16:00:00	2021-06-21 16:30:00	t	0
312	3	4	3	17	4	2021-06-21 16:00:00	2021-06-21 17:00:00	t	0
313	3	4	3	18	6	2021-06-21 16:00:00	2021-06-21 17:00:00	t	0
315	1	1	1	2	2	2021-06-21 16:30:00	2021-06-21 17:00:00	t	0
316	1	1	1	3	3	2021-06-21 17:00:00	2021-06-21 17:30:00	t	0
317	1	1	1	4	4	2021-06-21 17:30:00	2021-06-21 18:00:00	t	0
318	3	4	3	17	4	2021-06-21 17:00:00	2021-06-21 18:00:00	t	0
319	3	4	3	18	6	2021-06-21 17:00:00	2021-06-21 18:00:00	t	0
322	1	1	1	1	1	2021-06-21 18:00:00	2021-06-21 18:30:00	t	0
320	3	4	3	17	4	2021-06-21 18:00:00	2021-06-21 19:00:00	t	0
321	3	4	3	18	6	2021-06-21 18:00:00	2021-06-21 19:00:00	t	0
323	1	1	1	2	2	2021-06-21 18:30:00	2021-06-21 19:00:00	t	0
324	1	1	1	3	3	2021-06-21 19:00:00	2021-06-21 19:30:00	t	0
325	1	1	1	4	4	2021-06-21 19:30:00	2021-06-21 20:00:00	t	0
363	2	1	1	2	2	2021-06-19 06:30:00	2021-06-19 07:00:00	t	0
364	2	1	1	3	3	2021-06-19 07:00:00	2021-06-19 07:30:00	t	0
365	2	1	1	4	4	2021-06-19 07:30:00	2021-06-19 08:00:00	t	0
366	2	1	1	1	1	2021-06-19 08:00:00	2021-06-19 08:30:00	t	0
367	2	1	1	2	2	2021-06-19 08:30:00	2021-06-19 09:00:00	t	0
368	2	1	1	3	3	2021-06-19 09:00:00	2021-06-19 09:30:00	t	0
369	2	1	1	4	4	2021-06-19 09:30:00	2021-06-19 10:00:00	t	0
370	2	1	1	1	1	2021-06-19 10:00:00	2021-06-19 10:30:00	t	0
371	2	1	1	2	2	2021-06-19 10:30:00	2021-06-19 11:00:00	t	0
372	2	1	1	3	3	2021-06-19 11:00:00	2021-06-19 11:30:00	t	0
373	2	1	1	4	4	2021-06-19 11:30:00	2021-06-19 12:00:00	t	0
374	2	1	1	1	1	2021-06-19 12:00:00	2021-06-19 12:30:00	t	0
375	2	1	1	2	2	2021-06-19 12:30:00	2021-06-19 13:00:00	t	0
376	2	1	1	3	3	2021-06-19 13:00:00	2021-06-19 13:30:00	t	0
377	2	1	1	4	4	2021-06-19 13:30:00	2021-06-19 14:00:00	t	0
378	2	1	1	1	1	2021-06-19 14:00:00	2021-06-19 14:30:00	t	0
379	2	1	1	2	2	2021-06-19 14:30:00	2021-06-19 15:00:00	t	0
381	2	1	1	4	4	2021-06-19 15:30:00	2021-06-19 16:00:00	t	0
382	2	1	1	1	1	2021-06-19 16:00:00	2021-06-19 16:30:00	t	0
383	2	1	1	2	2	2021-06-19 16:30:00	2021-06-19 17:00:00	t	0
384	2	1	1	3	3	2021-06-19 17:00:00	2021-06-19 17:30:00	t	0
385	2	1	1	4	4	2021-06-19 17:30:00	2021-06-19 18:00:00	t	0
386	2	1	1	1	1	2021-06-19 18:00:00	2021-06-19 18:30:00	t	0
387	2	1	1	2	2	2021-06-19 18:30:00	2021-06-19 19:00:00	t	0
388	2	1	1	3	3	2021-06-19 19:00:00	2021-06-19 19:30:00	t	0
389	2	1	1	4	4	2021-06-19 19:30:00	2021-06-19 20:00:00	t	0
390	2	1	1	1	1	2021-06-19 20:00:00	2021-06-19 20:30:00	t	0
391	2	1	1	2	2	2021-06-19 20:30:00	2021-06-19 21:00:00	t	0
392	2	1	1	3	3	2021-06-19 21:00:00	2021-06-19 21:30:00	t	0
393	2	1	1	4	4	2021-06-19 21:30:00	2021-06-19 22:00:00	t	0
394	2	1	1	1	1	2021-06-19 22:00:00	2021-06-19 22:30:00	t	0
395	2	1	1	2	2	2021-06-19 22:30:00	2021-06-19 23:00:00	t	0
396	2	1	1	3	3	2021-06-19 23:00:00	2021-06-19 23:30:00	t	0
397	2	1	1	4	4	2021-06-19 23:30:00	2021-06-20 00:00:00	t	0
398	2	1	1	1	1	2021-06-20 00:00:00	2021-06-20 00:30:00	t	0
399	2	1	1	2	2	2021-06-20 00:30:00	2021-06-20 01:00:00	t	0
400	2	1	1	3	3	2021-06-20 01:00:00	2021-06-20 01:30:00	t	0
401	2	1	1	4	4	2021-06-20 01:30:00	2021-06-20 02:00:00	t	0
402	2	1	1	1	1	2021-06-20 02:00:00	2021-06-20 02:30:00	t	0
403	2	1	1	2	2	2021-06-20 02:30:00	2021-06-20 03:00:00	t	0
404	2	1	1	3	3	2021-06-20 03:00:00	2021-06-20 03:30:00	t	0
405	2	1	1	4	4	2021-06-20 03:30:00	2021-06-20 04:00:00	t	0
406	2	1	1	1	1	2021-06-20 04:00:00	2021-06-20 04:30:00	t	0
408	2	1	1	3	3	2021-06-20 05:00:00	2021-06-20 05:30:00	t	0
409	2	1	1	4	4	2021-06-20 05:30:00	2021-06-20 06:00:00	t	0
410	2	1	1	1	1	2021-06-20 06:00:00	2021-06-20 06:30:00	t	0
411	2	1	1	2	2	2021-06-20 06:30:00	2021-06-20 07:00:00	t	0
412	2	1	1	3	3	2021-06-20 07:00:00	2021-06-20 07:30:00	t	0
413	2	1	1	4	4	2021-06-20 07:30:00	2021-06-20 08:00:00	t	0
414	2	1	1	1	1	2021-06-20 08:00:00	2021-06-20 08:30:00	t	0
415	2	1	1	2	2	2021-06-20 08:30:00	2021-06-20 09:00:00	t	0
416	2	1	1	3	3	2021-06-20 09:00:00	2021-06-20 09:30:00	t	0
417	2	1	1	4	4	2021-06-20 09:30:00	2021-06-20 10:00:00	t	0
418	2	1	1	1	1	2021-06-20 10:00:00	2021-06-20 10:30:00	t	0
419	2	1	1	2	2	2021-06-20 10:30:00	2021-06-20 11:00:00	t	0
420	2	1	1	3	3	2021-06-20 11:00:00	2021-06-20 11:30:00	t	0
421	2	1	1	4	4	2021-06-20 11:30:00	2021-06-20 12:00:00	t	0
422	2	1	1	1	1	2021-06-20 12:00:00	2021-06-20 12:30:00	t	0
423	2	1	1	2	2	2021-06-20 12:30:00	2021-06-20 13:00:00	t	0
424	2	1	1	3	3	2021-06-20 13:00:00	2021-06-20 13:30:00	t	0
425	2	1	1	4	4	2021-06-20 13:30:00	2021-06-20 14:00:00	t	0
426	2	1	1	1	1	2021-06-20 14:00:00	2021-06-20 14:30:00	t	0
427	2	1	1	2	2	2021-06-20 14:30:00	2021-06-20 15:00:00	t	0
428	2	1	1	3	3	2021-06-20 15:00:00	2021-06-20 15:30:00	t	0
429	2	1	1	4	4	2021-06-20 15:30:00	2021-06-20 16:00:00	t	0
430	2	1	1	1	1	2021-06-20 16:00:00	2021-06-20 16:30:00	t	0
431	2	1	1	2	2	2021-06-20 16:30:00	2021-06-20 17:00:00	t	0
432	2	1	1	3	3	2021-06-20 17:00:00	2021-06-20 17:30:00	t	0
433	2	1	1	4	4	2021-06-20 17:30:00	2021-06-20 18:00:00	t	0
435	2	1	1	2	2	2021-06-20 18:30:00	2021-06-20 19:00:00	t	0
436	2	1	1	3	3	2021-06-20 19:00:00	2021-06-20 19:30:00	t	0
326	2	1	1	1	1	2021-06-18 12:00:00	2021-06-18 12:30:00	t	0
344	2	1	1	3	3	2021-06-18 21:00:00	2021-06-18 21:30:00	t	0
362	2	1	1	1	1	2021-06-19 06:00:00	2021-06-19 06:30:00	t	0
380	2	1	1	3	3	2021-06-19 15:00:00	2021-06-19 15:30:00	t	0
407	2	1	1	2	2	2021-06-20 04:30:00	2021-06-20 05:00:00	t	0
434	2	1	1	1	1	2021-06-20 18:00:00	2021-06-20 18:30:00	t	0
437	2	1	1	4	4	2021-06-20 19:30:00	2021-06-20 20:00:00	t	0
438	2	1	1	1	1	2021-06-20 20:00:00	2021-06-20 20:30:00	t	0
439	2	1	1	2	2	2021-06-20 20:30:00	2021-06-20 21:00:00	t	0
440	2	1	1	3	3	2021-06-20 21:00:00	2021-06-20 21:30:00	t	0
441	2	1	1	4	4	2021-06-20 21:30:00	2021-06-20 22:00:00	t	0
442	2	1	1	1	1	2021-06-20 22:00:00	2021-06-20 22:30:00	t	0
443	2	1	1	2	2	2021-06-20 22:30:00	2021-06-20 23:00:00	t	0
444	2	1	1	3	3	2021-06-20 23:00:00	2021-06-20 23:30:00	t	0
445	2	1	1	4	4	2021-06-20 23:30:00	2021-06-21 00:00:00	t	0
446	2	1	1	1	1	2021-06-21 00:00:00	2021-06-21 00:30:00	t	0
447	2	1	1	2	2	2021-06-21 00:30:00	2021-06-21 01:00:00	t	0
448	2	1	1	3	3	2021-06-21 01:00:00	2021-06-21 01:30:00	t	0
449	2	1	1	4	4	2021-06-21 01:30:00	2021-06-21 02:00:00	t	0
450	2	1	1	1	1	2021-06-21 02:00:00	2021-06-21 02:30:00	t	0
451	2	1	1	2	2	2021-06-21 02:30:00	2021-06-21 03:00:00	t	0
452	2	1	1	3	3	2021-06-21 03:00:00	2021-06-21 03:30:00	t	0
453	2	1	1	4	4	2021-06-21 03:30:00	2021-06-21 04:00:00	t	0
454	2	1	1	1	1	2021-06-21 04:00:00	2021-06-21 04:30:00	t	0
455	2	1	1	2	2	2021-06-21 04:30:00	2021-06-21 05:00:00	t	0
456	2	1	1	3	3	2021-06-21 05:00:00	2021-06-21 05:30:00	t	0
457	2	1	1	4	4	2021-06-21 05:30:00	2021-06-21 06:00:00	t	0
458	2	1	1	1	1	2021-06-21 06:00:00	2021-06-21 06:30:00	t	0
459	2	1	1	2	2	2021-06-21 06:30:00	2021-06-21 07:00:00	t	0
460	2	1	1	3	3	2021-06-21 07:00:00	2021-06-21 07:30:00	t	0
461	2	1	1	4	4	2021-06-21 07:30:00	2021-06-21 08:00:00	t	0
462	2	1	1	1	1	2021-06-21 08:00:00	2021-06-21 08:30:00	t	0
463	2	1	1	2	2	2021-06-21 08:30:00	2021-06-21 09:00:00	t	0
464	2	1	1	3	3	2021-06-21 09:00:00	2021-06-21 09:30:00	t	0
465	2	1	1	4	4	2021-06-21 09:30:00	2021-06-21 10:00:00	t	0
466	2	1	1	1	1	2021-06-21 10:00:00	2021-06-21 10:30:00	t	0
467	2	1	1	2	2	2021-06-21 10:30:00	2021-06-21 11:00:00	t	0
468	2	1	1	3	3	2021-06-21 11:00:00	2021-06-21 11:30:00	t	0
469	2	1	1	4	4	2021-06-21 11:30:00	2021-06-21 12:00:00	t	0
155	1	1	1	4	4	2021-06-21 13:30:00	2021-06-21 14:00:00	t	0
303	3	4	3	18	6	2021-06-21 13:00:00	2021-06-21 14:00:00	t	0
471	3	4	3	18	6	2021-06-21 19:00:00	2021-06-21 20:00:00	t	0
474	1	1	1	1	1	2021-06-21 20:00:00	2021-06-21 20:30:00	t	0
472	3	4	3	17	4	2021-06-21 20:00:00	2021-06-21 21:00:00	t	0
473	3	4	3	18	6	2021-06-21 20:00:00	2021-06-21 21:00:00	t	0
475	1	1	1	2	2	2021-06-21 20:30:00	2021-06-21 21:00:00	t	0
476	1	1	1	3	3	2021-06-21 21:00:00	2021-06-21 21:30:00	t	0
477	1	1	1	4	4	2021-06-21 21:30:00	2021-06-21 22:00:00	t	0
478	3	4	3	17	4	2021-06-21 21:00:00	2021-06-21 22:00:00	t	0
479	3	4	3	18	6	2021-06-21 21:00:00	2021-06-21 22:00:00	t	0
482	1	1	1	1	1	2021-06-21 22:00:00	2021-06-21 22:30:00	t	0
480	3	4	3	17	4	2021-06-21 22:00:00	2021-06-21 23:00:00	t	0
483	1	1	1	2	2	2021-06-21 22:30:00	2021-06-21 23:00:00	t	0
484	1	1	1	3	3	2021-06-21 23:00:00	2021-06-21 23:30:00	t	0
485	1	1	1	4	4	2021-06-21 23:30:00	2021-06-22 00:00:00	t	0
486	3	4	3	17	4	2021-06-21 23:00:00	2021-06-22 00:00:00	t	0
487	3	4	3	18	6	2021-06-21 23:00:00	2021-06-22 00:00:00	t	0
491	1	1	1	1	1	2021-06-22 00:00:00	2021-06-22 00:30:00	t	0
489	3	4	3	17	4	2021-06-22 00:00:00	2021-06-22 01:00:00	t	0
490	3	4	3	18	6	2021-06-22 00:00:00	2021-06-22 01:00:00	t	0
492	1	1	1	2	2	2021-06-22 00:30:00	2021-06-22 01:00:00	t	0
493	1	1	1	3	3	2021-06-22 01:00:00	2021-06-22 01:30:00	t	0
494	1	1	1	4	4	2021-06-22 01:30:00	2021-06-22 02:00:00	t	0
495	3	4	3	17	4	2021-06-22 01:00:00	2021-06-22 02:00:00	t	0
496	3	4	3	18	6	2021-06-22 01:00:00	2021-06-22 02:00:00	t	0
499	1	1	1	1	1	2021-06-22 02:00:00	2021-06-22 02:30:00	t	0
497	3	4	3	17	4	2021-06-22 02:00:00	2021-06-22 03:00:00	t	0
498	3	4	3	18	6	2021-06-22 02:00:00	2021-06-22 03:00:00	t	0
500	1	1	1	2	2	2021-06-22 02:30:00	2021-06-22 03:00:00	t	0
501	1	1	1	3	3	2021-06-22 03:00:00	2021-06-22 03:30:00	t	2055
502	1	1	1	4	4	2021-06-22 03:30:00	2021-06-22 04:00:00	t	510
488	4	0	0	0	0	2021-06-22 00:00:00	2021-06-22 12:00:00	t	0
470	3	4	3	17	4	2021-06-21 19:00:00	2021-06-21 20:00:00	t	0
481	3	4	3	18	6	2021-06-21 22:00:00	2021-06-21 23:00:00	t	0
503	3	4	3	17	4	2021-06-22 03:00:00	2021-06-22 04:00:00	t	0
504	3	4	3	18	6	2021-06-22 03:00:00	2021-06-22 04:00:00	t	0
507	1	1	1	1	1	2021-06-22 04:00:00	2021-06-22 04:30:00	t	0
505	3	4	3	17	4	2021-06-22 04:00:00	2021-06-22 05:00:00	t	1750
506	3	4	3	18	6	2021-06-22 04:00:00	2021-06-22 05:00:00	t	0
508	1	1	1	2	2	2021-06-22 04:30:00	2021-06-22 05:00:00	t	983
509	1	1	1	3	3	2021-06-22 05:00:00	2021-06-22 05:30:00	t	0
510	1	1	1	4	4	2021-06-22 05:30:00	2021-06-22 06:00:00	t	0
511	3	4	3	17	4	2021-06-22 05:00:00	2021-06-22 06:00:00	t	0
512	3	4	3	18	6	2021-06-22 05:00:00	2021-06-22 06:00:00	t	0
515	1	1	1	1	1	2021-06-22 06:00:00	2021-06-22 06:30:00	t	0
513	3	4	3	17	4	2021-06-22 06:00:00	2021-06-22 07:00:00	t	0
514	3	4	3	18	6	2021-06-22 06:00:00	2021-06-22 07:00:00	t	0
516	1	1	1	2	2	2021-06-22 06:30:00	2021-06-22 07:00:00	t	0
517	1	1	1	3	3	2021-06-22 07:00:00	2021-06-22 07:30:00	t	0
518	1	1	1	4	4	2021-06-22 07:30:00	2021-06-22 08:00:00	t	0
519	3	4	3	17	4	2021-06-22 07:00:00	2021-06-22 08:00:00	t	0
520	3	4	3	18	6	2021-06-22 07:00:00	2021-06-22 08:00:00	t	0
523	1	1	1	1	1	2021-06-22 08:00:00	2021-06-22 08:30:00	t	0
521	3	4	3	17	4	2021-06-22 08:00:00	2021-06-22 09:00:00	t	0
522	3	4	3	18	6	2021-06-22 08:00:00	2021-06-22 09:00:00	t	0
524	1	1	1	2	2	2021-06-22 08:30:00	2021-06-22 09:00:00	t	0
525	1	1	1	3	3	2021-06-22 09:00:00	2021-06-22 09:30:00	t	0
526	1	1	1	4	4	2021-06-22 09:30:00	2021-06-22 10:00:00	t	0
527	3	4	3	17	4	2021-06-22 09:00:00	2021-06-22 10:00:00	t	0
528	3	4	3	18	6	2021-06-22 09:00:00	2021-06-22 10:00:00	t	0
531	1	1	1	1	1	2021-06-22 10:00:00	2021-06-22 10:30:00	t	0
529	3	4	3	17	4	2021-06-22 10:00:00	2021-06-22 11:00:00	t	0
530	3	4	3	18	6	2021-06-22 10:00:00	2021-06-22 11:00:00	t	0
532	1	1	1	2	2	2021-06-22 10:30:00	2021-06-22 11:00:00	t	0
533	1	1	1	3	3	2021-06-22 11:00:00	2021-06-22 11:30:00	t	0
534	1	1	1	4	4	2021-06-22 11:30:00	2021-06-22 12:00:00	t	2042
535	3	4	3	17	4	2021-06-22 11:00:00	2021-06-22 12:00:00	t	0
536	3	4	3	18	6	2021-06-22 11:00:00	2021-06-22 12:00:00	t	0
540	1	1	1	1	1	2021-06-22 12:00:00	2021-06-22 12:30:00	t	0
538	3	4	3	17	4	2021-06-22 12:00:00	2021-06-22 13:00:00	t	0
539	3	4	3	18	6	2021-06-22 12:00:00	2021-06-22 13:00:00	t	978
541	1	1	1	2	2	2021-06-22 12:30:00	2021-06-22 13:00:00	t	0
542	1	1	1	3	3	2021-06-22 13:00:00	2021-06-22 13:30:00	t	0
543	1	1	1	4	4	2021-06-22 13:30:00	2021-06-22 14:00:00	t	1444
544	3	4	3	17	4	2021-06-22 13:00:00	2021-06-22 14:00:00	t	0
545	3	4	3	18	6	2021-06-22 13:00:00	2021-06-22 14:00:00	t	0
546	3	4	3	17	4	2021-06-22 14:00:00	2021-06-22 15:00:00	t	760
547	3	4	3	18	6	2021-06-22 14:00:00	2021-06-22 15:00:00	t	0
548	3	4	3	17	4	2021-06-22 15:00:00	2021-06-22 16:00:00	t	0
549	3	4	3	18	6	2021-06-22 15:00:00	2021-06-22 16:00:00	t	0
550	3	4	3	15	1	2021-06-22 16:00:00	2021-06-22 17:00:00	t	0
551	3	4	3	16	3	2021-06-22 16:00:00	2021-06-22 17:00:00	t	0
552	3	4	3	17	4	2021-06-22 17:00:00	2021-06-22 18:00:00	t	0
553	3	4	3	18	6	2021-06-22 17:00:00	2021-06-22 18:00:00	t	0
554	3	4	3	15	1	2021-06-22 18:00:00	2021-06-22 19:00:00	t	0
555	3	4	3	16	3	2021-06-22 18:00:00	2021-06-22 19:00:00	t	0
556	3	4	3	17	4	2021-06-22 19:00:00	2021-06-22 20:00:00	t	0
557	3	4	3	18	6	2021-06-22 19:00:00	2021-06-22 20:00:00	t	0
537	4	0	0	0	0	2021-06-22 12:00:00	2021-06-23 00:00:00	t	0
1156	7	3	2	7	3	2021-06-26 04:30:00	2021-06-26 05:00:00	t	0
1242	1	1	1	2	2	2021-06-26 12:30:00	2021-06-26 13:00:00	t	0
1243	1	1	1	3	3	2021-06-26 13:00:00	2021-06-26 13:30:00	t	0
1244	1	1	1	4	4	2021-06-26 13:30:00	2021-06-26 14:00:00	t	0
1249	3	4	3	17	4	2021-06-26 13:00:00	2021-06-26 14:00:00	t	0
1250	3	4	3	18	6	2021-06-26 13:00:00	2021-06-26 14:00:00	t	0
1251	28	3	2	5	5	2021-06-26 13:30:00	2021-06-26 14:00:00	t	0
1269	3	4	3	17	4	2021-06-26 15:00:00	2021-06-26 16:00:00	t	0
1270	3	4	3	18	6	2021-06-26 15:00:00	2021-06-26 16:00:00	t	0
1281	28	3	2	7	3	2021-06-26 20:30:00	2021-06-26 21:00:00	t	0
1282	28	3	2	8	7	2021-06-26 21:00:00	2021-06-26 21:30:00	t	0
1283	28	3	2	5	5	2021-06-26 21:30:00	2021-06-26 22:00:00	t	0
1284	28	3	2	6	6	2021-06-26 22:00:00	2021-06-26 22:30:00	t	0
1285	28	3	2	7	3	2021-06-26 22:30:00	2021-06-26 23:00:00	t	0
1286	28	3	2	8	7	2021-06-26 23:00:00	2021-06-26 23:30:00	t	0
558	3	4	3	15	1	2021-06-22 20:00:00	2021-06-22 21:00:00	t	0
559	3	4	3	16	3	2021-06-22 20:00:00	2021-06-22 21:00:00	t	0
560	3	4	3	17	4	2021-06-22 21:00:00	2021-06-22 22:00:00	t	0
561	3	4	3	18	6	2021-06-22 21:00:00	2021-06-22 22:00:00	t	0
562	3	4	3	15	1	2021-06-22 22:00:00	2021-06-22 23:00:00	t	0
563	3	4	3	16	3	2021-06-22 22:00:00	2021-06-22 23:00:00	t	0
564	3	4	3	17	4	2021-06-22 23:00:00	2021-06-23 00:00:00	t	0
565	3	4	3	18	6	2021-06-22 23:00:00	2021-06-23 00:00:00	t	0
567	3	4	3	17	4	2021-06-23 00:00:00	2021-06-23 01:00:00	t	0
568	3	4	3	18	6	2021-06-23 00:00:00	2021-06-23 01:00:00	t	0
569	3	4	3	15	1	2021-06-23 01:00:00	2021-06-23 02:00:00	t	0
570	3	4	3	16	3	2021-06-23 01:00:00	2021-06-23 02:00:00	t	0
571	3	4	3	17	4	2021-06-23 02:00:00	2021-06-23 03:00:00	t	2049
572	3	4	3	18	6	2021-06-23 02:00:00	2021-06-23 03:00:00	t	515
593	2	3	2	8	7	2021-06-22 06:00:00	2021-06-22 06:30:00	t	0
595	2	3	2	5	5	2021-06-22 06:30:00	2021-06-22 07:00:00	t	0
596	2	3	2	6	6	2021-06-22 07:00:00	2021-06-22 07:30:00	t	0
597	2	3	2	7	3	2021-06-22 07:30:00	2021-06-22 08:00:00	t	0
598	2	3	2	8	7	2021-06-22 08:00:00	2021-06-22 08:30:00	t	0
599	2	3	2	5	5	2021-06-22 08:30:00	2021-06-22 09:00:00	t	0
600	2	3	2	6	6	2021-06-22 09:00:00	2021-06-22 09:30:00	t	0
601	2	3	2	7	3	2021-06-22 09:30:00	2021-06-22 10:00:00	t	0
602	2	3	2	8	7	2021-06-22 10:00:00	2021-06-22 10:30:00	t	0
603	2	3	2	5	5	2021-06-22 10:30:00	2021-06-22 11:00:00	t	0
604	2	3	2	6	6	2021-06-22 11:00:00	2021-06-22 11:30:00	t	0
605	2	3	2	7	3	2021-06-22 11:30:00	2021-06-22 12:00:00	t	0
606	2	3	2	8	7	2021-06-22 12:00:00	2021-06-22 12:30:00	t	0
607	2	3	2	5	5	2021-06-22 12:30:00	2021-06-22 13:00:00	t	0
608	2	3	2	6	6	2021-06-22 13:00:00	2021-06-22 13:30:00	t	0
609	2	3	2	7	3	2021-06-22 13:30:00	2021-06-22 14:00:00	t	0
610	2	3	2	8	7	2021-06-22 14:00:00	2021-06-22 14:30:00	t	0
611	2	3	2	5	5	2021-06-22 14:30:00	2021-06-22 15:00:00	t	0
612	2	3	2	6	6	2021-06-22 15:00:00	2021-06-22 15:30:00	t	0
613	2	3	2	7	3	2021-06-22 15:30:00	2021-06-22 16:00:00	t	0
614	2	3	2	8	7	2021-06-22 16:00:00	2021-06-22 16:30:00	t	0
615	2	3	2	5	5	2021-06-22 16:30:00	2021-06-22 17:00:00	t	0
616	2	3	2	6	6	2021-06-22 17:00:00	2021-06-22 17:30:00	t	0
617	2	3	2	7	3	2021-06-22 17:30:00	2021-06-22 18:00:00	t	0
573	3	4	3	15	1	2021-06-23 03:00:00	2021-06-23 04:00:00	t	0
574	3	4	3	16	3	2021-06-23 03:00:00	2021-06-23 04:00:00	t	0
575	3	4	3	17	4	2021-06-23 04:00:00	2021-06-23 05:00:00	t	0
576	3	4	3	18	6	2021-06-23 04:00:00	2021-06-23 05:00:00	t	0
577	3	4	3	15	1	2021-06-23 05:00:00	2021-06-23 06:00:00	t	0
578	3	4	3	16	3	2021-06-23 05:00:00	2021-06-23 06:00:00	t	0
579	3	4	3	17	4	2021-06-23 06:00:00	2021-06-23 07:00:00	t	0
580	3	4	3	18	6	2021-06-23 06:00:00	2021-06-23 07:00:00	t	0
581	3	4	3	15	1	2021-06-23 07:00:00	2021-06-23 08:00:00	t	0
582	3	4	3	16	3	2021-06-23 07:00:00	2021-06-23 08:00:00	t	0
583	3	4	3	17	4	2021-06-23 08:00:00	2021-06-23 09:00:00	t	0
584	3	4	3	18	6	2021-06-23 08:00:00	2021-06-23 09:00:00	t	988
585	3	4	3	15	1	2021-06-23 09:00:00	2021-06-23 10:00:00	t	0
586	3	4	3	16	3	2021-06-23 09:00:00	2021-06-23 10:00:00	t	520
587	3	4	3	17	4	2021-06-23 10:00:00	2021-06-23 11:00:00	t	988
588	3	4	3	18	6	2021-06-23 10:00:00	2021-06-23 11:00:00	t	0
566	4	0	0	0	0	2021-06-23 00:00:00	2021-06-23 12:00:00	t	0
589	3	4	3	15	1	2021-06-23 11:00:00	2021-06-23 12:00:00	t	0
590	3	4	3	16	3	2021-06-23 11:00:00	2021-06-23 12:00:00	t	0
591	3	4	3	17	4	2021-06-23 12:00:00	2021-06-23 13:00:00	t	0
592	3	4	3	18	6	2021-06-23 12:00:00	2021-06-23 13:00:00	t	0
594	4	0	0	0	0	2021-06-23 12:00:00	2021-06-24 00:00:00	t	0
1245	2	3	2	5	5	2021-06-26 04:30:00	2021-06-26 05:00:00	t	0
1246	2	3	2	6	6	2021-06-26 05:00:00	2021-06-26 05:30:00	t	0
1247	2	3	2	7	3	2021-06-26 05:30:00	2021-06-26 06:00:00	t	0
1248	2	3	2	8	7	2021-06-26 06:00:00	2021-06-26 06:30:00	t	0
1241	1	1	1	1	1	2021-06-26 12:00:00	2021-06-26 12:30:00	t	0
1261	1	1	1	1	1	2021-06-26 14:00:00	2021-06-26 14:30:00	t	0
1259	3	4	3	17	4	2021-06-26 14:00:00	2021-06-26 15:00:00	t	0
1260	3	4	3	18	6	2021-06-26 14:00:00	2021-06-26 15:00:00	t	0
1262	1	1	1	2	2	2021-06-26 14:30:00	2021-06-26 15:00:00	t	0
1263	1	1	1	3	3	2021-06-26 15:00:00	2021-06-26 15:30:00	t	0
1264	1	1	1	4	4	2021-06-26 15:30:00	2021-06-26 16:00:00	t	0
1238	4	0	0	0	0	2021-06-26 12:00:00	2021-06-27 00:00:00	t	0
618	2	3	2	8	7	2021-06-22 18:00:00	2021-06-22 18:30:00	t	0
619	2	3	2	5	5	2021-06-22 18:30:00	2021-06-22 19:00:00	t	0
620	2	3	2	6	6	2021-06-22 19:00:00	2021-06-22 19:30:00	t	0
621	2	3	2	7	3	2021-06-22 19:30:00	2021-06-22 20:00:00	t	0
622	2	3	2	8	7	2021-06-22 20:00:00	2021-06-22 20:30:00	t	0
623	2	3	2	5	5	2021-06-22 20:30:00	2021-06-22 21:00:00	t	0
624	2	3	2	6	6	2021-06-22 21:00:00	2021-06-22 21:30:00	t	0
625	2	3	2	7	3	2021-06-22 21:30:00	2021-06-22 22:00:00	t	0
626	2	3	2	8	7	2021-06-22 22:00:00	2021-06-22 22:30:00	t	0
627	2	3	2	5	5	2021-06-22 22:30:00	2021-06-22 23:00:00	t	0
628	2	3	2	6	6	2021-06-22 23:00:00	2021-06-22 23:30:00	t	0
629	2	3	2	7	3	2021-06-22 23:30:00	2021-06-23 00:00:00	t	0
630	2	3	2	8	7	2021-06-23 00:00:00	2021-06-23 00:30:00	t	0
631	2	3	2	5	5	2021-06-23 00:30:00	2021-06-23 01:00:00	t	0
632	2	3	2	6	6	2021-06-23 01:00:00	2021-06-23 01:30:00	t	0
633	2	3	2	7	3	2021-06-23 01:30:00	2021-06-23 02:00:00	t	0
634	2	3	2	8	7	2021-06-23 02:00:00	2021-06-23 02:30:00	t	0
635	2	3	2	5	5	2021-06-23 02:30:00	2021-06-23 03:00:00	t	0
639	1	1	1	1	1	2021-06-22 14:00:00	2021-06-22 14:30:00	t	0
640	1	1	1	2	2	2021-06-22 14:30:00	2021-06-22 15:00:00	t	0
641	1	1	1	3	3	2021-06-22 15:00:00	2021-06-22 15:30:00	t	0
642	1	1	1	4	4	2021-06-22 15:30:00	2021-06-22 16:00:00	t	0
643	1	1	1	1	1	2021-06-22 16:00:00	2021-06-22 16:30:00	t	0
644	1	1	1	2	2	2021-06-22 16:30:00	2021-06-22 17:00:00	t	0
645	1	1	1	3	3	2021-06-22 17:00:00	2021-06-22 17:30:00	t	0
646	1	1	1	4	4	2021-06-22 17:30:00	2021-06-22 18:00:00	t	0
647	1	1	1	1	1	2021-06-22 18:00:00	2021-06-22 18:30:00	t	0
648	1	1	1	2	2	2021-06-22 18:30:00	2021-06-22 19:00:00	t	0
649	1	1	1	3	3	2021-06-22 19:00:00	2021-06-22 19:30:00	t	0
650	1	1	1	4	4	2021-06-22 19:30:00	2021-06-22 20:00:00	t	0
651	1	1	1	1	1	2021-06-22 20:00:00	2021-06-22 20:30:00	t	0
652	1	1	1	2	2	2021-06-22 20:30:00	2021-06-22 21:00:00	t	0
653	1	1	1	3	3	2021-06-22 21:00:00	2021-06-22 21:30:00	t	0
654	1	1	1	4	4	2021-06-22 21:30:00	2021-06-22 22:00:00	t	0
655	1	1	1	1	1	2021-06-22 22:00:00	2021-06-22 22:30:00	t	0
656	1	1	1	2	2	2021-06-22 22:30:00	2021-06-22 23:00:00	t	0
657	1	1	1	3	3	2021-06-22 23:00:00	2021-06-22 23:30:00	t	0
658	1	1	1	4	4	2021-06-22 23:30:00	2021-06-23 00:00:00	t	0
659	1	1	1	1	1	2021-06-23 00:00:00	2021-06-23 00:30:00	t	0
660	1	1	1	2	2	2021-06-23 00:30:00	2021-06-23 01:00:00	t	0
661	1	1	1	3	3	2021-06-23 01:00:00	2021-06-23 01:30:00	t	0
662	1	1	1	4	4	2021-06-23 01:30:00	2021-06-23 02:00:00	t	0
663	1	1	1	1	1	2021-06-23 02:00:00	2021-06-23 02:30:00	t	0
664	1	1	1	2	2	2021-06-23 02:30:00	2021-06-23 03:00:00	t	0
636	2	3	2	6	6	2021-06-23 03:00:00	2021-06-23 03:30:00	t	0
665	1	1	1	3	3	2021-06-23 03:00:00	2021-06-23 03:30:00	t	520
637	2	3	2	7	3	2021-06-23 03:30:00	2021-06-23 04:00:00	t	0
666	1	1	1	4	4	2021-06-23 03:30:00	2021-06-23 04:00:00	t	0
638	2	3	2	8	7	2021-06-23 04:00:00	2021-06-23 04:30:00	t	0
667	1	1	1	1	1	2021-06-23 04:00:00	2021-06-23 04:30:00	t	0
668	1	1	1	2	2	2021-06-23 04:30:00	2021-06-23 05:00:00	t	0
687	2	3	2	5	5	2021-06-23 04:30:00	2021-06-23 05:00:00	t	0
669	1	1	1	3	3	2021-06-23 05:00:00	2021-06-23 05:30:00	t	0
688	2	3	2	6	6	2021-06-23 05:00:00	2021-06-23 05:30:00	t	0
670	1	1	1	4	4	2021-06-23 05:30:00	2021-06-23 06:00:00	t	0
689	2	3	2	7	3	2021-06-23 05:30:00	2021-06-23 06:00:00	t	0
671	1	1	1	1	1	2021-06-23 06:00:00	2021-06-23 06:30:00	t	0
672	1	1	1	2	2	2021-06-23 06:30:00	2021-06-23 07:00:00	t	0
673	1	1	1	3	3	2021-06-23 07:00:00	2021-06-23 07:30:00	t	0
674	1	1	1	4	4	2021-06-23 07:30:00	2021-06-23 08:00:00	t	0
675	1	1	1	1	1	2021-06-23 08:00:00	2021-06-23 08:30:00	t	0
676	1	1	1	2	2	2021-06-23 08:30:00	2021-06-23 09:00:00	t	0
677	1	1	1	3	3	2021-06-23 09:00:00	2021-06-23 09:30:00	t	1624
678	1	1	1	4	4	2021-06-23 09:30:00	2021-06-23 10:00:00	t	988
679	1	1	1	1	1	2021-06-23 10:00:00	2021-06-23 10:30:00	t	0
680	1	1	1	2	2	2021-06-23 10:30:00	2021-06-23 11:00:00	t	0
681	1	1	1	3	3	2021-06-23 11:00:00	2021-06-23 11:30:00	t	992
682	1	1	1	4	4	2021-06-23 11:30:00	2021-06-23 12:00:00	t	0
683	1	1	1	1	1	2021-06-23 12:00:00	2021-06-23 12:30:00	t	0
684	1	1	1	2	2	2021-06-23 12:30:00	2021-06-23 13:00:00	t	0
685	1	1	1	3	3	2021-06-23 13:00:00	2021-06-23 13:30:00	t	0
686	1	1	1	4	4	2021-06-23 13:30:00	2021-06-23 14:00:00	t	0
690	2	3	2	8	7	2021-06-23 06:00:00	2021-06-23 06:30:00	t	0
699	2	3	2	5	5	2021-06-23 06:30:00	2021-06-23 07:00:00	t	0
700	2	3	2	6	6	2021-06-23 07:00:00	2021-06-23 07:30:00	t	0
701	2	3	2	7	3	2021-06-23 07:30:00	2021-06-23 08:00:00	t	0
702	2	3	2	8	7	2021-06-23 08:00:00	2021-06-23 08:30:00	t	0
711	2	3	2	5	5	2021-06-23 08:30:00	2021-06-23 09:00:00	t	0
712	2	3	2	6	6	2021-06-23 09:00:00	2021-06-23 09:30:00	t	520
713	2	3	2	7	3	2021-06-23 09:30:00	2021-06-23 10:00:00	t	0
714	2	3	2	8	7	2021-06-23 10:00:00	2021-06-23 10:30:00	t	0
723	2	3	2	5	5	2021-06-23 10:30:00	2021-06-23 11:00:00	t	0
724	2	3	2	6	6	2021-06-23 11:00:00	2021-06-23 11:30:00	t	0
725	2	3	2	7	3	2021-06-23 11:30:00	2021-06-23 12:00:00	t	0
726	2	3	2	8	7	2021-06-23 12:00:00	2021-06-23 12:30:00	t	0
735	2	3	2	5	5	2021-06-23 12:30:00	2021-06-23 13:00:00	t	0
736	2	3	2	6	6	2021-06-23 13:00:00	2021-06-23 13:30:00	t	0
691	3	4	3	17	4	2021-06-23 13:00:00	2021-06-23 14:00:00	t	0
692	3	4	3	18	6	2021-06-23 13:00:00	2021-06-23 14:00:00	t	0
737	2	3	2	7	3	2021-06-23 13:30:00	2021-06-23 14:00:00	t	0
695	1	1	1	1	1	2021-06-23 14:00:00	2021-06-23 14:30:00	t	0
738	2	3	2	8	7	2021-06-23 14:00:00	2021-06-23 14:30:00	t	0
693	3	4	3	17	4	2021-06-23 14:00:00	2021-06-23 15:00:00	t	0
694	3	4	3	18	6	2021-06-23 14:00:00	2021-06-23 15:00:00	t	0
696	1	1	1	2	2	2021-06-23 14:30:00	2021-06-23 15:00:00	t	0
747	2	3	2	5	5	2021-06-23 14:30:00	2021-06-23 15:00:00	t	0
748	2	3	2	6	6	2021-06-23 15:00:00	2021-06-23 15:30:00	t	0
698	1	1	1	4	4	2021-06-23 15:30:00	2021-06-23 16:00:00	t	0
703	3	4	3	17	4	2021-06-23 15:00:00	2021-06-23 16:00:00	t	0
704	3	4	3	18	6	2021-06-23 15:00:00	2021-06-23 16:00:00	t	0
749	2	3	2	7	3	2021-06-23 15:30:00	2021-06-23 16:00:00	t	0
707	1	1	1	1	1	2021-06-23 16:00:00	2021-06-23 16:30:00	t	0
750	2	3	2	8	7	2021-06-23 16:00:00	2021-06-23 16:30:00	t	0
705	3	4	3	17	4	2021-06-23 16:00:00	2021-06-23 17:00:00	t	0
706	3	4	3	18	6	2021-06-23 16:00:00	2021-06-23 17:00:00	t	0
708	1	1	1	2	2	2021-06-23 16:30:00	2021-06-23 17:00:00	t	0
760	2	3	2	5	5	2021-06-23 16:30:00	2021-06-23 17:00:00	t	0
709	1	1	1	3	3	2021-06-23 17:00:00	2021-06-23 17:30:00	t	0
761	2	3	2	6	6	2021-06-23 17:00:00	2021-06-23 17:30:00	t	0
710	1	1	1	4	4	2021-06-23 17:30:00	2021-06-23 18:00:00	t	0
715	3	4	3	17	4	2021-06-23 17:00:00	2021-06-23 18:00:00	t	0
716	3	4	3	18	6	2021-06-23 17:00:00	2021-06-23 18:00:00	t	0
762	2	3	2	7	3	2021-06-23 17:30:00	2021-06-23 18:00:00	t	0
719	1	1	1	1	1	2021-06-23 18:00:00	2021-06-23 18:30:00	t	0
763	2	3	2	8	7	2021-06-23 18:00:00	2021-06-23 18:30:00	t	0
717	3	4	3	17	4	2021-06-23 18:00:00	2021-06-23 19:00:00	t	0
720	1	1	1	2	2	2021-06-23 18:30:00	2021-06-23 19:00:00	t	0
721	1	1	1	3	3	2021-06-23 19:00:00	2021-06-23 19:30:00	t	0
722	1	1	1	4	4	2021-06-23 19:30:00	2021-06-23 20:00:00	t	0
727	3	4	3	17	4	2021-06-23 19:00:00	2021-06-23 20:00:00	t	0
728	3	4	3	18	6	2021-06-23 19:00:00	2021-06-23 20:00:00	t	0
731	1	1	1	1	1	2021-06-23 20:00:00	2021-06-23 20:30:00	t	0
729	3	4	3	17	4	2021-06-23 20:00:00	2021-06-23 21:00:00	t	0
730	3	4	3	18	6	2021-06-23 20:00:00	2021-06-23 21:00:00	t	0
732	1	1	1	2	2	2021-06-23 20:30:00	2021-06-23 21:00:00	t	0
733	1	1	1	3	3	2021-06-23 21:00:00	2021-06-23 21:30:00	t	0
734	1	1	1	4	4	2021-06-23 21:30:00	2021-06-23 22:00:00	t	0
739	3	4	3	17	4	2021-06-23 21:00:00	2021-06-23 22:00:00	t	0
740	3	4	3	18	6	2021-06-23 21:00:00	2021-06-23 22:00:00	t	0
743	1	1	1	1	1	2021-06-23 22:00:00	2021-06-23 22:30:00	t	0
741	3	4	3	17	4	2021-06-23 22:00:00	2021-06-23 23:00:00	t	0
742	3	4	3	18	6	2021-06-23 22:00:00	2021-06-23 23:00:00	t	0
744	1	1	1	2	2	2021-06-23 22:30:00	2021-06-23 23:00:00	t	0
745	1	1	1	3	3	2021-06-23 23:00:00	2021-06-23 23:30:00	t	0
746	1	1	1	4	4	2021-06-23 23:30:00	2021-06-24 00:00:00	t	0
751	3	4	3	17	4	2021-06-23 23:00:00	2021-06-24 00:00:00	t	0
752	3	4	3	18	6	2021-06-23 23:00:00	2021-06-24 00:00:00	t	0
756	1	1	1	1	1	2021-06-24 00:00:00	2021-06-24 00:30:00	t	0
754	3	4	3	17	4	2021-06-24 00:00:00	2021-06-24 01:00:00	t	0
755	3	4	3	18	6	2021-06-24 00:00:00	2021-06-24 01:00:00	t	0
757	1	1	1	2	2	2021-06-24 00:30:00	2021-06-24 01:00:00	t	0
758	1	1	1	3	3	2021-06-24 01:00:00	2021-06-24 01:30:00	t	0
753	4	0	0	0	0	2021-06-24 00:00:00	2021-06-24 12:00:00	t	0
697	1	1	1	3	3	2021-06-23 15:00:00	2021-06-23 15:30:00	t	0
718	3	4	3	18	6	2021-06-23 18:00:00	2021-06-23 19:00:00	t	0
772	2	3	2	5	5	2021-06-23 18:30:00	2021-06-23 19:00:00	t	0
773	2	3	2	6	6	2021-06-23 19:00:00	2021-06-23 19:30:00	t	0
774	2	3	2	7	3	2021-06-23 19:30:00	2021-06-23 20:00:00	t	0
775	2	3	2	8	7	2021-06-23 20:00:00	2021-06-23 20:30:00	t	0
784	2	3	2	5	5	2021-06-23 20:30:00	2021-06-23 21:00:00	t	0
785	2	3	2	6	6	2021-06-23 21:00:00	2021-06-23 21:30:00	t	0
786	2	3	2	7	3	2021-06-23 21:30:00	2021-06-23 22:00:00	t	0
787	2	3	2	8	7	2021-06-23 22:00:00	2021-06-23 22:30:00	t	0
796	2	3	2	5	5	2021-06-23 22:30:00	2021-06-23 23:00:00	t	0
797	2	3	2	6	6	2021-06-23 23:00:00	2021-06-23 23:30:00	t	0
798	2	3	2	7	3	2021-06-23 23:30:00	2021-06-24 00:00:00	t	0
799	2	3	2	8	7	2021-06-24 00:00:00	2021-06-24 00:30:00	t	0
808	2	3	2	5	5	2021-06-24 00:30:00	2021-06-24 01:00:00	t	0
809	2	3	2	6	6	2021-06-24 01:00:00	2021-06-24 01:30:00	t	0
759	1	1	1	4	4	2021-06-24 01:30:00	2021-06-24 02:00:00	t	0
764	3	4	3	17	4	2021-06-24 01:00:00	2021-06-24 02:00:00	t	0
765	3	4	3	18	6	2021-06-24 01:00:00	2021-06-24 02:00:00	t	0
810	2	3	2	7	3	2021-06-24 01:30:00	2021-06-24 02:00:00	t	0
768	1	1	1	1	1	2021-06-24 02:00:00	2021-06-24 02:30:00	t	0
811	2	3	2	8	7	2021-06-24 02:00:00	2021-06-24 02:30:00	t	0
766	3	4	3	17	4	2021-06-24 02:00:00	2021-06-24 03:00:00	t	0
767	3	4	3	18	6	2021-06-24 02:00:00	2021-06-24 03:00:00	t	0
769	1	1	1	2	2	2021-06-24 02:30:00	2021-06-24 03:00:00	t	765
820	2	3	2	5	5	2021-06-24 02:30:00	2021-06-24 03:00:00	t	0
770	1	1	1	3	3	2021-06-24 03:00:00	2021-06-24 03:30:00	t	0
821	2	3	2	6	6	2021-06-24 03:00:00	2021-06-24 03:30:00	t	0
771	1	1	1	4	4	2021-06-24 03:30:00	2021-06-24 04:00:00	t	0
776	3	4	3	17	4	2021-06-24 03:00:00	2021-06-24 04:00:00	t	0
777	3	4	3	18	6	2021-06-24 03:00:00	2021-06-24 04:00:00	t	0
822	2	3	2	7	3	2021-06-24 03:30:00	2021-06-24 04:00:00	t	0
780	1	1	1	1	1	2021-06-24 04:00:00	2021-06-24 04:30:00	t	0
823	2	3	2	8	7	2021-06-24 04:00:00	2021-06-24 04:30:00	t	0
778	3	4	3	17	4	2021-06-24 04:00:00	2021-06-24 05:00:00	t	0
779	3	4	3	18	6	2021-06-24 04:00:00	2021-06-24 05:00:00	t	0
781	1	1	1	2	2	2021-06-24 04:30:00	2021-06-24 05:00:00	t	0
833	2	3	2	5	5	2021-06-24 04:30:00	2021-06-24 05:00:00	t	0
782	1	1	1	3	3	2021-06-24 05:00:00	2021-06-24 05:30:00	t	0
783	1	1	1	4	4	2021-06-24 05:30:00	2021-06-24 06:00:00	t	0
788	3	4	3	17	4	2021-06-24 05:00:00	2021-06-24 06:00:00	t	0
789	3	4	3	18	6	2021-06-24 05:00:00	2021-06-24 06:00:00	t	0
792	1	1	1	1	1	2021-06-24 06:00:00	2021-06-24 06:30:00	t	0
790	3	4	3	17	4	2021-06-24 06:00:00	2021-06-24 07:00:00	t	0
791	3	4	3	18	6	2021-06-24 06:00:00	2021-06-24 07:00:00	t	0
793	1	1	1	2	2	2021-06-24 06:30:00	2021-06-24 07:00:00	t	0
794	1	1	1	3	3	2021-06-24 07:00:00	2021-06-24 07:30:00	t	0
795	1	1	1	4	4	2021-06-24 07:30:00	2021-06-24 08:00:00	t	525
801	3	4	3	18	6	2021-06-24 07:00:00	2021-06-24 08:00:00	t	0
804	1	1	1	1	1	2021-06-24 08:00:00	2021-06-24 08:30:00	t	2204
802	3	4	3	17	4	2021-06-24 08:00:00	2021-06-24 09:00:00	t	2096
803	3	4	3	18	6	2021-06-24 08:00:00	2021-06-24 09:00:00	t	0
805	1	1	1	2	2	2021-06-24 08:30:00	2021-06-24 09:00:00	t	0
806	1	1	1	3	3	2021-06-24 09:00:00	2021-06-24 09:30:00	t	0
807	1	1	1	4	4	2021-06-24 09:30:00	2021-06-24 10:00:00	t	0
812	3	4	3	17	4	2021-06-24 09:00:00	2021-06-24 10:00:00	t	0
813	3	4	3	18	6	2021-06-24 09:00:00	2021-06-24 10:00:00	t	0
816	1	1	1	1	1	2021-06-24 10:00:00	2021-06-24 10:30:00	t	0
814	3	4	3	17	4	2021-06-24 10:00:00	2021-06-24 11:00:00	t	0
815	3	4	3	18	6	2021-06-24 10:00:00	2021-06-24 11:00:00	t	0
817	1	1	1	2	2	2021-06-24 10:30:00	2021-06-24 11:00:00	t	0
818	1	1	1	3	3	2021-06-24 11:00:00	2021-06-24 11:30:00	t	0
819	1	1	1	4	4	2021-06-24 11:30:00	2021-06-24 12:00:00	t	0
824	3	4	3	17	4	2021-06-24 11:00:00	2021-06-24 12:00:00	t	0
825	3	4	3	18	6	2021-06-24 11:00:00	2021-06-24 12:00:00	t	0
829	1	1	1	1	1	2021-06-24 12:00:00	2021-06-24 12:30:00	t	0
827	3	4	3	17	4	2021-06-24 12:00:00	2021-06-24 13:00:00	t	0
828	3	4	3	18	6	2021-06-24 12:00:00	2021-06-24 13:00:00	t	0
830	1	1	1	2	2	2021-06-24 12:30:00	2021-06-24 13:00:00	t	0
831	1	1	1	3	3	2021-06-24 13:00:00	2021-06-24 13:30:00	t	0
832	1	1	1	4	4	2021-06-24 13:30:00	2021-06-24 14:00:00	t	0
826	4	0	0	0	0	2021-06-24 12:00:00	2021-06-25 00:00:00	t	0
834	2	3	2	6	6	2021-06-24 05:00:00	2021-06-24 05:30:00	t	0
835	2	3	2	7	3	2021-06-24 05:30:00	2021-06-24 06:00:00	t	0
836	2	3	2	8	7	2021-06-24 06:00:00	2021-06-24 06:30:00	t	0
845	2	3	2	5	5	2021-06-24 06:30:00	2021-06-24 07:00:00	t	0
846	2	3	2	6	6	2021-06-24 07:00:00	2021-06-24 07:30:00	t	0
800	3	4	3	17	4	2021-06-24 07:00:00	2021-06-24 08:00:00	t	0
847	2	3	2	7	3	2021-06-24 07:30:00	2021-06-24 08:00:00	t	0
848	2	3	2	8	7	2021-06-24 08:00:00	2021-06-24 08:30:00	t	988
857	2	3	2	5	5	2021-06-24 08:30:00	2021-06-24 09:00:00	t	0
858	2	3	2	6	6	2021-06-24 09:00:00	2021-06-24 09:30:00	t	0
859	2	3	2	7	3	2021-06-24 09:30:00	2021-06-24 10:00:00	t	520
860	2	3	2	8	7	2021-06-24 10:00:00	2021-06-24 10:30:00	t	0
869	2	3	2	5	5	2021-06-24 10:30:00	2021-06-24 11:00:00	t	0
870	2	3	2	6	6	2021-06-24 11:00:00	2021-06-24 11:30:00	t	0
871	2	3	2	7	3	2021-06-24 11:30:00	2021-06-24 12:00:00	t	0
872	2	3	2	8	7	2021-06-24 12:00:00	2021-06-24 12:30:00	t	0
881	2	3	2	5	5	2021-06-24 12:30:00	2021-06-24 13:00:00	t	0
882	2	3	2	6	6	2021-06-24 13:00:00	2021-06-24 13:30:00	t	0
837	3	4	3	17	4	2021-06-24 13:00:00	2021-06-24 14:00:00	t	0
838	3	4	3	18	6	2021-06-24 13:00:00	2021-06-24 14:00:00	t	0
883	2	3	2	7	3	2021-06-24 13:30:00	2021-06-24 14:00:00	t	0
841	1	1	1	1	1	2021-06-24 14:00:00	2021-06-24 14:30:00	t	0
884	2	3	2	8	7	2021-06-24 14:00:00	2021-06-24 14:30:00	t	0
839	3	4	3	17	4	2021-06-24 14:00:00	2021-06-24 15:00:00	t	0
840	3	4	3	18	6	2021-06-24 14:00:00	2021-06-24 15:00:00	t	0
842	1	1	1	2	2	2021-06-24 14:30:00	2021-06-24 15:00:00	t	0
893	2	3	2	5	5	2021-06-24 14:30:00	2021-06-24 15:00:00	t	0
894	2	3	2	6	6	2021-06-24 15:00:00	2021-06-24 15:30:00	t	0
844	1	1	1	4	4	2021-06-24 15:30:00	2021-06-24 16:00:00	t	0
849	3	4	3	17	4	2021-06-24 15:00:00	2021-06-24 16:00:00	t	0
850	3	4	3	18	6	2021-06-24 15:00:00	2021-06-24 16:00:00	t	0
895	2	3	2	7	3	2021-06-24 15:30:00	2021-06-24 16:00:00	t	0
853	1	1	1	1	1	2021-06-24 16:00:00	2021-06-24 16:30:00	t	0
896	2	3	2	8	7	2021-06-24 16:00:00	2021-06-24 16:30:00	t	0
851	3	4	3	17	4	2021-06-24 16:00:00	2021-06-24 17:00:00	t	0
852	3	4	3	18	6	2021-06-24 16:00:00	2021-06-24 17:00:00	t	0
854	1	1	1	2	2	2021-06-24 16:30:00	2021-06-24 17:00:00	t	0
906	2	3	2	5	5	2021-06-24 16:30:00	2021-06-24 17:00:00	t	0
855	1	1	1	3	3	2021-06-24 17:00:00	2021-06-24 17:30:00	t	0
856	1	1	1	4	4	2021-06-24 17:30:00	2021-06-24 18:00:00	t	0
861	3	4	3	17	4	2021-06-24 17:00:00	2021-06-24 18:00:00	t	0
862	3	4	3	18	6	2021-06-24 17:00:00	2021-06-24 18:00:00	t	0
865	1	1	1	1	1	2021-06-24 18:00:00	2021-06-24 18:30:00	t	0
863	3	4	3	17	4	2021-06-24 18:00:00	2021-06-24 19:00:00	t	0
864	3	4	3	18	6	2021-06-24 18:00:00	2021-06-24 19:00:00	t	0
867	1	1	1	3	3	2021-06-24 19:00:00	2021-06-24 19:30:00	t	0
868	1	1	1	4	4	2021-06-24 19:30:00	2021-06-24 20:00:00	t	0
873	3	4	3	17	4	2021-06-24 19:00:00	2021-06-24 20:00:00	t	0
874	3	4	3	18	6	2021-06-24 19:00:00	2021-06-24 20:00:00	t	0
877	1	1	1	1	1	2021-06-24 20:00:00	2021-06-24 20:30:00	t	0
875	3	4	3	17	4	2021-06-24 20:00:00	2021-06-24 21:00:00	t	0
876	3	4	3	18	6	2021-06-24 20:00:00	2021-06-24 21:00:00	t	0
878	1	1	1	2	2	2021-06-24 20:30:00	2021-06-24 21:00:00	t	0
879	1	1	1	3	3	2021-06-24 21:00:00	2021-06-24 21:30:00	t	0
880	1	1	1	4	4	2021-06-24 21:30:00	2021-06-24 22:00:00	t	0
885	3	4	3	17	4	2021-06-24 21:00:00	2021-06-24 22:00:00	t	0
886	3	4	3	18	6	2021-06-24 21:00:00	2021-06-24 22:00:00	t	0
889	1	1	1	1	1	2021-06-24 22:00:00	2021-06-24 22:30:00	t	0
887	3	4	3	17	4	2021-06-24 22:00:00	2021-06-24 23:00:00	t	0
888	3	4	3	18	6	2021-06-24 22:00:00	2021-06-24 23:00:00	t	0
890	1	1	1	2	2	2021-06-24 22:30:00	2021-06-24 23:00:00	t	0
891	1	1	1	3	3	2021-06-24 23:00:00	2021-06-24 23:30:00	t	0
892	1	1	1	4	4	2021-06-24 23:30:00	2021-06-25 00:00:00	t	0
897	3	4	3	17	4	2021-06-24 23:00:00	2021-06-25 00:00:00	t	0
898	3	4	3	18	6	2021-06-24 23:00:00	2021-06-25 00:00:00	t	0
902	1	1	1	1	1	2021-06-25 00:00:00	2021-06-25 00:30:00	t	0
900	3	4	3	17	4	2021-06-25 00:00:00	2021-06-25 01:00:00	t	0
901	3	4	3	18	6	2021-06-25 00:00:00	2021-06-25 01:00:00	t	0
903	1	1	1	2	2	2021-06-25 00:30:00	2021-06-25 01:00:00	t	0
904	1	1	1	3	3	2021-06-25 01:00:00	2021-06-25 01:30:00	t	0
905	1	1	1	4	4	2021-06-25 01:30:00	2021-06-25 02:00:00	t	0
843	1	1	1	3	3	2021-06-24 15:00:00	2021-06-24 15:30:00	t	0
907	2	3	2	6	6	2021-06-24 17:00:00	2021-06-24 17:30:00	t	0
908	2	3	2	7	3	2021-06-24 17:30:00	2021-06-24 18:00:00	t	0
909	2	3	2	8	7	2021-06-24 18:00:00	2021-06-24 18:30:00	t	0
866	1	1	1	2	2	2021-06-24 18:30:00	2021-06-24 19:00:00	t	0
918	2	3	2	5	5	2021-06-24 18:30:00	2021-06-24 19:00:00	t	0
919	2	3	2	6	6	2021-06-24 19:00:00	2021-06-24 19:30:00	t	0
920	2	3	2	7	3	2021-06-24 19:30:00	2021-06-24 20:00:00	t	0
921	2	3	2	8	7	2021-06-24 20:00:00	2021-06-24 20:30:00	t	0
930	2	3	2	5	5	2021-06-24 20:30:00	2021-06-24 21:00:00	t	0
931	2	3	2	6	6	2021-06-24 21:00:00	2021-06-24 21:30:00	t	0
932	2	3	2	7	3	2021-06-24 21:30:00	2021-06-24 22:00:00	t	0
933	2	3	2	8	7	2021-06-24 22:00:00	2021-06-24 22:30:00	t	0
942	2	3	2	5	5	2021-06-24 22:30:00	2021-06-24 23:00:00	t	0
943	2	3	2	6	6	2021-06-24 23:00:00	2021-06-24 23:30:00	t	0
944	2	3	2	7	3	2021-06-24 23:30:00	2021-06-25 00:00:00	t	0
945	2	3	2	8	7	2021-06-25 00:00:00	2021-06-25 00:30:00	t	0
954	2	3	2	5	5	2021-06-25 00:30:00	2021-06-25 01:00:00	t	0
955	2	3	2	6	6	2021-06-25 01:00:00	2021-06-25 01:30:00	t	0
910	3	4	3	17	4	2021-06-25 01:00:00	2021-06-25 02:00:00	t	0
911	3	4	3	18	6	2021-06-25 01:00:00	2021-06-25 02:00:00	t	0
956	2	3	2	7	3	2021-06-25 01:30:00	2021-06-25 02:00:00	t	0
914	1	1	1	1	1	2021-06-25 02:00:00	2021-06-25 02:30:00	t	0
957	2	3	2	8	7	2021-06-25 02:00:00	2021-06-25 02:30:00	t	0
913	3	4	3	18	6	2021-06-25 02:00:00	2021-06-25 03:00:00	t	0
915	1	1	1	2	2	2021-06-25 02:30:00	2021-06-25 03:00:00	t	0
966	2	3	2	5	5	2021-06-25 02:30:00	2021-06-25 03:00:00	t	0
916	1	1	1	3	3	2021-06-25 03:00:00	2021-06-25 03:30:00	t	0
967	2	3	2	6	6	2021-06-25 03:00:00	2021-06-25 03:30:00	t	0
917	1	1	1	4	4	2021-06-25 03:30:00	2021-06-25 04:00:00	t	0
922	3	4	3	17	4	2021-06-25 03:00:00	2021-06-25 04:00:00	t	2099
923	3	4	3	18	6	2021-06-25 03:00:00	2021-06-25 04:00:00	t	1421
968	2	3	2	7	3	2021-06-25 03:30:00	2021-06-25 04:00:00	t	0
926	1	1	1	1	1	2021-06-25 04:00:00	2021-06-25 04:30:00	t	0
969	2	3	2	8	7	2021-06-25 04:00:00	2021-06-25 04:30:00	t	530
924	3	4	3	17	4	2021-06-25 04:00:00	2021-06-25 05:00:00	t	530
925	3	4	3	18	6	2021-06-25 04:00:00	2021-06-25 05:00:00	t	1802
927	1	1	1	2	2	2021-06-25 04:30:00	2021-06-25 05:00:00	t	0
928	1	1	1	3	3	2021-06-25 05:00:00	2021-06-25 05:30:00	t	0
929	1	1	1	4	4	2021-06-25 05:30:00	2021-06-25 06:00:00	t	1431
934	3	4	3	17	4	2021-06-25 05:00:00	2021-06-25 06:00:00	t	0
935	3	4	3	18	6	2021-06-25 05:00:00	2021-06-25 06:00:00	t	1007
938	1	1	1	1	1	2021-06-25 06:00:00	2021-06-25 06:30:00	t	2637
936	3	4	3	17	4	2021-06-25 06:00:00	2021-06-25 07:00:00	t	978
937	3	4	3	18	6	2021-06-25 06:00:00	2021-06-25 07:00:00	t	515
939	1	1	1	2	2	2021-06-25 06:30:00	2021-06-25 07:00:00	t	0
941	1	1	1	4	4	2021-06-25 07:30:00	2021-06-25 08:00:00	t	2120
946	3	4	3	17	4	2021-06-25 07:00:00	2021-06-25 08:00:00	t	530
947	3	4	3	18	6	2021-06-25 07:00:00	2021-06-25 08:00:00	t	1439
950	1	1	1	1	1	2021-06-25 08:00:00	2021-06-25 08:30:00	t	0
948	3	4	3	17	4	2021-06-25 08:00:00	2021-06-25 09:00:00	t	0
949	3	4	3	18	6	2021-06-25 08:00:00	2021-06-25 09:00:00	t	0
951	1	1	1	2	2	2021-06-25 08:30:00	2021-06-25 09:00:00	t	0
952	1	1	1	3	3	2021-06-25 09:00:00	2021-06-25 09:30:00	t	535
953	1	1	1	4	4	2021-06-25 09:30:00	2021-06-25 10:00:00	t	0
958	3	4	3	17	4	2021-06-25 09:00:00	2021-06-25 10:00:00	t	0
959	3	4	3	18	6	2021-06-25 09:00:00	2021-06-25 10:00:00	t	0
962	1	1	1	1	1	2021-06-25 10:00:00	2021-06-25 10:30:00	t	0
960	3	4	3	17	4	2021-06-25 10:00:00	2021-06-25 11:00:00	t	1818
961	3	4	3	18	6	2021-06-25 10:00:00	2021-06-25 11:00:00	t	1016
963	1	1	1	2	2	2021-06-25 10:30:00	2021-06-25 11:00:00	t	1016
964	1	1	1	3	3	2021-06-25 11:00:00	2021-06-25 11:30:00	t	0
965	1	1	1	4	4	2021-06-25 11:30:00	2021-06-25 12:00:00	t	0
970	3	4	3	17	4	2021-06-25 11:00:00	2021-06-25 12:00:00	t	0
971	3	4	3	18	6	2021-06-25 11:00:00	2021-06-25 12:00:00	t	0
975	1	1	1	1	1	2021-06-25 12:00:00	2021-06-25 12:30:00	t	0
973	3	4	3	17	4	2021-06-25 12:00:00	2021-06-25 13:00:00	t	0
974	3	4	3	18	6	2021-06-25 12:00:00	2021-06-25 13:00:00	t	0
976	1	1	1	2	2	2021-06-25 12:30:00	2021-06-25 13:00:00	t	0
977	1	1	1	3	3	2021-06-25 13:00:00	2021-06-25 13:30:00	t	0
978	1	1	1	4	4	2021-06-25 13:30:00	2021-06-25 14:00:00	t	0
972	4	0	0	0	0	2021-06-25 12:00:00	2021-06-26 00:00:00	t	0
912	3	4	3	17	4	2021-06-25 02:00:00	2021-06-25 03:00:00	t	0
979	2	3	2	5	5	2021-06-25 04:30:00	2021-06-25 05:00:00	t	0
980	2	3	2	6	6	2021-06-25 05:00:00	2021-06-25 05:30:00	t	0
981	2	3	2	7	3	2021-06-25 05:30:00	2021-06-25 06:00:00	t	0
982	2	3	2	8	7	2021-06-25 06:00:00	2021-06-25 06:30:00	t	978
991	2	3	2	5	5	2021-06-25 06:30:00	2021-06-25 07:00:00	t	0
940	1	1	1	3	3	2021-06-25 07:00:00	2021-06-25 07:30:00	t	0
992	2	3	2	6	6	2021-06-25 07:00:00	2021-06-25 07:30:00	t	0
993	2	3	2	7	3	2021-06-25 07:30:00	2021-06-25 08:00:00	t	0
997	7	3	2	5	5	2021-06-25 07:30:00	2021-06-25 08:00:00	t	1818
1013	28	3	2	5	5	2021-06-25 07:30:00	2021-06-25 08:00:00	t	0
994	2	3	2	8	7	2021-06-25 08:00:00	2021-06-25 08:30:00	t	0
998	7	3	2	6	6	2021-06-25 08:00:00	2021-06-25 08:30:00	t	0
1014	28	3	2	6	6	2021-06-25 08:00:00	2021-06-25 08:30:00	t	0
999	7	3	2	7	3	2021-06-25 08:30:00	2021-06-25 09:00:00	t	515
1015	28	3	2	7	3	2021-06-25 08:30:00	2021-06-25 09:00:00	t	988
1043	2	3	2	5	5	2021-06-25 08:30:00	2021-06-25 09:00:00	t	0
1000	7	3	2	8	7	2021-06-25 09:00:00	2021-06-25 09:30:00	t	0
1016	28	3	2	8	7	2021-06-25 09:00:00	2021-06-25 09:30:00	t	0
1044	2	3	2	6	6	2021-06-25 09:00:00	2021-06-25 09:30:00	t	0
1017	28	3	2	5	5	2021-06-25 09:30:00	2021-06-25 10:00:00	t	0
1045	2	3	2	7	3	2021-06-25 09:30:00	2021-06-25 10:00:00	t	0
1002	7	3	2	6	6	2021-06-25 10:00:00	2021-06-25 10:30:00	t	0
1018	28	3	2	6	6	2021-06-25 10:00:00	2021-06-25 10:30:00	t	0
1046	2	3	2	8	7	2021-06-25 10:00:00	2021-06-25 10:30:00	t	0
1003	7	3	2	7	3	2021-06-25 10:30:00	2021-06-25 11:00:00	t	0
1019	28	3	2	7	3	2021-06-25 10:30:00	2021-06-25 11:00:00	t	0
1004	7	3	2	8	7	2021-06-25 11:00:00	2021-06-25 11:30:00	t	0
1020	28	3	2	8	7	2021-06-25 11:00:00	2021-06-25 11:30:00	t	0
1005	7	3	2	5	5	2021-06-25 11:30:00	2021-06-25 12:00:00	t	0
1021	28	3	2	5	5	2021-06-25 11:30:00	2021-06-25 12:00:00	t	0
1006	7	3	2	6	6	2021-06-25 12:00:00	2021-06-25 12:30:00	t	0
1022	28	3	2	6	6	2021-06-25 12:00:00	2021-06-25 12:30:00	t	0
1007	7	3	2	7	3	2021-06-25 12:30:00	2021-06-25 13:00:00	t	0
1023	28	3	2	7	3	2021-06-25 12:30:00	2021-06-25 13:00:00	t	0
1008	7	3	2	8	7	2021-06-25 13:00:00	2021-06-25 13:30:00	t	0
1024	28	3	2	8	7	2021-06-25 13:00:00	2021-06-25 13:30:00	t	0
983	3	4	3	17	4	2021-06-25 13:00:00	2021-06-25 14:00:00	t	0
984	3	4	3	18	6	2021-06-25 13:00:00	2021-06-25 14:00:00	t	0
1009	7	3	2	5	5	2021-06-25 13:30:00	2021-06-25 14:00:00	t	0
1025	28	3	2	5	5	2021-06-25 13:30:00	2021-06-25 14:00:00	t	0
987	1	1	1	1	1	2021-06-25 14:00:00	2021-06-25 14:30:00	t	0
1010	7	3	2	6	6	2021-06-25 14:00:00	2021-06-25 14:30:00	t	0
1026	28	3	2	6	6	2021-06-25 14:00:00	2021-06-25 14:30:00	t	0
985	3	4	3	17	4	2021-06-25 14:00:00	2021-06-25 15:00:00	t	0
986	3	4	3	18	6	2021-06-25 14:00:00	2021-06-25 15:00:00	t	0
1011	7	3	2	7	3	2021-06-25 14:30:00	2021-06-25 15:00:00	t	0
1027	28	3	2	7	3	2021-06-25 14:30:00	2021-06-25 15:00:00	t	0
989	1	1	1	3	3	2021-06-25 15:00:00	2021-06-25 15:30:00	t	0
1012	7	3	2	8	7	2021-06-25 15:00:00	2021-06-25 15:30:00	t	0
1028	28	3	2	8	7	2021-06-25 15:00:00	2021-06-25 15:30:00	t	0
990	1	1	1	4	4	2021-06-25 15:30:00	2021-06-25 16:00:00	t	0
995	3	4	3	17	4	2021-06-25 15:00:00	2021-06-25 16:00:00	t	0
996	3	4	3	18	6	2021-06-25 15:00:00	2021-06-25 16:00:00	t	0
1029	28	3	2	5	5	2021-06-25 15:30:00	2021-06-25 16:00:00	t	0
1033	7	3	2	5	5	2021-06-25 15:30:00	2021-06-25 16:00:00	t	0
1030	28	3	2	6	6	2021-06-25 16:00:00	2021-06-25 16:30:00	t	0
1034	7	3	2	6	6	2021-06-25 16:00:00	2021-06-25 16:30:00	t	0
1039	1	1	1	1	1	2021-06-25 16:00:00	2021-06-25 16:30:00	t	0
1031	28	3	2	7	3	2021-06-25 16:30:00	2021-06-25 17:00:00	t	0
1035	7	3	2	7	3	2021-06-25 16:30:00	2021-06-25 17:00:00	t	0
1037	3	4	3	17	4	2021-06-25 16:00:00	2021-06-25 17:00:00	t	0
1038	3	4	3	18	6	2021-06-25 16:00:00	2021-06-25 17:00:00	t	0
1040	1	1	1	2	2	2021-06-25 16:30:00	2021-06-25 17:00:00	t	0
1032	28	3	2	8	7	2021-06-25 17:00:00	2021-06-25 17:30:00	t	0
1036	7	3	2	8	7	2021-06-25 17:00:00	2021-06-25 17:30:00	t	0
1041	1	1	1	3	3	2021-06-25 17:00:00	2021-06-25 17:30:00	t	0
1042	1	1	1	4	4	2021-06-25 17:30:00	2021-06-25 18:00:00	t	0
1047	3	4	3	17	4	2021-06-25 17:00:00	2021-06-25 18:00:00	t	0
1048	3	4	3	18	6	2021-06-25 17:00:00	2021-06-25 18:00:00	t	0
1049	28	3	2	5	5	2021-06-25 17:30:00	2021-06-25 18:00:00	t	0
1050	28	3	2	6	6	2021-06-25 18:00:00	2021-06-25 18:30:00	t	0
1001	7	3	2	5	5	2021-06-25 09:30:00	2021-06-25 10:00:00	t	0
1063	2	3	2	5	5	2021-06-25 10:30:00	2021-06-25 11:00:00	t	0
1064	2	3	2	6	6	2021-06-25 11:00:00	2021-06-25 11:30:00	t	0
899	4	0	0	0	0	2021-06-25 00:00:00	2021-06-25 12:00:00	t	0
1065	2	3	2	7	3	2021-06-25 11:30:00	2021-06-25 12:00:00	t	0
1066	2	3	2	8	7	2021-06-25 12:00:00	2021-06-25 12:30:00	t	0
1083	2	3	2	5	5	2021-06-25 12:30:00	2021-06-25 13:00:00	t	0
1084	2	3	2	6	6	2021-06-25 13:00:00	2021-06-25 13:30:00	t	0
1085	2	3	2	7	3	2021-06-25 13:30:00	2021-06-25 14:00:00	t	0
1086	2	3	2	8	7	2021-06-25 14:00:00	2021-06-25 14:30:00	t	0
1103	2	3	2	5	5	2021-06-25 14:30:00	2021-06-25 15:00:00	t	0
1104	2	3	2	6	6	2021-06-25 15:00:00	2021-06-25 15:30:00	t	0
1105	2	3	2	7	3	2021-06-25 15:30:00	2021-06-25 16:00:00	t	0
1106	2	3	2	8	7	2021-06-25 16:00:00	2021-06-25 16:30:00	t	0
1053	7	3	2	5	5	2021-06-25 17:30:00	2021-06-25 18:00:00	t	0
1054	7	3	2	6	6	2021-06-25 18:00:00	2021-06-25 18:30:00	t	0
1059	1	1	1	1	1	2021-06-25 18:00:00	2021-06-25 18:30:00	t	0
1051	28	3	2	7	3	2021-06-25 18:30:00	2021-06-25 19:00:00	t	0
1055	7	3	2	7	3	2021-06-25 18:30:00	2021-06-25 19:00:00	t	0
1057	3	4	3	17	4	2021-06-25 18:00:00	2021-06-25 19:00:00	t	0
1058	3	4	3	18	6	2021-06-25 18:00:00	2021-06-25 19:00:00	t	0
1060	1	1	1	2	2	2021-06-25 18:30:00	2021-06-25 19:00:00	t	0
1052	28	3	2	8	7	2021-06-25 19:00:00	2021-06-25 19:30:00	t	0
1056	7	3	2	8	7	2021-06-25 19:00:00	2021-06-25 19:30:00	t	0
1061	1	1	1	3	3	2021-06-25 19:00:00	2021-06-25 19:30:00	t	0
1062	1	1	1	4	4	2021-06-25 19:30:00	2021-06-25 20:00:00	t	0
1067	3	4	3	17	4	2021-06-25 19:00:00	2021-06-25 20:00:00	t	0
1068	3	4	3	18	6	2021-06-25 19:00:00	2021-06-25 20:00:00	t	0
1069	28	3	2	5	5	2021-06-25 19:30:00	2021-06-25 20:00:00	t	0
1073	7	3	2	5	5	2021-06-25 19:30:00	2021-06-25 20:00:00	t	0
1070	28	3	2	6	6	2021-06-25 20:00:00	2021-06-25 20:30:00	t	0
1074	7	3	2	6	6	2021-06-25 20:00:00	2021-06-25 20:30:00	t	0
1079	1	1	1	1	1	2021-06-25 20:00:00	2021-06-25 20:30:00	t	0
1071	28	3	2	7	3	2021-06-25 20:30:00	2021-06-25 21:00:00	t	0
1075	7	3	2	7	3	2021-06-25 20:30:00	2021-06-25 21:00:00	t	0
1077	3	4	3	17	4	2021-06-25 20:00:00	2021-06-25 21:00:00	t	0
1078	3	4	3	18	6	2021-06-25 20:00:00	2021-06-25 21:00:00	t	0
1080	1	1	1	2	2	2021-06-25 20:30:00	2021-06-25 21:00:00	t	0
1072	28	3	2	8	7	2021-06-25 21:00:00	2021-06-25 21:30:00	t	0
1076	7	3	2	8	7	2021-06-25 21:00:00	2021-06-25 21:30:00	t	0
1081	1	1	1	3	3	2021-06-25 21:00:00	2021-06-25 21:30:00	t	0
1082	1	1	1	4	4	2021-06-25 21:30:00	2021-06-25 22:00:00	t	0
1087	3	4	3	17	4	2021-06-25 21:00:00	2021-06-25 22:00:00	t	0
1088	3	4	3	18	6	2021-06-25 21:00:00	2021-06-25 22:00:00	t	0
1089	28	3	2	5	5	2021-06-25 21:30:00	2021-06-25 22:00:00	t	0
1093	7	3	2	5	5	2021-06-25 21:30:00	2021-06-25 22:00:00	t	0
1090	28	3	2	6	6	2021-06-25 22:00:00	2021-06-25 22:30:00	t	0
1094	7	3	2	6	6	2021-06-25 22:00:00	2021-06-25 22:30:00	t	0
1099	1	1	1	1	1	2021-06-25 22:00:00	2021-06-25 22:30:00	t	0
1091	28	3	2	7	3	2021-06-25 22:30:00	2021-06-25 23:00:00	t	0
1095	7	3	2	7	3	2021-06-25 22:30:00	2021-06-25 23:00:00	t	0
1097	3	4	3	17	4	2021-06-25 22:00:00	2021-06-25 23:00:00	t	0
1098	3	4	3	18	6	2021-06-25 22:00:00	2021-06-25 23:00:00	t	0
1100	1	1	1	2	2	2021-06-25 22:30:00	2021-06-25 23:00:00	t	0
1092	28	3	2	8	7	2021-06-25 23:00:00	2021-06-25 23:30:00	t	0
1096	7	3	2	8	7	2021-06-25 23:00:00	2021-06-25 23:30:00	t	0
1101	1	1	1	3	3	2021-06-25 23:00:00	2021-06-25 23:30:00	t	0
1102	1	1	1	4	4	2021-06-25 23:30:00	2021-06-26 00:00:00	t	0
1107	3	4	3	17	4	2021-06-25 23:00:00	2021-06-26 00:00:00	t	0
1108	3	4	3	18	6	2021-06-25 23:00:00	2021-06-26 00:00:00	t	0
1109	28	3	2	5	5	2021-06-25 23:30:00	2021-06-26 00:00:00	t	0
1113	7	3	2	5	5	2021-06-25 23:30:00	2021-06-26 00:00:00	t	0
1110	28	3	2	6	6	2021-06-26 00:00:00	2021-06-26 00:30:00	t	0
1114	7	3	2	6	6	2021-06-26 00:00:00	2021-06-26 00:30:00	t	0
1111	28	3	2	7	3	2021-06-26 00:30:00	2021-06-26 01:00:00	t	0
1115	7	3	2	7	3	2021-06-26 00:30:00	2021-06-26 01:00:00	t	0
1112	28	3	2	8	7	2021-06-26 01:00:00	2021-06-26 01:30:00	t	0
1255	7	3	2	5	5	2021-06-26 13:30:00	2021-06-26 14:00:00	t	0
1252	28	3	2	6	6	2021-06-26 14:00:00	2021-06-26 14:30:00	t	0
1256	7	3	2	6	6	2021-06-26 14:00:00	2021-06-26 14:30:00	t	0
1253	28	3	2	7	3	2021-06-26 14:30:00	2021-06-26 15:00:00	t	0
1254	28	3	2	8	7	2021-06-26 15:00:00	2021-06-26 15:30:00	t	0
988	1	1	1	2	2	2021-06-25 14:30:00	2021-06-25 15:00:00	t	0
1132	28	3	2	7	3	2021-06-26 02:30:00	2021-06-26 03:00:00	t	0
1124	2	3	2	5	5	2021-06-25 16:30:00	2021-06-25 17:00:00	t	0
1125	2	3	2	6	6	2021-06-25 17:00:00	2021-06-25 17:30:00	t	0
1126	2	3	2	7	3	2021-06-25 17:30:00	2021-06-25 18:00:00	t	0
1127	2	3	2	8	7	2021-06-25 18:00:00	2021-06-25 18:30:00	t	0
1144	2	3	2	5	5	2021-06-25 18:30:00	2021-06-25 19:00:00	t	0
1145	2	3	2	6	6	2021-06-25 19:00:00	2021-06-25 19:30:00	t	0
1136	7	3	2	7	3	2021-06-26 02:30:00	2021-06-26 03:00:00	t	0
1146	2	3	2	7	3	2021-06-25 19:30:00	2021-06-25 20:00:00	t	0
1147	2	3	2	8	7	2021-06-25 20:00:00	2021-06-25 20:30:00	t	0
1164	2	3	2	5	5	2021-06-25 20:30:00	2021-06-25 21:00:00	t	0
1165	2	3	2	6	6	2021-06-25 21:00:00	2021-06-25 21:30:00	t	0
1167	2	3	2	8	7	2021-06-25 22:00:00	2021-06-25 22:30:00	t	0
1184	2	3	2	5	5	2021-06-25 22:30:00	2021-06-25 23:00:00	t	0
1185	2	3	2	6	6	2021-06-25 23:00:00	2021-06-25 23:30:00	t	0
1186	2	3	2	7	3	2021-06-25 23:30:00	2021-06-26 00:00:00	t	0
1120	1	1	1	1	1	2021-06-26 00:00:00	2021-06-26 00:30:00	t	0
1187	2	3	2	8	7	2021-06-26 00:00:00	2021-06-26 00:30:00	t	0
1118	3	4	3	17	4	2021-06-26 00:00:00	2021-06-26 01:00:00	t	0
1121	1	1	1	2	2	2021-06-26 00:30:00	2021-06-26 01:00:00	t	0
1116	7	3	2	8	7	2021-06-26 01:00:00	2021-06-26 01:30:00	t	0
1122	1	1	1	3	3	2021-06-26 01:00:00	2021-06-26 01:30:00	t	0
1123	1	1	1	4	4	2021-06-26 01:30:00	2021-06-26 02:00:00	t	0
1128	3	4	3	17	4	2021-06-26 01:00:00	2021-06-26 02:00:00	t	0
1129	3	4	3	18	6	2021-06-26 01:00:00	2021-06-26 02:00:00	t	0
1130	28	3	2	5	5	2021-06-26 01:30:00	2021-06-26 02:00:00	t	0
1134	7	3	2	5	5	2021-06-26 01:30:00	2021-06-26 02:00:00	t	0
1131	28	3	2	6	6	2021-06-26 02:00:00	2021-06-26 02:30:00	t	0
1135	7	3	2	6	6	2021-06-26 02:00:00	2021-06-26 02:30:00	t	0
1140	1	1	1	1	1	2021-06-26 02:00:00	2021-06-26 02:30:00	t	0
1138	3	4	3	17	4	2021-06-26 02:00:00	2021-06-26 03:00:00	t	0
1139	3	4	3	18	6	2021-06-26 02:00:00	2021-06-26 03:00:00	t	0
1141	1	1	1	2	2	2021-06-26 02:30:00	2021-06-26 03:00:00	t	0
1133	28	3	2	8	7	2021-06-26 03:00:00	2021-06-26 03:30:00	t	0
1137	7	3	2	8	7	2021-06-26 03:00:00	2021-06-26 03:30:00	t	0
1142	1	1	1	3	3	2021-06-26 03:00:00	2021-06-26 03:30:00	t	0
1143	1	1	1	4	4	2021-06-26 03:30:00	2021-06-26 04:00:00	t	0
1148	3	4	3	17	4	2021-06-26 03:00:00	2021-06-26 04:00:00	t	0
1149	3	4	3	18	6	2021-06-26 03:00:00	2021-06-26 04:00:00	t	0
1150	28	3	2	5	5	2021-06-26 03:30:00	2021-06-26 04:00:00	t	0
1154	7	3	2	5	5	2021-06-26 03:30:00	2021-06-26 04:00:00	t	0
1151	28	3	2	6	6	2021-06-26 04:00:00	2021-06-26 04:30:00	t	0
1155	7	3	2	6	6	2021-06-26 04:00:00	2021-06-26 04:30:00	t	0
1160	1	1	1	1	1	2021-06-26 04:00:00	2021-06-26 04:30:00	t	0
1152	28	3	2	7	3	2021-06-26 04:30:00	2021-06-26 05:00:00	t	0
1158	3	4	3	17	4	2021-06-26 04:00:00	2021-06-26 05:00:00	t	0
1159	3	4	3	18	6	2021-06-26 04:00:00	2021-06-26 05:00:00	t	0
1161	1	1	1	2	2	2021-06-26 04:30:00	2021-06-26 05:00:00	t	0
1153	28	3	2	8	7	2021-06-26 05:00:00	2021-06-26 05:30:00	t	0
1157	7	3	2	8	7	2021-06-26 05:00:00	2021-06-26 05:30:00	t	0
1162	1	1	1	3	3	2021-06-26 05:00:00	2021-06-26 05:30:00	t	0
1163	1	1	1	4	4	2021-06-26 05:30:00	2021-06-26 06:00:00	t	0
1168	3	4	3	17	4	2021-06-26 05:00:00	2021-06-26 06:00:00	t	0
1169	3	4	3	18	6	2021-06-26 05:00:00	2021-06-26 06:00:00	t	0
1170	28	3	2	5	5	2021-06-26 05:30:00	2021-06-26 06:00:00	t	0
1174	7	3	2	5	5	2021-06-26 05:30:00	2021-06-26 06:00:00	t	0
1171	28	3	2	6	6	2021-06-26 06:00:00	2021-06-26 06:30:00	t	0
1175	7	3	2	6	6	2021-06-26 06:00:00	2021-06-26 06:30:00	t	0
1180	1	1	1	1	1	2021-06-26 06:00:00	2021-06-26 06:30:00	t	0
1172	28	3	2	7	3	2021-06-26 06:30:00	2021-06-26 07:00:00	t	0
1176	7	3	2	7	3	2021-06-26 06:30:00	2021-06-26 07:00:00	t	0
1178	3	4	3	17	4	2021-06-26 06:00:00	2021-06-26 07:00:00	t	0
1179	3	4	3	18	6	2021-06-26 06:00:00	2021-06-26 07:00:00	t	0
1181	1	1	1	2	2	2021-06-26 06:30:00	2021-06-26 07:00:00	t	0
1173	28	3	2	8	7	2021-06-26 07:00:00	2021-06-26 07:30:00	t	0
1177	7	3	2	8	7	2021-06-26 07:00:00	2021-06-26 07:30:00	t	0
1182	1	1	1	3	3	2021-06-26 07:00:00	2021-06-26 07:30:00	t	0
1183	1	1	1	4	4	2021-06-26 07:30:00	2021-06-26 08:00:00	t	0
1188	3	4	3	17	4	2021-06-26 07:00:00	2021-06-26 08:00:00	t	0
1189	3	4	3	18	6	2021-06-26 07:00:00	2021-06-26 08:00:00	t	0
1117	4	0	0	0	0	2021-06-26 00:00:00	2021-06-26 12:00:00	t	0
1166	2	3	2	7	3	2021-06-25 21:30:00	2021-06-25 22:00:00	t	0
1119	3	4	3	18	6	2021-06-26 00:00:00	2021-06-26 01:00:00	t	0
1204	2	3	2	5	5	2021-06-26 00:30:00	2021-06-26 01:00:00	t	0
1205	2	3	2	6	6	2021-06-26 01:00:00	2021-06-26 01:30:00	t	0
1206	2	3	2	7	3	2021-06-26 01:30:00	2021-06-26 02:00:00	t	0
1207	2	3	2	8	7	2021-06-26 02:00:00	2021-06-26 02:30:00	t	0
1224	2	3	2	5	5	2021-06-26 02:30:00	2021-06-26 03:00:00	t	0
1225	2	3	2	6	6	2021-06-26 03:00:00	2021-06-26 03:30:00	t	0
1226	2	3	2	7	3	2021-06-26 03:30:00	2021-06-26 04:00:00	t	0
1227	2	3	2	8	7	2021-06-26 04:00:00	2021-06-26 04:30:00	t	0
1265	2	3	2	5	5	2021-06-26 06:30:00	2021-06-26 07:00:00	t	0
1266	2	3	2	6	6	2021-06-26 07:00:00	2021-06-26 07:30:00	t	0
1190	28	3	2	5	5	2021-06-26 07:30:00	2021-06-26 08:00:00	t	0
1194	7	3	2	5	5	2021-06-26 07:30:00	2021-06-26 08:00:00	t	0
1267	2	3	2	7	3	2021-06-26 07:30:00	2021-06-26 08:00:00	t	0
1191	28	3	2	6	6	2021-06-26 08:00:00	2021-06-26 08:30:00	t	0
1195	7	3	2	6	6	2021-06-26 08:00:00	2021-06-26 08:30:00	t	0
1200	1	1	1	1	1	2021-06-26 08:00:00	2021-06-26 08:30:00	t	0
1268	2	3	2	8	7	2021-06-26 08:00:00	2021-06-26 08:30:00	t	0
1192	28	3	2	7	3	2021-06-26 08:30:00	2021-06-26 09:00:00	t	0
1196	7	3	2	7	3	2021-06-26 08:30:00	2021-06-26 09:00:00	t	0
1198	3	4	3	17	4	2021-06-26 08:00:00	2021-06-26 09:00:00	t	0
1199	3	4	3	18	6	2021-06-26 08:00:00	2021-06-26 09:00:00	t	0
1201	1	1	1	2	2	2021-06-26 08:30:00	2021-06-26 09:00:00	t	0
1193	28	3	2	8	7	2021-06-26 09:00:00	2021-06-26 09:30:00	t	0
1197	7	3	2	8	7	2021-06-26 09:00:00	2021-06-26 09:30:00	t	0
1202	1	1	1	3	3	2021-06-26 09:00:00	2021-06-26 09:30:00	t	0
1203	1	1	1	4	4	2021-06-26 09:30:00	2021-06-26 10:00:00	t	0
1208	3	4	3	17	4	2021-06-26 09:00:00	2021-06-26 10:00:00	t	0
1209	3	4	3	18	6	2021-06-26 09:00:00	2021-06-26 10:00:00	t	0
1210	28	3	2	5	5	2021-06-26 09:30:00	2021-06-26 10:00:00	t	0
1214	7	3	2	5	5	2021-06-26 09:30:00	2021-06-26 10:00:00	t	0
1211	28	3	2	6	6	2021-06-26 10:00:00	2021-06-26 10:30:00	t	0
1215	7	3	2	6	6	2021-06-26 10:00:00	2021-06-26 10:30:00	t	0
1220	1	1	1	1	1	2021-06-26 10:00:00	2021-06-26 10:30:00	t	0
1212	28	3	2	7	3	2021-06-26 10:30:00	2021-06-26 11:00:00	t	0
1216	7	3	2	7	3	2021-06-26 10:30:00	2021-06-26 11:00:00	t	0
1218	3	4	3	17	4	2021-06-26 10:00:00	2021-06-26 11:00:00	t	0
1219	3	4	3	18	6	2021-06-26 10:00:00	2021-06-26 11:00:00	t	0
1221	1	1	1	2	2	2021-06-26 10:30:00	2021-06-26 11:00:00	t	0
1213	28	3	2	8	7	2021-06-26 11:00:00	2021-06-26 11:30:00	t	0
1217	7	3	2	8	7	2021-06-26 11:00:00	2021-06-26 11:30:00	t	0
1222	1	1	1	3	3	2021-06-26 11:00:00	2021-06-26 11:30:00	t	0
1223	1	1	1	4	4	2021-06-26 11:30:00	2021-06-26 12:00:00	t	0
1228	3	4	3	17	4	2021-06-26 11:00:00	2021-06-26 12:00:00	t	0
1229	3	4	3	18	6	2021-06-26 11:00:00	2021-06-26 12:00:00	t	0
1230	28	3	2	5	5	2021-06-26 11:30:00	2021-06-26 12:00:00	t	0
1234	7	3	2	5	5	2021-06-26 11:30:00	2021-06-26 12:00:00	t	0
1231	28	3	2	6	6	2021-06-26 12:00:00	2021-06-26 12:30:00	t	0
1235	7	3	2	6	6	2021-06-26 12:00:00	2021-06-26 12:30:00	t	0
1239	3	4	3	17	4	2021-06-26 12:00:00	2021-06-26 13:00:00	t	0
1240	3	4	3	18	6	2021-06-26 12:00:00	2021-06-26 13:00:00	t	0
1232	28	3	2	7	3	2021-06-26 12:30:00	2021-06-26 13:00:00	t	0
1236	7	3	2	7	3	2021-06-26 12:30:00	2021-06-26 13:00:00	t	0
1233	28	3	2	8	7	2021-06-26 13:00:00	2021-06-26 13:30:00	t	0
1237	7	3	2	8	7	2021-06-26 13:00:00	2021-06-26 13:30:00	t	0
1257	7	3	2	7	3	2021-06-26 14:30:00	2021-06-26 15:00:00	t	0
1258	7	3	2	8	7	2021-06-26 15:00:00	2021-06-26 15:30:00	t	0
1271	28	3	2	5	5	2021-06-26 15:30:00	2021-06-26 16:00:00	t	0
1272	28	3	2	6	6	2021-06-26 16:00:00	2021-06-26 16:30:00	t	0
1273	28	3	2	7	3	2021-06-26 16:30:00	2021-06-26 17:00:00	t	0
1274	28	3	2	8	7	2021-06-26 17:00:00	2021-06-26 17:30:00	t	0
1275	28	3	2	5	5	2021-06-26 17:30:00	2021-06-26 18:00:00	t	0
1276	28	3	2	6	6	2021-06-26 18:00:00	2021-06-26 18:30:00	t	0
1277	28	3	2	7	3	2021-06-26 18:30:00	2021-06-26 19:00:00	t	0
1278	28	3	2	8	7	2021-06-26 19:00:00	2021-06-26 19:30:00	t	0
1279	28	3	2	5	5	2021-06-26 19:30:00	2021-06-26 20:00:00	t	0
2775	34	13	7	36	7	2021-06-30 01:30:00	2021-06-30 01:40:00	t	0
2776	34	13	7	35	6	2021-06-30 01:30:00	2021-06-30 01:40:00	t	0
2777	33	12	9	44	3	2021-06-30 01:30:00	2021-06-30 01:40:00	t	0
2773	35	11	9	43	2	2021-06-30 01:40:00	2021-06-30 01:50:00	t	0
2774	35	11	9	42	1	2021-06-30 01:50:00	2021-06-30 02:00:00	t	0
1289	28	3	2	7	3	2021-06-27 00:30:00	2021-06-27 01:00:00	t	0
1290	28	3	2	8	7	2021-06-27 01:00:00	2021-06-27 01:30:00	t	0
1291	28	3	2	5	5	2021-06-27 01:30:00	2021-06-27 02:00:00	t	0
1292	28	3	2	6	6	2021-06-27 02:00:00	2021-06-27 02:30:00	t	0
1293	28	3	2	7	3	2021-06-27 02:30:00	2021-06-27 03:00:00	t	0
1294	28	3	2	8	7	2021-06-27 03:00:00	2021-06-27 03:30:00	t	0
1295	28	3	2	5	5	2021-06-27 03:30:00	2021-06-27 04:00:00	t	0
1296	28	3	2	6	6	2021-06-27 04:00:00	2021-06-27 04:30:00	t	0
1297	28	3	2	7	3	2021-06-27 04:30:00	2021-06-27 05:00:00	t	0
1298	28	3	2	8	7	2021-06-27 05:00:00	2021-06-27 05:30:00	t	0
1319	7	3	2	5	5	2021-06-26 15:30:00	2021-06-26 16:00:00	t	0
1320	7	3	2	6	6	2021-06-26 16:00:00	2021-06-26 16:30:00	t	0
1321	7	3	2	7	3	2021-06-26 16:30:00	2021-06-26 17:00:00	t	0
1322	7	3	2	8	7	2021-06-26 17:00:00	2021-06-26 17:30:00	t	0
1323	7	3	2	5	5	2021-06-26 17:30:00	2021-06-26 18:00:00	t	0
1324	7	3	2	6	6	2021-06-26 18:00:00	2021-06-26 18:30:00	t	0
1325	7	3	2	7	3	2021-06-26 18:30:00	2021-06-26 19:00:00	t	0
1327	7	3	2	5	5	2021-06-26 19:30:00	2021-06-26 20:00:00	t	0
1328	7	3	2	6	6	2021-06-26 20:00:00	2021-06-26 20:30:00	t	0
1329	7	3	2	7	3	2021-06-26 20:30:00	2021-06-26 21:00:00	t	0
1330	7	3	2	8	7	2021-06-26 21:00:00	2021-06-26 21:30:00	t	0
1331	7	3	2	5	5	2021-06-26 21:30:00	2021-06-26 22:00:00	t	0
1332	7	3	2	6	6	2021-06-26 22:00:00	2021-06-26 22:30:00	t	0
1333	7	3	2	7	3	2021-06-26 22:30:00	2021-06-26 23:00:00	t	0
1334	7	3	2	8	7	2021-06-26 23:00:00	2021-06-26 23:30:00	t	0
1335	7	3	2	5	5	2021-06-26 23:30:00	2021-06-27 00:00:00	t	0
1336	7	3	2	6	6	2021-06-27 00:00:00	2021-06-27 00:30:00	t	0
1337	7	3	2	7	3	2021-06-27 00:30:00	2021-06-27 01:00:00	t	0
1338	7	3	2	8	7	2021-06-27 01:00:00	2021-06-27 01:30:00	t	0
1339	7	3	2	5	5	2021-06-27 01:30:00	2021-06-27 02:00:00	t	0
1340	7	3	2	6	6	2021-06-27 02:00:00	2021-06-27 02:30:00	t	0
1341	7	3	2	7	3	2021-06-27 02:30:00	2021-06-27 03:00:00	t	0
1342	7	3	2	8	7	2021-06-27 03:00:00	2021-06-27 03:30:00	t	0
1343	7	3	2	5	5	2021-06-27 03:30:00	2021-06-27 04:00:00	t	0
1344	7	3	2	6	6	2021-06-27 04:00:00	2021-06-27 04:30:00	t	0
1345	7	3	2	7	3	2021-06-27 04:30:00	2021-06-27 05:00:00	t	0
1346	7	3	2	8	7	2021-06-27 05:00:00	2021-06-27 05:30:00	t	0
1299	28	3	2	5	5	2021-06-27 05:30:00	2021-06-27 06:00:00	t	0
1347	7	3	2	5	5	2021-06-27 05:30:00	2021-06-27 06:00:00	t	0
1300	28	3	2	6	6	2021-06-27 06:00:00	2021-06-27 06:30:00	t	0
1348	7	3	2	6	6	2021-06-27 06:00:00	2021-06-27 06:30:00	t	0
1301	28	3	2	7	3	2021-06-27 06:30:00	2021-06-27 07:00:00	t	0
1349	7	3	2	7	3	2021-06-27 06:30:00	2021-06-27 07:00:00	t	0
1350	7	3	2	8	7	2021-06-27 07:00:00	2021-06-27 07:30:00	t	0
1303	28	3	2	5	5	2021-06-27 07:30:00	2021-06-27 08:00:00	t	0
1351	7	3	2	5	5	2021-06-27 07:30:00	2021-06-27 08:00:00	t	0
1304	28	3	2	6	6	2021-06-27 08:00:00	2021-06-27 08:30:00	t	0
1352	7	3	2	6	6	2021-06-27 08:00:00	2021-06-27 08:30:00	t	0
1305	28	3	2	7	3	2021-06-27 08:30:00	2021-06-27 09:00:00	t	0
1353	7	3	2	7	3	2021-06-27 08:30:00	2021-06-27 09:00:00	t	0
1306	28	3	2	8	7	2021-06-27 09:00:00	2021-06-27 09:30:00	t	0
1354	7	3	2	8	7	2021-06-27 09:00:00	2021-06-27 09:30:00	t	0
1307	28	3	2	5	5	2021-06-27 09:30:00	2021-06-27 10:00:00	t	0
1355	7	3	2	5	5	2021-06-27 09:30:00	2021-06-27 10:00:00	t	0
1308	28	3	2	6	6	2021-06-27 10:00:00	2021-06-27 10:30:00	t	0
1356	7	3	2	6	6	2021-06-27 10:00:00	2021-06-27 10:30:00	t	0
1309	28	3	2	7	3	2021-06-27 10:30:00	2021-06-27 11:00:00	t	0
1357	7	3	2	7	3	2021-06-27 10:30:00	2021-06-27 11:00:00	t	0
1310	28	3	2	8	7	2021-06-27 11:00:00	2021-06-27 11:30:00	t	0
1358	7	3	2	8	7	2021-06-27 11:00:00	2021-06-27 11:30:00	t	0
1311	28	3	2	5	5	2021-06-27 11:30:00	2021-06-27 12:00:00	t	0
1359	7	3	2	5	5	2021-06-27 11:30:00	2021-06-27 12:00:00	t	0
1312	28	3	2	6	6	2021-06-27 12:00:00	2021-06-27 12:30:00	t	0
1360	7	3	2	6	6	2021-06-27 12:00:00	2021-06-27 12:30:00	t	0
1313	28	3	2	7	3	2021-06-27 12:30:00	2021-06-27 13:00:00	t	0
1361	7	3	2	7	3	2021-06-27 12:30:00	2021-06-27 13:00:00	t	0
1314	28	3	2	8	7	2021-06-27 13:00:00	2021-06-27 13:30:00	t	0
1362	7	3	2	8	7	2021-06-27 13:00:00	2021-06-27 13:30:00	t	0
1315	28	3	2	5	5	2021-06-27 13:30:00	2021-06-27 14:00:00	t	0
1317	28	3	2	7	3	2021-06-27 14:30:00	2021-06-27 15:00:00	t	0
1318	28	3	2	8	7	2021-06-27 15:00:00	2021-06-27 15:30:00	t	0
1368	3	4	3	18	6	2021-06-26 16:00:00	2021-06-26 17:00:00	t	0
1369	3	4	3	15	1	2021-06-26 17:00:00	2021-06-26 18:00:00	t	0
1370	3	4	3	16	3	2021-06-26 17:00:00	2021-06-26 18:00:00	t	0
1371	3	4	3	17	4	2021-06-26 18:00:00	2021-06-26 19:00:00	t	0
1372	3	4	3	18	6	2021-06-26 18:00:00	2021-06-26 19:00:00	t	0
1373	3	4	3	15	1	2021-06-26 19:00:00	2021-06-26 20:00:00	t	0
1374	3	4	3	16	3	2021-06-26 19:00:00	2021-06-26 20:00:00	t	0
1375	3	4	3	17	4	2021-06-26 20:00:00	2021-06-26 21:00:00	t	0
1376	3	4	3	18	6	2021-06-26 20:00:00	2021-06-26 21:00:00	t	0
1377	3	4	3	15	1	2021-06-26 21:00:00	2021-06-26 22:00:00	t	0
1378	3	4	3	16	3	2021-06-26 21:00:00	2021-06-26 22:00:00	t	0
1379	3	4	3	17	4	2021-06-26 22:00:00	2021-06-26 23:00:00	t	0
1380	3	4	3	18	6	2021-06-26 22:00:00	2021-06-26 23:00:00	t	0
1381	3	4	3	15	1	2021-06-26 23:00:00	2021-06-27 00:00:00	t	0
1382	3	4	3	16	3	2021-06-26 23:00:00	2021-06-27 00:00:00	t	0
1383	3	4	3	17	4	2021-06-27 00:00:00	2021-06-27 01:00:00	t	0
1384	3	4	3	18	6	2021-06-27 00:00:00	2021-06-27 01:00:00	t	0
1386	3	4	3	16	3	2021-06-27 01:00:00	2021-06-27 02:00:00	t	0
1387	3	4	3	17	4	2021-06-27 02:00:00	2021-06-27 03:00:00	t	0
1388	3	4	3	18	6	2021-06-27 02:00:00	2021-06-27 03:00:00	t	0
1389	3	4	3	15	1	2021-06-27 03:00:00	2021-06-27 04:00:00	t	0
1390	3	4	3	16	3	2021-06-27 03:00:00	2021-06-27 04:00:00	t	0
1391	3	4	3	17	4	2021-06-27 04:00:00	2021-06-27 05:00:00	t	0
1392	3	4	3	18	6	2021-06-27 04:00:00	2021-06-27 05:00:00	t	0
1413	2	3	2	5	5	2021-06-26 08:30:00	2021-06-26 09:00:00	t	0
1414	2	3	2	6	6	2021-06-26 09:00:00	2021-06-26 09:30:00	t	0
1415	2	3	2	7	3	2021-06-26 09:30:00	2021-06-26 10:00:00	t	0
1416	2	3	2	8	7	2021-06-26 10:00:00	2021-06-26 10:30:00	t	0
1417	2	3	2	5	5	2021-06-26 10:30:00	2021-06-26 11:00:00	t	0
1418	2	3	2	6	6	2021-06-26 11:00:00	2021-06-26 11:30:00	t	0
1419	2	3	2	7	3	2021-06-26 11:30:00	2021-06-26 12:00:00	t	0
1420	2	3	2	8	7	2021-06-26 12:00:00	2021-06-26 12:30:00	t	0
1421	2	3	2	5	5	2021-06-26 12:30:00	2021-06-26 13:00:00	t	0
1422	2	3	2	6	6	2021-06-26 13:00:00	2021-06-26 13:30:00	t	0
1423	2	3	2	7	3	2021-06-26 13:30:00	2021-06-26 14:00:00	t	0
1424	2	3	2	8	7	2021-06-26 14:00:00	2021-06-26 14:30:00	t	0
1425	2	3	2	5	5	2021-06-26 14:30:00	2021-06-26 15:00:00	t	0
1426	2	3	2	6	6	2021-06-26 15:00:00	2021-06-26 15:30:00	t	0
1427	2	3	2	7	3	2021-06-26 15:30:00	2021-06-26 16:00:00	t	0
1428	2	3	2	8	7	2021-06-26 16:00:00	2021-06-26 16:30:00	t	0
1429	2	3	2	5	5	2021-06-26 16:30:00	2021-06-26 17:00:00	t	0
1430	2	3	2	6	6	2021-06-26 17:00:00	2021-06-26 17:30:00	t	0
1431	2	3	2	7	3	2021-06-26 17:30:00	2021-06-26 18:00:00	t	0
1433	2	3	2	5	5	2021-06-26 18:30:00	2021-06-26 19:00:00	t	0
1434	2	3	2	6	6	2021-06-26 19:00:00	2021-06-26 19:30:00	t	0
1435	2	3	2	7	3	2021-06-26 19:30:00	2021-06-26 20:00:00	t	0
1436	2	3	2	8	7	2021-06-26 20:00:00	2021-06-26 20:30:00	t	0
1437	2	3	2	5	5	2021-06-26 20:30:00	2021-06-26 21:00:00	t	0
1393	3	4	3	15	1	2021-06-27 05:00:00	2021-06-27 06:00:00	t	0
1394	3	4	3	16	3	2021-06-27 05:00:00	2021-06-27 06:00:00	t	0
1395	3	4	3	17	4	2021-06-27 06:00:00	2021-06-27 07:00:00	t	0
1396	3	4	3	18	6	2021-06-27 06:00:00	2021-06-27 07:00:00	t	0
1397	3	4	3	15	1	2021-06-27 07:00:00	2021-06-27 08:00:00	t	0
1398	3	4	3	16	3	2021-06-27 07:00:00	2021-06-27 08:00:00	t	0
1399	3	4	3	17	4	2021-06-27 08:00:00	2021-06-27 09:00:00	t	0
1400	3	4	3	18	6	2021-06-27 08:00:00	2021-06-27 09:00:00	t	0
1401	3	4	3	15	1	2021-06-27 09:00:00	2021-06-27 10:00:00	t	0
1402	3	4	3	16	3	2021-06-27 09:00:00	2021-06-27 10:00:00	t	0
1403	3	4	3	17	4	2021-06-27 10:00:00	2021-06-27 11:00:00	t	0
1404	3	4	3	18	6	2021-06-27 10:00:00	2021-06-27 11:00:00	t	0
1405	3	4	3	15	1	2021-06-27 11:00:00	2021-06-27 12:00:00	t	0
1406	3	4	3	16	3	2021-06-27 11:00:00	2021-06-27 12:00:00	t	0
1407	3	4	3	17	4	2021-06-27 12:00:00	2021-06-27 13:00:00	t	0
1408	3	4	3	18	6	2021-06-27 12:00:00	2021-06-27 13:00:00	t	0
1363	7	3	2	5	5	2021-06-27 13:30:00	2021-06-27 14:00:00	t	0
1409	3	4	3	15	1	2021-06-27 13:00:00	2021-06-27 14:00:00	t	0
1410	3	4	3	16	3	2021-06-27 13:00:00	2021-06-27 14:00:00	t	0
1364	7	3	2	6	6	2021-06-27 14:00:00	2021-06-27 14:30:00	t	0
1365	7	3	2	7	3	2021-06-27 14:30:00	2021-06-27 15:00:00	t	0
1412	3	4	3	18	6	2021-06-27 14:00:00	2021-06-27 15:00:00	t	0
1366	7	3	2	8	7	2021-06-27 15:00:00	2021-06-27 15:30:00	t	0
1280	28	3	2	6	6	2021-06-26 20:00:00	2021-06-26 20:30:00	t	0
1287	28	3	2	5	5	2021-06-26 23:30:00	2021-06-27 00:00:00	t	0
1439	2	3	2	7	3	2021-06-26 21:30:00	2021-06-26 22:00:00	t	0
1440	2	3	2	8	7	2021-06-26 22:00:00	2021-06-26 22:30:00	t	0
1441	2	3	2	5	5	2021-06-26 22:30:00	2021-06-26 23:00:00	t	0
1442	2	3	2	6	6	2021-06-26 23:00:00	2021-06-26 23:30:00	t	0
1443	2	3	2	7	3	2021-06-26 23:30:00	2021-06-27 00:00:00	t	0
1444	2	3	2	8	7	2021-06-27 00:00:00	2021-06-27 00:30:00	t	0
1445	2	3	2	5	5	2021-06-27 00:30:00	2021-06-27 01:00:00	t	0
1446	2	3	2	6	6	2021-06-27 01:00:00	2021-06-27 01:30:00	t	0
1447	2	3	2	7	3	2021-06-27 01:30:00	2021-06-27 02:00:00	t	0
1448	2	3	2	8	7	2021-06-27 02:00:00	2021-06-27 02:30:00	t	0
1449	2	3	2	5	5	2021-06-27 02:30:00	2021-06-27 03:00:00	t	0
1450	2	3	2	6	6	2021-06-27 03:00:00	2021-06-27 03:30:00	t	0
1451	2	3	2	7	3	2021-06-27 03:30:00	2021-06-27 04:00:00	t	0
1452	2	3	2	8	7	2021-06-27 04:00:00	2021-06-27 04:30:00	t	0
1453	2	3	2	5	5	2021-06-27 04:30:00	2021-06-27 05:00:00	t	0
1454	2	3	2	6	6	2021-06-27 05:00:00	2021-06-27 05:30:00	t	0
1461	1	1	1	1	1	2021-06-26 16:00:00	2021-06-26 16:30:00	t	0
1463	1	1	1	3	3	2021-06-26 17:00:00	2021-06-26 17:30:00	t	0
1464	1	1	1	4	4	2021-06-26 17:30:00	2021-06-26 18:00:00	t	0
1465	1	1	1	1	1	2021-06-26 18:00:00	2021-06-26 18:30:00	t	0
1466	1	1	1	2	2	2021-06-26 18:30:00	2021-06-26 19:00:00	t	0
1467	1	1	1	3	3	2021-06-26 19:00:00	2021-06-26 19:30:00	t	0
1468	1	1	1	4	4	2021-06-26 19:30:00	2021-06-26 20:00:00	t	0
1469	1	1	1	1	1	2021-06-26 20:00:00	2021-06-26 20:30:00	t	0
1470	1	1	1	2	2	2021-06-26 20:30:00	2021-06-26 21:00:00	t	0
1471	1	1	1	3	3	2021-06-26 21:00:00	2021-06-26 21:30:00	t	0
1472	1	1	1	4	4	2021-06-26 21:30:00	2021-06-26 22:00:00	t	0
1473	1	1	1	1	1	2021-06-26 22:00:00	2021-06-26 22:30:00	t	0
1474	1	1	1	2	2	2021-06-26 22:30:00	2021-06-26 23:00:00	t	0
1475	1	1	1	3	3	2021-06-26 23:00:00	2021-06-26 23:30:00	t	0
1476	1	1	1	4	4	2021-06-26 23:30:00	2021-06-27 00:00:00	t	0
1477	1	1	1	1	1	2021-06-27 00:00:00	2021-06-27 00:30:00	t	0
1478	1	1	1	2	2	2021-06-27 00:30:00	2021-06-27 01:00:00	t	0
1479	1	1	1	3	3	2021-06-27 01:00:00	2021-06-27 01:30:00	t	0
1480	1	1	1	4	4	2021-06-27 01:30:00	2021-06-27 02:00:00	t	0
1481	1	1	1	1	1	2021-06-27 02:00:00	2021-06-27 02:30:00	t	0
1482	1	1	1	2	2	2021-06-27 02:30:00	2021-06-27 03:00:00	t	0
1483	1	1	1	3	3	2021-06-27 03:00:00	2021-06-27 03:30:00	t	0
1484	1	1	1	4	4	2021-06-27 03:30:00	2021-06-27 04:00:00	t	0
1485	1	1	1	1	1	2021-06-27 04:00:00	2021-06-27 04:30:00	t	0
1486	1	1	1	2	2	2021-06-27 04:30:00	2021-06-27 05:00:00	t	0
1487	1	1	1	3	3	2021-06-27 05:00:00	2021-06-27 05:30:00	t	0
1456	2	3	2	8	7	2021-06-27 06:00:00	2021-06-27 06:30:00	t	0
1489	1	1	1	1	1	2021-06-27 06:00:00	2021-06-27 06:30:00	t	0
1457	2	3	2	5	5	2021-06-27 06:30:00	2021-06-27 07:00:00	t	0
1490	1	1	1	2	2	2021-06-27 06:30:00	2021-06-27 07:00:00	t	0
1458	2	3	2	6	6	2021-06-27 07:00:00	2021-06-27 07:30:00	t	0
1491	1	1	1	3	3	2021-06-27 07:00:00	2021-06-27 07:30:00	t	0
1459	2	3	2	7	3	2021-06-27 07:30:00	2021-06-27 08:00:00	t	0
1492	1	1	1	4	4	2021-06-27 07:30:00	2021-06-27 08:00:00	t	0
1460	2	3	2	8	7	2021-06-27 08:00:00	2021-06-27 08:30:00	t	0
1493	1	1	1	1	1	2021-06-27 08:00:00	2021-06-27 08:30:00	t	0
1494	1	1	1	2	2	2021-06-27 08:30:00	2021-06-27 09:00:00	t	0
1495	1	1	1	3	3	2021-06-27 09:00:00	2021-06-27 09:30:00	t	0
1496	1	1	1	4	4	2021-06-27 09:30:00	2021-06-27 10:00:00	t	0
1497	1	1	1	1	1	2021-06-27 10:00:00	2021-06-27 10:30:00	t	0
1498	1	1	1	2	2	2021-06-27 10:30:00	2021-06-27 11:00:00	t	0
1499	1	1	1	3	3	2021-06-27 11:00:00	2021-06-27 11:30:00	t	0
1500	1	1	1	4	4	2021-06-27 11:30:00	2021-06-27 12:00:00	t	0
1509	4	0	0	0	0	2021-06-27 00:00:00	2021-06-27 12:00:00	t	0
1501	1	1	1	1	1	2021-06-27 12:00:00	2021-06-27 12:30:00	t	0
1502	1	1	1	2	2	2021-06-27 12:30:00	2021-06-27 13:00:00	t	0
1503	1	1	1	3	3	2021-06-27 13:00:00	2021-06-27 13:30:00	t	0
1504	1	1	1	4	4	2021-06-27 13:30:00	2021-06-27 14:00:00	t	0
1505	1	1	1	1	1	2021-06-27 14:00:00	2021-06-27 14:30:00	t	0
1506	1	1	1	2	2	2021-06-27 14:30:00	2021-06-27 15:00:00	t	0
1507	1	1	1	3	3	2021-06-27 15:00:00	2021-06-27 15:30:00	t	0
1508	1	1	1	4	4	2021-06-27 15:30:00	2021-06-27 16:00:00	t	0
1510	4	0	0	0	0	2021-06-27 12:00:00	2021-06-28 00:00:00	t	0
1288	28	3	2	6	6	2021-06-27 00:00:00	2021-06-27 00:30:00	t	0
1326	7	3	2	8	7	2021-06-26 19:00:00	2021-06-26 19:30:00	t	0
1367	3	4	3	17	4	2021-06-26 16:00:00	2021-06-26 17:00:00	t	0
1385	3	4	3	15	1	2021-06-27 01:00:00	2021-06-27 02:00:00	t	0
1432	2	3	2	8	7	2021-06-26 18:00:00	2021-06-26 18:30:00	t	0
1438	2	3	2	6	6	2021-06-26 21:00:00	2021-06-26 21:30:00	t	0
1462	1	1	1	2	2	2021-06-26 16:30:00	2021-06-26 17:00:00	t	0
1455	2	3	2	7	3	2021-06-27 05:30:00	2021-06-27 06:00:00	t	0
1488	1	1	1	4	4	2021-06-27 05:30:00	2021-06-27 06:00:00	t	0
2522	34	13	7	36	7	2021-06-29 20:10:00	2021-06-29 20:20:00	t	0
2784	30	10	8	40	4	2021-06-30 01:30:00	2021-06-30 01:40:00	t	0
2781	31	11	9	43	2	2021-06-30 01:40:00	2021-06-30 01:50:00	t	0
2785	34	13	7	36	7	2021-06-30 01:40:00	2021-06-30 01:50:00	t	0
2786	34	13	7	35	6	2021-06-30 01:40:00	2021-06-30 01:50:00	t	0
2787	30	10	8	41	7	2021-06-30 01:40:00	2021-06-30 01:50:00	t	0
2788	30	10	8	40	4	2021-06-30 01:40:00	2021-06-30 01:50:00	t	0
2782	31	11	9	42	1	2021-06-30 01:50:00	2021-06-30 02:00:00	t	0
2789	34	13	7	36	7	2021-06-30 01:50:00	2021-06-30 02:00:00	t	0
2790	34	13	7	35	6	2021-06-30 01:50:00	2021-06-30 02:00:00	t	0
2791	30	10	8	41	7	2021-06-30 01:50:00	2021-06-30 02:00:00	t	0
2792	30	10	8	40	4	2021-06-30 01:50:00	2021-06-30 02:00:00	t	0
2793	29	9	5	29	2	2021-06-30 01:50:00	2021-06-30 02:00:00	t	0
2794	29	9	5	28	1	2021-06-30 02:00:00	2021-06-30 02:10:00	t	0
2795	29	9	6	32	2	2021-06-30 02:10:00	2021-06-30 02:20:00	t	0
2796	29	9	6	30	3	2021-06-30 02:20:00	2021-06-30 02:30:00	t	0
2881	34	13	7	36	7	2021-06-30 03:40:00	2021-06-30 03:50:00	t	0
2882	34	13	7	35	6	2021-06-30 03:40:00	2021-06-30 03:50:00	t	0
2884	30	10	8	40	4	2021-06-30 03:40:00	2021-06-30 03:50:00	t	0
2885	34	13	7	36	7	2021-06-30 03:50:00	2021-06-30 04:00:00	t	0
2886	34	13	7	35	6	2021-06-30 03:50:00	2021-06-30 04:00:00	t	0
2887	30	10	8	41	7	2021-06-30 03:50:00	2021-06-30 04:00:00	t	0
2888	30	10	8	40	4	2021-06-30 03:50:00	2021-06-30 04:00:00	t	0
2889	29	9	5	29	2	2021-06-30 03:50:00	2021-06-30 04:00:00	t	0
2890	29	9	5	28	1	2021-06-30 04:00:00	2021-06-30 04:10:00	t	0
2893	35	11	9	44	3	2021-06-30 04:00:00	2021-06-30 04:10:00	t	0
2896	34	13	7	36	7	2021-06-30 04:00:00	2021-06-30 04:10:00	t	0
2897	34	13	7	35	6	2021-06-30 04:00:00	2021-06-30 04:10:00	t	0
2898	33	12	9	44	3	2021-06-30 04:00:00	2021-06-30 04:10:00	t	0
2901	31	11	9	44	3	2021-06-30 04:00:00	2021-06-30 04:10:00	t	0
2904	30	10	8	41	7	2021-06-30 04:00:00	2021-06-30 04:10:00	t	0
2905	30	10	8	40	4	2021-06-30 04:00:00	2021-06-30 04:10:00	t	0
2891	29	9	6	32	2	2021-06-30 04:10:00	2021-06-30 04:20:00	t	0
2894	35	11	9	43	2	2021-06-30 04:10:00	2021-06-30 04:20:00	t	0
2899	33	12	9	43	2	2021-06-30 04:10:00	2021-06-30 04:20:00	t	0
2902	31	11	9	43	2	2021-06-30 04:10:00	2021-06-30 04:20:00	t	0
2892	29	9	6	30	3	2021-06-30 04:20:00	2021-06-30 04:30:00	t	0
2895	35	11	9	42	1	2021-06-30 04:20:00	2021-06-30 04:30:00	t	0
2900	33	12	9	42	1	2021-06-30 04:20:00	2021-06-30 04:30:00	t	0
2903	31	11	9	42	1	2021-06-30 04:20:00	2021-06-30 04:30:00	t	0
3048	34	13	7	36	7	2021-06-30 07:10:00	2021-06-30 07:20:00	t	0
3049	34	13	7	35	6	2021-06-30 07:10:00	2021-06-30 07:20:00	t	300
3050	30	10	8	41	7	2021-06-30 07:10:00	2021-06-30 07:20:00	t	0
3051	30	10	8	40	4	2021-06-30 07:10:00	2021-06-30 07:20:00	t	0
3053	29	9	5	28	1	2021-06-30 07:20:00	2021-06-30 07:30:00	t	0
3056	34	13	7	36	7	2021-06-30 07:20:00	2021-06-30 07:30:00	t	0
3057	34	13	7	35	6	2021-06-30 07:20:00	2021-06-30 07:30:00	t	0
3058	30	10	8	41	7	2021-06-30 07:20:00	2021-06-30 07:30:00	t	0
3059	30	10	8	40	4	2021-06-30 07:20:00	2021-06-30 07:30:00	t	0
3054	29	9	6	32	2	2021-06-30 07:30:00	2021-06-30 07:40:00	t	0
3060	35	11	9	44	3	2021-06-30 07:30:00	2021-06-30 07:40:00	t	0
3063	34	13	7	36	7	2021-06-30 07:30:00	2021-06-30 07:40:00	t	0
3064	34	13	7	35	6	2021-06-30 07:30:00	2021-06-30 07:40:00	t	0
3065	33	12	9	44	3	2021-06-30 07:30:00	2021-06-30 07:40:00	t	0
3068	31	11	9	44	3	2021-06-30 07:30:00	2021-06-30 07:40:00	t	0
3071	30	10	8	41	7	2021-06-30 07:30:00	2021-06-30 07:40:00	t	0
3055	29	9	6	30	3	2021-06-30 07:40:00	2021-06-30 07:50:00	t	0
3061	35	11	9	43	2	2021-06-30 07:40:00	2021-06-30 07:50:00	t	0
3066	33	12	9	43	2	2021-06-30 07:40:00	2021-06-30 07:50:00	t	0
3069	31	11	9	43	2	2021-06-30 07:40:00	2021-06-30 07:50:00	t	0
3062	35	11	9	42	1	2021-06-30 07:50:00	2021-06-30 08:00:00	t	1700
3067	33	12	9	42	1	2021-06-30 07:50:00	2021-06-30 08:00:00	t	0
3070	31	11	9	42	1	2021-06-30 07:50:00	2021-06-30 08:00:00	t	0
2347	31	11	9	43	2	2021-06-29 16:40:00	2021-06-29 16:50:00	t	0
1302	28	3	2	8	7	2021-06-27 07:00:00	2021-06-27 07:30:00	t	0
1527	2	3	2	5	5	2021-06-27 08:30:00	2021-06-27 09:00:00	t	0
1528	2	3	2	6	6	2021-06-27 09:00:00	2021-06-27 09:30:00	t	0
1529	2	3	2	7	3	2021-06-27 09:30:00	2021-06-27 10:00:00	t	0
1530	2	3	2	8	7	2021-06-27 10:00:00	2021-06-27 10:30:00	t	0
1547	2	3	2	5	5	2021-06-27 10:30:00	2021-06-27 11:00:00	t	0
1548	2	3	2	6	6	2021-06-27 11:00:00	2021-06-27 11:30:00	t	0
1549	2	3	2	7	3	2021-06-27 11:30:00	2021-06-27 12:00:00	t	0
1550	2	3	2	8	7	2021-06-27 12:00:00	2021-06-27 12:30:00	t	0
1568	2	3	2	6	6	2021-06-27 13:00:00	2021-06-27 13:30:00	t	0
1569	2	3	2	7	3	2021-06-27 13:30:00	2021-06-27 14:00:00	t	0
1570	2	3	2	8	7	2021-06-27 14:00:00	2021-06-27 14:30:00	t	0
1512	3	4	3	18	6	2021-06-27 15:00:00	2021-06-27 16:00:00	t	0
1513	28	3	2	5	5	2021-06-27 15:30:00	2021-06-27 16:00:00	t	0
1517	7	3	2	5	5	2021-06-27 15:30:00	2021-06-27 16:00:00	t	0
1514	28	3	2	6	6	2021-06-27 16:00:00	2021-06-27 16:30:00	t	0
1518	7	3	2	6	6	2021-06-27 16:00:00	2021-06-27 16:30:00	t	0
1523	1	1	1	1	1	2021-06-27 16:00:00	2021-06-27 16:30:00	t	0
1519	7	3	2	7	3	2021-06-27 16:30:00	2021-06-27 17:00:00	t	0
1521	3	4	3	17	4	2021-06-27 16:00:00	2021-06-27 17:00:00	t	0
1522	3	4	3	18	6	2021-06-27 16:00:00	2021-06-27 17:00:00	t	0
1524	1	1	1	2	2	2021-06-27 16:30:00	2021-06-27 17:00:00	t	0
1516	28	3	2	8	7	2021-06-27 17:00:00	2021-06-27 17:30:00	t	0
1520	7	3	2	8	7	2021-06-27 17:00:00	2021-06-27 17:30:00	t	0
1525	1	1	1	3	3	2021-06-27 17:00:00	2021-06-27 17:30:00	t	0
1526	1	1	1	4	4	2021-06-27 17:30:00	2021-06-27 18:00:00	t	0
1531	3	4	3	17	4	2021-06-27 17:00:00	2021-06-27 18:00:00	t	0
1532	3	4	3	18	6	2021-06-27 17:00:00	2021-06-27 18:00:00	t	0
1533	28	3	2	5	5	2021-06-27 17:30:00	2021-06-27 18:00:00	t	0
1537	7	3	2	5	5	2021-06-27 17:30:00	2021-06-27 18:00:00	t	0
1534	28	3	2	6	6	2021-06-27 18:00:00	2021-06-27 18:30:00	t	0
1538	7	3	2	6	6	2021-06-27 18:00:00	2021-06-27 18:30:00	t	0
1543	1	1	1	1	1	2021-06-27 18:00:00	2021-06-27 18:30:00	t	0
1535	28	3	2	7	3	2021-06-27 18:30:00	2021-06-27 19:00:00	t	0
1539	7	3	2	7	3	2021-06-27 18:30:00	2021-06-27 19:00:00	t	0
1541	3	4	3	17	4	2021-06-27 18:00:00	2021-06-27 19:00:00	t	0
1542	3	4	3	18	6	2021-06-27 18:00:00	2021-06-27 19:00:00	t	0
1544	1	1	1	2	2	2021-06-27 18:30:00	2021-06-27 19:00:00	t	0
1536	28	3	2	8	7	2021-06-27 19:00:00	2021-06-27 19:30:00	t	0
1540	7	3	2	8	7	2021-06-27 19:00:00	2021-06-27 19:30:00	t	0
1545	1	1	1	3	3	2021-06-27 19:00:00	2021-06-27 19:30:00	t	0
1546	1	1	1	4	4	2021-06-27 19:30:00	2021-06-27 20:00:00	t	0
1551	3	4	3	17	4	2021-06-27 19:00:00	2021-06-27 20:00:00	t	0
1552	3	4	3	18	6	2021-06-27 19:00:00	2021-06-27 20:00:00	t	0
1557	7	3	2	5	5	2021-06-27 19:30:00	2021-06-27 20:00:00	t	0
1554	28	3	2	6	6	2021-06-27 20:00:00	2021-06-27 20:30:00	t	0
1558	7	3	2	6	6	2021-06-27 20:00:00	2021-06-27 20:30:00	t	0
1563	1	1	1	1	1	2021-06-27 20:00:00	2021-06-27 20:30:00	t	0
1555	28	3	2	7	3	2021-06-27 20:30:00	2021-06-27 21:00:00	t	0
1559	7	3	2	7	3	2021-06-27 20:30:00	2021-06-27 21:00:00	t	0
1561	3	4	3	17	4	2021-06-27 20:00:00	2021-06-27 21:00:00	t	0
1562	3	4	3	18	6	2021-06-27 20:00:00	2021-06-27 21:00:00	t	0
1564	1	1	1	2	2	2021-06-27 20:30:00	2021-06-27 21:00:00	t	0
1556	28	3	2	8	7	2021-06-27 21:00:00	2021-06-27 21:30:00	t	0
1560	7	3	2	8	7	2021-06-27 21:00:00	2021-06-27 21:30:00	t	0
1565	1	1	1	3	3	2021-06-27 21:00:00	2021-06-27 21:30:00	t	0
1566	1	1	1	4	4	2021-06-27 21:30:00	2021-06-27 22:00:00	t	0
1571	3	4	3	17	4	2021-06-27 21:00:00	2021-06-27 22:00:00	t	0
1572	3	4	3	18	6	2021-06-27 21:00:00	2021-06-27 22:00:00	t	0
1573	28	3	2	5	5	2021-06-27 21:30:00	2021-06-27 22:00:00	t	0
1577	7	3	2	5	5	2021-06-27 21:30:00	2021-06-27 22:00:00	t	0
1574	28	3	2	6	6	2021-06-27 22:00:00	2021-06-27 22:30:00	t	0
1578	7	3	2	6	6	2021-06-27 22:00:00	2021-06-27 22:30:00	t	0
1583	1	1	1	1	1	2021-06-27 22:00:00	2021-06-27 22:30:00	t	0
1575	28	3	2	7	3	2021-06-27 22:30:00	2021-06-27 23:00:00	t	0
1579	7	3	2	7	3	2021-06-27 22:30:00	2021-06-27 23:00:00	t	0
1581	3	4	3	17	4	2021-06-27 22:00:00	2021-06-27 23:00:00	t	0
1582	3	4	3	18	6	2021-06-27 22:00:00	2021-06-27 23:00:00	t	0
1584	1	1	1	2	2	2021-06-27 22:30:00	2021-06-27 23:00:00	t	0
1576	28	3	2	8	7	2021-06-27 23:00:00	2021-06-27 23:30:00	t	0
1585	1	1	1	3	3	2021-06-27 23:00:00	2021-06-27 23:30:00	t	0
1567	2	3	2	5	5	2021-06-27 12:30:00	2021-06-27 13:00:00	t	0
1316	28	3	2	6	6	2021-06-27 14:00:00	2021-06-27 14:30:00	t	0
1411	3	4	3	17	4	2021-06-27 14:00:00	2021-06-27 15:00:00	t	0
1587	2	3	2	5	5	2021-06-27 14:30:00	2021-06-27 15:00:00	t	0
1588	2	3	2	6	6	2021-06-27 15:00:00	2021-06-27 15:30:00	t	0
1511	3	4	3	17	4	2021-06-27 15:00:00	2021-06-27 16:00:00	t	0
1589	2	3	2	7	3	2021-06-27 15:30:00	2021-06-27 16:00:00	t	0
1590	2	3	2	8	7	2021-06-27 16:00:00	2021-06-27 16:30:00	t	0
1515	28	3	2	7	3	2021-06-27 16:30:00	2021-06-27 17:00:00	t	0
1608	2	3	2	5	5	2021-06-27 16:30:00	2021-06-27 17:00:00	t	0
1609	2	3	2	6	6	2021-06-27 17:00:00	2021-06-27 17:30:00	t	0
1610	2	3	2	7	3	2021-06-27 17:30:00	2021-06-27 18:00:00	t	0
1611	2	3	2	8	7	2021-06-27 18:00:00	2021-06-27 18:30:00	t	0
1628	2	3	2	5	5	2021-06-27 18:30:00	2021-06-27 19:00:00	t	0
1629	2	3	2	6	6	2021-06-27 19:00:00	2021-06-27 19:30:00	t	0
1553	28	3	2	5	5	2021-06-27 19:30:00	2021-06-27 20:00:00	t	0
1630	2	3	2	7	3	2021-06-27 19:30:00	2021-06-27 20:00:00	t	0
1631	2	3	2	8	7	2021-06-27 20:00:00	2021-06-27 20:30:00	t	0
1648	2	3	2	5	5	2021-06-27 20:30:00	2021-06-27 21:00:00	t	0
1649	2	3	2	6	6	2021-06-27 21:00:00	2021-06-27 21:30:00	t	0
1650	2	3	2	7	3	2021-06-27 21:30:00	2021-06-27 22:00:00	t	0
1651	2	3	2	8	7	2021-06-27 22:00:00	2021-06-27 22:30:00	t	0
1586	1	1	1	4	4	2021-06-27 23:30:00	2021-06-28 00:00:00	t	0
1591	3	4	3	17	4	2021-06-27 23:00:00	2021-06-28 00:00:00	t	0
1593	28	3	2	5	5	2021-06-27 23:30:00	2021-06-28 00:00:00	t	0
1597	7	3	2	5	5	2021-06-27 23:30:00	2021-06-28 00:00:00	t	0
1594	28	3	2	6	6	2021-06-28 00:00:00	2021-06-28 00:30:00	t	0
1598	7	3	2	6	6	2021-06-28 00:00:00	2021-06-28 00:30:00	t	0
1604	1	1	1	1	1	2021-06-28 00:00:00	2021-06-28 00:30:00	t	0
1595	28	3	2	7	3	2021-06-28 00:30:00	2021-06-28 01:00:00	t	0
1599	7	3	2	7	3	2021-06-28 00:30:00	2021-06-28 01:00:00	t	0
1602	3	4	3	17	4	2021-06-28 00:00:00	2021-06-28 01:00:00	t	0
1603	3	4	3	18	6	2021-06-28 00:00:00	2021-06-28 01:00:00	t	0
1605	1	1	1	2	2	2021-06-28 00:30:00	2021-06-28 01:00:00	t	0
1596	28	3	2	8	7	2021-06-28 01:00:00	2021-06-28 01:30:00	t	0
1600	7	3	2	8	7	2021-06-28 01:00:00	2021-06-28 01:30:00	t	0
1606	1	1	1	3	3	2021-06-28 01:00:00	2021-06-28 01:30:00	t	0
1607	1	1	1	4	4	2021-06-28 01:30:00	2021-06-28 02:00:00	t	0
1612	3	4	3	17	4	2021-06-28 01:00:00	2021-06-28 02:00:00	t	0
1613	3	4	3	18	6	2021-06-28 01:00:00	2021-06-28 02:00:00	t	0
1614	28	3	2	5	5	2021-06-28 01:30:00	2021-06-28 02:00:00	t	0
1618	7	3	2	5	5	2021-06-28 01:30:00	2021-06-28 02:00:00	t	0
1615	28	3	2	6	6	2021-06-28 02:00:00	2021-06-28 02:30:00	t	0
1619	7	3	2	6	6	2021-06-28 02:00:00	2021-06-28 02:30:00	t	0
1624	1	1	1	1	1	2021-06-28 02:00:00	2021-06-28 02:30:00	t	0
1616	28	3	2	7	3	2021-06-28 02:30:00	2021-06-28 03:00:00	t	1715
1620	7	3	2	7	3	2021-06-28 02:30:00	2021-06-28 03:00:00	t	0
1622	3	4	3	17	4	2021-06-28 02:00:00	2021-06-28 03:00:00	t	0
1623	3	4	3	18	6	2021-06-28 02:00:00	2021-06-28 03:00:00	t	0
1625	1	1	1	2	2	2021-06-28 02:30:00	2021-06-28 03:00:00	t	0
1621	7	3	2	8	7	2021-06-28 03:00:00	2021-06-28 03:30:00	t	0
1626	1	1	1	3	3	2021-06-28 03:00:00	2021-06-28 03:30:00	t	0
1627	1	1	1	4	4	2021-06-28 03:30:00	2021-06-28 04:00:00	t	0
1632	3	4	3	17	4	2021-06-28 03:00:00	2021-06-28 04:00:00	t	0
1633	3	4	3	18	6	2021-06-28 03:00:00	2021-06-28 04:00:00	t	0
1634	28	3	2	5	5	2021-06-28 03:30:00	2021-06-28 04:00:00	t	992
1638	7	3	2	5	5	2021-06-28 03:30:00	2021-06-28 04:00:00	t	0
1635	28	3	2	6	6	2021-06-28 04:00:00	2021-06-28 04:30:00	t	0
1639	7	3	2	6	6	2021-06-28 04:00:00	2021-06-28 04:30:00	t	988
1644	1	1	1	1	1	2021-06-28 04:00:00	2021-06-28 04:30:00	t	2080
1636	28	3	2	7	3	2021-06-28 04:30:00	2021-06-28 05:00:00	t	0
1640	7	3	2	7	3	2021-06-28 04:30:00	2021-06-28 05:00:00	t	0
1642	3	4	3	17	4	2021-06-28 04:00:00	2021-06-28 05:00:00	t	0
1643	3	4	3	18	6	2021-06-28 04:00:00	2021-06-28 05:00:00	t	520
1645	1	1	1	2	2	2021-06-28 04:30:00	2021-06-28 05:00:00	t	0
1637	28	3	2	8	7	2021-06-28 05:00:00	2021-06-28 05:30:00	t	0
1641	7	3	2	8	7	2021-06-28 05:00:00	2021-06-28 05:30:00	t	0
1646	1	1	1	3	3	2021-06-28 05:00:00	2021-06-28 05:30:00	t	0
1647	1	1	1	4	4	2021-06-28 05:30:00	2021-06-28 06:00:00	t	1016
1652	3	4	3	17	4	2021-06-28 05:00:00	2021-06-28 06:00:00	t	0
1653	3	4	3	18	6	2021-06-28 05:00:00	2021-06-28 06:00:00	t	1444
1601	4	0	0	0	0	2021-06-28 00:00:00	2021-06-28 12:00:00	t	0
1668	2	3	2	5	5	2021-06-27 22:30:00	2021-06-27 23:00:00	t	0
1580	7	3	2	8	7	2021-06-27 23:00:00	2021-06-27 23:30:00	t	0
1669	2	3	2	6	6	2021-06-27 23:00:00	2021-06-27 23:30:00	t	0
1592	3	4	3	18	6	2021-06-27 23:00:00	2021-06-28 00:00:00	t	0
1670	2	3	2	7	3	2021-06-27 23:30:00	2021-06-28 00:00:00	t	0
1671	2	3	2	8	7	2021-06-28 00:00:00	2021-06-28 00:30:00	t	0
1688	2	3	2	5	5	2021-06-28 00:30:00	2021-06-28 01:00:00	t	0
1689	2	3	2	6	6	2021-06-28 01:00:00	2021-06-28 01:30:00	t	0
1690	2	3	2	7	3	2021-06-28 01:30:00	2021-06-28 02:00:00	t	0
1691	2	3	2	8	7	2021-06-28 02:00:00	2021-06-28 02:30:00	t	0
1709	2	3	2	6	6	2021-06-28 03:00:00	2021-06-28 03:30:00	t	0
1710	2	3	2	7	3	2021-06-28 03:30:00	2021-06-28 04:00:00	t	0
1711	2	3	2	8	7	2021-06-28 04:00:00	2021-06-28 04:30:00	t	0
1654	28	3	2	5	5	2021-06-28 05:30:00	2021-06-28 06:00:00	t	0
1658	7	3	2	5	5	2021-06-28 05:30:00	2021-06-28 06:00:00	t	0
1655	28	3	2	6	6	2021-06-28 06:00:00	2021-06-28 06:30:00	t	0
1659	7	3	2	6	6	2021-06-28 06:00:00	2021-06-28 06:30:00	t	0
1664	1	1	1	1	1	2021-06-28 06:00:00	2021-06-28 06:30:00	t	0
1656	28	3	2	7	3	2021-06-28 06:30:00	2021-06-28 07:00:00	t	0
1662	3	4	3	17	4	2021-06-28 06:00:00	2021-06-28 07:00:00	t	0
1663	3	4	3	18	6	2021-06-28 06:00:00	2021-06-28 07:00:00	t	1444
1665	1	1	1	2	2	2021-06-28 06:30:00	2021-06-28 07:00:00	t	0
1657	28	3	2	8	7	2021-06-28 07:00:00	2021-06-28 07:30:00	t	0
1661	7	3	2	8	7	2021-06-28 07:00:00	2021-06-28 07:30:00	t	0
1666	1	1	1	3	3	2021-06-28 07:00:00	2021-06-28 07:30:00	t	0
1667	1	1	1	4	4	2021-06-28 07:30:00	2021-06-28 08:00:00	t	540
1672	3	4	3	17	4	2021-06-28 07:00:00	2021-06-28 08:00:00	t	0
1673	3	4	3	18	6	2021-06-28 07:00:00	2021-06-28 08:00:00	t	1026
1674	28	3	2	5	5	2021-06-28 07:30:00	2021-06-28 08:00:00	t	0
1678	7	3	2	5	5	2021-06-28 07:30:00	2021-06-28 08:00:00	t	0
1675	28	3	2	6	6	2021-06-28 08:00:00	2021-06-28 08:30:00	t	0
1679	7	3	2	6	6	2021-06-28 08:00:00	2021-06-28 08:30:00	t	0
1684	1	1	1	1	1	2021-06-28 08:00:00	2021-06-28 08:30:00	t	0
1676	28	3	2	7	3	2021-06-28 08:30:00	2021-06-28 09:00:00	t	0
1680	7	3	2	7	3	2021-06-28 08:30:00	2021-06-28 09:00:00	t	0
1682	3	4	3	17	4	2021-06-28 08:00:00	2021-06-28 09:00:00	t	0
1683	3	4	3	18	6	2021-06-28 08:00:00	2021-06-28 09:00:00	t	0
1685	1	1	1	2	2	2021-06-28 08:30:00	2021-06-28 09:00:00	t	525
1677	28	3	2	8	7	2021-06-28 09:00:00	2021-06-28 09:30:00	t	0
1681	7	3	2	8	7	2021-06-28 09:00:00	2021-06-28 09:30:00	t	0
1686	1	1	1	3	3	2021-06-28 09:00:00	2021-06-28 09:30:00	t	0
1687	1	1	1	4	4	2021-06-28 09:30:00	2021-06-28 10:00:00	t	0
1692	3	4	3	17	4	2021-06-28 09:00:00	2021-06-28 10:00:00	t	0
1693	3	4	3	18	6	2021-06-28 09:00:00	2021-06-28 10:00:00	t	0
1694	28	3	2	5	5	2021-06-28 09:30:00	2021-06-28 10:00:00	t	0
1695	28	3	2	6	6	2021-06-28 10:00:00	2021-06-28 10:30:00	t	0
1699	7	3	2	6	6	2021-06-28 10:00:00	2021-06-28 10:30:00	t	0
1704	1	1	1	1	1	2021-06-28 10:00:00	2021-06-28 10:30:00	t	0
1696	28	3	2	7	3	2021-06-28 10:30:00	2021-06-28 11:00:00	t	0
1700	7	3	2	7	3	2021-06-28 10:30:00	2021-06-28 11:00:00	t	0
1702	3	4	3	17	4	2021-06-28 10:00:00	2021-06-28 11:00:00	t	0
1703	3	4	3	18	6	2021-06-28 10:00:00	2021-06-28 11:00:00	t	0
1705	1	1	1	2	2	2021-06-28 10:30:00	2021-06-28 11:00:00	t	0
1697	28	3	2	8	7	2021-06-28 11:00:00	2021-06-28 11:30:00	t	0
1701	7	3	2	8	7	2021-06-28 11:00:00	2021-06-28 11:30:00	t	0
1706	1	1	1	3	3	2021-06-28 11:00:00	2021-06-28 11:30:00	t	0
1707	1	1	1	4	4	2021-06-28 11:30:00	2021-06-28 12:00:00	t	950
1712	3	4	3	17	4	2021-06-28 11:00:00	2021-06-28 12:00:00	t	0
1713	3	4	3	18	6	2021-06-28 11:00:00	2021-06-28 12:00:00	t	500
1714	28	3	2	5	5	2021-06-28 11:30:00	2021-06-28 12:00:00	t	0
1718	7	3	2	5	5	2021-06-28 11:30:00	2021-06-28 12:00:00	t	0
1715	28	3	2	6	6	2021-06-28 12:00:00	2021-06-28 12:30:00	t	0
1719	7	3	2	6	6	2021-06-28 12:00:00	2021-06-28 12:30:00	t	0
1725	1	1	1	1	1	2021-06-28 12:00:00	2021-06-28 12:30:00	t	0
1716	28	3	2	7	3	2021-06-28 12:30:00	2021-06-28 13:00:00	t	0
1720	7	3	2	7	3	2021-06-28 12:30:00	2021-06-28 13:00:00	t	0
1723	3	4	3	17	4	2021-06-28 12:00:00	2021-06-28 13:00:00	t	500
1724	3	4	3	18	6	2021-06-28 12:00:00	2021-06-28 13:00:00	t	0
1726	1	1	1	2	2	2021-06-28 12:30:00	2021-06-28 13:00:00	t	0
1717	28	3	2	8	7	2021-06-28 13:00:00	2021-06-28 13:30:00	t	0
1721	7	3	2	8	7	2021-06-28 13:00:00	2021-06-28 13:30:00	t	0
1708	2	3	2	5	5	2021-06-28 02:30:00	2021-06-28 03:00:00	t	1734
1617	28	3	2	8	7	2021-06-28 03:00:00	2021-06-28 03:30:00	t	0
1729	2	3	2	5	5	2021-06-28 04:30:00	2021-06-28 05:00:00	t	0
1730	2	3	2	6	6	2021-06-28 05:00:00	2021-06-28 05:30:00	t	0
1731	2	3	2	7	3	2021-06-28 05:30:00	2021-06-28 06:00:00	t	0
2451	34	13	7	36	7	2021-06-29 18:40:00	2021-06-29 18:50:00	t	0
1732	2	3	2	8	7	2021-06-28 06:00:00	2021-06-28 06:30:00	t	0
1660	7	3	2	7	3	2021-06-28 06:30:00	2021-06-28 07:00:00	t	0
1749	2	3	2	5	5	2021-06-28 06:30:00	2021-06-28 07:00:00	t	0
1750	2	3	2	6	6	2021-06-28 07:00:00	2021-06-28 07:30:00	t	0
1751	2	3	2	7	3	2021-06-28 07:30:00	2021-06-28 08:00:00	t	1458
1752	2	3	2	8	7	2021-06-28 08:00:00	2021-06-28 08:30:00	t	0
2618	34	13	7	36	7	2021-06-29 22:10:00	2021-06-29 22:20:00	t	0
1769	2	3	2	5	5	2021-06-28 08:30:00	2021-06-28 09:00:00	t	0
1770	2	3	2	6	6	2021-06-28 09:00:00	2021-06-28 09:30:00	t	0
1698	7	3	2	5	5	2021-06-28 09:30:00	2021-06-28 10:00:00	t	0
1771	2	3	2	7	3	2021-06-28 09:30:00	2021-06-28 10:00:00	t	0
1772	2	3	2	8	7	2021-06-28 10:00:00	2021-06-28 10:30:00	t	0
1789	2	3	2	5	5	2021-06-28 10:30:00	2021-06-28 11:00:00	t	0
1790	2	3	2	6	6	2021-06-28 11:00:00	2021-06-28 11:30:00	t	500
1791	2	3	2	7	3	2021-06-28 11:30:00	2021-06-28 12:00:00	t	0
1792	2	3	2	8	7	2021-06-28 12:00:00	2021-06-28 12:30:00	t	0
1727	1	1	1	3	3	2021-06-28 13:00:00	2021-06-28 13:30:00	t	0
2802	33	12	9	44	3	2021-06-30 02:00:00	2021-06-30 02:10:00	t	0
2805	31	11	9	44	3	2021-06-30 02:00:00	2021-06-30 02:10:00	t	0
2808	30	10	8	41	7	2021-06-30 02:00:00	2021-06-30 02:10:00	t	0
2809	30	10	8	40	4	2021-06-30 02:00:00	2021-06-30 02:10:00	t	0
2798	35	11	9	43	2	2021-06-30 02:10:00	2021-06-30 02:20:00	t	0
2803	33	12	9	43	2	2021-06-30 02:10:00	2021-06-30 02:20:00	t	0
2806	31	11	9	43	2	2021-06-30 02:10:00	2021-06-30 02:20:00	t	0
2810	34	13	7	36	7	2021-06-30 02:10:00	2021-06-30 02:20:00	t	0
2811	34	13	7	35	6	2021-06-30 02:10:00	2021-06-30 02:20:00	t	0
2812	30	10	8	41	7	2021-06-30 02:10:00	2021-06-30 02:20:00	t	0
2813	30	10	8	40	4	2021-06-30 02:10:00	2021-06-30 02:20:00	t	0
2799	35	11	9	42	1	2021-06-30 02:20:00	2021-06-30 02:30:00	t	0
2804	33	12	9	42	1	2021-06-30 02:20:00	2021-06-30 02:30:00	t	0
2807	31	11	9	42	1	2021-06-30 02:20:00	2021-06-30 02:30:00	t	0
2814	34	13	7	36	7	2021-06-30 02:20:00	2021-06-30 02:30:00	t	0
2815	34	13	7	35	6	2021-06-30 02:20:00	2021-06-30 02:30:00	t	0
2816	30	10	8	41	7	2021-06-30 02:20:00	2021-06-30 02:30:00	t	0
2817	30	10	8	40	4	2021-06-30 02:20:00	2021-06-30 02:30:00	t	0
2977	34	13	7	36	7	2021-06-30 05:40:00	2021-06-30 05:50:00	t	0
2978	34	13	7	35	6	2021-06-30 05:40:00	2021-06-30 05:50:00	t	0
2979	30	10	8	41	7	2021-06-30 05:40:00	2021-06-30 05:50:00	t	0
2980	30	10	8	40	4	2021-06-30 05:40:00	2021-06-30 05:50:00	t	0
2981	34	13	7	36	7	2021-06-30 05:50:00	2021-06-30 06:00:00	t	0
2982	34	13	7	35	6	2021-06-30 05:50:00	2021-06-30 06:00:00	t	0
2983	30	10	8	41	7	2021-06-30 05:50:00	2021-06-30 06:00:00	t	0
2984	30	10	8	40	4	2021-06-30 05:50:00	2021-06-30 06:00:00	t	0
2986	29	9	5	28	1	2021-06-30 06:00:00	2021-06-30 06:10:00	t	0
2989	35	11	9	44	3	2021-06-30 06:00:00	2021-06-30 06:10:00	t	0
2992	34	13	7	36	7	2021-06-30 06:00:00	2021-06-30 06:10:00	t	0
2993	34	13	7	35	6	2021-06-30 06:00:00	2021-06-30 06:10:00	t	0
2994	33	12	9	44	3	2021-06-30 06:00:00	2021-06-30 06:10:00	t	0
2997	31	11	9	44	3	2021-06-30 06:00:00	2021-06-30 06:10:00	t	0
3000	30	10	8	41	7	2021-06-30 06:00:00	2021-06-30 06:10:00	t	0
3001	30	10	8	40	4	2021-06-30 06:00:00	2021-06-30 06:10:00	t	0
2987	29	9	6	32	2	2021-06-30 06:10:00	2021-06-30 06:20:00	t	0
2990	35	11	9	43	2	2021-06-30 06:10:00	2021-06-30 06:20:00	t	0
2995	33	12	9	43	2	2021-06-30 06:10:00	2021-06-30 06:20:00	t	0
2998	31	11	9	43	2	2021-06-30 06:10:00	2021-06-30 06:20:00	t	0
2988	29	9	6	30	3	2021-06-30 06:20:00	2021-06-30 06:30:00	t	0
2991	35	11	9	42	1	2021-06-30 06:20:00	2021-06-30 06:30:00	t	0
2996	33	12	9	42	1	2021-06-30 06:20:00	2021-06-30 06:30:00	t	0
2999	31	11	9	42	1	2021-06-30 06:20:00	2021-06-30 06:30:00	t	0
3117	30	10	8	41	7	2021-06-30 08:30:00	2021-06-30 08:40:00	t	0
3118	30	10	8	40	4	2021-06-30 08:30:00	2021-06-30 08:40:00	t	0
3119	29	9	5	29	2	2021-06-30 08:30:00	2021-06-30 08:40:00	t	0
3120	29	9	5	28	1	2021-06-30 08:40:00	2021-06-30 08:50:00	t	0
3116	31	11	9	42	1	2021-06-30 08:50:00	2021-06-30 09:00:00	t	0
3121	29	9	6	32	2	2021-06-30 08:50:00	2021-06-30 09:00:00	t	0
3122	29	9	6	30	3	2021-06-30 09:00:00	2021-06-30 09:10:00	t	0
2378	30	10	8	41	7	2021-06-29 17:10:00	2021-06-29 17:20:00	t	0
1809	2	3	2	5	5	2021-06-28 12:30:00	2021-06-28 13:00:00	t	0
2547	34	13	7	36	7	2021-06-29 20:40:00	2021-06-29 20:50:00	t	0
1810	2	3	2	6	6	2021-06-28 13:00:00	2021-06-28 13:30:00	t	0
1833	29	9	5	28	1	2021-06-29 05:00:00	2021-06-29 05:10:00	t	3000
1834	29	9	5	29	2	2021-06-29 05:10:00	2021-06-29 05:20:00	t	2500
1835	29	9	6	30	3	2021-06-29 05:20:00	2021-06-29 05:30:00	t	2500
1836	29	9	6	32	2	2021-06-29 05:30:00	2021-06-29 05:40:00	t	1350
1837	29	9	5	28	1	2021-06-29 05:40:00	2021-06-29 05:50:00	t	0
1838	29	9	5	29	2	2021-06-29 05:50:00	2021-06-29 06:00:00	t	2100
1839	29	9	6	30	3	2021-06-29 06:00:00	2021-06-29 06:10:00	t	2500
1840	29	9	6	32	2	2021-06-29 06:10:00	2021-06-29 06:20:00	t	2500
1841	29	9	5	28	1	2021-06-29 06:20:00	2021-06-29 06:30:00	t	950
1842	29	9	5	29	2	2021-06-29 06:30:00	2021-06-29 06:40:00	t	2100
1843	29	9	6	30	3	2021-06-29 06:40:00	2021-06-29 06:50:00	t	0
1844	29	9	6	32	2	2021-06-29 06:50:00	2021-06-29 07:00:00	t	0
1845	29	9	5	28	1	2021-06-29 07:00:00	2021-06-29 07:10:00	t	0
1846	29	9	5	29	2	2021-06-29 07:10:00	2021-06-29 07:20:00	t	500
1847	29	9	6	30	3	2021-06-29 07:20:00	2021-06-29 07:30:00	t	0
1848	29	9	6	32	2	2021-06-29 07:30:00	2021-06-29 07:40:00	t	0
1849	29	9	5	28	1	2021-06-29 07:40:00	2021-06-29 07:50:00	t	500
1850	29	9	5	29	2	2021-06-29 07:50:00	2021-06-29 08:00:00	t	0
1851	29	9	6	30	3	2021-06-29 08:00:00	2021-06-29 08:10:00	t	0
1852	29	9	6	32	2	2021-06-29 08:10:00	2021-06-29 08:20:00	t	500
1853	29	9	5	28	1	2021-06-29 08:20:00	2021-06-29 08:30:00	t	0
1854	29	9	5	29	2	2021-06-29 08:30:00	2021-06-29 08:40:00	t	0
1855	29	9	6	30	3	2021-06-29 08:40:00	2021-06-29 08:50:00	t	0
1856	29	9	6	32	2	2021-06-29 08:50:00	2021-06-29 09:00:00	t	0
1857	29	9	5	28	1	2021-06-29 09:00:00	2021-06-29 09:10:00	t	0
1858	29	9	5	29	2	2021-06-29 09:10:00	2021-06-29 09:20:00	t	0
1859	29	9	6	30	3	2021-06-29 09:20:00	2021-06-29 09:30:00	t	0
1860	29	9	6	32	2	2021-06-29 09:30:00	2021-06-29 09:40:00	t	0
1861	29	9	5	28	1	2021-06-29 09:40:00	2021-06-29 09:50:00	t	0
1862	29	9	5	29	2	2021-06-29 09:50:00	2021-06-29 10:00:00	t	0
1863	29	9	6	30	3	2021-06-29 10:00:00	2021-06-29 10:10:00	t	0
1864	29	9	6	32	2	2021-06-29 10:10:00	2021-06-29 10:20:00	t	0
1865	29	9	5	28	1	2021-06-29 10:20:00	2021-06-29 10:30:00	t	0
1866	29	9	5	29	2	2021-06-29 10:30:00	2021-06-29 10:40:00	t	0
1867	29	9	6	30	3	2021-06-29 10:40:00	2021-06-29 10:50:00	t	0
1868	29	9	6	32	2	2021-06-29 10:50:00	2021-06-29 11:00:00	t	0
1869	29	9	5	28	1	2021-06-29 11:00:00	2021-06-29 11:10:00	t	0
2907	34	13	7	35	6	2021-06-30 04:10:00	2021-06-30 04:20:00	t	0
2908	30	10	8	41	7	2021-06-30 04:10:00	2021-06-30 04:20:00	t	0
2909	30	10	8	40	4	2021-06-30 04:10:00	2021-06-30 04:20:00	t	0
2910	34	13	7	36	7	2021-06-30 04:20:00	2021-06-30 04:30:00	t	0
2911	34	13	7	35	6	2021-06-30 04:20:00	2021-06-30 04:30:00	t	0
2913	30	10	8	40	4	2021-06-30 04:20:00	2021-06-30 04:30:00	t	0
2914	35	11	9	44	3	2021-06-30 04:30:00	2021-06-30 04:40:00	t	0
2917	34	13	7	36	7	2021-06-30 04:30:00	2021-06-30 04:40:00	t	0
2918	34	13	7	35	6	2021-06-30 04:30:00	2021-06-30 04:40:00	t	0
2919	33	12	9	44	3	2021-06-30 04:30:00	2021-06-30 04:40:00	t	0
2922	31	11	9	44	3	2021-06-30 04:30:00	2021-06-30 04:40:00	t	0
2925	30	10	8	41	7	2021-06-30 04:30:00	2021-06-30 04:40:00	t	0
2926	30	10	8	40	4	2021-06-30 04:30:00	2021-06-30 04:40:00	t	0
2927	29	9	5	29	2	2021-06-30 04:30:00	2021-06-30 04:40:00	t	0
2915	35	11	9	43	2	2021-06-30 04:40:00	2021-06-30 04:50:00	t	0
2920	33	12	9	43	2	2021-06-30 04:40:00	2021-06-30 04:50:00	t	0
2923	31	11	9	43	2	2021-06-30 04:40:00	2021-06-30 04:50:00	t	0
2928	29	9	5	28	1	2021-06-30 04:40:00	2021-06-30 04:50:00	t	0
2916	35	11	9	42	1	2021-06-30 04:50:00	2021-06-30 05:00:00	t	0
2921	33	12	9	42	1	2021-06-30 04:50:00	2021-06-30 05:00:00	t	0
2924	31	11	9	42	1	2021-06-30 04:50:00	2021-06-30 05:00:00	t	0
2929	29	9	6	32	2	2021-06-30 04:50:00	2021-06-30 05:00:00	t	0
2930	29	9	6	30	3	2021-06-30 05:00:00	2021-06-30 05:10:00	t	0
3072	30	10	8	40	4	2021-06-30 07:30:00	2021-06-30 07:40:00	t	0
3123	34	13	7	36	7	2021-06-30 08:40:00	2021-06-30 08:50:00	t	0
3124	34	13	7	35	6	2021-06-30 08:40:00	2021-06-30 08:50:00	t	0
3125	30	10	8	41	7	2021-06-30 08:40:00	2021-06-30 08:50:00	t	0
3126	30	10	8	40	4	2021-06-30 08:40:00	2021-06-30 08:50:00	t	0
3152	34	13	7	36	7	2021-06-30 09:20:00	2021-06-30 09:30:00	t	0
3153	34	13	7	35	6	2021-06-30 09:20:00	2021-06-30 09:30:00	t	0
3154	30	10	8	41	7	2021-06-30 09:20:00	2021-06-30 09:30:00	t	0
1874	30	10	7	33	4	2021-06-29 05:00:00	2021-06-29 05:10:00	t	0
1875	30	10	7	36	7	2021-06-29 05:10:00	2021-06-29 05:20:00	t	300
1876	30	10	7	35	6	2021-06-29 05:10:00	2021-06-29 05:20:00	t	300
1877	30	10	8	38	6	2021-06-29 05:20:00	2021-06-29 05:30:00	t	0
1878	30	10	8	39	5	2021-06-29 05:20:00	2021-06-29 05:30:00	t	0
1879	30	10	8	41	7	2021-06-29 05:30:00	2021-06-29 05:40:00	t	650
1880	30	10	8	40	4	2021-06-29 05:30:00	2021-06-29 05:40:00	t	0
1881	30	10	7	34	5	2021-06-29 05:40:00	2021-06-29 05:50:00	t	300
1882	30	10	7	33	4	2021-06-29 05:40:00	2021-06-29 05:50:00	t	300
1883	30	10	7	36	7	2021-06-29 05:50:00	2021-06-29 06:00:00	t	0
1884	30	10	7	35	6	2021-06-29 05:50:00	2021-06-29 06:00:00	t	0
1885	30	10	8	38	6	2021-06-29 06:00:00	2021-06-29 06:10:00	t	300
1886	30	10	8	39	5	2021-06-29 06:00:00	2021-06-29 06:10:00	t	0
1887	30	10	8	41	7	2021-06-29 06:10:00	2021-06-29 06:20:00	t	0
1888	30	10	8	40	4	2021-06-29 06:10:00	2021-06-29 06:20:00	t	0
1889	30	10	7	34	5	2021-06-29 06:20:00	2021-06-29 06:30:00	t	500
1890	30	10	7	33	4	2021-06-29 06:20:00	2021-06-29 06:30:00	t	300
1892	30	10	7	35	6	2021-06-29 06:30:00	2021-06-29 06:40:00	t	600
1893	30	10	8	38	6	2021-06-29 06:40:00	2021-06-29 06:50:00	t	0
1894	30	10	8	39	5	2021-06-29 06:40:00	2021-06-29 06:50:00	t	0
1895	30	10	8	41	7	2021-06-29 06:50:00	2021-06-29 07:00:00	t	0
1896	30	10	8	40	4	2021-06-29 06:50:00	2021-06-29 07:00:00	t	0
1897	30	10	7	34	5	2021-06-29 07:00:00	2021-06-29 07:10:00	t	0
1898	30	10	7	33	4	2021-06-29 07:00:00	2021-06-29 07:10:00	t	0
1899	30	10	7	36	7	2021-06-29 07:10:00	2021-06-29 07:20:00	t	0
1900	30	10	7	35	6	2021-06-29 07:10:00	2021-06-29 07:20:00	t	0
1901	30	10	8	38	6	2021-06-29 07:20:00	2021-06-29 07:30:00	t	0
1902	30	10	8	39	5	2021-06-29 07:20:00	2021-06-29 07:30:00	t	0
1903	30	10	8	41	7	2021-06-29 07:30:00	2021-06-29 07:40:00	t	0
1904	30	10	8	40	4	2021-06-29 07:30:00	2021-06-29 07:40:00	t	0
1905	30	10	7	34	5	2021-06-29 07:40:00	2021-06-29 07:50:00	t	0
1906	30	10	7	33	4	2021-06-29 07:40:00	2021-06-29 07:50:00	t	0
1907	30	10	7	36	7	2021-06-29 07:50:00	2021-06-29 08:00:00	t	0
1908	30	10	7	35	6	2021-06-29 07:50:00	2021-06-29 08:00:00	t	0
1909	30	10	8	38	6	2021-06-29 08:00:00	2021-06-29 08:10:00	t	0
1910	30	10	8	39	5	2021-06-29 08:00:00	2021-06-29 08:10:00	t	0
1911	30	10	8	41	7	2021-06-29 08:10:00	2021-06-29 08:20:00	t	300
1912	30	10	8	40	4	2021-06-29 08:10:00	2021-06-29 08:20:00	t	300
1913	30	10	7	34	5	2021-06-29 08:20:00	2021-06-29 08:30:00	t	0
1914	30	10	7	33	4	2021-06-29 08:20:00	2021-06-29 08:30:00	t	0
1915	30	10	7	36	7	2021-06-29 08:30:00	2021-06-29 08:40:00	t	0
1916	30	10	7	35	6	2021-06-29 08:30:00	2021-06-29 08:40:00	t	0
1917	30	10	8	38	6	2021-06-29 08:40:00	2021-06-29 08:50:00	t	0
1919	30	10	8	41	7	2021-06-29 08:50:00	2021-06-29 09:00:00	t	0
1920	30	10	8	40	4	2021-06-29 08:50:00	2021-06-29 09:00:00	t	0
1921	30	10	7	34	5	2021-06-29 09:00:00	2021-06-29 09:10:00	t	0
1922	30	10	7	33	4	2021-06-29 09:00:00	2021-06-29 09:10:00	t	0
1923	30	10	7	36	7	2021-06-29 09:10:00	2021-06-29 09:20:00	t	0
1924	30	10	7	35	6	2021-06-29 09:10:00	2021-06-29 09:20:00	t	0
1925	30	10	8	38	6	2021-06-29 09:20:00	2021-06-29 09:30:00	t	0
1926	30	10	8	39	5	2021-06-29 09:20:00	2021-06-29 09:30:00	t	0
1927	30	10	8	41	7	2021-06-29 09:30:00	2021-06-29 09:40:00	t	0
1928	30	10	8	40	4	2021-06-29 09:30:00	2021-06-29 09:40:00	t	0
1929	30	10	7	34	5	2021-06-29 09:40:00	2021-06-29 09:50:00	t	0
1930	30	10	7	33	4	2021-06-29 09:40:00	2021-06-29 09:50:00	t	0
1931	30	10	7	36	7	2021-06-29 09:50:00	2021-06-29 10:00:00	t	0
1932	30	10	7	35	6	2021-06-29 09:50:00	2021-06-29 10:00:00	t	0
1933	30	10	8	38	6	2021-06-29 10:00:00	2021-06-29 10:10:00	t	0
1934	30	10	8	39	5	2021-06-29 10:00:00	2021-06-29 10:10:00	t	0
1935	30	10	8	41	7	2021-06-29 10:10:00	2021-06-29 10:20:00	t	0
1936	30	10	8	40	4	2021-06-29 10:10:00	2021-06-29 10:20:00	t	0
1937	30	10	7	34	5	2021-06-29 10:20:00	2021-06-29 10:30:00	t	0
1938	30	10	7	33	4	2021-06-29 10:20:00	2021-06-29 10:30:00	t	0
1939	30	10	7	36	7	2021-06-29 10:30:00	2021-06-29 10:40:00	t	0
1940	30	10	7	35	6	2021-06-29 10:30:00	2021-06-29 10:40:00	t	0
1941	30	10	8	38	6	2021-06-29 10:40:00	2021-06-29 10:50:00	t	0
1942	30	10	8	39	5	2021-06-29 10:40:00	2021-06-29 10:50:00	t	0
1943	30	10	8	41	7	2021-06-29 10:50:00	2021-06-29 11:00:00	t	0
1944	30	10	8	40	4	2021-06-29 10:50:00	2021-06-29 11:00:00	t	0
1871	29	9	6	30	3	2021-06-29 11:20:00	2021-06-29 11:30:00	t	0
1872	29	9	6	32	2	2021-06-29 11:30:00	2021-06-29 11:40:00	t	0
1954	31	11	9	43	2	2021-06-29 05:10:00	2021-06-29 05:20:00	t	0
1955	31	11	9	42	1	2021-06-29 05:20:00	2021-06-29 05:30:00	t	1350
1956	31	11	9	44	3	2021-06-29 05:30:00	2021-06-29 05:40:00	t	500
1957	31	11	9	43	2	2021-06-29 05:40:00	2021-06-29 05:50:00	t	0
1958	31	11	9	42	1	2021-06-29 05:50:00	2021-06-29 06:00:00	t	0
1959	31	11	9	44	3	2021-06-29 06:00:00	2021-06-29 06:10:00	t	2000
1960	31	11	9	43	2	2021-06-29 06:10:00	2021-06-29 06:20:00	t	0
1961	31	11	9	42	1	2021-06-29 06:20:00	2021-06-29 06:30:00	t	0
1962	31	11	9	44	3	2021-06-29 06:30:00	2021-06-29 06:40:00	t	0
1963	31	11	9	43	2	2021-06-29 06:40:00	2021-06-29 06:50:00	t	0
1964	31	11	9	42	1	2021-06-29 06:50:00	2021-06-29 07:00:00	t	1700
1965	31	11	9	44	3	2021-06-29 07:00:00	2021-06-29 07:10:00	t	0
2009	33	12	9	44	3	2021-06-29 07:00:00	2021-06-29 07:10:00	t	0
1966	31	11	9	43	2	2021-06-29 07:10:00	2021-06-29 07:20:00	t	0
2010	33	12	9	43	2	2021-06-29 07:10:00	2021-06-29 07:20:00	t	500
1967	31	11	9	42	1	2021-06-29 07:20:00	2021-06-29 07:30:00	t	0
2011	33	12	9	42	1	2021-06-29 07:20:00	2021-06-29 07:30:00	t	0
2012	33	12	9	44	3	2021-06-29 07:30:00	2021-06-29 07:40:00	t	2500
1969	31	11	9	43	2	2021-06-29 07:40:00	2021-06-29 07:50:00	t	0
2013	33	12	9	43	2	2021-06-29 07:40:00	2021-06-29 07:50:00	t	2300
1970	31	11	9	42	1	2021-06-29 07:50:00	2021-06-29 08:00:00	t	0
2014	33	12	9	42	1	2021-06-29 07:50:00	2021-06-29 08:00:00	t	0
1971	31	11	9	44	3	2021-06-29 08:00:00	2021-06-29 08:10:00	t	0
2015	33	12	9	44	3	2021-06-29 08:00:00	2021-06-29 08:10:00	t	0
1972	31	11	9	43	2	2021-06-29 08:10:00	2021-06-29 08:20:00	t	0
2016	33	12	9	43	2	2021-06-29 08:10:00	2021-06-29 08:20:00	t	0
1973	31	11	9	42	1	2021-06-29 08:20:00	2021-06-29 08:30:00	t	0
2017	33	12	9	42	1	2021-06-29 08:20:00	2021-06-29 08:30:00	t	0
1974	31	11	9	44	3	2021-06-29 08:30:00	2021-06-29 08:40:00	t	0
2018	33	12	9	44	3	2021-06-29 08:30:00	2021-06-29 08:40:00	t	0
1975	31	11	9	43	2	2021-06-29 08:40:00	2021-06-29 08:50:00	t	0
2019	33	12	9	43	2	2021-06-29 08:40:00	2021-06-29 08:50:00	t	0
1976	31	11	9	42	1	2021-06-29 08:50:00	2021-06-29 09:00:00	t	0
1977	31	11	9	44	3	2021-06-29 09:00:00	2021-06-29 09:10:00	t	0
1978	31	11	9	43	2	2021-06-29 09:10:00	2021-06-29 09:20:00	t	0
1979	31	11	9	42	1	2021-06-29 09:20:00	2021-06-29 09:30:00	t	0
1980	31	11	9	44	3	2021-06-29 09:30:00	2021-06-29 09:40:00	t	0
1981	31	11	9	43	2	2021-06-29 09:40:00	2021-06-29 09:50:00	t	0
1982	31	11	9	42	1	2021-06-29 09:50:00	2021-06-29 10:00:00	t	0
1983	31	11	9	44	3	2021-06-29 10:00:00	2021-06-29 10:10:00	t	0
1984	31	11	9	43	2	2021-06-29 10:10:00	2021-06-29 10:20:00	t	0
1985	31	11	9	42	1	2021-06-29 10:20:00	2021-06-29 10:30:00	t	0
1986	31	11	9	44	3	2021-06-29 10:30:00	2021-06-29 10:40:00	t	0
1988	31	11	9	42	1	2021-06-29 10:50:00	2021-06-29 11:00:00	t	0
1945	30	10	7	34	5	2021-06-29 11:00:00	2021-06-29 11:10:00	t	0
1946	30	10	7	33	4	2021-06-29 11:00:00	2021-06-29 11:10:00	t	0
1989	31	11	9	44	3	2021-06-29 11:00:00	2021-06-29 11:10:00	t	0
1947	30	10	7	36	7	2021-06-29 11:10:00	2021-06-29 11:20:00	t	0
1948	30	10	7	35	6	2021-06-29 11:10:00	2021-06-29 11:20:00	t	0
1990	31	11	9	43	2	2021-06-29 11:10:00	2021-06-29 11:20:00	t	0
1949	30	10	8	38	6	2021-06-29 11:20:00	2021-06-29 11:30:00	t	0
1950	30	10	8	39	5	2021-06-29 11:20:00	2021-06-29 11:30:00	t	0
1991	31	11	9	42	1	2021-06-29 11:20:00	2021-06-29 11:30:00	t	0
1951	30	10	8	41	7	2021-06-29 11:30:00	2021-06-29 11:40:00	t	0
1952	30	10	8	40	4	2021-06-29 11:30:00	2021-06-29 11:40:00	t	0
1992	31	11	9	44	3	2021-06-29 11:30:00	2021-06-29 11:40:00	t	0
1993	31	11	9	43	2	2021-06-29 11:40:00	2021-06-29 11:50:00	t	0
1995	30	10	8	41	7	2021-06-29 11:40:00	2021-06-29 11:50:00	t	0
1996	30	10	8	40	4	2021-06-29 11:40:00	2021-06-29 11:50:00	t	0
1997	29	9	6	30	3	2021-06-29 11:40:00	2021-06-29 11:50:00	t	0
1994	31	11	9	42	1	2021-06-29 11:50:00	2021-06-29 12:00:00	t	0
1998	30	10	8	41	7	2021-06-29 11:50:00	2021-06-29 12:00:00	t	0
1999	30	10	8	40	4	2021-06-29 11:50:00	2021-06-29 12:00:00	t	0
2000	29	9	5	29	2	2021-06-29 11:50:00	2021-06-29 12:00:00	t	0
2001	29	9	5	28	1	2021-06-29 12:00:00	2021-06-29 12:10:00	t	0
2004	31	11	9	44	3	2021-06-29 12:00:00	2021-06-29 12:10:00	t	0
2007	30	10	8	41	7	2021-06-29 12:00:00	2021-06-29 12:10:00	t	0
2008	30	10	8	40	4	2021-06-29 12:00:00	2021-06-29 12:10:00	t	0
2002	29	9	6	32	2	2021-06-29 12:10:00	2021-06-29 12:20:00	t	0
2003	29	9	6	30	3	2021-06-29 12:20:00	2021-06-29 12:30:00	t	0
2006	31	11	9	42	1	2021-06-29 12:20:00	2021-06-29 12:30:00	t	0
2045	34	13	7	33	4	2021-06-29 07:00:00	2021-06-29 07:10:00	t	0
2046	34	13	7	36	7	2021-06-29 07:10:00	2021-06-29 07:20:00	t	0
2047	34	13	7	35	6	2021-06-29 07:10:00	2021-06-29 07:20:00	t	0
2048	34	13	7	34	5	2021-06-29 07:20:00	2021-06-29 07:30:00	t	0
2049	34	13	7	33	4	2021-06-29 07:20:00	2021-06-29 07:30:00	t	0
2050	34	13	7	36	7	2021-06-29 07:30:00	2021-06-29 07:40:00	t	0
2051	34	13	7	35	6	2021-06-29 07:30:00	2021-06-29 07:40:00	t	0
2052	34	13	7	34	5	2021-06-29 07:40:00	2021-06-29 07:50:00	t	0
2053	34	13	7	33	4	2021-06-29 07:40:00	2021-06-29 07:50:00	t	0
2054	34	13	7	36	7	2021-06-29 07:50:00	2021-06-29 08:00:00	t	0
2055	34	13	7	35	6	2021-06-29 07:50:00	2021-06-29 08:00:00	t	0
2056	34	13	7	34	5	2021-06-29 08:00:00	2021-06-29 08:10:00	t	0
2057	34	13	7	33	4	2021-06-29 08:00:00	2021-06-29 08:10:00	t	0
2058	34	13	7	36	7	2021-06-29 08:10:00	2021-06-29 08:20:00	t	0
2059	34	13	7	35	6	2021-06-29 08:10:00	2021-06-29 08:20:00	t	0
2060	34	13	7	34	5	2021-06-29 08:20:00	2021-06-29 08:30:00	t	0
2061	34	13	7	33	4	2021-06-29 08:20:00	2021-06-29 08:30:00	t	0
2063	34	13	7	35	6	2021-06-29 08:30:00	2021-06-29 08:40:00	t	0
2064	34	13	7	34	5	2021-06-29 08:40:00	2021-06-29 08:50:00	t	0
2065	34	13	7	33	4	2021-06-29 08:40:00	2021-06-29 08:50:00	t	0
2020	33	12	9	42	1	2021-06-29 08:50:00	2021-06-29 09:00:00	t	0
2066	34	13	7	36	7	2021-06-29 08:50:00	2021-06-29 09:00:00	t	0
2067	34	13	7	35	6	2021-06-29 08:50:00	2021-06-29 09:00:00	t	0
2021	33	12	9	44	3	2021-06-29 09:00:00	2021-06-29 09:10:00	t	0
2068	34	13	7	34	5	2021-06-29 09:00:00	2021-06-29 09:10:00	t	0
2069	34	13	7	33	4	2021-06-29 09:00:00	2021-06-29 09:10:00	t	0
2022	33	12	9	43	2	2021-06-29 09:10:00	2021-06-29 09:20:00	t	0
2070	34	13	7	36	7	2021-06-29 09:10:00	2021-06-29 09:20:00	t	0
2071	34	13	7	35	6	2021-06-29 09:10:00	2021-06-29 09:20:00	t	0
2023	33	12	9	42	1	2021-06-29 09:20:00	2021-06-29 09:30:00	t	0
2072	34	13	7	34	5	2021-06-29 09:20:00	2021-06-29 09:30:00	t	0
2073	34	13	7	33	4	2021-06-29 09:20:00	2021-06-29 09:30:00	t	0
2024	33	12	9	44	3	2021-06-29 09:30:00	2021-06-29 09:40:00	t	0
2074	34	13	7	36	7	2021-06-29 09:30:00	2021-06-29 09:40:00	t	0
2075	34	13	7	35	6	2021-06-29 09:30:00	2021-06-29 09:40:00	t	0
2025	33	12	9	43	2	2021-06-29 09:40:00	2021-06-29 09:50:00	t	0
2076	34	13	7	34	5	2021-06-29 09:40:00	2021-06-29 09:50:00	t	0
2077	34	13	7	33	4	2021-06-29 09:40:00	2021-06-29 09:50:00	t	0
2026	33	12	9	42	1	2021-06-29 09:50:00	2021-06-29 10:00:00	t	0
2078	34	13	7	36	7	2021-06-29 09:50:00	2021-06-29 10:00:00	t	0
2079	34	13	7	35	6	2021-06-29 09:50:00	2021-06-29 10:00:00	t	0
2027	33	12	9	44	3	2021-06-29 10:00:00	2021-06-29 10:10:00	t	0
2080	34	13	7	34	5	2021-06-29 10:00:00	2021-06-29 10:10:00	t	0
2028	33	12	9	43	2	2021-06-29 10:10:00	2021-06-29 10:20:00	t	0
2082	34	13	7	36	7	2021-06-29 10:10:00	2021-06-29 10:20:00	t	0
2083	34	13	7	35	6	2021-06-29 10:10:00	2021-06-29 10:20:00	t	0
2029	33	12	9	42	1	2021-06-29 10:20:00	2021-06-29 10:30:00	t	0
2084	34	13	7	34	5	2021-06-29 10:20:00	2021-06-29 10:30:00	t	0
2085	34	13	7	33	4	2021-06-29 10:20:00	2021-06-29 10:30:00	t	0
2030	33	12	9	44	3	2021-06-29 10:30:00	2021-06-29 10:40:00	t	0
2086	34	13	7	36	7	2021-06-29 10:30:00	2021-06-29 10:40:00	t	0
2087	34	13	7	35	6	2021-06-29 10:30:00	2021-06-29 10:40:00	t	0
2031	33	12	9	43	2	2021-06-29 10:40:00	2021-06-29 10:50:00	t	0
2088	34	13	7	34	5	2021-06-29 10:40:00	2021-06-29 10:50:00	t	0
2089	34	13	7	33	4	2021-06-29 10:40:00	2021-06-29 10:50:00	t	0
2032	33	12	9	42	1	2021-06-29 10:50:00	2021-06-29 11:00:00	t	0
2090	34	13	7	36	7	2021-06-29 10:50:00	2021-06-29 11:00:00	t	0
2091	34	13	7	35	6	2021-06-29 10:50:00	2021-06-29 11:00:00	t	0
2033	33	12	9	44	3	2021-06-29 11:00:00	2021-06-29 11:10:00	t	0
2092	34	13	7	34	5	2021-06-29 11:00:00	2021-06-29 11:10:00	t	0
2093	34	13	7	33	4	2021-06-29 11:00:00	2021-06-29 11:10:00	t	0
2034	33	12	9	43	2	2021-06-29 11:10:00	2021-06-29 11:20:00	t	0
2094	34	13	7	36	7	2021-06-29 11:10:00	2021-06-29 11:20:00	t	0
2035	33	12	9	42	1	2021-06-29 11:20:00	2021-06-29 11:30:00	t	0
2036	33	12	9	44	3	2021-06-29 11:30:00	2021-06-29 11:40:00	t	0
2037	33	12	9	43	2	2021-06-29 11:40:00	2021-06-29 11:50:00	t	0
2038	33	12	9	42	1	2021-06-29 11:50:00	2021-06-29 12:00:00	t	0
2039	33	12	9	44	3	2021-06-29 12:00:00	2021-06-29 12:10:00	t	0
2040	33	12	9	43	2	2021-06-29 12:10:00	2021-06-29 12:20:00	t	0
2043	30	10	8	40	4	2021-06-29 12:10:00	2021-06-29 12:20:00	t	0
2041	33	12	9	42	1	2021-06-29 12:20:00	2021-06-29 12:30:00	t	0
2113	35	11	9	43	2	2021-06-29 07:10:00	2021-06-29 07:20:00	t	950
2114	35	11	9	42	1	2021-06-29 07:20:00	2021-06-29 07:30:00	t	0
2115	35	11	9	44	3	2021-06-29 07:30:00	2021-06-29 07:40:00	t	0
2116	35	11	9	43	2	2021-06-29 07:40:00	2021-06-29 07:50:00	t	0
2117	35	11	9	42	1	2021-06-29 07:50:00	2021-06-29 08:00:00	t	0
2118	35	11	9	44	3	2021-06-29 08:00:00	2021-06-29 08:10:00	t	0
2119	35	11	9	43	2	2021-06-29 08:10:00	2021-06-29 08:20:00	t	500
2120	35	11	9	42	1	2021-06-29 08:20:00	2021-06-29 08:30:00	t	0
2121	35	11	9	44	3	2021-06-29 08:30:00	2021-06-29 08:40:00	t	0
2122	35	11	9	43	2	2021-06-29 08:40:00	2021-06-29 08:50:00	t	0
2123	35	11	9	42	1	2021-06-29 08:50:00	2021-06-29 09:00:00	t	0
2124	35	11	9	44	3	2021-06-29 09:00:00	2021-06-29 09:10:00	t	0
2125	35	11	9	43	2	2021-06-29 09:10:00	2021-06-29 09:20:00	t	0
2126	35	11	9	42	1	2021-06-29 09:20:00	2021-06-29 09:30:00	t	0
2127	35	11	9	44	3	2021-06-29 09:30:00	2021-06-29 09:40:00	t	0
2128	35	11	9	43	2	2021-06-29 09:40:00	2021-06-29 09:50:00	t	0
2129	35	11	9	42	1	2021-06-29 09:50:00	2021-06-29 10:00:00	t	0
2131	35	11	9	43	2	2021-06-29 10:10:00	2021-06-29 10:20:00	t	0
2132	35	11	9	42	1	2021-06-29 10:20:00	2021-06-29 10:30:00	t	0
2133	35	11	9	44	3	2021-06-29 10:30:00	2021-06-29 10:40:00	t	0
2134	35	11	9	43	2	2021-06-29 10:40:00	2021-06-29 10:50:00	t	0
2135	35	11	9	42	1	2021-06-29 10:50:00	2021-06-29 11:00:00	t	0
2136	35	11	9	44	3	2021-06-29 11:00:00	2021-06-29 11:10:00	t	0
2095	34	13	7	35	6	2021-06-29 11:10:00	2021-06-29 11:20:00	t	0
2137	35	11	9	43	2	2021-06-29 11:10:00	2021-06-29 11:20:00	t	0
2096	34	13	7	34	5	2021-06-29 11:20:00	2021-06-29 11:30:00	t	0
2097	34	13	7	33	4	2021-06-29 11:20:00	2021-06-29 11:30:00	t	0
2138	35	11	9	42	1	2021-06-29 11:20:00	2021-06-29 11:30:00	t	0
2098	34	13	7	36	7	2021-06-29 11:30:00	2021-06-29 11:40:00	t	0
2099	34	13	7	35	6	2021-06-29 11:30:00	2021-06-29 11:40:00	t	0
2139	35	11	9	44	3	2021-06-29 11:30:00	2021-06-29 11:40:00	t	0
2100	34	13	7	34	5	2021-06-29 11:40:00	2021-06-29 11:50:00	t	0
2101	34	13	7	33	4	2021-06-29 11:40:00	2021-06-29 11:50:00	t	0
2140	35	11	9	43	2	2021-06-29 11:40:00	2021-06-29 11:50:00	t	0
2102	34	13	7	36	7	2021-06-29 11:50:00	2021-06-29 12:00:00	t	0
2103	34	13	7	35	6	2021-06-29 11:50:00	2021-06-29 12:00:00	t	0
2141	35	11	9	42	1	2021-06-29 11:50:00	2021-06-29 12:00:00	t	0
2104	34	13	7	34	5	2021-06-29 12:00:00	2021-06-29 12:10:00	t	0
2105	34	13	7	33	4	2021-06-29 12:00:00	2021-06-29 12:10:00	t	0
2142	35	11	9	44	3	2021-06-29 12:00:00	2021-06-29 12:10:00	t	0
2106	34	13	7	36	7	2021-06-29 12:10:00	2021-06-29 12:20:00	t	0
2107	34	13	7	35	6	2021-06-29 12:10:00	2021-06-29 12:20:00	t	0
2143	35	11	9	43	2	2021-06-29 12:10:00	2021-06-29 12:20:00	t	0
2109	34	13	7	35	6	2021-06-29 12:20:00	2021-06-29 12:30:00	t	0
2110	30	10	8	41	7	2021-06-29 12:20:00	2021-06-29 12:30:00	t	0
2111	30	10	8	40	4	2021-06-29 12:20:00	2021-06-29 12:30:00	t	0
2144	35	11	9	42	1	2021-06-29 12:20:00	2021-06-29 12:30:00	t	0
2145	35	11	9	44	3	2021-06-29 12:30:00	2021-06-29 12:40:00	t	0
2148	34	13	7	36	7	2021-06-29 12:30:00	2021-06-29 12:40:00	t	0
2149	34	13	7	35	6	2021-06-29 12:30:00	2021-06-29 12:40:00	t	0
2150	33	12	9	44	3	2021-06-29 12:30:00	2021-06-29 12:40:00	t	0
2153	31	11	9	44	3	2021-06-29 12:30:00	2021-06-29 12:40:00	t	0
2156	30	10	8	41	7	2021-06-29 12:30:00	2021-06-29 12:40:00	t	0
2157	30	10	8	40	4	2021-06-29 12:30:00	2021-06-29 12:40:00	t	0
2158	29	9	5	29	2	2021-06-29 12:30:00	2021-06-29 12:40:00	t	0
2146	35	11	9	43	2	2021-06-29 12:40:00	2021-06-29 12:50:00	t	0
2151	33	12	9	43	2	2021-06-29 12:40:00	2021-06-29 12:50:00	t	0
2154	31	11	9	43	2	2021-06-29 12:40:00	2021-06-29 12:50:00	t	0
2159	29	9	5	28	1	2021-06-29 12:40:00	2021-06-29 12:50:00	t	0
2162	34	13	7	36	7	2021-06-29 12:40:00	2021-06-29 12:50:00	t	0
2163	34	13	7	35	6	2021-06-29 12:40:00	2021-06-29 12:50:00	t	0
2164	30	10	8	41	7	2021-06-29 12:40:00	2021-06-29 12:50:00	t	0
2165	30	10	8	40	4	2021-06-29 12:40:00	2021-06-29 12:50:00	t	0
2147	35	11	9	42	1	2021-06-29 12:50:00	2021-06-29 13:00:00	t	0
2152	33	12	9	42	1	2021-06-29 12:50:00	2021-06-29 13:00:00	t	0
2155	31	11	9	42	1	2021-06-29 12:50:00	2021-06-29 13:00:00	t	0
2160	29	9	6	32	2	2021-06-29 12:50:00	2021-06-29 13:00:00	t	0
2166	34	13	7	36	7	2021-06-29 12:50:00	2021-06-29 13:00:00	t	0
2167	34	13	7	35	6	2021-06-29 12:50:00	2021-06-29 13:00:00	t	0
2169	30	10	8	40	4	2021-06-29 12:50:00	2021-06-29 13:00:00	t	0
2161	29	9	6	30	3	2021-06-29 13:00:00	2021-06-29 13:10:00	t	0
1873	30	10	7	34	5	2021-06-29 05:00:00	2021-06-29 05:10:00	t	0
1953	31	11	9	44	3	2021-06-29 05:00:00	2021-06-29 05:10:00	t	0
2170	35	11	9	44	3	2021-06-29 13:00:00	2021-06-29 13:10:00	t	0
2173	34	13	7	36	7	2021-06-29 13:00:00	2021-06-29 13:10:00	t	0
2174	34	13	7	35	6	2021-06-29 13:00:00	2021-06-29 13:10:00	t	0
2175	33	12	9	44	3	2021-06-29 13:00:00	2021-06-29 13:10:00	t	0
2178	31	11	9	44	3	2021-06-29 13:00:00	2021-06-29 13:10:00	t	0
2181	30	10	8	41	7	2021-06-29 13:00:00	2021-06-29 13:10:00	t	0
2182	30	10	8	40	4	2021-06-29 13:00:00	2021-06-29 13:10:00	t	0
2171	35	11	9	43	2	2021-06-29 13:10:00	2021-06-29 13:20:00	t	0
2176	33	12	9	43	2	2021-06-29 13:10:00	2021-06-29 13:20:00	t	0
2179	31	11	9	43	2	2021-06-29 13:10:00	2021-06-29 13:20:00	t	0
2183	34	13	7	36	7	2021-06-29 13:10:00	2021-06-29 13:20:00	t	0
2184	34	13	7	35	6	2021-06-29 13:10:00	2021-06-29 13:20:00	t	0
2185	30	10	8	41	7	2021-06-29 13:10:00	2021-06-29 13:20:00	t	0
2186	30	10	8	40	4	2021-06-29 13:10:00	2021-06-29 13:20:00	t	0
2187	29	9	5	29	2	2021-06-29 13:10:00	2021-06-29 13:20:00	t	0
2172	35	11	9	42	1	2021-06-29 13:20:00	2021-06-29 13:30:00	t	0
2177	33	12	9	42	1	2021-06-29 13:20:00	2021-06-29 13:30:00	t	0
2188	29	9	5	28	1	2021-06-29 13:20:00	2021-06-29 13:30:00	t	0
2191	34	13	7	36	7	2021-06-29 13:20:00	2021-06-29 13:30:00	t	0
2192	34	13	7	35	6	2021-06-29 13:20:00	2021-06-29 13:30:00	t	0
2193	30	10	8	41	7	2021-06-29 13:20:00	2021-06-29 13:30:00	t	0
2194	30	10	8	40	4	2021-06-29 13:20:00	2021-06-29 13:30:00	t	0
2189	29	9	6	32	2	2021-06-29 13:30:00	2021-06-29 13:40:00	t	0
2195	35	11	9	44	3	2021-06-29 13:30:00	2021-06-29 13:40:00	t	0
2198	34	13	7	36	7	2021-06-29 13:30:00	2021-06-29 13:40:00	t	0
2199	34	13	7	35	6	2021-06-29 13:30:00	2021-06-29 13:40:00	t	0
2200	33	12	9	44	3	2021-06-29 13:30:00	2021-06-29 13:40:00	t	0
2203	31	11	9	44	3	2021-06-29 13:30:00	2021-06-29 13:40:00	t	0
2206	30	10	8	41	7	2021-06-29 13:30:00	2021-06-29 13:40:00	t	0
2207	30	10	8	40	4	2021-06-29 13:30:00	2021-06-29 13:40:00	t	0
2190	29	9	6	30	3	2021-06-29 13:40:00	2021-06-29 13:50:00	t	0
2196	35	11	9	43	2	2021-06-29 13:40:00	2021-06-29 13:50:00	t	0
2201	33	12	9	43	2	2021-06-29 13:40:00	2021-06-29 13:50:00	t	0
2204	31	11	9	43	2	2021-06-29 13:40:00	2021-06-29 13:50:00	t	0
2208	34	13	7	36	7	2021-06-29 13:40:00	2021-06-29 13:50:00	t	0
2209	34	13	7	35	6	2021-06-29 13:40:00	2021-06-29 13:50:00	t	0
2210	30	10	8	41	7	2021-06-29 13:40:00	2021-06-29 13:50:00	t	0
2211	30	10	8	40	4	2021-06-29 13:40:00	2021-06-29 13:50:00	t	0
2197	35	11	9	42	1	2021-06-29 13:50:00	2021-06-29 14:00:00	t	0
2202	33	12	9	42	1	2021-06-29 13:50:00	2021-06-29 14:00:00	t	0
2205	31	11	9	42	1	2021-06-29 13:50:00	2021-06-29 14:00:00	t	0
2212	34	13	7	36	7	2021-06-29 13:50:00	2021-06-29 14:00:00	t	0
2213	34	13	7	35	6	2021-06-29 13:50:00	2021-06-29 14:00:00	t	0
2215	30	10	8	40	4	2021-06-29 13:50:00	2021-06-29 14:00:00	t	0
2216	29	9	5	29	2	2021-06-29 13:50:00	2021-06-29 14:00:00	t	0
2217	29	9	5	28	1	2021-06-29 14:00:00	2021-06-29 14:10:00	t	0
2220	35	11	9	44	3	2021-06-29 14:00:00	2021-06-29 14:10:00	t	0
2223	34	13	7	36	7	2021-06-29 14:00:00	2021-06-29 14:10:00	t	0
2224	34	13	7	35	6	2021-06-29 14:00:00	2021-06-29 14:10:00	t	0
2225	33	12	9	44	3	2021-06-29 14:00:00	2021-06-29 14:10:00	t	0
2228	31	11	9	44	3	2021-06-29 14:00:00	2021-06-29 14:10:00	t	0
2231	30	10	8	41	7	2021-06-29 14:00:00	2021-06-29 14:10:00	t	0
2232	30	10	8	40	4	2021-06-29 14:00:00	2021-06-29 14:10:00	t	0
2218	29	9	6	32	2	2021-06-29 14:10:00	2021-06-29 14:20:00	t	0
2221	35	11	9	43	2	2021-06-29 14:10:00	2021-06-29 14:20:00	t	0
2226	33	12	9	43	2	2021-06-29 14:10:00	2021-06-29 14:20:00	t	0
2229	31	11	9	43	2	2021-06-29 14:10:00	2021-06-29 14:20:00	t	0
2234	34	13	7	36	7	2021-06-29 14:10:00	2021-06-29 14:20:00	t	0
2235	34	13	7	35	6	2021-06-29 14:10:00	2021-06-29 14:20:00	t	0
2236	30	10	8	41	7	2021-06-29 14:10:00	2021-06-29 14:20:00	t	0
2237	30	10	8	40	4	2021-06-29 14:10:00	2021-06-29 14:20:00	t	0
2219	29	9	6	30	3	2021-06-29 14:20:00	2021-06-29 14:30:00	t	0
2222	35	11	9	42	1	2021-06-29 14:20:00	2021-06-29 14:30:00	t	0
2227	33	12	9	42	1	2021-06-29 14:20:00	2021-06-29 14:30:00	t	0
2230	31	11	9	42	1	2021-06-29 14:20:00	2021-06-29 14:30:00	t	0
2238	34	13	7	36	7	2021-06-29 14:20:00	2021-06-29 14:30:00	t	0
2239	34	13	7	35	6	2021-06-29 14:20:00	2021-06-29 14:30:00	t	0
2240	30	10	8	41	7	2021-06-29 14:20:00	2021-06-29 14:30:00	t	0
2241	30	10	8	40	4	2021-06-29 14:20:00	2021-06-29 14:30:00	t	0
2316	29	9	6	30	3	2021-06-29 16:20:00	2021-06-29 16:30:00	t	0
1891	30	10	7	36	7	2021-06-29 06:30:00	2021-06-29 06:40:00	t	0
2246	34	13	7	35	6	2021-06-29 14:30:00	2021-06-29 14:40:00	t	0
2247	33	12	9	44	3	2021-06-29 14:30:00	2021-06-29 14:40:00	t	0
2250	31	11	9	44	3	2021-06-29 14:30:00	2021-06-29 14:40:00	t	0
2253	30	10	8	41	7	2021-06-29 14:30:00	2021-06-29 14:40:00	t	0
2254	30	10	8	40	4	2021-06-29 14:30:00	2021-06-29 14:40:00	t	0
2255	29	9	5	29	2	2021-06-29 14:30:00	2021-06-29 14:40:00	t	0
2243	35	11	9	43	2	2021-06-29 14:40:00	2021-06-29 14:50:00	t	0
2248	33	12	9	43	2	2021-06-29 14:40:00	2021-06-29 14:50:00	t	0
2251	31	11	9	43	2	2021-06-29 14:40:00	2021-06-29 14:50:00	t	0
2256	29	9	5	28	1	2021-06-29 14:40:00	2021-06-29 14:50:00	t	0
2259	34	13	7	36	7	2021-06-29 14:40:00	2021-06-29 14:50:00	t	0
2260	34	13	7	35	6	2021-06-29 14:40:00	2021-06-29 14:50:00	t	0
2261	30	10	8	41	7	2021-06-29 14:40:00	2021-06-29 14:50:00	t	0
2262	30	10	8	40	4	2021-06-29 14:40:00	2021-06-29 14:50:00	t	0
2244	35	11	9	42	1	2021-06-29 14:50:00	2021-06-29 15:00:00	t	0
2249	33	12	9	42	1	2021-06-29 14:50:00	2021-06-29 15:00:00	t	0
2252	31	11	9	42	1	2021-06-29 14:50:00	2021-06-29 15:00:00	t	0
2263	34	13	7	36	7	2021-06-29 14:50:00	2021-06-29 15:00:00	t	0
2264	34	13	7	35	6	2021-06-29 14:50:00	2021-06-29 15:00:00	t	0
2265	30	10	8	41	7	2021-06-29 14:50:00	2021-06-29 15:00:00	t	0
2266	30	10	8	40	4	2021-06-29 14:50:00	2021-06-29 15:00:00	t	0
2258	29	9	6	30	3	2021-06-29 15:00:00	2021-06-29 15:10:00	t	0
2267	35	11	9	44	3	2021-06-29 15:00:00	2021-06-29 15:10:00	t	0
2270	34	13	7	36	7	2021-06-29 15:00:00	2021-06-29 15:10:00	t	0
2271	34	13	7	35	6	2021-06-29 15:00:00	2021-06-29 15:10:00	t	0
2272	33	12	9	44	3	2021-06-29 15:00:00	2021-06-29 15:10:00	t	0
2275	31	11	9	44	3	2021-06-29 15:00:00	2021-06-29 15:10:00	t	0
2278	30	10	8	41	7	2021-06-29 15:00:00	2021-06-29 15:10:00	t	0
2279	30	10	8	40	4	2021-06-29 15:00:00	2021-06-29 15:10:00	t	0
2268	35	11	9	43	2	2021-06-29 15:10:00	2021-06-29 15:20:00	t	0
2273	33	12	9	43	2	2021-06-29 15:10:00	2021-06-29 15:20:00	t	0
2276	31	11	9	43	2	2021-06-29 15:10:00	2021-06-29 15:20:00	t	0
2280	34	13	7	36	7	2021-06-29 15:10:00	2021-06-29 15:20:00	t	0
2281	34	13	7	35	6	2021-06-29 15:10:00	2021-06-29 15:20:00	t	0
2282	30	10	8	41	7	2021-06-29 15:10:00	2021-06-29 15:20:00	t	0
2283	30	10	8	40	4	2021-06-29 15:10:00	2021-06-29 15:20:00	t	0
2284	29	9	5	29	2	2021-06-29 15:10:00	2021-06-29 15:20:00	t	0
2269	35	11	9	42	1	2021-06-29 15:20:00	2021-06-29 15:30:00	t	0
2274	33	12	9	42	1	2021-06-29 15:20:00	2021-06-29 15:30:00	t	0
2277	31	11	9	42	1	2021-06-29 15:20:00	2021-06-29 15:30:00	t	0
2285	29	9	5	28	1	2021-06-29 15:20:00	2021-06-29 15:30:00	t	0
2288	34	13	7	36	7	2021-06-29 15:20:00	2021-06-29 15:30:00	t	0
2289	34	13	7	35	6	2021-06-29 15:20:00	2021-06-29 15:30:00	t	0
2291	30	10	8	40	4	2021-06-29 15:20:00	2021-06-29 15:30:00	t	0
2286	29	9	6	32	2	2021-06-29 15:30:00	2021-06-29 15:40:00	t	0
2292	35	11	9	44	3	2021-06-29 15:30:00	2021-06-29 15:40:00	t	0
2295	34	13	7	36	7	2021-06-29 15:30:00	2021-06-29 15:40:00	t	0
2296	34	13	7	35	6	2021-06-29 15:30:00	2021-06-29 15:40:00	t	0
2297	33	12	9	44	3	2021-06-29 15:30:00	2021-06-29 15:40:00	t	0
2300	31	11	9	44	3	2021-06-29 15:30:00	2021-06-29 15:40:00	t	0
2303	30	10	8	41	7	2021-06-29 15:30:00	2021-06-29 15:40:00	t	0
2304	30	10	8	40	4	2021-06-29 15:30:00	2021-06-29 15:40:00	t	0
2287	29	9	6	30	3	2021-06-29 15:40:00	2021-06-29 15:50:00	t	0
2293	35	11	9	43	2	2021-06-29 15:40:00	2021-06-29 15:50:00	t	0
2298	33	12	9	43	2	2021-06-29 15:40:00	2021-06-29 15:50:00	t	0
2301	31	11	9	43	2	2021-06-29 15:40:00	2021-06-29 15:50:00	t	0
2305	34	13	7	36	7	2021-06-29 15:40:00	2021-06-29 15:50:00	t	0
2306	34	13	7	35	6	2021-06-29 15:40:00	2021-06-29 15:50:00	t	0
2307	30	10	8	41	7	2021-06-29 15:40:00	2021-06-29 15:50:00	t	0
2308	30	10	8	40	4	2021-06-29 15:40:00	2021-06-29 15:50:00	t	0
2294	35	11	9	42	1	2021-06-29 15:50:00	2021-06-29 16:00:00	t	0
2299	33	12	9	42	1	2021-06-29 15:50:00	2021-06-29 16:00:00	t	0
2302	31	11	9	42	1	2021-06-29 15:50:00	2021-06-29 16:00:00	t	0
2309	34	13	7	36	7	2021-06-29 15:50:00	2021-06-29 16:00:00	t	0
2310	34	13	7	35	6	2021-06-29 15:50:00	2021-06-29 16:00:00	t	0
2311	30	10	8	41	7	2021-06-29 15:50:00	2021-06-29 16:00:00	t	0
2312	30	10	8	40	4	2021-06-29 15:50:00	2021-06-29 16:00:00	t	0
2313	29	9	5	29	2	2021-06-29 15:50:00	2021-06-29 16:00:00	t	0
2314	29	9	5	28	1	2021-06-29 16:00:00	2021-06-29 16:10:00	t	0
2317	35	11	9	44	3	2021-06-29 16:00:00	2021-06-29 16:10:00	t	0
2320	34	13	7	36	7	2021-06-29 16:00:00	2021-06-29 16:10:00	t	0
2321	34	13	7	35	6	2021-06-29 16:00:00	2021-06-29 16:10:00	t	0
2322	33	12	9	44	3	2021-06-29 16:00:00	2021-06-29 16:10:00	t	0
2325	31	11	9	44	3	2021-06-29 16:00:00	2021-06-29 16:10:00	t	0
2328	30	10	8	41	7	2021-06-29 16:00:00	2021-06-29 16:10:00	t	0
2329	30	10	8	40	4	2021-06-29 16:00:00	2021-06-29 16:10:00	t	0
2318	35	11	9	43	2	2021-06-29 16:10:00	2021-06-29 16:20:00	t	0
2323	33	12	9	43	2	2021-06-29 16:10:00	2021-06-29 16:20:00	t	0
2326	31	11	9	43	2	2021-06-29 16:10:00	2021-06-29 16:20:00	t	0
2319	35	11	9	42	1	2021-06-29 16:20:00	2021-06-29 16:30:00	t	0
2324	33	12	9	42	1	2021-06-29 16:20:00	2021-06-29 16:30:00	t	0
2327	31	11	9	42	1	2021-06-29 16:20:00	2021-06-29 16:30:00	t	0
2473	34	13	7	35	6	2021-06-29 19:10:00	2021-06-29 19:20:00	t	0
2545	29	9	6	32	2	2021-06-29 20:50:00	2021-06-29 21:00:00	t	0
2564	31	11	9	43	2	2021-06-29 21:10:00	2021-06-29 21:20:00	t	0
2826	31	11	9	44	3	2021-06-30 02:30:00	2021-06-30 02:40:00	t	0
2829	30	10	8	41	7	2021-06-30 02:30:00	2021-06-30 02:40:00	t	0
2830	30	10	8	40	4	2021-06-30 02:30:00	2021-06-30 02:40:00	t	0
2831	29	9	5	29	2	2021-06-30 02:30:00	2021-06-30 02:40:00	t	0
2827	31	11	9	43	2	2021-06-30 02:40:00	2021-06-30 02:50:00	t	0
2832	29	9	5	28	1	2021-06-30 02:40:00	2021-06-30 02:50:00	t	0
2835	34	13	7	36	7	2021-06-30 02:40:00	2021-06-30 02:50:00	t	0
2836	34	13	7	35	6	2021-06-30 02:40:00	2021-06-30 02:50:00	t	0
2837	30	10	8	41	7	2021-06-30 02:40:00	2021-06-30 02:50:00	t	0
2838	30	10	8	40	4	2021-06-30 02:40:00	2021-06-30 02:50:00	t	0
2825	33	12	9	42	1	2021-06-30 02:50:00	2021-06-30 03:00:00	t	0
2828	31	11	9	42	1	2021-06-30 02:50:00	2021-06-30 03:00:00	t	0
2833	29	9	6	32	2	2021-06-30 02:50:00	2021-06-30 03:00:00	t	0
2839	34	13	7	36	7	2021-06-30 02:50:00	2021-06-30 03:00:00	t	0
2840	34	13	7	35	6	2021-06-30 02:50:00	2021-06-30 03:00:00	t	0
2841	30	10	8	41	7	2021-06-30 02:50:00	2021-06-30 03:00:00	t	0
2842	30	10	8	40	4	2021-06-30 02:50:00	2021-06-30 03:00:00	t	0
2834	29	9	6	30	3	2021-06-30 03:00:00	2021-06-30 03:10:00	t	0
3073	34	13	7	36	7	2021-06-30 07:40:00	2021-06-30 07:50:00	t	0
3074	34	13	7	35	6	2021-06-30 07:40:00	2021-06-30 07:50:00	t	0
3075	30	10	8	41	7	2021-06-30 07:40:00	2021-06-30 07:50:00	t	0
3076	30	10	8	40	4	2021-06-30 07:40:00	2021-06-30 07:50:00	t	0
3077	34	13	7	36	7	2021-06-30 07:50:00	2021-06-30 08:00:00	t	0
3078	34	13	7	35	6	2021-06-30 07:50:00	2021-06-30 08:00:00	t	0
3079	30	10	8	41	7	2021-06-30 07:50:00	2021-06-30 08:00:00	t	0
3080	30	10	8	40	4	2021-06-30 07:50:00	2021-06-30 08:00:00	t	0
3081	29	9	5	29	2	2021-06-30 07:50:00	2021-06-30 08:00:00	t	0
3082	29	9	5	28	1	2021-06-30 08:00:00	2021-06-30 08:10:00	t	0
3085	35	11	9	44	3	2021-06-30 08:00:00	2021-06-30 08:10:00	t	0
3088	34	13	7	36	7	2021-06-30 08:00:00	2021-06-30 08:10:00	t	0
3090	33	12	9	44	3	2021-06-30 08:00:00	2021-06-30 08:10:00	t	0
3093	31	11	9	44	3	2021-06-30 08:00:00	2021-06-30 08:10:00	t	0
3096	30	10	8	41	7	2021-06-30 08:00:00	2021-06-30 08:10:00	t	0
3097	30	10	8	40	4	2021-06-30 08:00:00	2021-06-30 08:10:00	t	0
3083	29	9	6	32	2	2021-06-30 08:10:00	2021-06-30 08:20:00	t	0
3086	35	11	9	43	2	2021-06-30 08:10:00	2021-06-30 08:20:00	t	0
3091	33	12	9	43	2	2021-06-30 08:10:00	2021-06-30 08:20:00	t	0
3094	31	11	9	43	2	2021-06-30 08:10:00	2021-06-30 08:20:00	t	0
3098	34	13	7	36	7	2021-06-30 08:10:00	2021-06-30 08:20:00	t	0
3099	34	13	7	35	6	2021-06-30 08:10:00	2021-06-30 08:20:00	t	0
3100	30	10	8	41	7	2021-06-30 08:10:00	2021-06-30 08:20:00	t	0
3101	30	10	8	40	4	2021-06-30 08:10:00	2021-06-30 08:20:00	t	0
3084	29	9	6	30	3	2021-06-30 08:20:00	2021-06-30 08:30:00	t	0
3087	35	11	9	42	1	2021-06-30 08:20:00	2021-06-30 08:30:00	t	0
3092	33	12	9	42	1	2021-06-30 08:20:00	2021-06-30 08:30:00	t	0
3095	31	11	9	42	1	2021-06-30 08:20:00	2021-06-30 08:30:00	t	0
3127	34	13	7	36	7	2021-06-30 08:50:00	2021-06-30 09:00:00	t	0
3128	34	13	7	35	6	2021-06-30 08:50:00	2021-06-30 09:00:00	t	0
3129	30	10	8	41	7	2021-06-30 08:50:00	2021-06-30 09:00:00	t	0
3130	30	10	8	40	4	2021-06-30 08:50:00	2021-06-30 09:00:00	t	0
3131	35	11	9	44	3	2021-06-30 09:00:00	2021-06-30 09:10:00	t	0
3134	34	13	7	36	7	2021-06-30 09:00:00	2021-06-30 09:10:00	t	0
3135	34	13	7	35	6	2021-06-30 09:00:00	2021-06-30 09:10:00	t	0
3136	33	12	9	44	3	2021-06-30 09:00:00	2021-06-30 09:10:00	t	0
3132	35	11	9	43	2	2021-06-30 09:10:00	2021-06-30 09:20:00	t	0
3133	35	11	9	42	1	2021-06-30 09:20:00	2021-06-30 09:30:00	t	0
2233	32	0	0	0	0	2021-06-29 05:00:00	2021-06-29 07:00:00	t	0
2044	34	13	7	34	5	2021-06-29 07:00:00	2021-06-29 07:10:00	t	0
2112	35	11	9	44	3	2021-06-29 07:00:00	2021-06-29 07:10:00	t	0
1968	31	11	9	44	3	2021-06-29 07:30:00	2021-06-29 07:40:00	t	0
2331	34	13	7	35	6	2021-06-29 16:10:00	2021-06-29 16:20:00	t	0
2332	30	10	8	41	7	2021-06-29 16:10:00	2021-06-29 16:20:00	t	0
2333	30	10	8	40	4	2021-06-29 16:10:00	2021-06-29 16:20:00	t	0
2334	34	13	7	36	7	2021-06-29 16:20:00	2021-06-29 16:30:00	t	0
2335	34	13	7	35	6	2021-06-29 16:20:00	2021-06-29 16:30:00	t	0
2336	30	10	8	41	7	2021-06-29 16:20:00	2021-06-29 16:30:00	t	0
2337	30	10	8	40	4	2021-06-29 16:20:00	2021-06-29 16:30:00	t	0
2338	35	11	9	44	3	2021-06-29 16:30:00	2021-06-29 16:40:00	t	0
2341	34	13	7	36	7	2021-06-29 16:30:00	2021-06-29 16:40:00	t	0
2342	34	13	7	35	6	2021-06-29 16:30:00	2021-06-29 16:40:00	t	0
2343	33	12	9	44	3	2021-06-29 16:30:00	2021-06-29 16:40:00	t	0
2346	31	11	9	44	3	2021-06-29 16:30:00	2021-06-29 16:40:00	t	0
2349	30	10	8	41	7	2021-06-29 16:30:00	2021-06-29 16:40:00	t	0
2350	30	10	8	40	4	2021-06-29 16:30:00	2021-06-29 16:40:00	t	0
2351	29	9	5	29	2	2021-06-29 16:30:00	2021-06-29 16:40:00	t	0
2339	35	11	9	43	2	2021-06-29 16:40:00	2021-06-29 16:50:00	t	0
2344	33	12	9	43	2	2021-06-29 16:40:00	2021-06-29 16:50:00	t	0
2352	29	9	5	28	1	2021-06-29 16:40:00	2021-06-29 16:50:00	t	0
2355	34	13	7	36	7	2021-06-29 16:40:00	2021-06-29 16:50:00	t	0
2356	34	13	7	35	6	2021-06-29 16:40:00	2021-06-29 16:50:00	t	0
2357	30	10	8	41	7	2021-06-29 16:40:00	2021-06-29 16:50:00	t	0
2358	30	10	8	40	4	2021-06-29 16:40:00	2021-06-29 16:50:00	t	0
2340	35	11	9	42	1	2021-06-29 16:50:00	2021-06-29 17:00:00	t	0
2345	33	12	9	42	1	2021-06-29 16:50:00	2021-06-29 17:00:00	t	0
2348	31	11	9	42	1	2021-06-29 16:50:00	2021-06-29 17:00:00	t	0
2353	29	9	6	32	2	2021-06-29 16:50:00	2021-06-29 17:00:00	t	0
2359	34	13	7	36	7	2021-06-29 16:50:00	2021-06-29 17:00:00	t	0
2360	34	13	7	35	6	2021-06-29 16:50:00	2021-06-29 17:00:00	t	0
2361	30	10	8	41	7	2021-06-29 16:50:00	2021-06-29 17:00:00	t	0
2362	30	10	8	40	4	2021-06-29 16:50:00	2021-06-29 17:00:00	t	0
2354	29	9	6	30	3	2021-06-29 17:00:00	2021-06-29 17:10:00	t	0
2363	35	11	9	44	3	2021-06-29 17:00:00	2021-06-29 17:10:00	t	0
2366	34	13	7	36	7	2021-06-29 17:00:00	2021-06-29 17:10:00	t	0
2367	34	13	7	35	6	2021-06-29 17:00:00	2021-06-29 17:10:00	t	0
2368	33	12	9	44	3	2021-06-29 17:00:00	2021-06-29 17:10:00	t	0
2371	31	11	9	44	3	2021-06-29 17:00:00	2021-06-29 17:10:00	t	0
2374	30	10	8	41	7	2021-06-29 17:00:00	2021-06-29 17:10:00	t	0
2375	30	10	8	40	4	2021-06-29 17:00:00	2021-06-29 17:10:00	t	0
2364	35	11	9	43	2	2021-06-29 17:10:00	2021-06-29 17:20:00	t	0
2369	33	12	9	43	2	2021-06-29 17:10:00	2021-06-29 17:20:00	t	0
2372	31	11	9	43	2	2021-06-29 17:10:00	2021-06-29 17:20:00	t	0
2376	34	13	7	36	7	2021-06-29 17:10:00	2021-06-29 17:20:00	t	0
2377	34	13	7	35	6	2021-06-29 17:10:00	2021-06-29 17:20:00	t	0
2379	30	10	8	40	4	2021-06-29 17:10:00	2021-06-29 17:20:00	t	0
2380	29	9	5	29	2	2021-06-29 17:10:00	2021-06-29 17:20:00	t	0
2365	35	11	9	42	1	2021-06-29 17:20:00	2021-06-29 17:30:00	t	0
2370	33	12	9	42	1	2021-06-29 17:20:00	2021-06-29 17:30:00	t	0
2373	31	11	9	42	1	2021-06-29 17:20:00	2021-06-29 17:30:00	t	0
2381	29	9	5	28	1	2021-06-29 17:20:00	2021-06-29 17:30:00	t	0
2384	34	13	7	36	7	2021-06-29 17:20:00	2021-06-29 17:30:00	t	0
2385	34	13	7	35	6	2021-06-29 17:20:00	2021-06-29 17:30:00	t	0
2386	30	10	8	41	7	2021-06-29 17:20:00	2021-06-29 17:30:00	t	0
2387	30	10	8	40	4	2021-06-29 17:20:00	2021-06-29 17:30:00	t	0
2382	29	9	6	32	2	2021-06-29 17:30:00	2021-06-29 17:40:00	t	0
2388	35	11	9	44	3	2021-06-29 17:30:00	2021-06-29 17:40:00	t	0
2391	34	13	7	36	7	2021-06-29 17:30:00	2021-06-29 17:40:00	t	0
2392	34	13	7	35	6	2021-06-29 17:30:00	2021-06-29 17:40:00	t	0
2393	33	12	9	44	3	2021-06-29 17:30:00	2021-06-29 17:40:00	t	0
2396	31	11	9	44	3	2021-06-29 17:30:00	2021-06-29 17:40:00	t	0
2399	30	10	8	41	7	2021-06-29 17:30:00	2021-06-29 17:40:00	t	0
2400	30	10	8	40	4	2021-06-29 17:30:00	2021-06-29 17:40:00	t	0
2383	29	9	6	30	3	2021-06-29 17:40:00	2021-06-29 17:50:00	t	0
2389	35	11	9	43	2	2021-06-29 17:40:00	2021-06-29 17:50:00	t	0
2394	33	12	9	43	2	2021-06-29 17:40:00	2021-06-29 17:50:00	t	0
2397	31	11	9	43	2	2021-06-29 17:40:00	2021-06-29 17:50:00	t	0
2390	35	11	9	42	1	2021-06-29 17:50:00	2021-06-29 18:00:00	t	0
2395	33	12	9	42	1	2021-06-29 17:50:00	2021-06-29 18:00:00	t	0
2398	31	11	9	42	1	2021-06-29 17:50:00	2021-06-29 18:00:00	t	0
2062	34	13	7	36	7	2021-06-29 08:30:00	2021-06-29 08:40:00	t	0
2401	34	13	7	36	7	2021-06-29 17:40:00	2021-06-29 17:50:00	t	0
2635	31	11	9	43	2	2021-06-29 22:40:00	2021-06-29 22:50:00	t	0
2691	30	10	8	41	7	2021-06-29 23:40:00	2021-06-29 23:50:00	t	0
2686	31	11	9	42	1	2021-06-29 23:50:00	2021-06-30 00:00:00	t	0
2741	30	10	8	41	7	2021-06-30 00:40:00	2021-06-30 00:50:00	t	0
2762	30	10	8	41	7	2021-06-30 01:10:00	2021-06-30 01:20:00	t	0
2932	34	13	7	35	6	2021-06-30 04:40:00	2021-06-30 04:50:00	t	0
2933	30	10	8	41	7	2021-06-30 04:40:00	2021-06-30 04:50:00	t	0
2934	30	10	8	40	4	2021-06-30 04:40:00	2021-06-30 04:50:00	t	0
2935	34	13	7	36	7	2021-06-30 04:50:00	2021-06-30 05:00:00	t	0
2936	34	13	7	35	6	2021-06-30 04:50:00	2021-06-30 05:00:00	t	0
2937	30	10	8	41	7	2021-06-30 04:50:00	2021-06-30 05:00:00	t	0
2938	30	10	8	40	4	2021-06-30 04:50:00	2021-06-30 05:00:00	t	0
2939	35	11	9	44	3	2021-06-30 05:00:00	2021-06-30 05:10:00	t	0
2942	34	13	7	36	7	2021-06-30 05:00:00	2021-06-30 05:10:00	t	0
2943	34	13	7	35	6	2021-06-30 05:00:00	2021-06-30 05:10:00	t	0
2944	33	12	9	44	3	2021-06-30 05:00:00	2021-06-30 05:10:00	t	0
2947	31	11	9	44	3	2021-06-30 05:00:00	2021-06-30 05:10:00	t	0
2950	30	10	8	41	7	2021-06-30 05:00:00	2021-06-30 05:10:00	t	0
2951	30	10	8	40	4	2021-06-30 05:00:00	2021-06-30 05:10:00	t	0
2940	35	11	9	43	2	2021-06-30 05:10:00	2021-06-30 05:20:00	t	0
2945	33	12	9	43	2	2021-06-30 05:10:00	2021-06-30 05:20:00	t	0
2948	31	11	9	43	2	2021-06-30 05:10:00	2021-06-30 05:20:00	t	0
2946	33	12	9	42	1	2021-06-30 05:20:00	2021-06-30 05:30:00	t	0
2949	31	11	9	42	1	2021-06-30 05:20:00	2021-06-30 05:30:00	t	0
3002	34	13	7	36	7	2021-06-30 06:10:00	2021-06-30 06:20:00	t	0
3003	34	13	7	35	6	2021-06-30 06:10:00	2021-06-30 06:20:00	t	0
3004	30	10	8	41	7	2021-06-30 06:10:00	2021-06-30 06:20:00	t	0
3005	30	10	8	40	4	2021-06-30 06:10:00	2021-06-30 06:20:00	t	0
3006	34	13	7	36	7	2021-06-30 06:20:00	2021-06-30 06:30:00	t	0
3007	34	13	7	35	6	2021-06-30 06:20:00	2021-06-30 06:30:00	t	0
3008	30	10	8	41	7	2021-06-30 06:20:00	2021-06-30 06:30:00	t	0
3009	30	10	8	40	4	2021-06-30 06:20:00	2021-06-30 06:30:00	t	0
3010	35	11	9	44	3	2021-06-30 06:30:00	2021-06-30 06:40:00	t	0
3013	34	13	7	36	7	2021-06-30 06:30:00	2021-06-30 06:40:00	t	0
3014	34	13	7	35	6	2021-06-30 06:30:00	2021-06-30 06:40:00	t	0
3015	33	12	9	44	3	2021-06-30 06:30:00	2021-06-30 06:40:00	t	0
3018	31	11	9	44	3	2021-06-30 06:30:00	2021-06-30 06:40:00	t	0
3021	30	10	8	41	7	2021-06-30 06:30:00	2021-06-30 06:40:00	t	0
3022	30	10	8	40	4	2021-06-30 06:30:00	2021-06-30 06:40:00	t	0
3023	29	9	5	29	2	2021-06-30 06:30:00	2021-06-30 06:40:00	t	0
3011	35	11	9	43	2	2021-06-30 06:40:00	2021-06-30 06:50:00	t	0
3016	33	12	9	43	2	2021-06-30 06:40:00	2021-06-30 06:50:00	t	0
3019	31	11	9	43	2	2021-06-30 06:40:00	2021-06-30 06:50:00	t	0
3024	29	9	5	28	1	2021-06-30 06:40:00	2021-06-30 06:50:00	t	0
3012	35	11	9	42	1	2021-06-30 06:50:00	2021-06-30 07:00:00	t	0
3017	33	12	9	42	1	2021-06-30 06:50:00	2021-06-30 07:00:00	t	0
3020	31	11	9	42	1	2021-06-30 06:50:00	2021-06-30 07:00:00	t	0
3025	29	9	6	32	2	2021-06-30 06:50:00	2021-06-30 07:00:00	t	0
3155	30	10	8	40	4	2021-06-30 09:20:00	2021-06-30 09:30:00	t	0
3156	35	11	9	44	3	2021-06-30 09:30:00	2021-06-30 09:40:00	t	0
3159	34	13	7	36	7	2021-06-30 09:30:00	2021-06-30 09:40:00	t	0
3160	34	13	7	35	6	2021-06-30 09:30:00	2021-06-30 09:40:00	t	0
3161	33	12	9	44	3	2021-06-30 09:30:00	2021-06-30 09:40:00	t	0
3164	31	11	9	44	3	2021-06-30 09:30:00	2021-06-30 09:40:00	t	0
3167	30	10	8	41	7	2021-06-30 09:30:00	2021-06-30 09:40:00	t	0
3168	30	10	8	40	4	2021-06-30 09:30:00	2021-06-30 09:40:00	t	0
3157	35	11	9	43	2	2021-06-30 09:40:00	2021-06-30 09:50:00	t	0
3162	33	12	9	43	2	2021-06-30 09:40:00	2021-06-30 09:50:00	t	0
3165	31	11	9	43	2	2021-06-30 09:40:00	2021-06-30 09:50:00	t	0
3169	34	13	7	36	7	2021-06-30 09:40:00	2021-06-30 09:50:00	t	0
3170	34	13	7	35	6	2021-06-30 09:40:00	2021-06-30 09:50:00	t	0
3171	30	10	8	41	7	2021-06-30 09:40:00	2021-06-30 09:50:00	t	0
3172	30	10	8	40	4	2021-06-30 09:40:00	2021-06-30 09:50:00	t	0
3158	35	11	9	42	1	2021-06-30 09:50:00	2021-06-30 10:00:00	t	0
3163	33	12	9	42	1	2021-06-30 09:50:00	2021-06-30 10:00:00	t	0
3166	31	11	9	42	1	2021-06-30 09:50:00	2021-06-30 10:00:00	t	0
3198	34	13	7	36	7	2021-06-30 10:20:00	2021-06-30 10:30:00	t	0
3199	34	13	7	35	6	2021-06-30 10:20:00	2021-06-30 10:30:00	t	0
3200	30	10	8	41	7	2021-06-30 10:20:00	2021-06-30 10:30:00	t	0
3201	30	10	8	40	4	2021-06-30 10:20:00	2021-06-30 10:30:00	t	0
1918	30	10	8	39	5	2021-06-29 08:40:00	2021-06-29 08:50:00	t	0
2081	34	13	7	33	4	2021-06-29 10:00:00	2021-06-29 10:10:00	t	0
2130	35	11	9	44	3	2021-06-29 10:00:00	2021-06-29 10:10:00	t	0
2402	34	13	7	35	6	2021-06-29 17:40:00	2021-06-29 17:50:00	t	0
2403	30	10	8	41	7	2021-06-29 17:40:00	2021-06-29 17:50:00	t	0
2404	30	10	8	40	4	2021-06-29 17:40:00	2021-06-29 17:50:00	t	0
2405	34	13	7	36	7	2021-06-29 17:50:00	2021-06-29 18:00:00	t	0
2406	34	13	7	35	6	2021-06-29 17:50:00	2021-06-29 18:00:00	t	0
2407	30	10	8	41	7	2021-06-29 17:50:00	2021-06-29 18:00:00	t	0
2408	30	10	8	40	4	2021-06-29 17:50:00	2021-06-29 18:00:00	t	0
2409	29	9	5	29	2	2021-06-29 17:50:00	2021-06-29 18:00:00	t	0
2410	29	9	5	28	1	2021-06-29 18:00:00	2021-06-29 18:10:00	t	0
2413	35	11	9	44	3	2021-06-29 18:00:00	2021-06-29 18:10:00	t	0
2416	34	13	7	36	7	2021-06-29 18:00:00	2021-06-29 18:10:00	t	0
2417	34	13	7	35	6	2021-06-29 18:00:00	2021-06-29 18:10:00	t	0
2418	33	12	9	44	3	2021-06-29 18:00:00	2021-06-29 18:10:00	t	0
2421	31	11	9	44	3	2021-06-29 18:00:00	2021-06-29 18:10:00	t	0
2424	30	10	8	41	7	2021-06-29 18:00:00	2021-06-29 18:10:00	t	0
2425	30	10	8	40	4	2021-06-29 18:00:00	2021-06-29 18:10:00	t	0
2411	29	9	6	32	2	2021-06-29 18:10:00	2021-06-29 18:20:00	t	0
2419	33	12	9	43	2	2021-06-29 18:10:00	2021-06-29 18:20:00	t	0
2422	31	11	9	43	2	2021-06-29 18:10:00	2021-06-29 18:20:00	t	0
2426	34	13	7	36	7	2021-06-29 18:10:00	2021-06-29 18:20:00	t	0
2427	34	13	7	35	6	2021-06-29 18:10:00	2021-06-29 18:20:00	t	0
2428	30	10	8	41	7	2021-06-29 18:10:00	2021-06-29 18:20:00	t	0
2429	30	10	8	40	4	2021-06-29 18:10:00	2021-06-29 18:20:00	t	0
2412	29	9	6	30	3	2021-06-29 18:20:00	2021-06-29 18:30:00	t	0
2415	35	11	9	42	1	2021-06-29 18:20:00	2021-06-29 18:30:00	t	0
2420	33	12	9	42	1	2021-06-29 18:20:00	2021-06-29 18:30:00	t	0
2423	31	11	9	42	1	2021-06-29 18:20:00	2021-06-29 18:30:00	t	0
2430	34	13	7	36	7	2021-06-29 18:20:00	2021-06-29 18:30:00	t	0
2431	34	13	7	35	6	2021-06-29 18:20:00	2021-06-29 18:30:00	t	0
2432	30	10	8	41	7	2021-06-29 18:20:00	2021-06-29 18:30:00	t	0
2433	30	10	8	40	4	2021-06-29 18:20:00	2021-06-29 18:30:00	t	0
2434	35	11	9	44	3	2021-06-29 18:30:00	2021-06-29 18:40:00	t	0
2437	34	13	7	36	7	2021-06-29 18:30:00	2021-06-29 18:40:00	t	0
2438	34	13	7	35	6	2021-06-29 18:30:00	2021-06-29 18:40:00	t	0
2439	33	12	9	44	3	2021-06-29 18:30:00	2021-06-29 18:40:00	t	0
2442	31	11	9	44	3	2021-06-29 18:30:00	2021-06-29 18:40:00	t	0
2445	30	10	8	41	7	2021-06-29 18:30:00	2021-06-29 18:40:00	t	0
2446	30	10	8	40	4	2021-06-29 18:30:00	2021-06-29 18:40:00	t	0
2447	29	9	5	29	2	2021-06-29 18:30:00	2021-06-29 18:40:00	t	0
2435	35	11	9	43	2	2021-06-29 18:40:00	2021-06-29 18:50:00	t	0
2440	33	12	9	43	2	2021-06-29 18:40:00	2021-06-29 18:50:00	t	0
2443	31	11	9	43	2	2021-06-29 18:40:00	2021-06-29 18:50:00	t	0
2448	29	9	5	28	1	2021-06-29 18:40:00	2021-06-29 18:50:00	t	0
2452	34	13	7	35	6	2021-06-29 18:40:00	2021-06-29 18:50:00	t	0
2453	30	10	8	41	7	2021-06-29 18:40:00	2021-06-29 18:50:00	t	0
2454	30	10	8	40	4	2021-06-29 18:40:00	2021-06-29 18:50:00	t	0
2436	35	11	9	42	1	2021-06-29 18:50:00	2021-06-29 19:00:00	t	0
2441	33	12	9	42	1	2021-06-29 18:50:00	2021-06-29 19:00:00	t	0
2444	31	11	9	42	1	2021-06-29 18:50:00	2021-06-29 19:00:00	t	0
2449	29	9	6	32	2	2021-06-29 18:50:00	2021-06-29 19:00:00	t	0
2455	34	13	7	36	7	2021-06-29 18:50:00	2021-06-29 19:00:00	t	0
2456	34	13	7	35	6	2021-06-29 18:50:00	2021-06-29 19:00:00	t	0
2457	30	10	8	41	7	2021-06-29 18:50:00	2021-06-29 19:00:00	t	0
2458	30	10	8	40	4	2021-06-29 18:50:00	2021-06-29 19:00:00	t	0
2450	29	9	6	30	3	2021-06-29 19:00:00	2021-06-29 19:10:00	t	0
2459	35	11	9	44	3	2021-06-29 19:00:00	2021-06-29 19:10:00	t	0
2462	34	13	7	36	7	2021-06-29 19:00:00	2021-06-29 19:10:00	t	0
2463	34	13	7	35	6	2021-06-29 19:00:00	2021-06-29 19:10:00	t	0
2464	33	12	9	44	3	2021-06-29 19:00:00	2021-06-29 19:10:00	t	0
2467	31	11	9	44	3	2021-06-29 19:00:00	2021-06-29 19:10:00	t	0
2470	30	10	8	41	7	2021-06-29 19:00:00	2021-06-29 19:10:00	t	0
2471	30	10	8	40	4	2021-06-29 19:00:00	2021-06-29 19:10:00	t	0
2460	35	11	9	43	2	2021-06-29 19:10:00	2021-06-29 19:20:00	t	0
2465	33	12	9	43	2	2021-06-29 19:10:00	2021-06-29 19:20:00	t	0
2468	31	11	9	43	2	2021-06-29 19:10:00	2021-06-29 19:20:00	t	0
2472	34	13	7	36	7	2021-06-29 19:10:00	2021-06-29 19:20:00	t	0
2461	35	11	9	42	1	2021-06-29 19:20:00	2021-06-29 19:30:00	t	0
2466	33	12	9	42	1	2021-06-29 19:20:00	2021-06-29 19:30:00	t	0
2469	31	11	9	42	1	2021-06-29 19:20:00	2021-06-29 19:30:00	t	0
1987	31	11	9	43	2	2021-06-29 10:40:00	2021-06-29 10:50:00	t	0
1870	29	9	5	29	2	2021-06-29 11:10:00	2021-06-29 11:20:00	t	0
2474	30	10	8	41	7	2021-06-29 19:10:00	2021-06-29 19:20:00	t	0
2475	30	10	8	40	4	2021-06-29 19:10:00	2021-06-29 19:20:00	t	0
2476	29	9	5	29	2	2021-06-29 19:10:00	2021-06-29 19:20:00	t	0
2477	29	9	5	28	1	2021-06-29 19:20:00	2021-06-29 19:30:00	t	0
2480	34	13	7	36	7	2021-06-29 19:20:00	2021-06-29 19:30:00	t	0
2481	34	13	7	35	6	2021-06-29 19:20:00	2021-06-29 19:30:00	t	0
2482	30	10	8	41	7	2021-06-29 19:20:00	2021-06-29 19:30:00	t	0
2483	30	10	8	40	4	2021-06-29 19:20:00	2021-06-29 19:30:00	t	0
2478	29	9	6	32	2	2021-06-29 19:30:00	2021-06-29 19:40:00	t	0
2484	35	11	9	44	3	2021-06-29 19:30:00	2021-06-29 19:40:00	t	0
2487	34	13	7	36	7	2021-06-29 19:30:00	2021-06-29 19:40:00	t	0
2488	34	13	7	35	6	2021-06-29 19:30:00	2021-06-29 19:40:00	t	0
2489	33	12	9	44	3	2021-06-29 19:30:00	2021-06-29 19:40:00	t	0
2492	31	11	9	44	3	2021-06-29 19:30:00	2021-06-29 19:40:00	t	0
2495	30	10	8	41	7	2021-06-29 19:30:00	2021-06-29 19:40:00	t	0
2496	30	10	8	40	4	2021-06-29 19:30:00	2021-06-29 19:40:00	t	0
2479	29	9	6	30	3	2021-06-29 19:40:00	2021-06-29 19:50:00	t	0
2490	33	12	9	43	2	2021-06-29 19:40:00	2021-06-29 19:50:00	t	0
2493	31	11	9	43	2	2021-06-29 19:40:00	2021-06-29 19:50:00	t	0
2497	34	13	7	36	7	2021-06-29 19:40:00	2021-06-29 19:50:00	t	0
2498	34	13	7	35	6	2021-06-29 19:40:00	2021-06-29 19:50:00	t	0
2499	30	10	8	41	7	2021-06-29 19:40:00	2021-06-29 19:50:00	t	0
2500	30	10	8	40	4	2021-06-29 19:40:00	2021-06-29 19:50:00	t	0
2486	35	11	9	42	1	2021-06-29 19:50:00	2021-06-29 20:00:00	t	0
2491	33	12	9	42	1	2021-06-29 19:50:00	2021-06-29 20:00:00	t	0
2494	31	11	9	42	1	2021-06-29 19:50:00	2021-06-29 20:00:00	t	0
2501	34	13	7	36	7	2021-06-29 19:50:00	2021-06-29 20:00:00	t	0
2502	34	13	7	35	6	2021-06-29 19:50:00	2021-06-29 20:00:00	t	0
2503	30	10	8	41	7	2021-06-29 19:50:00	2021-06-29 20:00:00	t	0
2504	30	10	8	40	4	2021-06-29 19:50:00	2021-06-29 20:00:00	t	0
2505	29	9	5	29	2	2021-06-29 19:50:00	2021-06-29 20:00:00	t	0
2506	29	9	5	28	1	2021-06-29 20:00:00	2021-06-29 20:10:00	t	0
2509	35	11	9	44	3	2021-06-29 20:00:00	2021-06-29 20:10:00	t	0
2512	34	13	7	36	7	2021-06-29 20:00:00	2021-06-29 20:10:00	t	0
2513	34	13	7	35	6	2021-06-29 20:00:00	2021-06-29 20:10:00	t	0
2514	33	12	9	44	3	2021-06-29 20:00:00	2021-06-29 20:10:00	t	0
2517	31	11	9	44	3	2021-06-29 20:00:00	2021-06-29 20:10:00	t	0
2520	30	10	8	41	7	2021-06-29 20:00:00	2021-06-29 20:10:00	t	0
2521	30	10	8	40	4	2021-06-29 20:00:00	2021-06-29 20:10:00	t	0
2507	29	9	6	32	2	2021-06-29 20:10:00	2021-06-29 20:20:00	t	0
2510	35	11	9	43	2	2021-06-29 20:10:00	2021-06-29 20:20:00	t	0
2515	33	12	9	43	2	2021-06-29 20:10:00	2021-06-29 20:20:00	t	0
2518	31	11	9	43	2	2021-06-29 20:10:00	2021-06-29 20:20:00	t	0
2523	34	13	7	35	6	2021-06-29 20:10:00	2021-06-29 20:20:00	t	0
2524	30	10	8	41	7	2021-06-29 20:10:00	2021-06-29 20:20:00	t	0
2525	30	10	8	40	4	2021-06-29 20:10:00	2021-06-29 20:20:00	t	0
2508	29	9	6	30	3	2021-06-29 20:20:00	2021-06-29 20:30:00	t	0
2511	35	11	9	42	1	2021-06-29 20:20:00	2021-06-29 20:30:00	t	0
2516	33	12	9	42	1	2021-06-29 20:20:00	2021-06-29 20:30:00	t	0
2519	31	11	9	42	1	2021-06-29 20:20:00	2021-06-29 20:30:00	t	0
2526	34	13	7	36	7	2021-06-29 20:20:00	2021-06-29 20:30:00	t	0
2527	34	13	7	35	6	2021-06-29 20:20:00	2021-06-29 20:30:00	t	0
2528	30	10	8	41	7	2021-06-29 20:20:00	2021-06-29 20:30:00	t	0
2529	30	10	8	40	4	2021-06-29 20:20:00	2021-06-29 20:30:00	t	0
2530	35	11	9	44	3	2021-06-29 20:30:00	2021-06-29 20:40:00	t	0
2533	34	13	7	36	7	2021-06-29 20:30:00	2021-06-29 20:40:00	t	0
2534	34	13	7	35	6	2021-06-29 20:30:00	2021-06-29 20:40:00	t	0
2535	33	12	9	44	3	2021-06-29 20:30:00	2021-06-29 20:40:00	t	0
2538	31	11	9	44	3	2021-06-29 20:30:00	2021-06-29 20:40:00	t	0
2541	30	10	8	41	7	2021-06-29 20:30:00	2021-06-29 20:40:00	t	0
2542	30	10	8	40	4	2021-06-29 20:30:00	2021-06-29 20:40:00	t	0
2543	29	9	5	29	2	2021-06-29 20:30:00	2021-06-29 20:40:00	t	0
2531	35	11	9	43	2	2021-06-29 20:40:00	2021-06-29 20:50:00	t	0
2536	33	12	9	43	2	2021-06-29 20:40:00	2021-06-29 20:50:00	t	0
2539	31	11	9	43	2	2021-06-29 20:40:00	2021-06-29 20:50:00	t	0
2544	29	9	5	28	1	2021-06-29 20:40:00	2021-06-29 20:50:00	t	0
2532	35	11	9	42	1	2021-06-29 20:50:00	2021-06-29 21:00:00	t	0
2537	33	12	9	42	1	2021-06-29 20:50:00	2021-06-29 21:00:00	t	0
2540	31	11	9	42	1	2021-06-29 20:50:00	2021-06-29 21:00:00	t	0
2005	31	11	9	43	2	2021-06-29 12:10:00	2021-06-29 12:20:00	t	0
2042	30	10	8	41	7	2021-06-29 12:10:00	2021-06-29 12:20:00	t	0
2108	34	13	7	36	7	2021-06-29 12:20:00	2021-06-29 12:30:00	t	0
2548	34	13	7	35	6	2021-06-29 20:40:00	2021-06-29 20:50:00	t	0
2549	30	10	8	41	7	2021-06-29 20:40:00	2021-06-29 20:50:00	t	0
2550	30	10	8	40	4	2021-06-29 20:40:00	2021-06-29 20:50:00	t	0
2551	34	13	7	36	7	2021-06-29 20:50:00	2021-06-29 21:00:00	t	0
2552	34	13	7	35	6	2021-06-29 20:50:00	2021-06-29 21:00:00	t	0
2553	30	10	8	41	7	2021-06-29 20:50:00	2021-06-29 21:00:00	t	0
2554	30	10	8	40	4	2021-06-29 20:50:00	2021-06-29 21:00:00	t	0
2546	29	9	6	30	3	2021-06-29 21:00:00	2021-06-29 21:10:00	t	0
2555	35	11	9	44	3	2021-06-29 21:00:00	2021-06-29 21:10:00	t	0
2558	34	13	7	36	7	2021-06-29 21:00:00	2021-06-29 21:10:00	t	0
2559	34	13	7	35	6	2021-06-29 21:00:00	2021-06-29 21:10:00	t	0
2560	33	12	9	44	3	2021-06-29 21:00:00	2021-06-29 21:10:00	t	0
2563	31	11	9	44	3	2021-06-29 21:00:00	2021-06-29 21:10:00	t	0
2566	30	10	8	41	7	2021-06-29 21:00:00	2021-06-29 21:10:00	t	0
2567	30	10	8	40	4	2021-06-29 21:00:00	2021-06-29 21:10:00	t	0
2556	35	11	9	43	2	2021-06-29 21:10:00	2021-06-29 21:20:00	t	0
2561	33	12	9	43	2	2021-06-29 21:10:00	2021-06-29 21:20:00	t	0
2568	34	13	7	36	7	2021-06-29 21:10:00	2021-06-29 21:20:00	t	0
2569	34	13	7	35	6	2021-06-29 21:10:00	2021-06-29 21:20:00	t	0
2570	30	10	8	41	7	2021-06-29 21:10:00	2021-06-29 21:20:00	t	0
2571	30	10	8	40	4	2021-06-29 21:10:00	2021-06-29 21:20:00	t	0
2572	29	9	5	29	2	2021-06-29 21:10:00	2021-06-29 21:20:00	t	0
2557	35	11	9	42	1	2021-06-29 21:20:00	2021-06-29 21:30:00	t	0
2562	33	12	9	42	1	2021-06-29 21:20:00	2021-06-29 21:30:00	t	0
2565	31	11	9	42	1	2021-06-29 21:20:00	2021-06-29 21:30:00	t	0
2573	29	9	5	28	1	2021-06-29 21:20:00	2021-06-29 21:30:00	t	0
2576	34	13	7	36	7	2021-06-29 21:20:00	2021-06-29 21:30:00	t	0
2577	34	13	7	35	6	2021-06-29 21:20:00	2021-06-29 21:30:00	t	0
2578	30	10	8	41	7	2021-06-29 21:20:00	2021-06-29 21:30:00	t	0
2579	30	10	8	40	4	2021-06-29 21:20:00	2021-06-29 21:30:00	t	0
2574	29	9	6	32	2	2021-06-29 21:30:00	2021-06-29 21:40:00	t	0
2580	35	11	9	44	3	2021-06-29 21:30:00	2021-06-29 21:40:00	t	0
2583	34	13	7	36	7	2021-06-29 21:30:00	2021-06-29 21:40:00	t	0
2584	34	13	7	35	6	2021-06-29 21:30:00	2021-06-29 21:40:00	t	0
2585	33	12	9	44	3	2021-06-29 21:30:00	2021-06-29 21:40:00	t	0
2588	31	11	9	44	3	2021-06-29 21:30:00	2021-06-29 21:40:00	t	0
2591	30	10	8	41	7	2021-06-29 21:30:00	2021-06-29 21:40:00	t	0
2592	30	10	8	40	4	2021-06-29 21:30:00	2021-06-29 21:40:00	t	0
2575	29	9	6	30	3	2021-06-29 21:40:00	2021-06-29 21:50:00	t	0
2581	35	11	9	43	2	2021-06-29 21:40:00	2021-06-29 21:50:00	t	0
2586	33	12	9	43	2	2021-06-29 21:40:00	2021-06-29 21:50:00	t	0
2589	31	11	9	43	2	2021-06-29 21:40:00	2021-06-29 21:50:00	t	0
2593	34	13	7	36	7	2021-06-29 21:40:00	2021-06-29 21:50:00	t	0
2595	30	10	8	41	7	2021-06-29 21:40:00	2021-06-29 21:50:00	t	0
2596	30	10	8	40	4	2021-06-29 21:40:00	2021-06-29 21:50:00	t	0
2582	35	11	9	42	1	2021-06-29 21:50:00	2021-06-29 22:00:00	t	0
2587	33	12	9	42	1	2021-06-29 21:50:00	2021-06-29 22:00:00	t	0
2590	31	11	9	42	1	2021-06-29 21:50:00	2021-06-29 22:00:00	t	0
2597	34	13	7	36	7	2021-06-29 21:50:00	2021-06-29 22:00:00	t	0
2598	34	13	7	35	6	2021-06-29 21:50:00	2021-06-29 22:00:00	t	0
2599	30	10	8	41	7	2021-06-29 21:50:00	2021-06-29 22:00:00	t	0
2600	30	10	8	40	4	2021-06-29 21:50:00	2021-06-29 22:00:00	t	0
2601	29	9	5	29	2	2021-06-29 21:50:00	2021-06-29 22:00:00	t	0
2602	29	9	5	28	1	2021-06-29 22:00:00	2021-06-29 22:10:00	t	0
2605	35	11	9	44	3	2021-06-29 22:00:00	2021-06-29 22:10:00	t	0
2608	34	13	7	36	7	2021-06-29 22:00:00	2021-06-29 22:10:00	t	0
2609	34	13	7	35	6	2021-06-29 22:00:00	2021-06-29 22:10:00	t	0
2610	33	12	9	44	3	2021-06-29 22:00:00	2021-06-29 22:10:00	t	0
2613	31	11	9	44	3	2021-06-29 22:00:00	2021-06-29 22:10:00	t	0
2616	30	10	8	41	7	2021-06-29 22:00:00	2021-06-29 22:10:00	t	0
2617	30	10	8	40	4	2021-06-29 22:00:00	2021-06-29 22:10:00	t	0
2603	29	9	6	32	2	2021-06-29 22:10:00	2021-06-29 22:20:00	t	0
2606	35	11	9	43	2	2021-06-29 22:10:00	2021-06-29 22:20:00	t	0
2611	33	12	9	43	2	2021-06-29 22:10:00	2021-06-29 22:20:00	t	0
2614	31	11	9	43	2	2021-06-29 22:10:00	2021-06-29 22:20:00	t	0
2604	29	9	6	30	3	2021-06-29 22:20:00	2021-06-29 22:30:00	t	0
2607	35	11	9	42	1	2021-06-29 22:20:00	2021-06-29 22:30:00	t	0
2612	33	12	9	42	1	2021-06-29 22:20:00	2021-06-29 22:30:00	t	0
2615	31	11	9	42	1	2021-06-29 22:20:00	2021-06-29 22:30:00	t	0
2168	30	10	8	41	7	2021-06-29 12:50:00	2021-06-29 13:00:00	t	0
2485	35	11	9	43	2	2021-06-29 19:40:00	2021-06-29 19:50:00	t	0
2846	34	13	7	36	7	2021-06-30 03:00:00	2021-06-30 03:10:00	t	0
2847	34	13	7	35	6	2021-06-30 03:00:00	2021-06-30 03:10:00	t	0
2848	33	12	9	44	3	2021-06-30 03:00:00	2021-06-30 03:10:00	t	0
2851	31	11	9	44	3	2021-06-30 03:00:00	2021-06-30 03:10:00	t	0
2854	30	10	8	41	7	2021-06-30 03:00:00	2021-06-30 03:10:00	t	0
2855	30	10	8	40	4	2021-06-30 03:00:00	2021-06-30 03:10:00	t	0
2844	35	11	9	43	2	2021-06-30 03:10:00	2021-06-30 03:20:00	t	0
2849	33	12	9	43	2	2021-06-30 03:10:00	2021-06-30 03:20:00	t	0
2852	31	11	9	43	2	2021-06-30 03:10:00	2021-06-30 03:20:00	t	0
2856	34	13	7	36	7	2021-06-30 03:10:00	2021-06-30 03:20:00	t	0
2857	34	13	7	35	6	2021-06-30 03:10:00	2021-06-30 03:20:00	t	0
2858	30	10	8	41	7	2021-06-30 03:10:00	2021-06-30 03:20:00	t	0
2859	30	10	8	40	4	2021-06-30 03:10:00	2021-06-30 03:20:00	t	0
2860	29	9	5	29	2	2021-06-30 03:10:00	2021-06-30 03:20:00	t	0
2845	35	11	9	42	1	2021-06-30 03:20:00	2021-06-30 03:30:00	t	0
2850	33	12	9	42	1	2021-06-30 03:20:00	2021-06-30 03:30:00	t	0
2853	31	11	9	42	1	2021-06-30 03:20:00	2021-06-30 03:30:00	t	0
2864	34	13	7	36	7	2021-06-30 03:20:00	2021-06-30 03:30:00	t	0
2865	34	13	7	35	6	2021-06-30 03:20:00	2021-06-30 03:30:00	t	0
2866	30	10	8	41	7	2021-06-30 03:20:00	2021-06-30 03:30:00	t	0
2867	30	10	8	40	4	2021-06-30 03:20:00	2021-06-30 03:30:00	t	0
2862	29	9	6	32	2	2021-06-30 03:30:00	2021-06-30 03:40:00	t	0
2868	35	11	9	44	3	2021-06-30 03:30:00	2021-06-30 03:40:00	t	0
2871	34	13	7	36	7	2021-06-30 03:30:00	2021-06-30 03:40:00	t	0
2872	34	13	7	35	6	2021-06-30 03:30:00	2021-06-30 03:40:00	t	0
2873	33	12	9	44	3	2021-06-30 03:30:00	2021-06-30 03:40:00	t	0
2876	31	11	9	44	3	2021-06-30 03:30:00	2021-06-30 03:40:00	t	0
2879	30	10	8	41	7	2021-06-30 03:30:00	2021-06-30 03:40:00	t	0
2880	30	10	8	40	4	2021-06-30 03:30:00	2021-06-30 03:40:00	t	0
2863	29	9	6	30	3	2021-06-30 03:40:00	2021-06-30 03:50:00	t	0
2869	35	11	9	43	2	2021-06-30 03:40:00	2021-06-30 03:50:00	t	0
2874	33	12	9	43	2	2021-06-30 03:40:00	2021-06-30 03:50:00	t	0
2877	31	11	9	43	2	2021-06-30 03:40:00	2021-06-30 03:50:00	t	0
2870	35	11	9	42	1	2021-06-30 03:50:00	2021-06-30 04:00:00	t	0
2875	33	12	9	42	1	2021-06-30 03:50:00	2021-06-30 04:00:00	t	0
2878	31	11	9	42	1	2021-06-30 03:50:00	2021-06-30 04:00:00	t	0
3027	34	13	7	36	7	2021-06-30 06:40:00	2021-06-30 06:50:00	t	0
3028	34	13	7	35	6	2021-06-30 06:40:00	2021-06-30 06:50:00	t	0
3029	30	10	8	41	7	2021-06-30 06:40:00	2021-06-30 06:50:00	t	0
3030	30	10	8	40	4	2021-06-30 06:40:00	2021-06-30 06:50:00	t	0
3031	34	13	7	36	7	2021-06-30 06:50:00	2021-06-30 07:00:00	t	0
3032	34	13	7	35	6	2021-06-30 06:50:00	2021-06-30 07:00:00	t	0
3033	30	10	8	41	7	2021-06-30 06:50:00	2021-06-30 07:00:00	t	0
3035	35	11	9	44	3	2021-06-30 07:00:00	2021-06-30 07:10:00	t	0
3038	34	13	7	36	7	2021-06-30 07:00:00	2021-06-30 07:10:00	t	0
3039	34	13	7	35	6	2021-06-30 07:00:00	2021-06-30 07:10:00	t	300
3040	33	12	9	44	3	2021-06-30 07:00:00	2021-06-30 07:10:00	t	0
3043	31	11	9	44	3	2021-06-30 07:00:00	2021-06-30 07:10:00	t	0
3046	30	10	8	41	7	2021-06-30 07:00:00	2021-06-30 07:10:00	t	0
3047	30	10	8	40	4	2021-06-30 07:00:00	2021-06-30 07:10:00	t	0
3036	35	11	9	43	2	2021-06-30 07:10:00	2021-06-30 07:20:00	t	0
3041	33	12	9	43	2	2021-06-30 07:10:00	2021-06-30 07:20:00	t	0
3044	31	11	9	43	2	2021-06-30 07:10:00	2021-06-30 07:20:00	t	0
3037	35	11	9	42	1	2021-06-30 07:20:00	2021-06-30 07:30:00	t	0
3042	33	12	9	42	1	2021-06-30 07:20:00	2021-06-30 07:30:00	t	0
3045	31	11	9	42	1	2021-06-30 07:20:00	2021-06-30 07:30:00	t	0
3102	34	13	7	36	7	2021-06-30 08:20:00	2021-06-30 08:30:00	t	0
3103	34	13	7	35	6	2021-06-30 08:20:00	2021-06-30 08:30:00	t	0
3104	30	10	8	41	7	2021-06-30 08:20:00	2021-06-30 08:30:00	t	0
3105	30	10	8	40	4	2021-06-30 08:20:00	2021-06-30 08:30:00	t	0
3106	35	11	9	44	3	2021-06-30 08:30:00	2021-06-30 08:40:00	t	0
3109	34	13	7	36	7	2021-06-30 08:30:00	2021-06-30 08:40:00	t	0
3110	34	13	7	35	6	2021-06-30 08:30:00	2021-06-30 08:40:00	t	0
3111	33	12	9	44	3	2021-06-30 08:30:00	2021-06-30 08:40:00	t	0
3114	31	11	9	44	3	2021-06-30 08:30:00	2021-06-30 08:40:00	t	0
3107	35	11	9	43	2	2021-06-30 08:40:00	2021-06-30 08:50:00	t	0
3112	33	12	9	43	2	2021-06-30 08:40:00	2021-06-30 08:50:00	t	0
3115	31	11	9	43	2	2021-06-30 08:40:00	2021-06-30 08:50:00	t	0
3108	35	11	9	42	1	2021-06-30 08:50:00	2021-06-30 09:00:00	t	0
2180	31	11	9	42	1	2021-06-29 13:20:00	2021-06-29 13:30:00	t	0
2214	30	10	8	41	7	2021-06-29 13:50:00	2021-06-29 14:00:00	t	0
2619	34	13	7	35	6	2021-06-29 22:10:00	2021-06-29 22:20:00	t	0
2620	30	10	8	41	7	2021-06-29 22:10:00	2021-06-29 22:20:00	t	0
2621	30	10	8	40	4	2021-06-29 22:10:00	2021-06-29 22:20:00	t	0
2622	34	13	7	36	7	2021-06-29 22:20:00	2021-06-29 22:30:00	t	0
2623	34	13	7	35	6	2021-06-29 22:20:00	2021-06-29 22:30:00	t	0
2624	30	10	8	41	7	2021-06-29 22:20:00	2021-06-29 22:30:00	t	0
2625	30	10	8	40	4	2021-06-29 22:20:00	2021-06-29 22:30:00	t	0
2626	35	11	9	44	3	2021-06-29 22:30:00	2021-06-29 22:40:00	t	0
2629	34	13	7	36	7	2021-06-29 22:30:00	2021-06-29 22:40:00	t	0
2630	34	13	7	35	6	2021-06-29 22:30:00	2021-06-29 22:40:00	t	0
2631	33	12	9	44	3	2021-06-29 22:30:00	2021-06-29 22:40:00	t	0
2634	31	11	9	44	3	2021-06-29 22:30:00	2021-06-29 22:40:00	t	0
2637	30	10	8	41	7	2021-06-29 22:30:00	2021-06-29 22:40:00	t	0
2638	30	10	8	40	4	2021-06-29 22:30:00	2021-06-29 22:40:00	t	0
2639	29	9	5	29	2	2021-06-29 22:30:00	2021-06-29 22:40:00	t	0
2627	35	11	9	43	2	2021-06-29 22:40:00	2021-06-29 22:50:00	t	0
2632	33	12	9	43	2	2021-06-29 22:40:00	2021-06-29 22:50:00	t	0
2640	29	9	5	28	1	2021-06-29 22:40:00	2021-06-29 22:50:00	t	0
2643	34	13	7	36	7	2021-06-29 22:40:00	2021-06-29 22:50:00	t	0
2644	34	13	7	35	6	2021-06-29 22:40:00	2021-06-29 22:50:00	t	0
2645	30	10	8	41	7	2021-06-29 22:40:00	2021-06-29 22:50:00	t	0
2646	30	10	8	40	4	2021-06-29 22:40:00	2021-06-29 22:50:00	t	0
2628	35	11	9	42	1	2021-06-29 22:50:00	2021-06-29 23:00:00	t	0
2633	33	12	9	42	1	2021-06-29 22:50:00	2021-06-29 23:00:00	t	0
2636	31	11	9	42	1	2021-06-29 22:50:00	2021-06-29 23:00:00	t	0
2641	29	9	6	32	2	2021-06-29 22:50:00	2021-06-29 23:00:00	t	0
2647	34	13	7	36	7	2021-06-29 22:50:00	2021-06-29 23:00:00	t	0
2648	34	13	7	35	6	2021-06-29 22:50:00	2021-06-29 23:00:00	t	0
2649	30	10	8	41	7	2021-06-29 22:50:00	2021-06-29 23:00:00	t	0
2650	30	10	8	40	4	2021-06-29 22:50:00	2021-06-29 23:00:00	t	0
2642	29	9	6	30	3	2021-06-29 23:00:00	2021-06-29 23:10:00	t	0
2651	35	11	9	44	3	2021-06-29 23:00:00	2021-06-29 23:10:00	t	0
2654	34	13	7	36	7	2021-06-29 23:00:00	2021-06-29 23:10:00	t	0
2655	34	13	7	35	6	2021-06-29 23:00:00	2021-06-29 23:10:00	t	0
2656	33	12	9	44	3	2021-06-29 23:00:00	2021-06-29 23:10:00	t	0
2659	31	11	9	44	3	2021-06-29 23:00:00	2021-06-29 23:10:00	t	0
2662	30	10	8	41	7	2021-06-29 23:00:00	2021-06-29 23:10:00	t	0
2663	30	10	8	40	4	2021-06-29 23:00:00	2021-06-29 23:10:00	t	0
2652	35	11	9	43	2	2021-06-29 23:10:00	2021-06-29 23:20:00	t	0
2657	33	12	9	43	2	2021-06-29 23:10:00	2021-06-29 23:20:00	t	0
2660	31	11	9	43	2	2021-06-29 23:10:00	2021-06-29 23:20:00	t	0
2664	34	13	7	36	7	2021-06-29 23:10:00	2021-06-29 23:20:00	t	0
2665	34	13	7	35	6	2021-06-29 23:10:00	2021-06-29 23:20:00	t	0
2667	30	10	8	40	4	2021-06-29 23:10:00	2021-06-29 23:20:00	t	0
2668	29	9	5	29	2	2021-06-29 23:10:00	2021-06-29 23:20:00	t	0
2653	35	11	9	42	1	2021-06-29 23:20:00	2021-06-29 23:30:00	t	0
2658	33	12	9	42	1	2021-06-29 23:20:00	2021-06-29 23:30:00	t	0
2661	31	11	9	42	1	2021-06-29 23:20:00	2021-06-29 23:30:00	t	0
2669	29	9	5	28	1	2021-06-29 23:20:00	2021-06-29 23:30:00	t	0
2672	34	13	7	36	7	2021-06-29 23:20:00	2021-06-29 23:30:00	t	0
2673	34	13	7	35	6	2021-06-29 23:20:00	2021-06-29 23:30:00	t	0
2674	30	10	8	41	7	2021-06-29 23:20:00	2021-06-29 23:30:00	t	0
2675	30	10	8	40	4	2021-06-29 23:20:00	2021-06-29 23:30:00	t	0
2670	29	9	6	32	2	2021-06-29 23:30:00	2021-06-29 23:40:00	t	0
2676	35	11	9	44	3	2021-06-29 23:30:00	2021-06-29 23:40:00	t	0
2679	34	13	7	36	7	2021-06-29 23:30:00	2021-06-29 23:40:00	t	0
2680	34	13	7	35	6	2021-06-29 23:30:00	2021-06-29 23:40:00	t	0
2681	33	12	9	44	3	2021-06-29 23:30:00	2021-06-29 23:40:00	t	0
2684	31	11	9	44	3	2021-06-29 23:30:00	2021-06-29 23:40:00	t	0
2687	30	10	8	41	7	2021-06-29 23:30:00	2021-06-29 23:40:00	t	0
2688	30	10	8	40	4	2021-06-29 23:30:00	2021-06-29 23:40:00	t	0
2671	29	9	6	30	3	2021-06-29 23:40:00	2021-06-29 23:50:00	t	0
2677	35	11	9	43	2	2021-06-29 23:40:00	2021-06-29 23:50:00	t	0
2682	33	12	9	43	2	2021-06-29 23:40:00	2021-06-29 23:50:00	t	0
2685	31	11	9	43	2	2021-06-29 23:40:00	2021-06-29 23:50:00	t	0
2689	34	13	7	36	7	2021-06-29 23:40:00	2021-06-29 23:50:00	t	0
2690	34	13	7	35	6	2021-06-29 23:40:00	2021-06-29 23:50:00	t	0
2678	35	11	9	42	1	2021-06-29 23:50:00	2021-06-30 00:00:00	t	0
2683	33	12	9	42	1	2021-06-29 23:50:00	2021-06-30 00:00:00	t	0
2242	35	11	9	44	3	2021-06-29 14:30:00	2021-06-29 14:40:00	t	0
2245	34	13	7	36	7	2021-06-29 14:30:00	2021-06-29 14:40:00	t	0
2257	29	9	6	32	2	2021-06-29 14:50:00	2021-06-29 15:00:00	t	0
2290	30	10	8	41	7	2021-06-29 15:20:00	2021-06-29 15:30:00	t	0
2692	30	10	8	40	4	2021-06-29 23:40:00	2021-06-29 23:50:00	t	0
2693	34	13	7	36	7	2021-06-29 23:50:00	2021-06-30 00:00:00	t	0
2694	34	13	7	35	6	2021-06-29 23:50:00	2021-06-30 00:00:00	t	0
2695	30	10	8	41	7	2021-06-29 23:50:00	2021-06-30 00:00:00	t	0
2696	30	10	8	40	4	2021-06-29 23:50:00	2021-06-30 00:00:00	t	0
2697	29	9	5	29	2	2021-06-29 23:50:00	2021-06-30 00:00:00	t	0
2698	29	9	5	28	1	2021-06-30 00:00:00	2021-06-30 00:10:00	t	0
2701	35	11	9	44	3	2021-06-30 00:00:00	2021-06-30 00:10:00	t	0
2704	34	13	7	36	7	2021-06-30 00:00:00	2021-06-30 00:10:00	t	0
2705	34	13	7	35	6	2021-06-30 00:00:00	2021-06-30 00:10:00	t	0
2706	33	12	9	44	3	2021-06-30 00:00:00	2021-06-30 00:10:00	t	0
2709	31	11	9	44	3	2021-06-30 00:00:00	2021-06-30 00:10:00	t	0
2712	30	10	8	41	7	2021-06-30 00:00:00	2021-06-30 00:10:00	t	0
2713	30	10	8	40	4	2021-06-30 00:00:00	2021-06-30 00:10:00	t	0
2699	29	9	6	32	2	2021-06-30 00:10:00	2021-06-30 00:20:00	t	0
2702	35	11	9	43	2	2021-06-30 00:10:00	2021-06-30 00:20:00	t	0
2707	33	12	9	43	2	2021-06-30 00:10:00	2021-06-30 00:20:00	t	0
2714	34	13	7	36	7	2021-06-30 00:10:00	2021-06-30 00:20:00	t	0
2715	34	13	7	35	6	2021-06-30 00:10:00	2021-06-30 00:20:00	t	0
2716	30	10	8	41	7	2021-06-30 00:10:00	2021-06-30 00:20:00	t	0
2717	30	10	8	40	4	2021-06-30 00:10:00	2021-06-30 00:20:00	t	0
2700	29	9	6	30	3	2021-06-30 00:20:00	2021-06-30 00:30:00	t	0
2703	35	11	9	42	1	2021-06-30 00:20:00	2021-06-30 00:30:00	t	0
2708	33	12	9	42	1	2021-06-30 00:20:00	2021-06-30 00:30:00	t	0
2711	31	11	9	42	1	2021-06-30 00:20:00	2021-06-30 00:30:00	t	0
2718	34	13	7	36	7	2021-06-30 00:20:00	2021-06-30 00:30:00	t	0
2719	34	13	7	35	6	2021-06-30 00:20:00	2021-06-30 00:30:00	t	0
2720	30	10	8	41	7	2021-06-30 00:20:00	2021-06-30 00:30:00	t	0
2721	30	10	8	40	4	2021-06-30 00:20:00	2021-06-30 00:30:00	t	0
2722	35	11	9	44	3	2021-06-30 00:30:00	2021-06-30 00:40:00	t	0
2725	34	13	7	36	7	2021-06-30 00:30:00	2021-06-30 00:40:00	t	0
2726	34	13	7	35	6	2021-06-30 00:30:00	2021-06-30 00:40:00	t	0
2727	33	12	9	44	3	2021-06-30 00:30:00	2021-06-30 00:40:00	t	0
2730	31	11	9	44	3	2021-06-30 00:30:00	2021-06-30 00:40:00	t	0
2733	30	10	8	41	7	2021-06-30 00:30:00	2021-06-30 00:40:00	t	0
2734	30	10	8	40	4	2021-06-30 00:30:00	2021-06-30 00:40:00	t	0
2735	29	9	5	29	2	2021-06-30 00:30:00	2021-06-30 00:40:00	t	0
2723	35	11	9	43	2	2021-06-30 00:40:00	2021-06-30 00:50:00	t	0
2728	33	12	9	43	2	2021-06-30 00:40:00	2021-06-30 00:50:00	t	0
2731	31	11	9	43	2	2021-06-30 00:40:00	2021-06-30 00:50:00	t	0
2736	29	9	5	28	1	2021-06-30 00:40:00	2021-06-30 00:50:00	t	0
2739	34	13	7	36	7	2021-06-30 00:40:00	2021-06-30 00:50:00	t	0
2740	34	13	7	35	6	2021-06-30 00:40:00	2021-06-30 00:50:00	t	0
2742	30	10	8	40	4	2021-06-30 00:40:00	2021-06-30 00:50:00	t	0
2724	35	11	9	42	1	2021-06-30 00:50:00	2021-06-30 01:00:00	t	0
2729	33	12	9	42	1	2021-06-30 00:50:00	2021-06-30 01:00:00	t	0
2732	31	11	9	42	1	2021-06-30 00:50:00	2021-06-30 01:00:00	t	0
2737	29	9	6	32	2	2021-06-30 00:50:00	2021-06-30 01:00:00	t	0
2743	34	13	7	36	7	2021-06-30 00:50:00	2021-06-30 01:00:00	t	0
2744	34	13	7	35	6	2021-06-30 00:50:00	2021-06-30 01:00:00	t	0
2745	30	10	8	41	7	2021-06-30 00:50:00	2021-06-30 01:00:00	t	0
2746	30	10	8	40	4	2021-06-30 00:50:00	2021-06-30 01:00:00	t	0
2738	29	9	6	30	3	2021-06-30 01:00:00	2021-06-30 01:10:00	t	0
2747	35	11	9	44	3	2021-06-30 01:00:00	2021-06-30 01:10:00	t	0
2750	34	13	7	36	7	2021-06-30 01:00:00	2021-06-30 01:10:00	t	0
2751	34	13	7	35	6	2021-06-30 01:00:00	2021-06-30 01:10:00	t	0
2752	33	12	9	44	3	2021-06-30 01:00:00	2021-06-30 01:10:00	t	0
2755	31	11	9	44	3	2021-06-30 01:00:00	2021-06-30 01:10:00	t	0
2758	30	10	8	41	7	2021-06-30 01:00:00	2021-06-30 01:10:00	t	0
2759	30	10	8	40	4	2021-06-30 01:00:00	2021-06-30 01:10:00	t	0
2748	35	11	9	43	2	2021-06-30 01:10:00	2021-06-30 01:20:00	t	0
2753	33	12	9	43	2	2021-06-30 01:10:00	2021-06-30 01:20:00	t	0
2756	31	11	9	43	2	2021-06-30 01:10:00	2021-06-30 01:20:00	t	0
2760	34	13	7	36	7	2021-06-30 01:10:00	2021-06-30 01:20:00	t	0
2761	34	13	7	35	6	2021-06-30 01:10:00	2021-06-30 01:20:00	t	0
2749	35	11	9	42	1	2021-06-30 01:20:00	2021-06-30 01:30:00	t	0
2754	33	12	9	42	1	2021-06-30 01:20:00	2021-06-30 01:30:00	t	0
2757	31	11	9	42	1	2021-06-30 01:20:00	2021-06-30 01:30:00	t	0
2414	35	11	9	43	2	2021-06-29 18:10:00	2021-06-29 18:20:00	t	0
2594	34	13	7	35	6	2021-06-29 21:40:00	2021-06-29 21:50:00	t	0
2666	30	10	8	41	7	2021-06-29 23:10:00	2021-06-29 23:20:00	t	0
2710	31	11	9	43	2	2021-06-30 00:10:00	2021-06-30 00:20:00	t	0
2763	30	10	8	40	4	2021-06-30 01:10:00	2021-06-30 01:20:00	t	0
2764	29	9	5	29	2	2021-06-30 01:10:00	2021-06-30 01:20:00	t	0
2765	29	9	5	28	1	2021-06-30 01:20:00	2021-06-30 01:30:00	t	0
2766	29	9	6	32	2	2021-06-30 01:30:00	2021-06-30 01:40:00	t	0
2767	29	9	6	30	3	2021-06-30 01:40:00	2021-06-30 01:50:00	t	0
2952	34	13	7	36	7	2021-06-30 05:10:00	2021-06-30 05:20:00	t	0
2953	34	13	7	35	6	2021-06-30 05:10:00	2021-06-30 05:20:00	t	0
2954	30	10	8	41	7	2021-06-30 05:10:00	2021-06-30 05:20:00	t	0
2955	30	10	8	40	4	2021-06-30 05:10:00	2021-06-30 05:20:00	t	0
2956	29	9	5	29	2	2021-06-30 05:10:00	2021-06-30 05:20:00	t	0
2957	29	9	5	28	1	2021-06-30 05:20:00	2021-06-30 05:30:00	t	0
2960	34	13	7	36	7	2021-06-30 05:20:00	2021-06-30 05:30:00	t	0
2961	34	13	7	35	6	2021-06-30 05:20:00	2021-06-30 05:30:00	t	0
2962	30	10	8	41	7	2021-06-30 05:20:00	2021-06-30 05:30:00	t	0
2963	30	10	8	40	4	2021-06-30 05:20:00	2021-06-30 05:30:00	t	0
2958	29	9	6	32	2	2021-06-30 05:30:00	2021-06-30 05:40:00	t	0
2964	35	11	9	44	3	2021-06-30 05:30:00	2021-06-30 05:40:00	t	0
2968	34	13	7	35	6	2021-06-30 05:30:00	2021-06-30 05:40:00	t	0
2969	33	12	9	44	3	2021-06-30 05:30:00	2021-06-30 05:40:00	t	0
2972	31	11	9	44	3	2021-06-30 05:30:00	2021-06-30 05:40:00	t	0
2975	30	10	8	41	7	2021-06-30 05:30:00	2021-06-30 05:40:00	t	0
2976	30	10	8	40	4	2021-06-30 05:30:00	2021-06-30 05:40:00	t	0
2959	29	9	6	30	3	2021-06-30 05:40:00	2021-06-30 05:50:00	t	0
2965	35	11	9	43	2	2021-06-30 05:40:00	2021-06-30 05:50:00	t	0
2970	33	12	9	43	2	2021-06-30 05:40:00	2021-06-30 05:50:00	t	0
2973	31	11	9	43	2	2021-06-30 05:40:00	2021-06-30 05:50:00	t	0
2966	35	11	9	42	1	2021-06-30 05:50:00	2021-06-30 06:00:00	t	0
2971	33	12	9	42	1	2021-06-30 05:50:00	2021-06-30 06:00:00	t	0
2974	31	11	9	42	1	2021-06-30 05:50:00	2021-06-30 06:00:00	t	0
3139	31	11	9	44	3	2021-06-30 09:00:00	2021-06-30 09:10:00	t	0
3142	30	10	8	41	7	2021-06-30 09:00:00	2021-06-30 09:10:00	t	0
3143	30	10	8	40	4	2021-06-30 09:00:00	2021-06-30 09:10:00	t	0
3137	33	12	9	43	2	2021-06-30 09:10:00	2021-06-30 09:20:00	t	0
3140	31	11	9	43	2	2021-06-30 09:10:00	2021-06-30 09:20:00	t	0
3144	34	13	7	36	7	2021-06-30 09:10:00	2021-06-30 09:20:00	t	0
3145	34	13	7	35	6	2021-06-30 09:10:00	2021-06-30 09:20:00	t	0
3146	30	10	8	41	7	2021-06-30 09:10:00	2021-06-30 09:20:00	t	0
3147	30	10	8	40	4	2021-06-30 09:10:00	2021-06-30 09:20:00	t	0
3148	29	9	5	29	2	2021-06-30 09:10:00	2021-06-30 09:20:00	t	0
3138	33	12	9	42	1	2021-06-30 09:20:00	2021-06-30 09:30:00	t	0
3141	31	11	9	42	1	2021-06-30 09:20:00	2021-06-30 09:30:00	t	0
3149	29	9	5	28	1	2021-06-30 09:20:00	2021-06-30 09:30:00	t	0
3150	29	9	6	32	2	2021-06-30 09:30:00	2021-06-30 09:40:00	t	0
3173	34	13	7	36	7	2021-06-30 09:50:00	2021-06-30 10:00:00	t	0
3174	34	13	7	35	6	2021-06-30 09:50:00	2021-06-30 10:00:00	t	0
3175	30	10	8	41	7	2021-06-30 09:50:00	2021-06-30 10:00:00	t	0
3176	30	10	8	40	4	2021-06-30 09:50:00	2021-06-30 10:00:00	t	0
3177	29	9	5	29	2	2021-06-30 09:50:00	2021-06-30 10:00:00	t	0
3178	29	9	5	28	1	2021-06-30 10:00:00	2021-06-30 10:10:00	t	0
3181	35	11	9	44	3	2021-06-30 10:00:00	2021-06-30 10:10:00	t	0
3184	34	13	7	36	7	2021-06-30 10:00:00	2021-06-30 10:10:00	t	0
3185	34	13	7	35	6	2021-06-30 10:00:00	2021-06-30 10:10:00	t	0
3186	33	12	9	44	3	2021-06-30 10:00:00	2021-06-30 10:10:00	t	0
3189	31	11	9	44	3	2021-06-30 10:00:00	2021-06-30 10:10:00	t	0
3192	30	10	8	41	7	2021-06-30 10:00:00	2021-06-30 10:10:00	t	0
3193	30	10	8	40	4	2021-06-30 10:00:00	2021-06-30 10:10:00	t	0
3179	29	9	6	32	2	2021-06-30 10:10:00	2021-06-30 10:20:00	t	0
3182	35	11	9	43	2	2021-06-30 10:10:00	2021-06-30 10:20:00	t	0
3187	33	12	9	43	2	2021-06-30 10:10:00	2021-06-30 10:20:00	t	0
3190	31	11	9	43	2	2021-06-30 10:10:00	2021-06-30 10:20:00	t	0
3194	34	13	7	36	7	2021-06-30 10:10:00	2021-06-30 10:20:00	t	0
3195	34	13	7	35	6	2021-06-30 10:10:00	2021-06-30 10:20:00	t	0
3196	30	10	8	41	7	2021-06-30 10:10:00	2021-06-30 10:20:00	t	0
3197	30	10	8	40	4	2021-06-30 10:10:00	2021-06-30 10:20:00	t	0
3180	29	9	6	30	3	2021-06-30 10:20:00	2021-06-30 10:30:00	t	0
3183	35	11	9	42	1	2021-06-30 10:20:00	2021-06-30 10:30:00	t	0
3188	33	12	9	42	1	2021-06-30 10:20:00	2021-06-30 10:30:00	t	0
3191	31	11	9	42	1	2021-06-30 10:20:00	2021-06-30 10:30:00	t	0
3202	35	11	9	44	3	2021-06-30 10:30:00	2021-06-30 10:40:00	t	0
3205	34	13	7	36	7	2021-06-30 10:30:00	2021-06-30 10:40:00	t	0
3206	34	13	7	35	6	2021-06-30 10:30:00	2021-06-30 10:40:00	t	0
3207	33	12	9	44	3	2021-06-30 10:30:00	2021-06-30 10:40:00	t	0
3210	31	11	9	44	3	2021-06-30 10:30:00	2021-06-30 10:40:00	t	0
3213	30	10	8	41	7	2021-06-30 10:30:00	2021-06-30 10:40:00	t	0
3214	30	10	8	40	4	2021-06-30 10:30:00	2021-06-30 10:40:00	t	0
3215	29	9	5	29	2	2021-06-30 10:30:00	2021-06-30 10:40:00	t	0
3203	35	11	9	43	2	2021-06-30 10:40:00	2021-06-30 10:50:00	t	0
3208	33	12	9	43	2	2021-06-30 10:40:00	2021-06-30 10:50:00	t	0
3211	31	11	9	43	2	2021-06-30 10:40:00	2021-06-30 10:50:00	t	0
3216	29	9	5	28	1	2021-06-30 10:40:00	2021-06-30 10:50:00	t	0
3219	34	13	7	36	7	2021-06-30 10:40:00	2021-06-30 10:50:00	t	0
3220	34	13	7	35	6	2021-06-30 10:40:00	2021-06-30 10:50:00	t	0
3221	30	10	8	41	7	2021-06-30 10:40:00	2021-06-30 10:50:00	t	0
3222	30	10	8	40	4	2021-06-30 10:40:00	2021-06-30 10:50:00	t	0
3204	35	11	9	42	1	2021-06-30 10:50:00	2021-06-30 11:00:00	t	0
3209	33	12	9	42	1	2021-06-30 10:50:00	2021-06-30 11:00:00	t	0
3212	31	11	9	42	1	2021-06-30 10:50:00	2021-06-30 11:00:00	t	0
3217	29	9	6	32	2	2021-06-30 10:50:00	2021-06-30 11:00:00	t	0
3218	29	9	6	30	3	2021-06-30 11:00:00	2021-06-30 11:10:00	t	0
2768	34	13	7	36	7	2021-06-30 01:20:00	2021-06-30 01:30:00	t	0
2769	34	13	7	35	6	2021-06-30 01:20:00	2021-06-30 01:30:00	t	0
2770	30	10	8	41	7	2021-06-30 01:20:00	2021-06-30 01:30:00	t	0
2771	30	10	8	40	4	2021-06-30 01:20:00	2021-06-30 01:30:00	t	0
2772	35	11	9	44	3	2021-06-30 01:30:00	2021-06-30 01:40:00	t	0
2780	31	11	9	44	3	2021-06-30 01:30:00	2021-06-30 01:40:00	t	0
2783	30	10	8	41	7	2021-06-30 01:30:00	2021-06-30 01:40:00	t	0
2778	33	12	9	43	2	2021-06-30 01:40:00	2021-06-30 01:50:00	t	0
2779	33	12	9	42	1	2021-06-30 01:50:00	2021-06-30 02:00:00	t	0
2797	35	11	9	44	3	2021-06-30 02:00:00	2021-06-30 02:10:00	t	0
2800	34	13	7	36	7	2021-06-30 02:00:00	2021-06-30 02:10:00	t	0
2801	34	13	7	35	6	2021-06-30 02:00:00	2021-06-30 02:10:00	t	0
2818	35	11	9	44	3	2021-06-30 02:30:00	2021-06-30 02:40:00	t	0
2821	34	13	7	36	7	2021-06-30 02:30:00	2021-06-30 02:40:00	t	0
2822	34	13	7	35	6	2021-06-30 02:30:00	2021-06-30 02:40:00	t	0
2823	33	12	9	44	3	2021-06-30 02:30:00	2021-06-30 02:40:00	t	0
2819	35	11	9	43	2	2021-06-30 02:40:00	2021-06-30 02:50:00	t	0
2824	33	12	9	43	2	2021-06-30 02:40:00	2021-06-30 02:50:00	t	0
3224	34	13	7	35	6	2021-06-30 10:50:00	2021-06-30 11:00:00	t	0
3225	30	10	8	41	7	2021-06-30 10:50:00	2021-06-30 11:00:00	t	0
3226	30	10	8	40	4	2021-06-30 10:50:00	2021-06-30 11:00:00	t	0
3227	35	11	9	44	3	2021-06-30 11:00:00	2021-06-30 11:10:00	t	0
3230	34	13	7	36	7	2021-06-30 11:00:00	2021-06-30 11:10:00	t	0
3231	34	13	7	35	6	2021-06-30 11:00:00	2021-06-30 11:10:00	t	0
3232	33	12	9	44	3	2021-06-30 11:00:00	2021-06-30 11:10:00	t	0
3235	31	11	9	44	3	2021-06-30 11:00:00	2021-06-30 11:10:00	t	0
3238	30	10	8	41	7	2021-06-30 11:00:00	2021-06-30 11:10:00	t	0
3239	30	10	8	40	4	2021-06-30 11:00:00	2021-06-30 11:10:00	t	0
3228	35	11	9	43	2	2021-06-30 11:10:00	2021-06-30 11:20:00	t	0
3233	33	12	9	43	2	2021-06-30 11:10:00	2021-06-30 11:20:00	t	0
3236	31	11	9	43	2	2021-06-30 11:10:00	2021-06-30 11:20:00	t	0
3240	34	13	7	36	7	2021-06-30 11:10:00	2021-06-30 11:20:00	t	0
3241	34	13	7	35	6	2021-06-30 11:10:00	2021-06-30 11:20:00	t	0
3242	30	10	8	41	7	2021-06-30 11:10:00	2021-06-30 11:20:00	t	0
3243	30	10	8	40	4	2021-06-30 11:10:00	2021-06-30 11:20:00	t	0
3229	35	11	9	42	1	2021-06-30 11:20:00	2021-06-30 11:30:00	t	0
3234	33	12	9	42	1	2021-06-30 11:20:00	2021-06-30 11:30:00	t	0
3237	31	11	9	42	1	2021-06-30 11:20:00	2021-06-30 11:30:00	t	0
3245	29	9	5	28	1	2021-06-30 11:20:00	2021-06-30 11:30:00	t	0
3248	34	13	7	36	7	2021-06-30 11:20:00	2021-06-30 11:30:00	t	0
3249	34	13	7	35	6	2021-06-30 11:20:00	2021-06-30 11:30:00	t	0
3250	30	10	8	41	7	2021-06-30 11:20:00	2021-06-30 11:30:00	t	0
3251	30	10	8	40	4	2021-06-30 11:20:00	2021-06-30 11:30:00	t	0
3246	29	9	6	32	2	2021-06-30 11:30:00	2021-06-30 11:40:00	t	0
3252	35	11	9	44	3	2021-06-30 11:30:00	2021-06-30 11:40:00	t	0
3255	34	13	7	36	7	2021-06-30 11:30:00	2021-06-30 11:40:00	t	0
3256	34	13	7	35	6	2021-06-30 11:30:00	2021-06-30 11:40:00	t	0
3257	33	12	9	44	3	2021-06-30 11:30:00	2021-06-30 11:40:00	t	0
3260	31	11	9	44	3	2021-06-30 11:30:00	2021-06-30 11:40:00	t	0
3263	30	10	8	41	7	2021-06-30 11:30:00	2021-06-30 11:40:00	t	0
3264	30	10	8	40	4	2021-06-30 11:30:00	2021-06-30 11:40:00	t	0
3247	29	9	6	30	3	2021-06-30 11:40:00	2021-06-30 11:50:00	t	0
3253	35	11	9	43	2	2021-06-30 11:40:00	2021-06-30 11:50:00	t	0
3258	33	12	9	43	2	2021-06-30 11:40:00	2021-06-30 11:50:00	t	0
3261	31	11	9	43	2	2021-06-30 11:40:00	2021-06-30 11:50:00	t	0
3265	34	13	7	36	7	2021-06-30 11:40:00	2021-06-30 11:50:00	t	0
3266	34	13	7	35	6	2021-06-30 11:40:00	2021-06-30 11:50:00	t	0
3267	30	10	8	41	7	2021-06-30 11:40:00	2021-06-30 11:50:00	t	0
3268	30	10	8	40	4	2021-06-30 11:40:00	2021-06-30 11:50:00	t	0
3254	35	11	9	42	1	2021-06-30 11:50:00	2021-06-30 12:00:00	t	0
3259	33	12	9	42	1	2021-06-30 11:50:00	2021-06-30 12:00:00	t	0
3269	34	13	7	36	7	2021-06-30 11:50:00	2021-06-30 12:00:00	t	0
3270	34	13	7	35	6	2021-06-30 11:50:00	2021-06-30 12:00:00	t	0
3271	30	10	8	41	7	2021-06-30 11:50:00	2021-06-30 12:00:00	t	0
3272	30	10	8	40	4	2021-06-30 11:50:00	2021-06-30 12:00:00	t	0
3273	29	9	5	29	2	2021-06-30 11:50:00	2021-06-30 12:00:00	t	0
3274	29	9	5	28	1	2021-06-30 12:00:00	2021-06-30 12:10:00	t	0
3277	35	11	9	44	3	2021-06-30 12:00:00	2021-06-30 12:10:00	t	0
3275	29	9	6	32	2	2021-06-30 12:10:00	2021-06-30 12:20:00	t	0
3278	35	11	9	43	2	2021-06-30 12:10:00	2021-06-30 12:20:00	t	0
3276	29	9	6	30	3	2021-06-30 12:20:00	2021-06-30 12:30:00	t	0
3279	35	11	9	42	1	2021-06-30 12:20:00	2021-06-30 12:30:00	t	0
3280	34	13	7	36	7	2021-06-30 12:00:00	2021-06-30 12:10:00	t	0
3281	34	13	7	35	6	2021-06-30 12:00:00	2021-06-30 12:10:00	t	0
3282	33	12	9	44	3	2021-06-30 12:00:00	2021-06-30 12:10:00	t	0
3285	31	11	9	44	3	2021-06-30 12:00:00	2021-06-30 12:10:00	t	0
3288	30	10	8	41	7	2021-06-30 12:00:00	2021-06-30 12:10:00	t	0
3289	30	10	8	40	4	2021-06-30 12:00:00	2021-06-30 12:10:00	t	0
3283	33	12	9	43	2	2021-06-30 12:10:00	2021-06-30 12:20:00	t	0
3286	31	11	9	43	2	2021-06-30 12:10:00	2021-06-30 12:20:00	t	0
3290	34	13	7	36	7	2021-06-30 12:10:00	2021-06-30 12:20:00	t	0
3291	34	13	7	35	6	2021-06-30 12:10:00	2021-06-30 12:20:00	t	0
3292	30	10	8	41	7	2021-06-30 12:10:00	2021-06-30 12:20:00	t	0
3293	30	10	8	40	4	2021-06-30 12:10:00	2021-06-30 12:20:00	t	0
3284	33	12	9	42	1	2021-06-30 12:20:00	2021-06-30 12:30:00	t	0
3287	31	11	9	42	1	2021-06-30 12:20:00	2021-06-30 12:30:00	t	0
2820	35	11	9	42	1	2021-06-30 02:50:00	2021-06-30 03:00:00	t	0
2843	35	11	9	44	3	2021-06-30 03:00:00	2021-06-30 03:10:00	t	0
2861	29	9	5	28	1	2021-06-30 03:20:00	2021-06-30 03:30:00	t	0
2883	30	10	8	41	7	2021-06-30 03:40:00	2021-06-30 03:50:00	t	0
2906	34	13	7	36	7	2021-06-30 04:10:00	2021-06-30 04:20:00	t	0
2912	30	10	8	41	7	2021-06-30 04:20:00	2021-06-30 04:30:00	t	0
3295	34	13	7	35	6	2021-06-30 12:20:00	2021-06-30 12:30:00	t	0
3296	30	10	8	41	7	2021-06-30 12:20:00	2021-06-30 12:30:00	t	0
3297	30	10	8	40	4	2021-06-30 12:20:00	2021-06-30 12:30:00	t	0
3298	35	11	9	44	3	2021-06-30 12:30:00	2021-06-30 12:40:00	t	0
3301	34	13	7	36	7	2021-06-30 12:30:00	2021-06-30 12:40:00	t	0
3302	34	13	7	35	6	2021-06-30 12:30:00	2021-06-30 12:40:00	t	0
3303	33	12	9	44	3	2021-06-30 12:30:00	2021-06-30 12:40:00	t	0
3306	31	11	9	44	3	2021-06-30 12:30:00	2021-06-30 12:40:00	t	0
3309	30	10	8	41	7	2021-06-30 12:30:00	2021-06-30 12:40:00	t	0
3310	30	10	8	40	4	2021-06-30 12:30:00	2021-06-30 12:40:00	t	0
3311	29	9	5	29	2	2021-06-30 12:30:00	2021-06-30 12:40:00	t	0
3299	35	11	9	43	2	2021-06-30 12:40:00	2021-06-30 12:50:00	t	0
3304	33	12	9	43	2	2021-06-30 12:40:00	2021-06-30 12:50:00	t	0
3307	31	11	9	43	2	2021-06-30 12:40:00	2021-06-30 12:50:00	t	0
3312	29	9	5	28	1	2021-06-30 12:40:00	2021-06-30 12:50:00	t	0
3315	34	13	7	36	7	2021-06-30 12:40:00	2021-06-30 12:50:00	t	0
3316	34	13	7	35	6	2021-06-30 12:40:00	2021-06-30 12:50:00	t	0
3318	30	10	8	40	4	2021-06-30 12:40:00	2021-06-30 12:50:00	t	0
3300	35	11	9	42	1	2021-06-30 12:50:00	2021-06-30 13:00:00	t	0
3305	33	12	9	42	1	2021-06-30 12:50:00	2021-06-30 13:00:00	t	0
3308	31	11	9	42	1	2021-06-30 12:50:00	2021-06-30 13:00:00	t	0
3313	29	9	6	32	2	2021-06-30 12:50:00	2021-06-30 13:00:00	t	0
3319	34	13	7	36	7	2021-06-30 12:50:00	2021-06-30 13:00:00	t	0
3320	34	13	7	35	6	2021-06-30 12:50:00	2021-06-30 13:00:00	t	0
3321	30	10	8	41	7	2021-06-30 12:50:00	2021-06-30 13:00:00	t	0
3322	30	10	8	40	4	2021-06-30 12:50:00	2021-06-30 13:00:00	t	0
3314	29	9	6	30	3	2021-06-30 13:00:00	2021-06-30 13:10:00	t	0
3323	35	11	9	44	3	2021-06-30 13:00:00	2021-06-30 13:10:00	t	0
3326	34	13	7	36	7	2021-06-30 13:00:00	2021-06-30 13:10:00	t	0
3327	34	13	7	35	6	2021-06-30 13:00:00	2021-06-30 13:10:00	t	0
3328	33	12	9	44	3	2021-06-30 13:00:00	2021-06-30 13:10:00	t	0
3331	31	11	9	44	3	2021-06-30 13:00:00	2021-06-30 13:10:00	t	0
3334	30	10	8	41	7	2021-06-30 13:00:00	2021-06-30 13:10:00	t	0
3335	30	10	8	40	4	2021-06-30 13:00:00	2021-06-30 13:10:00	t	0
3324	35	11	9	43	2	2021-06-30 13:10:00	2021-06-30 13:20:00	t	0
3329	33	12	9	43	2	2021-06-30 13:10:00	2021-06-30 13:20:00	t	0
3332	31	11	9	43	2	2021-06-30 13:10:00	2021-06-30 13:20:00	t	0
3336	34	13	7	36	7	2021-06-30 13:10:00	2021-06-30 13:20:00	t	0
3337	34	13	7	35	6	2021-06-30 13:10:00	2021-06-30 13:20:00	t	0
3338	30	10	8	41	7	2021-06-30 13:10:00	2021-06-30 13:20:00	t	0
3339	30	10	8	40	4	2021-06-30 13:10:00	2021-06-30 13:20:00	t	0
3340	29	9	5	29	2	2021-06-30 13:10:00	2021-06-30 13:20:00	t	0
3325	35	11	9	42	1	2021-06-30 13:20:00	2021-06-30 13:30:00	t	0
3333	31	11	9	42	1	2021-06-30 13:20:00	2021-06-30 13:30:00	t	0
3341	29	9	5	28	1	2021-06-30 13:20:00	2021-06-30 13:30:00	t	0
3344	34	13	7	36	7	2021-06-30 13:20:00	2021-06-30 13:30:00	t	0
3345	34	13	7	35	6	2021-06-30 13:20:00	2021-06-30 13:30:00	t	0
3346	30	10	8	41	7	2021-06-30 13:20:00	2021-06-30 13:30:00	t	0
3347	30	10	8	40	4	2021-06-30 13:20:00	2021-06-30 13:30:00	t	0
3342	29	9	6	32	2	2021-06-30 13:30:00	2021-06-30 13:40:00	t	0
3348	35	11	9	44	3	2021-06-30 13:30:00	2021-06-30 13:40:00	t	0
3351	34	13	7	36	7	2021-06-30 13:30:00	2021-06-30 13:40:00	t	0
3352	34	13	7	35	6	2021-06-30 13:30:00	2021-06-30 13:40:00	t	0
3353	33	12	9	44	3	2021-06-30 13:30:00	2021-06-30 13:40:00	t	0
3356	31	11	9	44	3	2021-06-30 13:30:00	2021-06-30 13:40:00	t	0
3359	30	10	8	41	7	2021-06-30 13:30:00	2021-06-30 13:40:00	t	0
3360	30	10	8	40	4	2021-06-30 13:30:00	2021-06-30 13:40:00	t	0
3343	29	9	6	30	3	2021-06-30 13:40:00	2021-06-30 13:50:00	t	0
3349	35	11	9	43	2	2021-06-30 13:40:00	2021-06-30 13:50:00	t	0
3354	33	12	9	43	2	2021-06-30 13:40:00	2021-06-30 13:50:00	t	0
3357	31	11	9	43	2	2021-06-30 13:40:00	2021-06-30 13:50:00	t	0
3361	34	13	7	36	7	2021-06-30 13:40:00	2021-06-30 13:50:00	t	0
3362	34	13	7	35	6	2021-06-30 13:40:00	2021-06-30 13:50:00	t	0
3350	35	11	9	42	1	2021-06-30 13:50:00	2021-06-30 14:00:00	t	0
3355	33	12	9	42	1	2021-06-30 13:50:00	2021-06-30 14:00:00	t	0
3358	31	11	9	42	1	2021-06-30 13:50:00	2021-06-30 14:00:00	t	0
2931	34	13	7	36	7	2021-06-30 04:40:00	2021-06-30 04:50:00	t	0
2941	35	11	9	42	1	2021-06-30 05:20:00	2021-06-30 05:30:00	t	0
2967	34	13	7	36	7	2021-06-30 05:30:00	2021-06-30 05:40:00	t	0
2985	29	9	5	29	2	2021-06-30 05:50:00	2021-06-30 06:00:00	t	0
3364	30	10	8	40	4	2021-06-30 13:40:00	2021-06-30 13:50:00	t	0
3365	34	13	7	36	7	2021-06-30 13:50:00	2021-06-30 14:00:00	t	0
3366	34	13	7	35	6	2021-06-30 13:50:00	2021-06-30 14:00:00	t	0
3367	30	10	8	41	7	2021-06-30 13:50:00	2021-06-30 14:00:00	t	0
3368	30	10	8	40	4	2021-06-30 13:50:00	2021-06-30 14:00:00	t	0
3369	29	9	5	29	2	2021-06-30 13:50:00	2021-06-30 14:00:00	t	0
3370	29	9	5	28	1	2021-06-30 14:00:00	2021-06-30 14:10:00	t	0
3373	35	11	9	44	3	2021-06-30 14:00:00	2021-06-30 14:10:00	t	0
3376	34	13	7	36	7	2021-06-30 14:00:00	2021-06-30 14:10:00	t	0
3377	34	13	7	35	6	2021-06-30 14:00:00	2021-06-30 14:10:00	t	0
3378	33	12	9	44	3	2021-06-30 14:00:00	2021-06-30 14:10:00	t	0
3381	31	11	9	44	3	2021-06-30 14:00:00	2021-06-30 14:10:00	t	0
3384	30	10	8	41	7	2021-06-30 14:00:00	2021-06-30 14:10:00	t	0
3385	30	10	8	40	4	2021-06-30 14:00:00	2021-06-30 14:10:00	t	0
3371	29	9	6	32	2	2021-06-30 14:10:00	2021-06-30 14:20:00	t	0
3374	35	11	9	43	2	2021-06-30 14:10:00	2021-06-30 14:20:00	t	0
3379	33	12	9	43	2	2021-06-30 14:10:00	2021-06-30 14:20:00	t	0
3386	34	13	7	36	7	2021-06-30 14:10:00	2021-06-30 14:20:00	t	0
3387	34	13	7	35	6	2021-06-30 14:10:00	2021-06-30 14:20:00	t	0
3388	30	10	8	41	7	2021-06-30 14:10:00	2021-06-30 14:20:00	t	0
3389	30	10	8	40	4	2021-06-30 14:10:00	2021-06-30 14:20:00	t	0
3372	29	9	6	30	3	2021-06-30 14:20:00	2021-06-30 14:30:00	t	0
3375	35	11	9	42	1	2021-06-30 14:20:00	2021-06-30 14:30:00	t	0
3380	33	12	9	42	1	2021-06-30 14:20:00	2021-06-30 14:30:00	t	0
3383	31	11	9	42	1	2021-06-30 14:20:00	2021-06-30 14:30:00	t	0
3390	34	13	7	36	7	2021-06-30 14:20:00	2021-06-30 14:30:00	t	0
3391	34	13	7	35	6	2021-06-30 14:20:00	2021-06-30 14:30:00	t	0
3392	30	10	8	41	7	2021-06-30 14:20:00	2021-06-30 14:30:00	t	0
3393	30	10	8	40	4	2021-06-30 14:20:00	2021-06-30 14:30:00	t	0
3394	35	11	9	44	3	2021-06-30 14:30:00	2021-06-30 14:40:00	t	0
3397	34	13	7	36	7	2021-06-30 14:30:00	2021-06-30 14:40:00	t	0
3398	34	13	7	35	6	2021-06-30 14:30:00	2021-06-30 14:40:00	t	0
3399	33	12	9	44	3	2021-06-30 14:30:00	2021-06-30 14:40:00	t	0
3402	31	11	9	44	3	2021-06-30 14:30:00	2021-06-30 14:40:00	t	0
3405	30	10	8	41	7	2021-06-30 14:30:00	2021-06-30 14:40:00	t	0
3406	30	10	8	40	4	2021-06-30 14:30:00	2021-06-30 14:40:00	t	0
3407	29	9	5	29	2	2021-06-30 14:30:00	2021-06-30 14:40:00	t	0
3395	35	11	9	43	2	2021-06-30 14:40:00	2021-06-30 14:50:00	t	0
3400	33	12	9	43	2	2021-06-30 14:40:00	2021-06-30 14:50:00	t	0
3403	31	11	9	43	2	2021-06-30 14:40:00	2021-06-30 14:50:00	t	0
3408	29	9	5	28	1	2021-06-30 14:40:00	2021-06-30 14:50:00	t	0
3411	34	13	7	36	7	2021-06-30 14:40:00	2021-06-30 14:50:00	t	0
3412	34	13	7	35	6	2021-06-30 14:40:00	2021-06-30 14:50:00	t	0
3414	30	10	8	40	4	2021-06-30 14:40:00	2021-06-30 14:50:00	t	0
3396	35	11	9	42	1	2021-06-30 14:50:00	2021-06-30 15:00:00	t	0
3401	33	12	9	42	1	2021-06-30 14:50:00	2021-06-30 15:00:00	t	0
3404	31	11	9	42	1	2021-06-30 14:50:00	2021-06-30 15:00:00	t	0
3409	29	9	6	32	2	2021-06-30 14:50:00	2021-06-30 15:00:00	t	0
3415	34	13	7	36	7	2021-06-30 14:50:00	2021-06-30 15:00:00	t	0
3416	34	13	7	35	6	2021-06-30 14:50:00	2021-06-30 15:00:00	t	0
3417	30	10	8	41	7	2021-06-30 14:50:00	2021-06-30 15:00:00	t	0
3418	30	10	8	40	4	2021-06-30 14:50:00	2021-06-30 15:00:00	t	0
3410	29	9	6	30	3	2021-06-30 15:00:00	2021-06-30 15:10:00	t	0
3419	35	11	9	44	3	2021-06-30 15:00:00	2021-06-30 15:10:00	t	0
3422	34	13	7	36	7	2021-06-30 15:00:00	2021-06-30 15:10:00	t	0
3423	34	13	7	35	6	2021-06-30 15:00:00	2021-06-30 15:10:00	t	0
3424	33	12	9	44	3	2021-06-30 15:00:00	2021-06-30 15:10:00	t	0
3427	31	11	9	44	3	2021-06-30 15:00:00	2021-06-30 15:10:00	t	0
3430	30	10	8	41	7	2021-06-30 15:00:00	2021-06-30 15:10:00	t	0
3431	30	10	8	40	4	2021-06-30 15:00:00	2021-06-30 15:10:00	t	0
3420	35	11	9	43	2	2021-06-30 15:10:00	2021-06-30 15:20:00	t	0
3425	33	12	9	43	2	2021-06-30 15:10:00	2021-06-30 15:20:00	t	0
3428	31	11	9	43	2	2021-06-30 15:10:00	2021-06-30 15:20:00	t	0
3432	34	13	7	36	7	2021-06-30 15:10:00	2021-06-30 15:20:00	t	0
3433	34	13	7	35	6	2021-06-30 15:10:00	2021-06-30 15:20:00	t	0
3421	35	11	9	42	1	2021-06-30 15:20:00	2021-06-30 15:30:00	t	0
3426	33	12	9	42	1	2021-06-30 15:20:00	2021-06-30 15:30:00	t	0
3429	31	11	9	42	1	2021-06-30 15:20:00	2021-06-30 15:30:00	t	0
3034	30	10	8	40	4	2021-06-30 06:50:00	2021-06-30 07:00:00	t	0
3026	29	9	6	30	3	2021-06-30 07:00:00	2021-06-30 07:10:00	t	0
3052	29	9	5	29	2	2021-06-30 07:10:00	2021-06-30 07:20:00	t	0
3435	30	10	8	40	4	2021-06-30 15:10:00	2021-06-30 15:20:00	t	0
3436	29	9	5	29	2	2021-06-30 15:10:00	2021-06-30 15:20:00	t	0
3437	29	9	5	28	1	2021-06-30 15:20:00	2021-06-30 15:30:00	t	0
3440	34	13	7	36	7	2021-06-30 15:20:00	2021-06-30 15:30:00	t	0
3441	34	13	7	35	6	2021-06-30 15:20:00	2021-06-30 15:30:00	t	0
3442	30	10	8	41	7	2021-06-30 15:20:00	2021-06-30 15:30:00	t	0
3443	30	10	8	40	4	2021-06-30 15:20:00	2021-06-30 15:30:00	t	0
3438	29	9	6	32	2	2021-06-30 15:30:00	2021-06-30 15:40:00	t	0
3444	35	11	9	44	3	2021-06-30 15:30:00	2021-06-30 15:40:00	t	0
3447	34	13	7	36	7	2021-06-30 15:30:00	2021-06-30 15:40:00	t	0
3448	34	13	7	35	6	2021-06-30 15:30:00	2021-06-30 15:40:00	t	0
3449	33	12	9	44	3	2021-06-30 15:30:00	2021-06-30 15:40:00	t	0
3452	31	11	9	44	3	2021-06-30 15:30:00	2021-06-30 15:40:00	t	0
3455	30	10	8	41	7	2021-06-30 15:30:00	2021-06-30 15:40:00	t	0
3456	30	10	8	40	4	2021-06-30 15:30:00	2021-06-30 15:40:00	t	0
3439	29	9	6	30	3	2021-06-30 15:40:00	2021-06-30 15:50:00	t	0
3445	35	11	9	43	2	2021-06-30 15:40:00	2021-06-30 15:50:00	t	0
3453	31	11	9	43	2	2021-06-30 15:40:00	2021-06-30 15:50:00	t	0
3457	34	13	7	36	7	2021-06-30 15:40:00	2021-06-30 15:50:00	t	0
3458	34	13	7	35	6	2021-06-30 15:40:00	2021-06-30 15:50:00	t	0
3459	30	10	8	41	7	2021-06-30 15:40:00	2021-06-30 15:50:00	t	0
3460	30	10	8	40	4	2021-06-30 15:40:00	2021-06-30 15:50:00	t	0
3446	35	11	9	42	1	2021-06-30 15:50:00	2021-06-30 16:00:00	t	0
3451	33	12	9	42	1	2021-06-30 15:50:00	2021-06-30 16:00:00	t	0
3454	31	11	9	42	1	2021-06-30 15:50:00	2021-06-30 16:00:00	t	0
3461	34	13	7	36	7	2021-06-30 15:50:00	2021-06-30 16:00:00	t	0
3462	34	13	7	35	6	2021-06-30 15:50:00	2021-06-30 16:00:00	t	0
3463	30	10	8	41	7	2021-06-30 15:50:00	2021-06-30 16:00:00	t	0
3464	30	10	8	40	4	2021-06-30 15:50:00	2021-06-30 16:00:00	t	0
3465	29	9	5	29	2	2021-06-30 15:50:00	2021-06-30 16:00:00	t	0
3466	29	9	5	28	1	2021-06-30 16:00:00	2021-06-30 16:10:00	t	0
3469	35	11	9	44	3	2021-06-30 16:00:00	2021-06-30 16:10:00	t	0
3472	34	13	7	36	7	2021-06-30 16:00:00	2021-06-30 16:10:00	t	0
3473	34	13	7	35	6	2021-06-30 16:00:00	2021-06-30 16:10:00	t	0
3474	33	12	9	44	3	2021-06-30 16:00:00	2021-06-30 16:10:00	t	0
3477	31	11	9	44	3	2021-06-30 16:00:00	2021-06-30 16:10:00	t	0
3480	30	10	8	41	7	2021-06-30 16:00:00	2021-06-30 16:10:00	t	0
3481	30	10	8	40	4	2021-06-30 16:00:00	2021-06-30 16:10:00	t	0
3467	29	9	6	32	2	2021-06-30 16:10:00	2021-06-30 16:20:00	t	0
3470	35	11	9	43	2	2021-06-30 16:10:00	2021-06-30 16:20:00	t	0
3475	33	12	9	43	2	2021-06-30 16:10:00	2021-06-30 16:20:00	t	0
3478	31	11	9	43	2	2021-06-30 16:10:00	2021-06-30 16:20:00	t	0
3482	34	13	7	36	7	2021-06-30 16:10:00	2021-06-30 16:20:00	t	0
3484	30	10	8	41	7	2021-06-30 16:10:00	2021-06-30 16:20:00	t	0
3485	30	10	8	40	4	2021-06-30 16:10:00	2021-06-30 16:20:00	t	0
3468	29	9	6	30	3	2021-06-30 16:20:00	2021-06-30 16:30:00	t	0
3471	35	11	9	42	1	2021-06-30 16:20:00	2021-06-30 16:30:00	t	0
3476	33	12	9	42	1	2021-06-30 16:20:00	2021-06-30 16:30:00	t	0
3479	31	11	9	42	1	2021-06-30 16:20:00	2021-06-30 16:30:00	t	0
3486	34	13	7	36	7	2021-06-30 16:20:00	2021-06-30 16:30:00	t	0
3487	34	13	7	35	6	2021-06-30 16:20:00	2021-06-30 16:30:00	t	0
3488	30	10	8	41	7	2021-06-30 16:20:00	2021-06-30 16:30:00	t	0
3489	30	10	8	40	4	2021-06-30 16:20:00	2021-06-30 16:30:00	t	0
3490	35	11	9	44	3	2021-06-30 16:30:00	2021-06-30 16:40:00	t	0
3493	34	13	7	36	7	2021-06-30 16:30:00	2021-06-30 16:40:00	t	0
3494	34	13	7	35	6	2021-06-30 16:30:00	2021-06-30 16:40:00	t	0
3495	33	12	9	44	3	2021-06-30 16:30:00	2021-06-30 16:40:00	t	0
3498	31	11	9	44	3	2021-06-30 16:30:00	2021-06-30 16:40:00	t	0
3501	30	10	8	41	7	2021-06-30 16:30:00	2021-06-30 16:40:00	t	0
3502	30	10	8	40	4	2021-06-30 16:30:00	2021-06-30 16:40:00	t	0
3503	29	9	5	29	2	2021-06-30 16:30:00	2021-06-30 16:40:00	t	0
3491	35	11	9	43	2	2021-06-30 16:40:00	2021-06-30 16:50:00	t	0
3496	33	12	9	43	2	2021-06-30 16:40:00	2021-06-30 16:50:00	t	0
3499	31	11	9	43	2	2021-06-30 16:40:00	2021-06-30 16:50:00	t	0
3504	29	9	5	28	1	2021-06-30 16:40:00	2021-06-30 16:50:00	t	0
3492	35	11	9	42	1	2021-06-30 16:50:00	2021-06-30 17:00:00	t	0
3497	33	12	9	42	1	2021-06-30 16:50:00	2021-06-30 17:00:00	t	0
3500	31	11	9	42	1	2021-06-30 16:50:00	2021-06-30 17:00:00	t	0
3505	29	9	6	32	2	2021-06-30 16:50:00	2021-06-30 17:00:00	t	0
3089	34	13	7	35	6	2021-06-30 08:00:00	2021-06-30 08:10:00	t	0
3113	33	12	9	42	1	2021-06-30 08:50:00	2021-06-30 09:00:00	t	0
3508	34	13	7	35	6	2021-06-30 16:40:00	2021-06-30 16:50:00	t	0
3509	30	10	8	41	7	2021-06-30 16:40:00	2021-06-30 16:50:00	t	0
3510	30	10	8	40	4	2021-06-30 16:40:00	2021-06-30 16:50:00	t	0
3511	34	13	7	36	7	2021-06-30 16:50:00	2021-06-30 17:00:00	t	0
3512	34	13	7	35	6	2021-06-30 16:50:00	2021-06-30 17:00:00	t	0
3513	30	10	8	41	7	2021-06-30 16:50:00	2021-06-30 17:00:00	t	0
3514	30	10	8	40	4	2021-06-30 16:50:00	2021-06-30 17:00:00	t	0
3506	29	9	6	30	3	2021-06-30 17:00:00	2021-06-30 17:10:00	t	0
3515	34	13	7	36	7	2021-06-30 17:00:00	2021-06-30 17:10:00	t	0
3516	34	13	7	35	6	2021-06-30 17:00:00	2021-06-30 17:10:00	t	0
3517	33	12	9	44	3	2021-06-30 17:00:00	2021-06-30 17:10:00	t	0
3520	31	11	9	44	3	2021-06-30 17:00:00	2021-06-30 17:10:00	t	0
3523	30	10	8	41	7	2021-06-30 17:00:00	2021-06-30 17:10:00	t	0
3524	30	10	8	40	4	2021-06-30 17:00:00	2021-06-30 17:10:00	t	0
3525	35	11	9	44	3	2021-06-30 17:00:00	2021-06-30 17:10:00	t	0
3518	33	12	9	43	2	2021-06-30 17:10:00	2021-06-30 17:20:00	t	0
3521	31	11	9	43	2	2021-06-30 17:10:00	2021-06-30 17:20:00	t	0
3528	34	13	7	36	7	2021-06-30 17:10:00	2021-06-30 17:20:00	t	0
3529	34	13	7	35	6	2021-06-30 17:10:00	2021-06-30 17:20:00	t	0
3530	30	10	8	41	7	2021-06-30 17:10:00	2021-06-30 17:20:00	t	0
3531	30	10	8	40	4	2021-06-30 17:10:00	2021-06-30 17:20:00	t	0
3532	29	9	5	29	2	2021-06-30 17:10:00	2021-06-30 17:20:00	t	0
3519	33	12	9	42	1	2021-06-30 17:20:00	2021-06-30 17:30:00	t	0
3522	31	11	9	42	1	2021-06-30 17:20:00	2021-06-30 17:30:00	t	0
3527	35	11	9	42	1	2021-06-30 17:20:00	2021-06-30 17:30:00	t	0
3533	29	9	5	28	1	2021-06-30 17:20:00	2021-06-30 17:30:00	t	0
3536	34	13	7	36	7	2021-06-30 17:20:00	2021-06-30 17:30:00	t	0
3537	34	13	7	35	6	2021-06-30 17:20:00	2021-06-30 17:30:00	t	0
3538	30	10	8	41	7	2021-06-30 17:20:00	2021-06-30 17:30:00	t	0
3539	30	10	8	40	4	2021-06-30 17:20:00	2021-06-30 17:30:00	t	0
3534	29	9	6	32	2	2021-06-30 17:30:00	2021-06-30 17:40:00	t	0
3540	35	11	9	44	3	2021-06-30 17:30:00	2021-06-30 17:40:00	t	0
3543	34	13	7	36	7	2021-06-30 17:30:00	2021-06-30 17:40:00	t	0
3544	34	13	7	35	6	2021-06-30 17:30:00	2021-06-30 17:40:00	t	0
3545	33	12	9	44	3	2021-06-30 17:30:00	2021-06-30 17:40:00	t	0
3548	31	11	9	44	3	2021-06-30 17:30:00	2021-06-30 17:40:00	t	0
3551	30	10	8	41	7	2021-06-30 17:30:00	2021-06-30 17:40:00	t	0
3552	30	10	8	40	4	2021-06-30 17:30:00	2021-06-30 17:40:00	t	0
3535	29	9	6	30	3	2021-06-30 17:40:00	2021-06-30 17:50:00	t	0
3541	35	11	9	43	2	2021-06-30 17:40:00	2021-06-30 17:50:00	t	0
3546	33	12	9	43	2	2021-06-30 17:40:00	2021-06-30 17:50:00	t	0
3549	31	11	9	43	2	2021-06-30 17:40:00	2021-06-30 17:50:00	t	0
3553	34	13	7	36	7	2021-06-30 17:40:00	2021-06-30 17:50:00	t	0
3555	30	10	8	41	7	2021-06-30 17:40:00	2021-06-30 17:50:00	t	0
3556	30	10	8	40	4	2021-06-30 17:40:00	2021-06-30 17:50:00	t	0
3542	35	11	9	42	1	2021-06-30 17:50:00	2021-06-30 18:00:00	t	0
3547	33	12	9	42	1	2021-06-30 17:50:00	2021-06-30 18:00:00	t	0
3550	31	11	9	42	1	2021-06-30 17:50:00	2021-06-30 18:00:00	t	0
3557	34	13	7	36	7	2021-06-30 17:50:00	2021-06-30 18:00:00	t	0
3558	34	13	7	35	6	2021-06-30 17:50:00	2021-06-30 18:00:00	t	0
3559	30	10	8	41	7	2021-06-30 17:50:00	2021-06-30 18:00:00	t	0
3560	30	10	8	40	4	2021-06-30 17:50:00	2021-06-30 18:00:00	t	0
3561	29	9	5	29	2	2021-06-30 17:50:00	2021-06-30 18:00:00	t	0
3562	29	9	5	28	1	2021-06-30 18:00:00	2021-06-30 18:10:00	t	0
3565	35	11	9	44	3	2021-06-30 18:00:00	2021-06-30 18:10:00	t	0
3568	34	13	7	36	7	2021-06-30 18:00:00	2021-06-30 18:10:00	t	0
3569	34	13	7	35	6	2021-06-30 18:00:00	2021-06-30 18:10:00	t	0
3570	33	12	9	44	3	2021-06-30 18:00:00	2021-06-30 18:10:00	t	0
3573	31	11	9	44	3	2021-06-30 18:00:00	2021-06-30 18:10:00	t	0
3576	30	10	8	41	7	2021-06-30 18:00:00	2021-06-30 18:10:00	t	0
3577	30	10	8	40	4	2021-06-30 18:00:00	2021-06-30 18:10:00	t	0
3563	29	9	6	32	2	2021-06-30 18:10:00	2021-06-30 18:20:00	t	0
3566	35	11	9	43	2	2021-06-30 18:10:00	2021-06-30 18:20:00	t	0
3571	33	12	9	43	2	2021-06-30 18:10:00	2021-06-30 18:20:00	t	0
3574	31	11	9	43	2	2021-06-30 18:10:00	2021-06-30 18:20:00	t	0
3578	34	13	7	36	7	2021-06-30 18:10:00	2021-06-30 18:20:00	t	0
3564	29	9	6	30	3	2021-06-30 18:20:00	2021-06-30 18:30:00	t	0
3567	35	11	9	42	1	2021-06-30 18:20:00	2021-06-30 18:30:00	t	0
3572	33	12	9	42	1	2021-06-30 18:20:00	2021-06-30 18:30:00	t	0
3151	29	9	6	30	3	2021-06-30 09:40:00	2021-06-30 09:50:00	t	0
3580	30	10	8	41	7	2021-06-30 18:10:00	2021-06-30 18:20:00	t	0
3581	30	10	8	40	4	2021-06-30 18:10:00	2021-06-30 18:20:00	t	0
3582	34	13	7	36	7	2021-06-30 18:20:00	2021-06-30 18:30:00	t	0
3583	34	13	7	35	6	2021-06-30 18:20:00	2021-06-30 18:30:00	t	0
3584	30	10	8	41	7	2021-06-30 18:20:00	2021-06-30 18:30:00	t	0
3585	30	10	8	40	4	2021-06-30 18:20:00	2021-06-30 18:30:00	t	0
3586	35	11	9	44	3	2021-06-30 18:30:00	2021-06-30 18:40:00	t	0
3589	34	13	7	36	7	2021-06-30 18:30:00	2021-06-30 18:40:00	t	0
3590	34	13	7	35	6	2021-06-30 18:30:00	2021-06-30 18:40:00	t	0
3591	33	12	9	44	3	2021-06-30 18:30:00	2021-06-30 18:40:00	t	0
3594	31	11	9	44	3	2021-06-30 18:30:00	2021-06-30 18:40:00	t	0
3597	30	10	8	41	7	2021-06-30 18:30:00	2021-06-30 18:40:00	t	0
3598	30	10	8	40	4	2021-06-30 18:30:00	2021-06-30 18:40:00	t	0
3599	29	9	5	29	2	2021-06-30 18:30:00	2021-06-30 18:40:00	t	0
3587	35	11	9	43	2	2021-06-30 18:40:00	2021-06-30 18:50:00	t	0
3592	33	12	9	43	2	2021-06-30 18:40:00	2021-06-30 18:50:00	t	0
3595	31	11	9	43	2	2021-06-30 18:40:00	2021-06-30 18:50:00	t	0
3603	34	13	7	36	7	2021-06-30 18:40:00	2021-06-30 18:50:00	t	0
3604	34	13	7	35	6	2021-06-30 18:40:00	2021-06-30 18:50:00	t	0
3605	30	10	8	41	7	2021-06-30 18:40:00	2021-06-30 18:50:00	t	0
3606	30	10	8	40	4	2021-06-30 18:40:00	2021-06-30 18:50:00	t	0
3588	35	11	9	42	1	2021-06-30 18:50:00	2021-06-30 19:00:00	t	0
3593	33	12	9	42	1	2021-06-30 18:50:00	2021-06-30 19:00:00	t	0
3596	31	11	9	42	1	2021-06-30 18:50:00	2021-06-30 19:00:00	t	0
3601	29	9	6	32	2	2021-06-30 18:50:00	2021-06-30 19:00:00	t	0
3607	34	13	7	36	7	2021-06-30 18:50:00	2021-06-30 19:00:00	t	0
3608	34	13	7	35	6	2021-06-30 18:50:00	2021-06-30 19:00:00	t	0
3609	30	10	8	41	7	2021-06-30 18:50:00	2021-06-30 19:00:00	t	0
3610	30	10	8	40	4	2021-06-30 18:50:00	2021-06-30 19:00:00	t	0
3602	29	9	6	30	3	2021-06-30 19:00:00	2021-06-30 19:10:00	t	0
3611	35	11	9	44	3	2021-06-30 19:00:00	2021-06-30 19:10:00	t	0
3614	34	13	7	36	7	2021-06-30 19:00:00	2021-06-30 19:10:00	t	0
3615	34	13	7	35	6	2021-06-30 19:00:00	2021-06-30 19:10:00	t	0
3616	33	12	9	44	3	2021-06-30 19:00:00	2021-06-30 19:10:00	t	0
3619	31	11	9	44	3	2021-06-30 19:00:00	2021-06-30 19:10:00	t	0
3622	30	10	8	41	7	2021-06-30 19:00:00	2021-06-30 19:10:00	t	0
3623	30	10	8	40	4	2021-06-30 19:00:00	2021-06-30 19:10:00	t	0
3612	35	11	9	43	2	2021-06-30 19:10:00	2021-06-30 19:20:00	t	0
3617	33	12	9	43	2	2021-06-30 19:10:00	2021-06-30 19:20:00	t	0
3620	31	11	9	43	2	2021-06-30 19:10:00	2021-06-30 19:20:00	t	0
3624	34	13	7	36	7	2021-06-30 19:10:00	2021-06-30 19:20:00	t	0
3625	34	13	7	35	6	2021-06-30 19:10:00	2021-06-30 19:20:00	t	0
3626	30	10	8	41	7	2021-06-30 19:10:00	2021-06-30 19:20:00	t	0
3628	29	9	5	29	2	2021-06-30 19:10:00	2021-06-30 19:20:00	t	0
3613	35	11	9	42	1	2021-06-30 19:20:00	2021-06-30 19:30:00	t	0
3618	33	12	9	42	1	2021-06-30 19:20:00	2021-06-30 19:30:00	t	0
3621	31	11	9	42	1	2021-06-30 19:20:00	2021-06-30 19:30:00	t	0
3629	29	9	5	28	1	2021-06-30 19:20:00	2021-06-30 19:30:00	t	0
3632	34	13	7	36	7	2021-06-30 19:20:00	2021-06-30 19:30:00	t	0
3633	34	13	7	35	6	2021-06-30 19:20:00	2021-06-30 19:30:00	t	0
3634	30	10	8	41	7	2021-06-30 19:20:00	2021-06-30 19:30:00	t	0
3635	30	10	8	40	4	2021-06-30 19:20:00	2021-06-30 19:30:00	t	0
3630	29	9	6	32	2	2021-06-30 19:30:00	2021-06-30 19:40:00	t	0
3636	35	11	9	44	3	2021-06-30 19:30:00	2021-06-30 19:40:00	t	0
3639	34	13	7	36	7	2021-06-30 19:30:00	2021-06-30 19:40:00	t	0
3640	34	13	7	35	6	2021-06-30 19:30:00	2021-06-30 19:40:00	t	0
3641	33	12	9	44	3	2021-06-30 19:30:00	2021-06-30 19:40:00	t	0
3644	31	11	9	44	3	2021-06-30 19:30:00	2021-06-30 19:40:00	t	0
3647	30	10	8	41	7	2021-06-30 19:30:00	2021-06-30 19:40:00	t	0
3648	30	10	8	40	4	2021-06-30 19:30:00	2021-06-30 19:40:00	t	0
3631	29	9	6	30	3	2021-06-30 19:40:00	2021-06-30 19:50:00	t	0
3637	35	11	9	43	2	2021-06-30 19:40:00	2021-06-30 19:50:00	t	0
3642	33	12	9	43	2	2021-06-30 19:40:00	2021-06-30 19:50:00	t	0
3645	31	11	9	43	2	2021-06-30 19:40:00	2021-06-30 19:50:00	t	0
3649	34	13	7	36	7	2021-06-30 19:40:00	2021-06-30 19:50:00	t	0
3650	34	13	7	35	6	2021-06-30 19:40:00	2021-06-30 19:50:00	t	0
3651	30	10	8	41	7	2021-06-30 19:40:00	2021-06-30 19:50:00	t	0
3652	30	10	8	40	4	2021-06-30 19:40:00	2021-06-30 19:50:00	t	0
3638	35	11	9	42	1	2021-06-30 19:50:00	2021-06-30 20:00:00	t	0
3646	31	11	9	42	1	2021-06-30 19:50:00	2021-06-30 20:00:00	t	0
3223	34	13	7	36	7	2021-06-30 10:50:00	2021-06-30 11:00:00	t	0
3244	29	9	5	29	2	2021-06-30 11:10:00	2021-06-30 11:20:00	t	0
3262	31	11	9	42	1	2021-06-30 11:50:00	2021-06-30 12:00:00	t	0
3654	34	13	7	35	6	2021-06-30 19:50:00	2021-06-30 20:00:00	t	0
3655	30	10	8	41	7	2021-06-30 19:50:00	2021-06-30 20:00:00	t	0
3656	30	10	8	40	4	2021-06-30 19:50:00	2021-06-30 20:00:00	t	0
3657	29	9	5	29	2	2021-06-30 19:50:00	2021-06-30 20:00:00	t	0
3658	29	9	5	28	1	2021-06-30 20:00:00	2021-06-30 20:10:00	t	0
3661	35	11	9	44	3	2021-06-30 20:00:00	2021-06-30 20:10:00	t	0
3664	34	13	7	36	7	2021-06-30 20:00:00	2021-06-30 20:10:00	t	0
3665	34	13	7	35	6	2021-06-30 20:00:00	2021-06-30 20:10:00	t	0
3666	33	12	9	44	3	2021-06-30 20:00:00	2021-06-30 20:10:00	t	0
3669	31	11	9	44	3	2021-06-30 20:00:00	2021-06-30 20:10:00	t	0
3672	30	10	8	41	7	2021-06-30 20:00:00	2021-06-30 20:10:00	t	0
3673	30	10	8	40	4	2021-06-30 20:00:00	2021-06-30 20:10:00	t	0
3659	29	9	6	32	2	2021-06-30 20:10:00	2021-06-30 20:20:00	t	0
3662	35	11	9	43	2	2021-06-30 20:10:00	2021-06-30 20:20:00	t	0
3667	33	12	9	43	2	2021-06-30 20:10:00	2021-06-30 20:20:00	t	0
3670	31	11	9	43	2	2021-06-30 20:10:00	2021-06-30 20:20:00	t	0
3674	34	13	7	36	7	2021-06-30 20:10:00	2021-06-30 20:20:00	t	0
3676	30	10	8	41	7	2021-06-30 20:10:00	2021-06-30 20:20:00	t	0
3677	30	10	8	40	4	2021-06-30 20:10:00	2021-06-30 20:20:00	t	0
3660	29	9	6	30	3	2021-06-30 20:20:00	2021-06-30 20:30:00	t	0
3663	35	11	9	42	1	2021-06-30 20:20:00	2021-06-30 20:30:00	t	0
3668	33	12	9	42	1	2021-06-30 20:20:00	2021-06-30 20:30:00	t	0
3671	31	11	9	42	1	2021-06-30 20:20:00	2021-06-30 20:30:00	t	0
3678	34	13	7	36	7	2021-06-30 20:20:00	2021-06-30 20:30:00	t	0
3679	34	13	7	35	6	2021-06-30 20:20:00	2021-06-30 20:30:00	t	0
3680	30	10	8	41	7	2021-06-30 20:20:00	2021-06-30 20:30:00	t	0
3681	30	10	8	40	4	2021-06-30 20:20:00	2021-06-30 20:30:00	t	0
3682	35	11	9	44	3	2021-06-30 20:30:00	2021-06-30 20:40:00	t	0
3685	34	13	7	36	7	2021-06-30 20:30:00	2021-06-30 20:40:00	t	0
3686	34	13	7	35	6	2021-06-30 20:30:00	2021-06-30 20:40:00	t	0
3687	33	12	9	44	3	2021-06-30 20:30:00	2021-06-30 20:40:00	t	0
3690	31	11	9	44	3	2021-06-30 20:30:00	2021-06-30 20:40:00	t	0
3693	30	10	8	41	7	2021-06-30 20:30:00	2021-06-30 20:40:00	t	0
3694	30	10	8	40	4	2021-06-30 20:30:00	2021-06-30 20:40:00	t	0
3695	29	9	5	29	2	2021-06-30 20:30:00	2021-06-30 20:40:00	t	0
3683	35	11	9	43	2	2021-06-30 20:40:00	2021-06-30 20:50:00	t	0
3688	33	12	9	43	2	2021-06-30 20:40:00	2021-06-30 20:50:00	t	0
3691	31	11	9	43	2	2021-06-30 20:40:00	2021-06-30 20:50:00	t	0
3696	29	9	5	28	1	2021-06-30 20:40:00	2021-06-30 20:50:00	t	0
3699	34	13	7	36	7	2021-06-30 20:40:00	2021-06-30 20:50:00	t	0
3700	34	13	7	35	6	2021-06-30 20:40:00	2021-06-30 20:50:00	t	0
3701	30	10	8	41	7	2021-06-30 20:40:00	2021-06-30 20:50:00	t	0
3702	30	10	8	40	4	2021-06-30 20:40:00	2021-06-30 20:50:00	t	0
3689	33	12	9	42	1	2021-06-30 20:50:00	2021-06-30 21:00:00	t	0
3692	31	11	9	42	1	2021-06-30 20:50:00	2021-06-30 21:00:00	t	0
3697	29	9	6	32	2	2021-06-30 20:50:00	2021-06-30 21:00:00	t	0
3703	34	13	7	36	7	2021-06-30 20:50:00	2021-06-30 21:00:00	t	0
3704	34	13	7	35	6	2021-06-30 20:50:00	2021-06-30 21:00:00	t	0
3705	30	10	8	41	7	2021-06-30 20:50:00	2021-06-30 21:00:00	t	0
3706	30	10	8	40	4	2021-06-30 20:50:00	2021-06-30 21:00:00	t	0
3698	29	9	6	30	3	2021-06-30 21:00:00	2021-06-30 21:10:00	t	0
3707	35	11	9	44	3	2021-06-30 21:00:00	2021-06-30 21:10:00	t	0
3710	34	13	7	36	7	2021-06-30 21:00:00	2021-06-30 21:10:00	t	0
3711	34	13	7	35	6	2021-06-30 21:00:00	2021-06-30 21:10:00	t	0
3712	33	12	9	44	3	2021-06-30 21:00:00	2021-06-30 21:10:00	t	0
3715	31	11	9	44	3	2021-06-30 21:00:00	2021-06-30 21:10:00	t	0
3718	30	10	8	41	7	2021-06-30 21:00:00	2021-06-30 21:10:00	t	0
3719	30	10	8	40	4	2021-06-30 21:00:00	2021-06-30 21:10:00	t	0
3708	35	11	9	43	2	2021-06-30 21:10:00	2021-06-30 21:20:00	t	0
3713	33	12	9	43	2	2021-06-30 21:10:00	2021-06-30 21:20:00	t	0
3716	31	11	9	43	2	2021-06-30 21:10:00	2021-06-30 21:20:00	t	0
3720	34	13	7	36	7	2021-06-30 21:10:00	2021-06-30 21:20:00	t	0
3721	34	13	7	35	6	2021-06-30 21:10:00	2021-06-30 21:20:00	t	0
3722	30	10	8	41	7	2021-06-30 21:10:00	2021-06-30 21:20:00	t	0
3723	30	10	8	40	4	2021-06-30 21:10:00	2021-06-30 21:20:00	t	0
3724	29	9	5	29	2	2021-06-30 21:10:00	2021-06-30 21:20:00	t	0
3709	35	11	9	42	1	2021-06-30 21:20:00	2021-06-30 21:30:00	t	0
3714	33	12	9	42	1	2021-06-30 21:20:00	2021-06-30 21:30:00	t	0
3717	31	11	9	42	1	2021-06-30 21:20:00	2021-06-30 21:30:00	t	0
3294	34	13	7	36	7	2021-06-30 12:20:00	2021-06-30 12:30:00	t	0
3317	30	10	8	41	7	2021-06-30 12:40:00	2021-06-30 12:50:00	t	0
3330	33	12	9	42	1	2021-06-30 13:20:00	2021-06-30 13:30:00	t	0
3728	34	13	7	36	7	2021-06-30 21:20:00	2021-06-30 21:30:00	t	0
3729	34	13	7	35	6	2021-06-30 21:20:00	2021-06-30 21:30:00	t	0
3730	30	10	8	41	7	2021-06-30 21:20:00	2021-06-30 21:30:00	t	0
3731	30	10	8	40	4	2021-06-30 21:20:00	2021-06-30 21:30:00	t	0
3726	29	9	6	32	2	2021-06-30 21:30:00	2021-06-30 21:40:00	t	0
3732	35	11	9	44	3	2021-06-30 21:30:00	2021-06-30 21:40:00	t	0
3735	34	13	7	36	7	2021-06-30 21:30:00	2021-06-30 21:40:00	t	0
3736	34	13	7	35	6	2021-06-30 21:30:00	2021-06-30 21:40:00	t	0
3737	33	12	9	44	3	2021-06-30 21:30:00	2021-06-30 21:40:00	t	0
3740	31	11	9	44	3	2021-06-30 21:30:00	2021-06-30 21:40:00	t	0
3743	30	10	8	41	7	2021-06-30 21:30:00	2021-06-30 21:40:00	t	0
3744	30	10	8	40	4	2021-06-30 21:30:00	2021-06-30 21:40:00	t	0
3727	29	9	6	30	3	2021-06-30 21:40:00	2021-06-30 21:50:00	t	0
3733	35	11	9	43	2	2021-06-30 21:40:00	2021-06-30 21:50:00	t	0
3738	33	12	9	43	2	2021-06-30 21:40:00	2021-06-30 21:50:00	t	0
3741	31	11	9	43	2	2021-06-30 21:40:00	2021-06-30 21:50:00	t	0
3745	34	13	7	36	7	2021-06-30 21:40:00	2021-06-30 21:50:00	t	0
3747	30	10	8	41	7	2021-06-30 21:40:00	2021-06-30 21:50:00	t	0
3748	30	10	8	40	4	2021-06-30 21:40:00	2021-06-30 21:50:00	t	0
3734	35	11	9	42	1	2021-06-30 21:50:00	2021-06-30 22:00:00	t	0
3739	33	12	9	42	1	2021-06-30 21:50:00	2021-06-30 22:00:00	t	0
3742	31	11	9	42	1	2021-06-30 21:50:00	2021-06-30 22:00:00	t	0
3749	34	13	7	36	7	2021-06-30 21:50:00	2021-06-30 22:00:00	t	0
3750	34	13	7	35	6	2021-06-30 21:50:00	2021-06-30 22:00:00	t	0
3751	30	10	8	41	7	2021-06-30 21:50:00	2021-06-30 22:00:00	t	0
3752	30	10	8	40	4	2021-06-30 21:50:00	2021-06-30 22:00:00	t	0
3753	29	9	5	29	2	2021-06-30 21:50:00	2021-06-30 22:00:00	t	0
3754	29	9	5	28	1	2021-06-30 22:00:00	2021-06-30 22:10:00	t	0
3757	35	11	9	44	3	2021-06-30 22:00:00	2021-06-30 22:10:00	t	0
3760	34	13	7	36	7	2021-06-30 22:00:00	2021-06-30 22:10:00	t	0
3761	34	13	7	35	6	2021-06-30 22:00:00	2021-06-30 22:10:00	t	0
3762	33	12	9	44	3	2021-06-30 22:00:00	2021-06-30 22:10:00	t	0
3765	31	11	9	44	3	2021-06-30 22:00:00	2021-06-30 22:10:00	t	0
3768	30	10	8	41	7	2021-06-30 22:00:00	2021-06-30 22:10:00	t	0
3769	30	10	8	40	4	2021-06-30 22:00:00	2021-06-30 22:10:00	t	0
3755	29	9	6	32	2	2021-06-30 22:10:00	2021-06-30 22:20:00	t	0
3758	35	11	9	43	2	2021-06-30 22:10:00	2021-06-30 22:20:00	t	0
3763	33	12	9	43	2	2021-06-30 22:10:00	2021-06-30 22:20:00	t	0
3766	31	11	9	43	2	2021-06-30 22:10:00	2021-06-30 22:20:00	t	0
3770	34	13	7	36	7	2021-06-30 22:10:00	2021-06-30 22:20:00	t	0
3771	34	13	7	35	6	2021-06-30 22:10:00	2021-06-30 22:20:00	t	0
3772	30	10	8	41	7	2021-06-30 22:10:00	2021-06-30 22:20:00	t	0
3773	30	10	8	40	4	2021-06-30 22:10:00	2021-06-30 22:20:00	t	0
3759	35	11	9	42	1	2021-06-30 22:20:00	2021-06-30 22:30:00	t	0
3764	33	12	9	42	1	2021-06-30 22:20:00	2021-06-30 22:30:00	t	0
3767	31	11	9	42	1	2021-06-30 22:20:00	2021-06-30 22:30:00	t	0
3774	34	13	7	36	7	2021-06-30 22:20:00	2021-06-30 22:30:00	t	0
3775	34	13	7	35	6	2021-06-30 22:20:00	2021-06-30 22:30:00	t	0
3776	30	10	8	41	7	2021-06-30 22:20:00	2021-06-30 22:30:00	t	0
3777	30	10	8	40	4	2021-06-30 22:20:00	2021-06-30 22:30:00	t	0
3778	35	11	9	44	3	2021-06-30 22:30:00	2021-06-30 22:40:00	t	0
3781	34	13	7	36	7	2021-06-30 22:30:00	2021-06-30 22:40:00	t	0
3782	34	13	7	35	6	2021-06-30 22:30:00	2021-06-30 22:40:00	t	0
3783	33	12	9	44	3	2021-06-30 22:30:00	2021-06-30 22:40:00	t	0
3786	31	11	9	44	3	2021-06-30 22:30:00	2021-06-30 22:40:00	t	0
3789	30	10	8	41	7	2021-06-30 22:30:00	2021-06-30 22:40:00	t	0
3790	30	10	8	40	4	2021-06-30 22:30:00	2021-06-30 22:40:00	t	0
3791	29	9	5	29	2	2021-06-30 22:30:00	2021-06-30 22:40:00	t	0
3779	35	11	9	43	2	2021-06-30 22:40:00	2021-06-30 22:50:00	t	0
3784	33	12	9	43	2	2021-06-30 22:40:00	2021-06-30 22:50:00	t	0
3787	31	11	9	43	2	2021-06-30 22:40:00	2021-06-30 22:50:00	t	0
3792	29	9	5	28	1	2021-06-30 22:40:00	2021-06-30 22:50:00	t	0
3795	34	13	7	36	7	2021-06-30 22:40:00	2021-06-30 22:50:00	t	0
3796	34	13	7	35	6	2021-06-30 22:40:00	2021-06-30 22:50:00	t	0
3780	35	11	9	42	1	2021-06-30 22:50:00	2021-06-30 23:00:00	t	0
3785	33	12	9	42	1	2021-06-30 22:50:00	2021-06-30 23:00:00	t	0
3788	31	11	9	42	1	2021-06-30 22:50:00	2021-06-30 23:00:00	t	0
3793	29	9	6	32	2	2021-06-30 22:50:00	2021-06-30 23:00:00	t	0
3794	29	9	6	30	3	2021-06-30 23:00:00	2021-06-30 23:10:00	t	0
3363	30	10	8	41	7	2021-06-30 13:40:00	2021-06-30 13:50:00	t	0
3823	29	9	6	30	3	2021-06-30 23:40:00	2021-06-30 23:50:00	f	0
3382	31	11	9	43	2	2021-06-30 14:10:00	2021-06-30 14:20:00	t	0
3829	35	11	9	43	2	2021-06-30 23:40:00	2021-06-30 23:50:00	f	0
3830	35	11	9	42	1	2021-06-30 23:50:00	2021-07-01 00:00:00	f	0
3834	33	12	9	43	2	2021-06-30 23:40:00	2021-06-30 23:50:00	f	0
3835	33	12	9	42	1	2021-06-30 23:50:00	2021-07-01 00:00:00	f	0
3837	31	11	9	43	2	2021-06-30 23:40:00	2021-06-30 23:50:00	f	0
3838	31	11	9	42	1	2021-06-30 23:50:00	2021-07-01 00:00:00	f	0
3841	34	13	7	36	7	2021-06-30 23:40:00	2021-06-30 23:50:00	f	0
3842	34	13	7	35	6	2021-06-30 23:40:00	2021-06-30 23:50:00	f	0
3843	30	10	8	41	7	2021-06-30 23:40:00	2021-06-30 23:50:00	f	0
3844	30	10	8	40	4	2021-06-30 23:40:00	2021-06-30 23:50:00	f	0
3845	34	13	7	36	7	2021-06-30 23:50:00	2021-07-01 00:00:00	f	0
3846	34	13	7	35	6	2021-06-30 23:50:00	2021-07-01 00:00:00	f	0
3847	30	10	8	41	7	2021-06-30 23:50:00	2021-07-01 00:00:00	f	0
3848	30	10	8	40	4	2021-06-30 23:50:00	2021-07-01 00:00:00	f	0
3849	29	9	5	29	2	2021-06-30 23:50:00	2021-07-01 00:00:00	f	0
3850	29	9	5	28	1	2021-07-01 00:00:00	2021-07-01 00:10:00	f	0
3851	29	9	6	32	2	2021-07-01 00:10:00	2021-07-01 00:20:00	f	0
3852	29	9	6	30	3	2021-07-01 00:20:00	2021-07-01 00:30:00	f	0
3413	30	10	8	41	7	2021-06-30 14:40:00	2021-06-30 14:50:00	t	0
3853	35	11	9	44	3	2021-07-01 00:00:00	2021-07-01 00:10:00	f	0
3854	35	11	9	43	2	2021-07-01 00:10:00	2021-07-01 00:20:00	f	0
3855	35	11	9	42	1	2021-07-01 00:20:00	2021-07-01 00:30:00	f	0
3856	34	13	7	36	7	2021-07-01 00:00:00	2021-07-01 00:10:00	f	0
3857	34	13	7	35	6	2021-07-01 00:00:00	2021-07-01 00:10:00	f	0
3858	33	12	9	44	3	2021-07-01 00:00:00	2021-07-01 00:10:00	f	0
3859	33	12	9	43	2	2021-07-01 00:10:00	2021-07-01 00:20:00	f	0
3860	33	12	9	42	1	2021-07-01 00:20:00	2021-07-01 00:30:00	f	0
3861	31	11	9	44	3	2021-07-01 00:00:00	2021-07-01 00:10:00	f	0
3862	31	11	9	43	2	2021-07-01 00:10:00	2021-07-01 00:20:00	f	0
3863	31	11	9	42	1	2021-07-01 00:20:00	2021-07-01 00:30:00	f	0
3864	30	10	8	41	7	2021-07-01 00:00:00	2021-07-01 00:10:00	f	0
3865	30	10	8	40	4	2021-07-01 00:00:00	2021-07-01 00:10:00	f	0
3866	34	13	7	36	7	2021-07-01 00:10:00	2021-07-01 00:20:00	f	0
3867	34	13	7	35	6	2021-07-01 00:10:00	2021-07-01 00:20:00	f	0
3868	30	10	8	41	7	2021-07-01 00:10:00	2021-07-01 00:20:00	f	0
3798	30	10	8	40	4	2021-06-30 22:40:00	2021-06-30 22:50:00	t	0
3799	34	13	7	36	7	2021-06-30 22:50:00	2021-06-30 23:00:00	t	0
3800	34	13	7	35	6	2021-06-30 22:50:00	2021-06-30 23:00:00	t	0
3801	30	10	8	41	7	2021-06-30 22:50:00	2021-06-30 23:00:00	t	0
3802	30	10	8	40	4	2021-06-30 22:50:00	2021-06-30 23:00:00	t	0
3803	35	11	9	44	3	2021-06-30 23:00:00	2021-06-30 23:10:00	t	0
3806	34	13	7	36	7	2021-06-30 23:00:00	2021-06-30 23:10:00	t	0
3807	34	13	7	35	6	2021-06-30 23:00:00	2021-06-30 23:10:00	t	0
3808	33	12	9	44	3	2021-06-30 23:00:00	2021-06-30 23:10:00	t	0
3811	31	11	9	44	3	2021-06-30 23:00:00	2021-06-30 23:10:00	t	0
3814	30	10	8	41	7	2021-06-30 23:00:00	2021-06-30 23:10:00	t	0
3815	30	10	8	40	4	2021-06-30 23:00:00	2021-06-30 23:10:00	t	0
3804	35	11	9	43	2	2021-06-30 23:10:00	2021-06-30 23:20:00	t	0
3809	33	12	9	43	2	2021-06-30 23:10:00	2021-06-30 23:20:00	t	0
3812	31	11	9	43	2	2021-06-30 23:10:00	2021-06-30 23:20:00	t	0
3816	34	13	7	36	7	2021-06-30 23:10:00	2021-06-30 23:20:00	t	0
3817	34	13	7	35	6	2021-06-30 23:10:00	2021-06-30 23:20:00	t	0
3819	30	10	8	40	4	2021-06-30 23:10:00	2021-06-30 23:20:00	t	0
3820	29	9	5	29	2	2021-06-30 23:10:00	2021-06-30 23:20:00	t	0
3805	35	11	9	42	1	2021-06-30 23:20:00	2021-06-30 23:30:00	t	0
3810	33	12	9	42	1	2021-06-30 23:20:00	2021-06-30 23:30:00	t	0
3813	31	11	9	42	1	2021-06-30 23:20:00	2021-06-30 23:30:00	t	0
3821	29	9	5	28	1	2021-06-30 23:20:00	2021-06-30 23:30:00	t	0
3824	34	13	7	36	7	2021-06-30 23:20:00	2021-06-30 23:30:00	t	0
3825	34	13	7	35	6	2021-06-30 23:20:00	2021-06-30 23:30:00	t	0
3826	30	10	8	41	7	2021-06-30 23:20:00	2021-06-30 23:30:00	t	0
3827	30	10	8	40	4	2021-06-30 23:20:00	2021-06-30 23:30:00	t	0
3822	29	9	6	32	2	2021-06-30 23:30:00	2021-06-30 23:40:00	t	0
3828	35	11	9	44	3	2021-06-30 23:30:00	2021-06-30 23:40:00	t	0
3831	34	13	7	36	7	2021-06-30 23:30:00	2021-06-30 23:40:00	t	0
3832	34	13	7	35	6	2021-06-30 23:30:00	2021-06-30 23:40:00	t	0
3833	33	12	9	44	3	2021-06-30 23:30:00	2021-06-30 23:40:00	t	0
3836	31	11	9	44	3	2021-06-30 23:30:00	2021-06-30 23:40:00	t	0
3839	30	10	8	41	7	2021-06-30 23:30:00	2021-06-30 23:40:00	t	0
3840	30	10	8	40	4	2021-06-30 23:30:00	2021-06-30 23:40:00	t	0
3869	30	10	8	40	4	2021-07-01 00:10:00	2021-07-01 00:20:00	f	0
3870	34	13	7	36	7	2021-07-01 00:20:00	2021-07-01 00:30:00	f	0
3871	34	13	7	35	6	2021-07-01 00:20:00	2021-07-01 00:30:00	f	0
3872	30	10	8	41	7	2021-07-01 00:20:00	2021-07-01 00:30:00	f	0
3873	30	10	8	40	4	2021-07-01 00:20:00	2021-07-01 00:30:00	f	0
3874	35	11	9	44	3	2021-07-01 00:30:00	2021-07-01 00:40:00	f	0
3875	35	11	9	43	2	2021-07-01 00:40:00	2021-07-01 00:50:00	f	0
3876	35	11	9	42	1	2021-07-01 00:50:00	2021-07-01 01:00:00	f	0
3877	34	13	7	36	7	2021-07-01 00:30:00	2021-07-01 00:40:00	f	0
3878	34	13	7	35	6	2021-07-01 00:30:00	2021-07-01 00:40:00	f	0
3879	33	12	9	44	3	2021-07-01 00:30:00	2021-07-01 00:40:00	f	0
3880	33	12	9	43	2	2021-07-01 00:40:00	2021-07-01 00:50:00	f	0
3881	33	12	9	42	1	2021-07-01 00:50:00	2021-07-01 01:00:00	f	0
3882	31	11	9	44	3	2021-07-01 00:30:00	2021-07-01 00:40:00	f	0
3883	31	11	9	43	2	2021-07-01 00:40:00	2021-07-01 00:50:00	f	0
3884	31	11	9	42	1	2021-07-01 00:50:00	2021-07-01 01:00:00	f	0
3885	30	10	8	41	7	2021-07-01 00:30:00	2021-07-01 00:40:00	f	0
3886	30	10	8	40	4	2021-07-01 00:30:00	2021-07-01 00:40:00	f	0
3887	29	9	5	29	2	2021-07-01 00:30:00	2021-07-01 00:40:00	f	0
3888	29	9	5	28	1	2021-07-01 00:40:00	2021-07-01 00:50:00	f	0
3889	29	9	6	32	2	2021-07-01 00:50:00	2021-07-01 01:00:00	f	0
3890	29	9	6	30	3	2021-07-01 01:00:00	2021-07-01 01:10:00	f	0
3891	34	13	7	36	7	2021-07-01 00:40:00	2021-07-01 00:50:00	f	0
3892	34	13	7	35	6	2021-07-01 00:40:00	2021-07-01 00:50:00	f	0
3893	30	10	8	41	7	2021-07-01 00:40:00	2021-07-01 00:50:00	f	0
3894	30	10	8	40	4	2021-07-01 00:40:00	2021-07-01 00:50:00	f	0
3434	30	10	8	41	7	2021-06-30 15:10:00	2021-06-30 15:20:00	t	0
3450	33	12	9	43	2	2021-06-30 15:40:00	2021-06-30 15:50:00	t	0
3895	34	13	7	36	7	2021-07-01 00:50:00	2021-07-01 01:00:00	f	0
3896	34	13	7	35	6	2021-07-01 00:50:00	2021-07-01 01:00:00	f	0
3897	30	10	8	41	7	2021-07-01 00:50:00	2021-07-01 01:00:00	f	0
3898	30	10	8	40	4	2021-07-01 00:50:00	2021-07-01 01:00:00	f	0
3899	35	11	9	44	3	2021-07-01 01:00:00	2021-07-01 01:10:00	f	0
3900	35	11	9	43	2	2021-07-01 01:10:00	2021-07-01 01:20:00	f	0
3901	35	11	9	42	1	2021-07-01 01:20:00	2021-07-01 01:30:00	f	0
3902	34	13	7	36	7	2021-07-01 01:00:00	2021-07-01 01:10:00	f	0
3903	34	13	7	35	6	2021-07-01 01:00:00	2021-07-01 01:10:00	f	0
3904	33	12	9	44	3	2021-07-01 01:00:00	2021-07-01 01:10:00	f	0
3905	33	12	9	43	2	2021-07-01 01:10:00	2021-07-01 01:20:00	f	0
3906	33	12	9	42	1	2021-07-01 01:20:00	2021-07-01 01:30:00	f	0
3907	31	11	9	44	3	2021-07-01 01:00:00	2021-07-01 01:10:00	f	0
3908	31	11	9	43	2	2021-07-01 01:10:00	2021-07-01 01:20:00	f	0
3909	31	11	9	42	1	2021-07-01 01:20:00	2021-07-01 01:30:00	f	0
3910	30	10	8	41	7	2021-07-01 01:00:00	2021-07-01 01:10:00	f	0
3911	30	10	8	40	4	2021-07-01 01:00:00	2021-07-01 01:10:00	f	0
3912	34	13	7	36	7	2021-07-01 01:10:00	2021-07-01 01:20:00	f	0
3913	34	13	7	35	6	2021-07-01 01:10:00	2021-07-01 01:20:00	f	0
3914	30	10	8	41	7	2021-07-01 01:10:00	2021-07-01 01:20:00	f	0
3915	30	10	8	40	4	2021-07-01 01:10:00	2021-07-01 01:20:00	f	0
3916	29	9	5	29	2	2021-07-01 01:10:00	2021-07-01 01:20:00	f	0
3917	29	9	5	28	1	2021-07-01 01:20:00	2021-07-01 01:30:00	f	0
3918	29	9	6	32	2	2021-07-01 01:30:00	2021-07-01 01:40:00	f	0
3919	29	9	6	30	3	2021-07-01 01:40:00	2021-07-01 01:50:00	f	0
3920	34	13	7	36	7	2021-07-01 01:20:00	2021-07-01 01:30:00	f	0
3921	34	13	7	35	6	2021-07-01 01:20:00	2021-07-01 01:30:00	f	0
3922	30	10	8	41	7	2021-07-01 01:20:00	2021-07-01 01:30:00	f	0
3923	30	10	8	40	4	2021-07-01 01:20:00	2021-07-01 01:30:00	f	0
3483	34	13	7	35	6	2021-06-30 16:10:00	2021-06-30 16:20:00	t	0
3924	35	11	9	44	3	2021-07-01 01:30:00	2021-07-01 01:40:00	f	0
3925	35	11	9	43	2	2021-07-01 01:40:00	2021-07-01 01:50:00	f	0
3926	35	11	9	42	1	2021-07-01 01:50:00	2021-07-01 02:00:00	f	0
3927	34	13	7	36	7	2021-07-01 01:30:00	2021-07-01 01:40:00	f	0
3928	34	13	7	35	6	2021-07-01 01:30:00	2021-07-01 01:40:00	f	0
3929	33	12	9	44	3	2021-07-01 01:30:00	2021-07-01 01:40:00	f	0
3930	33	12	9	43	2	2021-07-01 01:40:00	2021-07-01 01:50:00	f	0
3931	33	12	9	42	1	2021-07-01 01:50:00	2021-07-01 02:00:00	f	0
3932	31	11	9	44	3	2021-07-01 01:30:00	2021-07-01 01:40:00	f	0
3933	31	11	9	43	2	2021-07-01 01:40:00	2021-07-01 01:50:00	f	0
3934	31	11	9	42	1	2021-07-01 01:50:00	2021-07-01 02:00:00	f	0
3935	30	10	8	41	7	2021-07-01 01:30:00	2021-07-01 01:40:00	f	0
3936	30	10	8	40	4	2021-07-01 01:30:00	2021-07-01 01:40:00	f	0
3937	34	13	7	36	7	2021-07-01 01:40:00	2021-07-01 01:50:00	f	0
3938	34	13	7	35	6	2021-07-01 01:40:00	2021-07-01 01:50:00	f	0
3939	30	10	8	41	7	2021-07-01 01:40:00	2021-07-01 01:50:00	f	0
3940	30	10	8	40	4	2021-07-01 01:40:00	2021-07-01 01:50:00	f	0
3507	34	13	7	36	7	2021-06-30 16:40:00	2021-06-30 16:50:00	t	0
3941	34	13	7	36	7	2021-07-01 01:50:00	2021-07-01 02:00:00	f	0
3942	34	13	7	35	6	2021-07-01 01:50:00	2021-07-01 02:00:00	f	0
3943	30	10	8	41	7	2021-07-01 01:50:00	2021-07-01 02:00:00	f	0
3944	30	10	8	40	4	2021-07-01 01:50:00	2021-07-01 02:00:00	f	0
3945	29	9	5	29	2	2021-07-01 01:50:00	2021-07-01 02:00:00	f	0
3946	29	9	5	28	1	2021-07-01 02:00:00	2021-07-01 02:10:00	f	0
3947	29	9	6	32	2	2021-07-01 02:10:00	2021-07-01 02:20:00	f	0
3948	29	9	6	30	3	2021-07-01 02:20:00	2021-07-01 02:30:00	f	0
3949	35	11	9	44	3	2021-07-01 02:00:00	2021-07-01 02:10:00	f	0
3950	35	11	9	43	2	2021-07-01 02:10:00	2021-07-01 02:20:00	f	0
3951	35	11	9	42	1	2021-07-01 02:20:00	2021-07-01 02:30:00	f	0
3952	34	13	7	36	7	2021-07-01 02:00:00	2021-07-01 02:10:00	f	0
3953	34	13	7	35	6	2021-07-01 02:00:00	2021-07-01 02:10:00	f	0
3954	33	12	9	44	3	2021-07-01 02:00:00	2021-07-01 02:10:00	f	0
3955	33	12	9	43	2	2021-07-01 02:10:00	2021-07-01 02:20:00	f	0
3956	33	12	9	42	1	2021-07-01 02:20:00	2021-07-01 02:30:00	f	0
3957	31	11	9	44	3	2021-07-01 02:00:00	2021-07-01 02:10:00	f	0
3958	31	11	9	43	2	2021-07-01 02:10:00	2021-07-01 02:20:00	f	0
3959	31	11	9	42	1	2021-07-01 02:20:00	2021-07-01 02:30:00	f	0
3960	30	10	8	41	7	2021-07-01 02:00:00	2021-07-01 02:10:00	f	0
3961	30	10	8	40	4	2021-07-01 02:00:00	2021-07-01 02:10:00	f	0
3962	34	13	7	36	7	2021-07-01 02:10:00	2021-07-01 02:20:00	f	0
3963	34	13	7	35	6	2021-07-01 02:10:00	2021-07-01 02:20:00	f	0
3964	30	10	8	41	7	2021-07-01 02:10:00	2021-07-01 02:20:00	f	0
3965	30	10	8	40	4	2021-07-01 02:10:00	2021-07-01 02:20:00	f	0
3526	35	11	9	43	2	2021-06-30 17:10:00	2021-06-30 17:20:00	t	0
3966	34	13	7	36	7	2021-07-01 02:20:00	2021-07-01 02:30:00	f	0
3967	34	13	7	35	6	2021-07-01 02:20:00	2021-07-01 02:30:00	f	0
3968	30	10	8	41	7	2021-07-01 02:20:00	2021-07-01 02:30:00	f	0
3969	30	10	8	40	4	2021-07-01 02:20:00	2021-07-01 02:30:00	f	0
3970	34	13	7	36	7	2021-07-01 02:30:00	2021-07-01 02:40:00	f	0
3971	34	13	7	35	6	2021-07-01 02:30:00	2021-07-01 02:40:00	f	0
3972	33	12	9	44	3	2021-07-01 02:30:00	2021-07-01 02:40:00	f	0
3973	33	12	9	43	2	2021-07-01 02:40:00	2021-07-01 02:50:00	f	0
3974	33	12	9	42	1	2021-07-01 02:50:00	2021-07-01 03:00:00	f	0
3975	31	11	9	44	3	2021-07-01 02:30:00	2021-07-01 02:40:00	f	0
3976	31	11	9	43	2	2021-07-01 02:40:00	2021-07-01 02:50:00	f	0
3977	31	11	9	42	1	2021-07-01 02:50:00	2021-07-01 03:00:00	f	0
3978	30	10	8	41	7	2021-07-01 02:30:00	2021-07-01 02:40:00	f	0
3979	30	10	8	40	4	2021-07-01 02:30:00	2021-07-01 02:40:00	f	0
3980	29	9	5	29	2	2021-07-01 02:30:00	2021-07-01 02:40:00	f	0
3981	29	9	5	28	1	2021-07-01 02:40:00	2021-07-01 02:50:00	f	0
3982	29	9	6	32	2	2021-07-01 02:50:00	2021-07-01 03:00:00	f	0
3983	29	9	6	30	3	2021-07-01 03:00:00	2021-07-01 03:10:00	f	0
3984	35	11	9	44	3	2021-07-01 02:30:00	2021-07-01 02:40:00	f	0
3985	35	11	9	43	2	2021-07-01 02:40:00	2021-07-01 02:50:00	f	0
3986	35	11	9	42	1	2021-07-01 02:50:00	2021-07-01 03:00:00	f	0
3987	34	13	7	36	7	2021-07-01 02:40:00	2021-07-01 02:50:00	f	0
3988	34	13	7	35	6	2021-07-01 02:40:00	2021-07-01 02:50:00	f	0
3989	30	10	8	41	7	2021-07-01 02:40:00	2021-07-01 02:50:00	f	0
3990	30	10	8	40	4	2021-07-01 02:40:00	2021-07-01 02:50:00	f	0
3991	34	13	7	36	7	2021-07-01 02:50:00	2021-07-01 03:00:00	f	0
3992	34	13	7	35	6	2021-07-01 02:50:00	2021-07-01 03:00:00	f	0
3993	30	10	8	41	7	2021-07-01 02:50:00	2021-07-01 03:00:00	f	0
3994	30	10	8	40	4	2021-07-01 02:50:00	2021-07-01 03:00:00	f	0
3554	34	13	7	35	6	2021-06-30 17:40:00	2021-06-30 17:50:00	t	0
3995	35	11	9	44	3	2021-07-01 03:00:00	2021-07-01 03:10:00	f	0
3996	35	11	9	43	2	2021-07-01 03:10:00	2021-07-01 03:20:00	f	0
3997	35	11	9	42	1	2021-07-01 03:20:00	2021-07-01 03:30:00	f	0
3998	34	13	7	36	7	2021-07-01 03:00:00	2021-07-01 03:10:00	f	0
3999	34	13	7	35	6	2021-07-01 03:00:00	2021-07-01 03:10:00	f	0
4000	33	12	9	44	3	2021-07-01 03:00:00	2021-07-01 03:10:00	f	0
4001	33	12	9	43	2	2021-07-01 03:10:00	2021-07-01 03:20:00	f	0
4002	33	12	9	42	1	2021-07-01 03:20:00	2021-07-01 03:30:00	f	0
4003	31	11	9	44	3	2021-07-01 03:00:00	2021-07-01 03:10:00	f	0
4004	31	11	9	43	2	2021-07-01 03:10:00	2021-07-01 03:20:00	f	0
4005	31	11	9	42	1	2021-07-01 03:20:00	2021-07-01 03:30:00	f	0
4006	30	10	8	41	7	2021-07-01 03:00:00	2021-07-01 03:10:00	f	0
4007	30	10	8	40	4	2021-07-01 03:00:00	2021-07-01 03:10:00	f	0
4008	34	13	7	36	7	2021-07-01 03:10:00	2021-07-01 03:20:00	f	0
4009	34	13	7	35	6	2021-07-01 03:10:00	2021-07-01 03:20:00	f	0
4010	30	10	8	41	7	2021-07-01 03:10:00	2021-07-01 03:20:00	f	0
4011	30	10	8	40	4	2021-07-01 03:10:00	2021-07-01 03:20:00	f	0
4012	29	9	5	29	2	2021-07-01 03:10:00	2021-07-01 03:20:00	f	0
4013	29	9	5	28	1	2021-07-01 03:20:00	2021-07-01 03:30:00	f	0
4014	29	9	6	32	2	2021-07-01 03:30:00	2021-07-01 03:40:00	f	0
4015	29	9	6	30	3	2021-07-01 03:40:00	2021-07-01 03:50:00	f	0
4016	34	13	7	36	7	2021-07-01 03:20:00	2021-07-01 03:30:00	f	0
4017	34	13	7	35	6	2021-07-01 03:20:00	2021-07-01 03:30:00	f	0
4018	30	10	8	41	7	2021-07-01 03:20:00	2021-07-01 03:30:00	f	0
4019	30	10	8	40	4	2021-07-01 03:20:00	2021-07-01 03:30:00	f	0
3579	34	13	7	35	6	2021-06-30 18:10:00	2021-06-30 18:20:00	t	0
4020	35	11	9	44	3	2021-07-01 03:30:00	2021-07-01 03:40:00	f	0
4021	35	11	9	43	2	2021-07-01 03:40:00	2021-07-01 03:50:00	f	0
4022	35	11	9	42	1	2021-07-01 03:50:00	2021-07-01 04:00:00	f	0
4023	34	13	7	36	7	2021-07-01 03:30:00	2021-07-01 03:40:00	f	0
4024	34	13	7	35	6	2021-07-01 03:30:00	2021-07-01 03:40:00	f	0
4025	33	12	9	44	3	2021-07-01 03:30:00	2021-07-01 03:40:00	f	0
4026	33	12	9	43	2	2021-07-01 03:40:00	2021-07-01 03:50:00	f	0
4027	33	12	9	42	1	2021-07-01 03:50:00	2021-07-01 04:00:00	f	0
4028	31	11	9	44	3	2021-07-01 03:30:00	2021-07-01 03:40:00	f	0
4029	31	11	9	43	2	2021-07-01 03:40:00	2021-07-01 03:50:00	f	0
4030	31	11	9	42	1	2021-07-01 03:50:00	2021-07-01 04:00:00	f	0
4031	30	10	8	41	7	2021-07-01 03:30:00	2021-07-01 03:40:00	f	0
4032	30	10	8	40	4	2021-07-01 03:30:00	2021-07-01 03:40:00	f	0
3575	31	11	9	42	1	2021-06-30 18:20:00	2021-06-30 18:30:00	t	0
4033	34	13	7	36	7	2021-07-01 03:40:00	2021-07-01 03:50:00	f	0
4034	34	13	7	35	6	2021-07-01 03:40:00	2021-07-01 03:50:00	f	0
4035	30	10	8	41	7	2021-07-01 03:40:00	2021-07-01 03:50:00	f	0
4036	30	10	8	40	4	2021-07-01 03:40:00	2021-07-01 03:50:00	f	0
4037	34	13	7	36	7	2021-07-01 03:50:00	2021-07-01 04:00:00	f	0
4038	34	13	7	35	6	2021-07-01 03:50:00	2021-07-01 04:00:00	f	0
4039	30	10	8	41	7	2021-07-01 03:50:00	2021-07-01 04:00:00	f	0
4040	30	10	8	40	4	2021-07-01 03:50:00	2021-07-01 04:00:00	f	0
4041	29	9	5	29	2	2021-07-01 03:50:00	2021-07-01 04:00:00	f	0
4042	29	9	5	28	1	2021-07-01 04:00:00	2021-07-01 04:10:00	f	0
4043	29	9	6	32	2	2021-07-01 04:10:00	2021-07-01 04:20:00	f	0
4044	29	9	6	30	3	2021-07-01 04:20:00	2021-07-01 04:30:00	f	0
4045	35	11	9	44	3	2021-07-01 04:00:00	2021-07-01 04:10:00	f	0
4046	35	11	9	43	2	2021-07-01 04:10:00	2021-07-01 04:20:00	f	0
4047	35	11	9	42	1	2021-07-01 04:20:00	2021-07-01 04:30:00	f	0
4048	34	13	7	36	7	2021-07-01 04:00:00	2021-07-01 04:10:00	f	0
4049	34	13	7	35	6	2021-07-01 04:00:00	2021-07-01 04:10:00	f	0
4050	33	12	9	44	3	2021-07-01 04:00:00	2021-07-01 04:10:00	f	0
4051	33	12	9	43	2	2021-07-01 04:10:00	2021-07-01 04:20:00	f	0
4052	33	12	9	42	1	2021-07-01 04:20:00	2021-07-01 04:30:00	f	0
4053	31	11	9	44	3	2021-07-01 04:00:00	2021-07-01 04:10:00	f	0
4054	31	11	9	43	2	2021-07-01 04:10:00	2021-07-01 04:20:00	f	0
4055	31	11	9	42	1	2021-07-01 04:20:00	2021-07-01 04:30:00	f	0
4056	30	10	8	41	7	2021-07-01 04:00:00	2021-07-01 04:10:00	f	0
4057	30	10	8	40	4	2021-07-01 04:00:00	2021-07-01 04:10:00	f	0
4058	34	13	7	36	7	2021-07-01 04:10:00	2021-07-01 04:20:00	f	0
4059	34	13	7	35	6	2021-07-01 04:10:00	2021-07-01 04:20:00	f	0
4060	30	10	8	41	7	2021-07-01 04:10:00	2021-07-01 04:20:00	f	0
4061	30	10	8	40	4	2021-07-01 04:10:00	2021-07-01 04:20:00	f	0
3600	29	9	5	28	1	2021-06-30 18:40:00	2021-06-30 18:50:00	t	0
4062	34	13	7	36	7	2021-07-01 04:20:00	2021-07-01 04:30:00	f	0
4063	34	13	7	35	6	2021-07-01 04:20:00	2021-07-01 04:30:00	f	0
4064	30	10	8	41	7	2021-07-01 04:20:00	2021-07-01 04:30:00	f	0
4065	30	10	8	40	4	2021-07-01 04:20:00	2021-07-01 04:30:00	f	0
3627	30	10	8	40	4	2021-06-30 19:10:00	2021-06-30 19:20:00	t	0
4066	35	11	9	44	3	2021-07-01 04:30:00	2021-07-01 04:40:00	f	0
4067	35	11	9	43	2	2021-07-01 04:40:00	2021-07-01 04:50:00	f	0
4068	35	11	9	42	1	2021-07-01 04:50:00	2021-07-01 05:00:00	f	0
4069	34	13	7	36	7	2021-07-01 04:30:00	2021-07-01 04:40:00	f	0
4070	34	13	7	35	6	2021-07-01 04:30:00	2021-07-01 04:40:00	f	0
4071	33	12	9	44	3	2021-07-01 04:30:00	2021-07-01 04:40:00	f	0
4072	33	12	9	43	2	2021-07-01 04:40:00	2021-07-01 04:50:00	f	0
4073	33	12	9	42	1	2021-07-01 04:50:00	2021-07-01 05:00:00	f	0
4074	31	11	9	44	3	2021-07-01 04:30:00	2021-07-01 04:40:00	f	0
4075	31	11	9	43	2	2021-07-01 04:40:00	2021-07-01 04:50:00	f	0
4076	31	11	9	42	1	2021-07-01 04:50:00	2021-07-01 05:00:00	f	0
4077	30	10	8	41	7	2021-07-01 04:30:00	2021-07-01 04:40:00	f	0
4078	30	10	8	40	4	2021-07-01 04:30:00	2021-07-01 04:40:00	f	0
4079	29	9	5	29	2	2021-07-01 04:30:00	2021-07-01 04:40:00	f	0
4080	29	9	5	28	1	2021-07-01 04:40:00	2021-07-01 04:50:00	f	0
4081	29	9	6	32	2	2021-07-01 04:50:00	2021-07-01 05:00:00	f	0
4082	29	9	6	30	3	2021-07-01 05:00:00	2021-07-01 05:10:00	f	0
4083	34	13	7	36	7	2021-07-01 04:40:00	2021-07-01 04:50:00	f	0
4084	34	13	7	35	6	2021-07-01 04:40:00	2021-07-01 04:50:00	f	0
4085	30	10	8	41	7	2021-07-01 04:40:00	2021-07-01 04:50:00	f	0
4086	30	10	8	40	4	2021-07-01 04:40:00	2021-07-01 04:50:00	f	0
4087	34	13	7	36	7	2021-07-01 04:50:00	2021-07-01 05:00:00	f	0
4088	34	13	7	35	6	2021-07-01 04:50:00	2021-07-01 05:00:00	f	0
4089	30	10	8	41	7	2021-07-01 04:50:00	2021-07-01 05:00:00	f	0
4090	30	10	8	40	4	2021-07-01 04:50:00	2021-07-01 05:00:00	f	0
4091	35	11	9	44	3	2021-07-01 05:00:00	2021-07-01 05:10:00	f	0
4092	35	11	9	43	2	2021-07-01 05:10:00	2021-07-01 05:20:00	f	0
4093	35	11	9	42	1	2021-07-01 05:20:00	2021-07-01 05:30:00	f	0
4094	34	13	7	36	7	2021-07-01 05:00:00	2021-07-01 05:10:00	f	0
4095	34	13	7	35	6	2021-07-01 05:00:00	2021-07-01 05:10:00	f	0
4096	33	12	9	44	3	2021-07-01 05:00:00	2021-07-01 05:10:00	f	0
4097	33	12	9	43	2	2021-07-01 05:10:00	2021-07-01 05:20:00	f	0
4098	33	12	9	42	1	2021-07-01 05:20:00	2021-07-01 05:30:00	f	0
4099	31	11	9	44	3	2021-07-01 05:00:00	2021-07-01 05:10:00	f	0
4100	31	11	9	43	2	2021-07-01 05:10:00	2021-07-01 05:20:00	f	0
4101	31	11	9	42	1	2021-07-01 05:20:00	2021-07-01 05:30:00	f	0
4102	30	10	8	41	7	2021-07-01 05:00:00	2021-07-01 05:10:00	f	0
4103	30	10	8	40	4	2021-07-01 05:00:00	2021-07-01 05:10:00	f	0
3643	33	12	9	42	1	2021-06-30 19:50:00	2021-06-30 20:00:00	t	0
3653	34	13	7	36	7	2021-06-30 19:50:00	2021-06-30 20:00:00	t	0
4104	34	13	7	36	7	2021-07-01 05:10:00	2021-07-01 05:20:00	f	0
4105	34	13	7	35	6	2021-07-01 05:10:00	2021-07-01 05:20:00	f	0
4106	30	10	8	41	7	2021-07-01 05:10:00	2021-07-01 05:20:00	f	0
4107	30	10	8	40	4	2021-07-01 05:10:00	2021-07-01 05:20:00	f	0
4108	29	9	5	29	2	2021-07-01 05:10:00	2021-07-01 05:20:00	f	0
4109	29	9	5	28	1	2021-07-01 05:20:00	2021-07-01 05:30:00	f	0
4110	29	9	6	32	2	2021-07-01 05:30:00	2021-07-01 05:40:00	f	0
4111	29	9	6	30	3	2021-07-01 05:40:00	2021-07-01 05:50:00	f	0
4112	34	13	7	36	7	2021-07-01 05:20:00	2021-07-01 05:30:00	f	0
4113	34	13	7	35	6	2021-07-01 05:20:00	2021-07-01 05:30:00	f	0
4114	30	10	8	41	7	2021-07-01 05:20:00	2021-07-01 05:30:00	f	0
4115	30	10	8	40	4	2021-07-01 05:20:00	2021-07-01 05:30:00	f	0
3675	34	13	7	35	6	2021-06-30 20:10:00	2021-06-30 20:20:00	t	0
4116	35	11	9	44	3	2021-07-01 05:30:00	2021-07-01 05:40:00	f	0
4117	35	11	9	43	2	2021-07-01 05:40:00	2021-07-01 05:50:00	f	0
4118	35	11	9	42	1	2021-07-01 05:50:00	2021-07-01 06:00:00	f	0
4119	34	13	7	36	7	2021-07-01 05:30:00	2021-07-01 05:40:00	f	0
4120	34	13	7	35	6	2021-07-01 05:30:00	2021-07-01 05:40:00	f	0
4121	33	12	9	44	3	2021-07-01 05:30:00	2021-07-01 05:40:00	f	0
4122	33	12	9	43	2	2021-07-01 05:40:00	2021-07-01 05:50:00	f	0
4123	33	12	9	42	1	2021-07-01 05:50:00	2021-07-01 06:00:00	f	0
4124	31	11	9	44	3	2021-07-01 05:30:00	2021-07-01 05:40:00	f	0
4125	31	11	9	43	2	2021-07-01 05:40:00	2021-07-01 05:50:00	f	0
4126	31	11	9	42	1	2021-07-01 05:50:00	2021-07-01 06:00:00	f	0
4127	30	10	8	41	7	2021-07-01 05:30:00	2021-07-01 05:40:00	f	0
4128	30	10	8	40	4	2021-07-01 05:30:00	2021-07-01 05:40:00	f	0
4129	34	13	7	36	7	2021-07-01 05:40:00	2021-07-01 05:50:00	f	0
4130	34	13	7	35	6	2021-07-01 05:40:00	2021-07-01 05:50:00	f	0
4131	30	10	8	41	7	2021-07-01 05:40:00	2021-07-01 05:50:00	f	0
4132	30	10	8	40	4	2021-07-01 05:40:00	2021-07-01 05:50:00	f	0
4133	34	13	7	36	7	2021-07-01 05:50:00	2021-07-01 06:00:00	f	0
4134	34	13	7	35	6	2021-07-01 05:50:00	2021-07-01 06:00:00	f	0
4135	30	10	8	41	7	2021-07-01 05:50:00	2021-07-01 06:00:00	f	0
4136	30	10	8	40	4	2021-07-01 05:50:00	2021-07-01 06:00:00	f	0
4137	29	9	5	29	2	2021-07-01 05:50:00	2021-07-01 06:00:00	f	0
4138	29	9	5	28	1	2021-07-01 06:00:00	2021-07-01 06:10:00	f	0
4139	29	9	6	32	2	2021-07-01 06:10:00	2021-07-01 06:20:00	f	0
4140	29	9	6	30	3	2021-07-01 06:20:00	2021-07-01 06:30:00	f	0
4141	35	11	9	44	3	2021-07-01 06:00:00	2021-07-01 06:10:00	f	0
4142	35	11	9	43	2	2021-07-01 06:10:00	2021-07-01 06:20:00	f	0
4143	35	11	9	42	1	2021-07-01 06:20:00	2021-07-01 06:30:00	f	0
4144	34	13	7	36	7	2021-07-01 06:00:00	2021-07-01 06:10:00	f	0
4145	34	13	7	35	6	2021-07-01 06:00:00	2021-07-01 06:10:00	f	0
4146	33	12	9	44	3	2021-07-01 06:00:00	2021-07-01 06:10:00	f	0
4147	33	12	9	43	2	2021-07-01 06:10:00	2021-07-01 06:20:00	f	0
4148	33	12	9	42	1	2021-07-01 06:20:00	2021-07-01 06:30:00	f	0
4149	31	11	9	44	3	2021-07-01 06:00:00	2021-07-01 06:10:00	f	0
4150	31	11	9	43	2	2021-07-01 06:10:00	2021-07-01 06:20:00	f	0
4151	31	11	9	42	1	2021-07-01 06:20:00	2021-07-01 06:30:00	f	0
4152	30	10	8	41	7	2021-07-01 06:00:00	2021-07-01 06:10:00	f	0
4153	30	10	8	40	4	2021-07-01 06:00:00	2021-07-01 06:10:00	f	0
3684	35	11	9	42	1	2021-06-30 20:50:00	2021-06-30 21:00:00	t	0
4154	34	13	7	36	7	2021-07-01 06:10:00	2021-07-01 06:20:00	f	0
4155	34	13	7	35	6	2021-07-01 06:10:00	2021-07-01 06:20:00	f	0
4156	30	10	8	41	7	2021-07-01 06:10:00	2021-07-01 06:20:00	f	0
4157	30	10	8	40	4	2021-07-01 06:10:00	2021-07-01 06:20:00	f	0
4158	34	13	7	36	7	2021-07-01 06:20:00	2021-07-01 06:30:00	f	0
4159	34	13	7	35	6	2021-07-01 06:20:00	2021-07-01 06:30:00	f	0
4160	30	10	8	41	7	2021-07-01 06:20:00	2021-07-01 06:30:00	f	0
4161	30	10	8	40	4	2021-07-01 06:20:00	2021-07-01 06:30:00	f	0
3725	29	9	5	28	1	2021-06-30 21:20:00	2021-06-30 21:30:00	t	0
4162	35	11	9	44	3	2021-07-01 06:30:00	2021-07-01 06:40:00	f	0
4163	35	11	9	43	2	2021-07-01 06:40:00	2021-07-01 06:50:00	f	0
4164	35	11	9	42	1	2021-07-01 06:50:00	2021-07-01 07:00:00	f	0
4165	34	13	7	36	7	2021-07-01 06:30:00	2021-07-01 06:40:00	f	0
4166	34	13	7	35	6	2021-07-01 06:30:00	2021-07-01 06:40:00	f	0
4167	33	12	9	44	3	2021-07-01 06:30:00	2021-07-01 06:40:00	f	0
4168	33	12	9	43	2	2021-07-01 06:40:00	2021-07-01 06:50:00	f	0
4169	33	12	9	42	1	2021-07-01 06:50:00	2021-07-01 07:00:00	f	0
4170	31	11	9	44	3	2021-07-01 06:30:00	2021-07-01 06:40:00	f	0
4171	31	11	9	43	2	2021-07-01 06:40:00	2021-07-01 06:50:00	f	0
4172	31	11	9	42	1	2021-07-01 06:50:00	2021-07-01 07:00:00	f	0
4173	30	10	8	41	7	2021-07-01 06:30:00	2021-07-01 06:40:00	f	0
4174	30	10	8	40	4	2021-07-01 06:30:00	2021-07-01 06:40:00	f	0
4175	29	9	5	29	2	2021-07-01 06:30:00	2021-07-01 06:40:00	f	0
4176	29	9	5	28	1	2021-07-01 06:40:00	2021-07-01 06:50:00	f	0
4177	29	9	6	32	2	2021-07-01 06:50:00	2021-07-01 07:00:00	f	0
4178	29	9	6	30	3	2021-07-01 07:00:00	2021-07-01 07:10:00	f	0
4179	34	13	7	36	7	2021-07-01 06:40:00	2021-07-01 06:50:00	f	0
4180	34	13	7	35	6	2021-07-01 06:40:00	2021-07-01 06:50:00	f	0
4181	30	10	8	41	7	2021-07-01 06:40:00	2021-07-01 06:50:00	f	0
4182	30	10	8	40	4	2021-07-01 06:40:00	2021-07-01 06:50:00	f	0
4183	34	13	7	36	7	2021-07-01 06:50:00	2021-07-01 07:00:00	f	0
4184	34	13	7	35	6	2021-07-01 06:50:00	2021-07-01 07:00:00	f	0
4185	30	10	8	41	7	2021-07-01 06:50:00	2021-07-01 07:00:00	f	0
4186	30	10	8	40	4	2021-07-01 06:50:00	2021-07-01 07:00:00	f	0
3746	34	13	7	35	6	2021-06-30 21:40:00	2021-06-30 21:50:00	t	0
4187	35	11	9	44	3	2021-07-01 07:00:00	2021-07-01 07:10:00	f	0
4188	35	11	9	43	2	2021-07-01 07:10:00	2021-07-01 07:20:00	f	0
4189	35	11	9	42	1	2021-07-01 07:20:00	2021-07-01 07:30:00	f	0
4190	34	13	7	36	7	2021-07-01 07:00:00	2021-07-01 07:10:00	f	0
4191	34	13	7	35	6	2021-07-01 07:00:00	2021-07-01 07:10:00	f	0
4192	33	12	9	44	3	2021-07-01 07:00:00	2021-07-01 07:10:00	f	0
4193	33	12	9	43	2	2021-07-01 07:10:00	2021-07-01 07:20:00	f	0
4194	33	12	9	42	1	2021-07-01 07:20:00	2021-07-01 07:30:00	f	0
4195	31	11	9	44	3	2021-07-01 07:00:00	2021-07-01 07:10:00	f	0
4196	31	11	9	43	2	2021-07-01 07:10:00	2021-07-01 07:20:00	f	0
4197	31	11	9	42	1	2021-07-01 07:20:00	2021-07-01 07:30:00	f	0
4198	30	10	8	41	7	2021-07-01 07:00:00	2021-07-01 07:10:00	f	0
4199	30	10	8	40	4	2021-07-01 07:00:00	2021-07-01 07:10:00	f	0
4200	34	13	7	36	7	2021-07-01 07:10:00	2021-07-01 07:20:00	f	0
4201	34	13	7	35	6	2021-07-01 07:10:00	2021-07-01 07:20:00	f	0
4202	30	10	8	41	7	2021-07-01 07:10:00	2021-07-01 07:20:00	f	0
4203	30	10	8	40	4	2021-07-01 07:10:00	2021-07-01 07:20:00	f	0
4204	29	9	5	29	2	2021-07-01 07:10:00	2021-07-01 07:20:00	f	0
4205	29	9	5	28	1	2021-07-01 07:20:00	2021-07-01 07:30:00	f	0
4206	29	9	6	32	2	2021-07-01 07:30:00	2021-07-01 07:40:00	f	0
4207	29	9	6	30	3	2021-07-01 07:40:00	2021-07-01 07:50:00	f	0
4208	34	13	7	36	7	2021-07-01 07:20:00	2021-07-01 07:30:00	f	0
4209	34	13	7	35	6	2021-07-01 07:20:00	2021-07-01 07:30:00	f	0
4210	30	10	8	41	7	2021-07-01 07:20:00	2021-07-01 07:30:00	f	0
4211	30	10	8	40	4	2021-07-01 07:20:00	2021-07-01 07:30:00	f	0
4212	35	11	9	44	3	2021-07-01 07:30:00	2021-07-01 07:40:00	f	0
4213	35	11	9	43	2	2021-07-01 07:40:00	2021-07-01 07:50:00	f	0
4214	35	11	9	42	1	2021-07-01 07:50:00	2021-07-01 08:00:00	f	0
4215	34	13	7	36	7	2021-07-01 07:30:00	2021-07-01 07:40:00	f	0
4216	34	13	7	35	6	2021-07-01 07:30:00	2021-07-01 07:40:00	f	0
4217	33	12	9	44	3	2021-07-01 07:30:00	2021-07-01 07:40:00	f	0
4218	33	12	9	43	2	2021-07-01 07:40:00	2021-07-01 07:50:00	f	0
4219	33	12	9	42	1	2021-07-01 07:50:00	2021-07-01 08:00:00	f	0
4220	31	11	9	44	3	2021-07-01 07:30:00	2021-07-01 07:40:00	f	0
4221	31	11	9	43	2	2021-07-01 07:40:00	2021-07-01 07:50:00	f	0
4222	31	11	9	42	1	2021-07-01 07:50:00	2021-07-01 08:00:00	f	0
4223	30	10	8	41	7	2021-07-01 07:30:00	2021-07-01 07:40:00	f	0
4224	30	10	8	40	4	2021-07-01 07:30:00	2021-07-01 07:40:00	f	0
3756	29	9	6	30	3	2021-06-30 22:20:00	2021-06-30 22:30:00	t	0
4225	34	13	7	36	7	2021-07-01 07:40:00	2021-07-01 07:50:00	f	0
4226	34	13	7	35	6	2021-07-01 07:40:00	2021-07-01 07:50:00	f	0
4227	30	10	8	41	7	2021-07-01 07:40:00	2021-07-01 07:50:00	f	0
4228	30	10	8	40	4	2021-07-01 07:40:00	2021-07-01 07:50:00	f	0
3797	30	10	8	41	7	2021-06-30 22:40:00	2021-06-30 22:50:00	t	0
4229	34	13	7	36	7	2021-07-01 07:50:00	2021-07-01 08:00:00	f	0
4230	34	13	7	35	6	2021-07-01 07:50:00	2021-07-01 08:00:00	f	0
4231	30	10	8	41	7	2021-07-01 07:50:00	2021-07-01 08:00:00	f	0
4232	30	10	8	40	4	2021-07-01 07:50:00	2021-07-01 08:00:00	f	0
4233	29	9	5	29	2	2021-07-01 07:50:00	2021-07-01 08:00:00	f	0
4234	29	9	5	28	1	2021-07-01 08:00:00	2021-07-01 08:10:00	f	0
4235	29	9	6	32	2	2021-07-01 08:10:00	2021-07-01 08:20:00	f	0
4236	29	9	6	30	3	2021-07-01 08:20:00	2021-07-01 08:30:00	f	0
4237	35	11	9	44	3	2021-07-01 08:00:00	2021-07-01 08:10:00	f	0
4238	35	11	9	43	2	2021-07-01 08:10:00	2021-07-01 08:20:00	f	0
4239	35	11	9	42	1	2021-07-01 08:20:00	2021-07-01 08:30:00	f	0
4240	34	13	7	36	7	2021-07-01 08:00:00	2021-07-01 08:10:00	f	0
4241	34	13	7	35	6	2021-07-01 08:00:00	2021-07-01 08:10:00	f	0
4242	33	12	9	44	3	2021-07-01 08:00:00	2021-07-01 08:10:00	f	0
4243	33	12	9	43	2	2021-07-01 08:10:00	2021-07-01 08:20:00	f	0
4244	33	12	9	42	1	2021-07-01 08:20:00	2021-07-01 08:30:00	f	0
4245	31	11	9	44	3	2021-07-01 08:00:00	2021-07-01 08:10:00	f	0
4246	31	11	9	43	2	2021-07-01 08:10:00	2021-07-01 08:20:00	f	0
4247	31	11	9	42	1	2021-07-01 08:20:00	2021-07-01 08:30:00	f	0
4248	30	10	8	41	7	2021-07-01 08:00:00	2021-07-01 08:10:00	f	0
4249	30	10	8	40	4	2021-07-01 08:00:00	2021-07-01 08:10:00	f	0
4250	34	13	7	36	7	2021-07-01 08:10:00	2021-07-01 08:20:00	f	0
4251	34	13	7	35	6	2021-07-01 08:10:00	2021-07-01 08:20:00	f	0
4252	30	10	8	41	7	2021-07-01 08:10:00	2021-07-01 08:20:00	f	0
4253	30	10	8	40	4	2021-07-01 08:10:00	2021-07-01 08:20:00	f	0
3818	30	10	8	41	7	2021-06-30 23:10:00	2021-06-30 23:20:00	t	0
4254	34	13	7	36	7	2021-07-01 08:20:00	2021-07-01 08:30:00	f	0
4255	34	13	7	35	6	2021-07-01 08:20:00	2021-07-01 08:30:00	f	0
4256	30	10	8	41	7	2021-07-01 08:20:00	2021-07-01 08:30:00	f	0
4257	30	10	8	40	4	2021-07-01 08:20:00	2021-07-01 08:30:00	f	0
4258	35	11	9	44	3	2021-07-01 08:30:00	2021-07-01 08:40:00	f	0
4259	35	11	9	43	2	2021-07-01 08:40:00	2021-07-01 08:50:00	f	0
4260	35	11	9	42	1	2021-07-01 08:50:00	2021-07-01 09:00:00	f	0
4261	34	13	7	36	7	2021-07-01 08:30:00	2021-07-01 08:40:00	f	0
4262	34	13	7	35	6	2021-07-01 08:30:00	2021-07-01 08:40:00	f	0
4263	33	12	9	44	3	2021-07-01 08:30:00	2021-07-01 08:40:00	f	0
4264	33	12	9	43	2	2021-07-01 08:40:00	2021-07-01 08:50:00	f	0
4265	33	12	9	42	1	2021-07-01 08:50:00	2021-07-01 09:00:00	f	0
4266	31	11	9	44	3	2021-07-01 08:30:00	2021-07-01 08:40:00	f	0
4267	31	11	9	43	2	2021-07-01 08:40:00	2021-07-01 08:50:00	f	0
4268	31	11	9	42	1	2021-07-01 08:50:00	2021-07-01 09:00:00	f	0
4269	30	10	8	41	7	2021-07-01 08:30:00	2021-07-01 08:40:00	f	0
4270	30	10	8	40	4	2021-07-01 08:30:00	2021-07-01 08:40:00	f	0
4271	29	9	5	29	2	2021-07-01 08:30:00	2021-07-01 08:40:00	f	0
4272	29	9	5	28	1	2021-07-01 08:40:00	2021-07-01 08:50:00	f	0
4273	29	9	6	32	2	2021-07-01 08:50:00	2021-07-01 09:00:00	f	0
4274	29	9	6	30	3	2021-07-01 09:00:00	2021-07-01 09:10:00	f	0
4275	34	13	7	36	7	2021-07-01 08:40:00	2021-07-01 08:50:00	f	0
4276	34	13	7	35	6	2021-07-01 08:40:00	2021-07-01 08:50:00	f	0
4277	30	10	8	41	7	2021-07-01 08:40:00	2021-07-01 08:50:00	f	0
4278	30	10	8	40	4	2021-07-01 08:40:00	2021-07-01 08:50:00	f	0
\.


--
-- Data for Name: error_log; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.error_log (id, module_id, detail, created_on) FROM stdin;
\.


--
-- Data for Name: game; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.game (id, title, subtitle, img_url, content, type_id, game_code, engine_id, version, status, score_rule, watch_ad_get_tickets, watch_ad_get_exp, use_gem_get_tickets, use_gem_get_exp, use_how_many_gems) FROM stdin;
3	Jumper		https://esm-cdn.sgp1.digitaloceanspaces.com/games/jumper/jumper.png		0	<script type="text/javascript" src="https://esm-cdn.sgp1.digitaloceanspaces.com/games/jumper/js/phaser.min.js"></script>\n<style type="text/css">\nbody {\n    background: #000000;\n    padding: 0px;\n    margin: 0px;\n}\n\ncanvas {\n    display: block;\n    margin: 0;\n    position: absolute;\n    top: 50%;\n    left: 50%;\n    transform: translate(-50%, -50%);\n}\n</style>\n<script src="https://esm-cdn.sgp1.digitaloceanspaces.com/games/jumper/js/game.js"></script>	10	1	2	4	5	0	10	2	1
7	Float		https://esm-cdn.sgp1.digitaloceanspaces.com/games/float/float.png		0	<script type="text/javascript" src="https://esm-cdn.sgp1.digitaloceanspaces.com/games/float/js/phaser.min.js"></script>\n<style type="text/css">\n    body {\n        background: #000000;\n        padding: 0px;\n        margin: 0px;\n    }\n\n    canvas {\n        display: block;\n        margin: 0;\n        position: absolute;\n        top: 50%;\n        left: 50%;\n        transform: translate(-50%, -50%);\n    }\n</style>\n\n<script src="https://esm-cdn.sgp1.digitaloceanspaces.com/games/float/js/game.js"></script>	11	0	2	4	5	0	10	2	1
6	2 Cars		https://esm-cdn.sgp1.digitaloceanspaces.com/games/2cars/2cars.png		0	<script type="text/javascript" src="https://esm-cdn.sgp1.digitaloceanspaces.com/games/2cars/js/phaser.min.js"></script>\n<style type="text/css">\n    body {\n        background: black;\n        padding: 0px;\n        margin: 0px;\n    }\n\n    canvas {\n        display: block;\n        margin: 0;\n        position: absolute;\n        top: 50%;\n        left: 50%;\n        transform: translate(-50%, -50%);\n    }\n</style>\n<script src="https://esm-cdn.sgp1.digitaloceanspaces.com/games/2cars/js/game.js"></script>	11	0	2	4	5	0	10	2	1
4	Revolve		https://esm-cdn.sgp1.digitaloceanspaces.com/games/revolve/revolve.png		0	<script type="text/javascript" src="https://esm-cdn.sgp1.digitaloceanspaces.com/games/revolve/js/phaser.min.js"></script>\n<style type="text/css">\n    body {\n        background: #000000;\n        padding: 0px;\n        margin: 0px;\n    }\n\n    canvas {\n        display: block;\n        margin: 0;\n        position: absolute;\n        top: 50%;\n        left: 50%;\n        transform: translate(-50%, -50%);\n    }\n</style>\n<script src="https://esm-cdn.sgp1.digitaloceanspaces.com/games/revolve/js/game.js"></script>	10	1	2	4	5	0	10	2	1
5	Boom Dots		https://esm-cdn.sgp1.digitaloceanspaces.com/games/boomdots/boomdots.png		0	<script type="text/javascript" src="https://esm-cdn.sgp1.digitaloceanspaces.com/games/boomdots/js/phaser.min.js"></script>\n<style type="text/css">\n    body {\n        background: #000000;\n        padding: 0px;\n        margin: 0px;\n    }\n\n    canvas {\n        display: block;\n        margin: 0;\n        position: absolute;\n        top: 50%;\n        left: 50%;\n        transform: translate(-50%, -50%);\n    }\n</style>\n<script src="https://esm-cdn.sgp1.digitaloceanspaces.com/games/boomdots/js/game.js"></script>	10	1	2	4	5	0	10	2	1
1	Path		https://esm-cdn.sgp1.digitaloceanspaces.com/games/path/path.png		0	<script type="text/javascript" src="https://esm-cdn.sgp1.digitaloceanspaces.com/games/path/js/phaser.min.js"></script>\n<style type="text/css">\n        body {\n            background: #000000;\n            padding: 0px;\n            margin: 0px;\n        }\n\n        canvas {\n            display: block;\n            margin: 0;\n            position: absolute;\n            top: 50%;\n            left: 50%;\n            transform: translate(-50%, -50%);\n        }\n</style>\n<script src="https://esm-cdn.sgp1.digitaloceanspaces.com/games/path/js/game.js"></script>\n	10	1	2	4	5	0	10	2	1
2	Bounce		https://esm-cdn.sgp1.digitaloceanspaces.com/games/bouncingball/bounce.png		0	<script src="https://cdnjs.cloudflare.com/ajax/libs/phaser/2.6.2/phaser.min.js"></script>\n<style>\n    body {\n        padding: 0px;\n        margin: 0px;\n        background: black;\n    }\n    canvas {\n        display: block;\n        margin: 0;\n        position: absolute;\n        top: 50%;\n        left: 50%;\n        transform: translate(-50%, -50%);\n    }\n</style>\n<script src="https://esm-cdn.sgp1.digitaloceanspaces.com/games/bouncingball/js/game.js"></script>	10	1	2	4	5	0	10	2	1
\.


--
-- Data for Name: game_leader_rule; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.game_leader_rule (game_id, tickets, exp, rank_from, rank_to) FROM stdin;
6	300	5	1	1
6	200	4	2	2
6	100	3	3	3
6	10	1	5	5
6	50	2	4	4
7	300	5	1	1
7	200	4	2	2
7	100	3	3	3
7	50	2	4	4
7	10	1	5	5
1	500	5	1	1
1	450	4	2	2
1	400	3	3	3
1	350	2	4	4
1	300	1	5	5
1	200	0	6	10
2	500	5	1	1
2	450	4	2	2
2	400	3	3	3
2	350	2	4	4
2	300	1	5	5
2	100	0	6	10
3	500	5	1	1
3	450	4	2	2
3	400	3	3	3
3	350	2	4	4
3	300	1	5	5
3	100	0	6	10
4	300	5	1	1
4	200	4	2	2
5	300	5	1	1
5	200	4	2	2
\.


--
-- Data for Name: gplayer; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.gplayer (id, user_id, prize_id, game_id, enter_timestamp, leave_timestamp, game_score, is_watched_ad, is_used_gem, is_logged_leave, is_closed, closed_timestamp) FROM stdin;
1	3	1	1	2021-06-18 12:07:33.799139	2021-06-18 12:07:38.668381	2	f	f	t	t	1970-01-01 00:00:00
59	2	1	4	2021-06-22 07:45:53.591948	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
2	5	1	3	2021-06-20 05:25:10.3907	2021-06-20 05:25:16.553883	0	f	f	t	t	1970-01-01 00:00:00
39	6	1	3	2021-06-22 03:23:20.093343	2021-06-22 03:23:36.917309	38	f	f	t	t	1970-01-01 00:00:00
3	2	3	1	2021-06-21 04:03:20.951536	2021-06-21 04:03:23.182852	0	f	f	t	t	1970-01-01 00:00:00
35	2	1	3	2021-06-22 03:04:38.813809	2021-06-22 03:04:51.970134	6	f	t	t	t	1970-01-01 00:00:00
37	6	1	3	2021-06-22 03:23:02.325459	2021-06-22 03:23:07.026772	2	f	f	t	t	1970-01-01 00:00:00
36	6	1	3	2021-06-22 03:22:53.094986	2021-06-22 03:22:57.331502	0	f	f	t	t	1970-01-01 00:00:00
38	6	1	3	2021-06-22 03:23:12.283841	2021-06-22 03:23:16.065174	0	f	f	t	t	1970-01-01 00:00:00
40	2	1	4	2021-06-22 03:41:34.199887	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
60	2	1	4	2021-06-22 07:47:16.80409	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
41	2	1	4	2021-06-22 03:41:41.905551	2021-06-22 03:41:49.455625	5	f	t	t	t	1970-01-01 00:00:00
7	2	1	3	2021-06-21 07:04:47.866194	2021-06-21 07:05:01.262527	8	f	f	t	t	1970-01-01 00:00:00
4	2	1	3	2021-06-21 07:03:20.073509	2021-06-21 07:03:31.415544	4	f	f	t	t	1970-01-01 00:00:00
5	2	1	3	2021-06-21 07:04:29.90255	2021-06-21 07:04:35.715417	0	f	f	t	t	1970-01-01 00:00:00
6	2	1	3	2021-06-21 07:04:38.905758	2021-06-21 07:04:45.634136	0	f	f	t	t	1970-01-01 00:00:00
8	6	1	3	2021-06-21 07:20:30.607646	2021-06-21 07:20:35.770777	0	f	f	t	t	1970-01-01 00:00:00
9	6	1	3	2021-06-21 07:20:40.578922	2021-06-21 07:20:44.13557	0	f	f	t	t	1970-01-01 00:00:00
11	6	3	6	2021-06-21 07:21:01.87882	2021-06-21 07:21:24.370841	2	f	f	t	t	1970-01-01 00:00:00
10	6	3	6	2021-06-21 07:20:51.29713	2021-06-21 07:20:58.60635	0	f	f	t	t	1970-01-01 00:00:00
61	2	1	4	2021-06-22 07:47:46.824266	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
62	2	1	4	2021-06-22 07:50:08.346736	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
63	2	1	1	2021-06-22 08:03:48.854984	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
64	2	1	1	2021-06-22 08:05:03.259535	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
18	6	3	4	2021-06-21 09:33:41.675663	2021-06-21 09:33:47.944816	5	f	f	t	t	1970-01-01 00:00:00
19	6	3	4	2021-06-21 09:33:50.212986	2021-06-21 09:33:52.844702	1	f	f	t	t	1970-01-01 00:00:00
15	6	3	4	2021-06-21 09:33:25.952399	2021-06-21 09:33:30.104339	0	f	f	t	t	1970-01-01 00:00:00
16	6	3	4	2021-06-21 09:33:32.936565	2021-06-21 09:33:34.462158	0	f	f	t	t	1970-01-01 00:00:00
17	6	3	4	2021-06-21 09:33:36.979396	2021-06-21 09:33:39.663917	0	f	f	t	t	1970-01-01 00:00:00
13	3	3	6	2021-06-21 09:20:23.546974	2021-06-21 09:22:18.67787	73	f	f	t	t	1970-01-01 00:00:00
12	3	3	6	2021-06-21 09:19:58.563887	2021-06-21 09:20:16.509934	10	f	f	t	t	1970-01-01 00:00:00
14	6	3	6	2021-06-21 09:32:20.535276	2021-06-21 09:32:25.834929	0	f	f	t	t	1970-01-01 00:00:00
20	2	1	1	2021-06-21 10:18:49.338521	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
21	2	1	1	2021-06-21 10:19:56.220962	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
22	2	1	1	2021-06-21 10:25:47.939962	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
23	2	1	1	2021-06-21 10:26:57.27998	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
24	2	1	1	2021-06-21 10:27:59.953332	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
25	2	1	1	2021-06-21 10:28:35.384862	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
26	2	1	1	2021-06-21 10:29:45.185968	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
27	2	3	1	2021-06-21 10:37:43.293422	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
28	2	3	3	2021-06-21 10:38:44.124039	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
29	2	3	1	2021-06-21 10:45:12.009177	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
30	2	3	1	2021-06-21 10:46:57.761767	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
31	2	3	3	2021-06-21 10:49:34.8771	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
32	2	3	3	2021-06-21 10:50:56.914437	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
33	2	3	3	2021-06-21 10:53:25.356834	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
34	2	1	3	2021-06-22 03:04:29.124217	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
65	3	1	1	2021-06-22 10:17:04.861596	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
66	3	3	6	2021-06-22 10:17:21.41781	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
67	2	1	1	2021-06-22 10:17:40.577916	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
68	2	3	6	2021-06-22 10:17:58.662874	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
69	3	1	1	2021-06-22 10:18:18.792523	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
70	3	1	1	2021-06-22 10:18:38.567077	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
46	6	3	4	2021-06-22 04:52:17.352491	2021-06-22 04:52:20.672353	2	f	f	t	t	1970-01-01 00:00:00
47	6	3	4	2021-06-22 04:52:27.189796	2021-06-22 04:52:30.289103	2	f	f	t	t	1970-01-01 00:00:00
42	6	3	4	2021-06-22 04:03:00.884824	2021-06-22 04:03:03.40484	0	f	f	t	t	1970-01-01 00:00:00
45	6	3	4	2021-06-22 04:52:09.618417	2021-06-22 04:52:11.307894	0	f	f	t	t	1970-01-01 00:00:00
43	6	1	2	2021-06-22 04:48:54.381676	2021-06-22 04:48:59.393804	5	f	f	t	t	1970-01-01 00:00:00
44	6	1	2	2021-06-22 04:49:54.078464	2021-06-22 04:49:56.307173	5	f	f	t	t	1970-01-01 00:00:00
48	2	1	4	2021-06-22 05:34:57.231485	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
49	2	1	4	2021-06-22 05:36:17.180878	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
50	2	1	4	2021-06-22 05:38:01.997979	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
51	2	1	1	2021-06-22 06:10:18.643782	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
52	2	1	1	2021-06-22 06:22:45.310087	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
53	2	3	4	2021-06-22 06:49:12.573376	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
54	2	3	4	2021-06-22 06:50:06.667698	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
55	2	3	6	2021-06-22 06:51:22.12868	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
56	2	3	6	2021-06-22 06:51:55.729984	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
57	2	3	6	2021-06-22 06:54:07.655459	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
58	2	1	3	2021-06-22 07:01:40.556435	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
73	5	1	4	2021-06-22 11:57:07.500855	2021-06-22 11:57:09.90484	1	f	f	t	t	1970-01-01 00:00:00
71	5	1	4	2021-06-22 11:53:08.898179	2021-06-22 11:53:13.661423	0	f	f	t	t	1970-01-01 00:00:00
72	5	1	4	2021-06-22 11:56:55.449215	2021-06-22 11:56:58.345396	0	f	f	t	t	1970-01-01 00:00:00
75	2	3	6	2021-06-22 12:46:17.076548	2021-06-22 12:46:24.946216	3	f	t	t	t	1970-01-01 00:00:00
74	2	3	6	2021-06-22 12:34:26.549812	2021-06-22 12:34:36.955563	1	f	t	t	t	1970-01-01 00:00:00
76	5	1	4	2021-06-22 13:36:44.061706	2021-06-22 13:36:46.92628	0	f	f	t	t	1970-01-01 00:00:00
77	5	1	4	2021-06-22 13:53:29.575662	2021-06-22 13:53:32.495776	0	f	f	t	t	1970-01-01 00:00:00
78	5	3	4	2021-06-22 14:33:52.633291	2021-06-22 14:33:56.917934	3	f	f	t	t	1970-01-01 00:00:00
80	2	3	4	2021-06-23 02:45:55.48164	2021-06-23 02:45:58.886553	1	f	f	t	t	1970-01-01 00:00:00
84	7	3	4	2021-06-23 02:55:20.568134	2021-06-23 02:55:23.92076	1	f	f	t	t	1970-01-01 00:00:00
79	2	3	4	2021-06-23 02:45:08.812021	2021-06-23 02:45:15.926982	5	f	f	t	t	1970-01-01 00:00:00
83	2	3	6	2021-06-23 02:53:12.205537	2021-06-23 02:53:21.638484	2	f	t	t	t	1970-01-01 00:00:00
85	2	1	3	2021-06-23 03:23:04.795219	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
82	2	3	4	2021-06-23 02:52:33.412052	2021-06-23 02:52:35.156855	0	f	f	t	t	1970-01-01 00:00:00
81	2	3	4	2021-06-23 02:52:16.91132	2021-06-23 02:52:28.763005	10	f	f	t	t	1970-01-01 00:00:00
86	2	1	3	2021-06-23 03:23:18.151015	2021-06-23 03:23:26.043665	4	f	t	t	t	1970-01-01 00:00:00
87	2	1	4	2021-06-23 03:57:51.524056	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
88	2	3	1	2021-06-23 03:58:17.105581	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
89	2	1	1	2021-06-23 04:25:32.031402	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
90	2	2	7	2021-06-23 04:25:50.704499	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
91	2	3	4	2021-06-23 04:35:16.450891	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
92	2	3	6	2021-06-23 04:35:25.81329	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
93	2	1	3	2021-06-23 05:00:13.672498	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
94	2	2	6	2021-06-23 05:00:34.193233	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
95	2	3	3	2021-06-23 05:00:50.982312	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
96	2	3	1	2021-06-23 05:31:14.973671	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
97	2	3	3	2021-06-23 05:31:21.849417	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
98	2	3	1	2021-06-23 05:31:34.308893	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
99	2	1	4	2021-06-23 05:31:57.47487	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
100	2	3	3	2021-06-23 05:32:09.088043	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
101	2	2	3	2021-06-23 05:32:18.760824	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
102	6	3	6	2021-06-23 08:14:29.130146	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
103	6	3	6	2021-06-23 08:14:35.085724	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
104	6	3	6	2021-06-23 08:14:36.375405	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
105	6	3	6	2021-06-23 08:14:37.495088	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
106	6	3	6	2021-06-23 08:14:38.118875	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
107	6	3	6	2021-06-23 08:14:38.542941	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
108	6	3	6	2021-06-23 08:14:38.960558	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
109	6	3	6	2021-06-23 08:14:39.365696	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
110	6	3	6	2021-06-23 08:14:39.77518	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
111	6	3	6	2021-06-23 08:14:40.165211	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
112	6	3	6	2021-06-23 08:14:40.526845	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
113	6	3	6	2021-06-23 08:14:40.837006	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
114	6	3	6	2021-06-23 08:14:40.990092	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
115	6	3	6	2021-06-23 08:14:41.111112	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
116	6	3	6	2021-06-23 08:14:41.239524	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
117	6	3	6	2021-06-23 08:14:41.365694	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
118	6	3	6	2021-06-23 08:14:45.668979	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
119	6	3	6	2021-06-23 08:14:45.815153	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
120	6	3	6	2021-06-23 08:14:45.974497	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
121	6	3	6	2021-06-23 08:14:46.127562	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
122	6	3	6	2021-06-23 08:14:46.262772	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
123	6	3	6	2021-06-23 08:14:46.410359	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
124	6	3	6	2021-06-23 08:14:46.558474	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
125	6	3	6	2021-06-23 08:14:48.045654	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
165	2	1	3	2021-06-23 11:05:26.320802	2021-06-23 11:05:36.933517	2	f	t	t	t	1970-01-01 00:00:00
127	6	3	6	2021-06-23 08:18:53.892032	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
128	6	3	6	2021-06-23 08:19:33.821596	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
129	6	3	6	2021-06-23 08:26:53.095646	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
152	2	1	4	2021-06-23 09:53:08.790873	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
131	6	3	6	2021-06-23 08:28:20.231733	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
132	6	3	6	2021-06-23 08:28:20.968405	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
133	6	3	6	2021-06-23 08:28:21.372668	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
134	6	3	6	2021-06-23 08:28:21.596718	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
135	6	3	6	2021-06-23 08:28:21.892383	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
136	6	3	6	2021-06-23 08:28:22.028311	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
137	6	3	6	2021-06-23 08:28:22.190696	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
138	6	3	6	2021-06-23 08:28:22.34025	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
139	6	3	6	2021-06-23 08:28:22.532455	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
140	6	3	6	2021-06-23 08:28:23.108413	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
141	6	3	6	2021-06-23 08:28:23.29991	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
142	6	3	4	2021-06-23 08:29:05.574544	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
130	6	3	6	2021-06-23 08:26:57.54511	2021-06-23 08:27:17.870836	9	f	t	t	t	1970-01-01 00:00:00
126	6	3	6	2021-06-23 08:14:56.025101	2021-06-23 08:15:28.94718	8	f	t	t	t	1970-01-01 00:00:00
143	6	3	3	2021-06-23 09:06:25.288232	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
156	2	3	4	2021-06-23 10:57:20.913888	2021-06-23 10:57:27.714424	5	f	t	t	t	1970-01-01 00:00:00
146	2	1	3	2021-06-23 09:25:19.68451	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
147	2	2	6	2021-06-23 09:26:25.702571	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
159	2	3	4	2021-06-23 10:58:19.34156	2021-06-23 10:58:21.881972	0	f	t	t	t	1970-01-01 00:00:00
144	6	3	3	2021-06-23 09:06:46.982898	2021-06-23 09:06:59.060715	6	f	t	t	t	1970-01-01 00:00:00
153	2	1	4	2021-06-23 09:53:15.363376	2021-06-23 09:53:23.833884	8	f	t	t	t	1970-01-01 00:00:00
148	2	1	3	2021-06-23 09:27:12.123595	2021-06-23 09:27:21.862847	4	f	t	t	t	1970-01-01 00:00:00
145	5	1	3	2021-06-23 09:12:19.21682	2021-06-23 09:12:25.14392	0	f	f	t	t	1970-01-01 00:00:00
149	2	1	3	2021-06-23 09:28:00.028767	2021-06-23 09:28:05.192931	0	f	t	t	t	1970-01-01 00:00:00
150	2	2	6	2021-06-23 09:28:29.079893	2021-06-23 09:28:38.448365	4	f	t	t	t	1970-01-01 00:00:00
151	2	1	4	2021-06-23 09:53:01.635853	2021-06-23 09:53:05.641364	0	f	f	t	t	1970-01-01 00:00:00
154	2	3	6	2021-06-23 10:57:02.113231	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
155	2	3	4	2021-06-23 10:57:09.238018	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
163	2	1	3	2021-06-23 11:04:52.377255	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
157	2	3	6	2021-06-23 10:58:08.207118	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
158	2	3	4	2021-06-23 10:58:13.795043	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
160	2	2	6	2021-06-23 11:03:56.649787	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
161	2	1	3	2021-06-23 11:04:06.18384	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
164	2	2	6	2021-06-23 11:05:00.99741	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
166	2	1	4	2021-06-23 13:31:46.443841	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
162	2	1	3	2021-06-23 11:04:09.290092	2021-06-23 11:04:27.575337	2	f	t	t	t	1970-01-01 00:00:00
167	6	2	3	2021-06-24 01:41:40.205583	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
168	6	2	3	2021-06-24 01:46:14.164145	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
169	6	2	3	2021-06-24 01:58:05.938293	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
170	6	2	3	2021-06-24 01:58:56.611231	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
171	6	3	6	2021-06-24 02:03:06.221674	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
172	6	3	6	2021-06-24 02:03:18.53431	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
173	6	3	6	2021-06-24 02:08:38.620544	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
174	6	3	6	2021-06-24 02:12:56.527125	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
175	6	3	6	2021-06-24 02:14:16.301739	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
176	6	3	6	2021-06-24 02:14:28.632641	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
193	2	3	6	2021-06-25 03:36:46.654668	2021-06-25 03:36:56.03546	3	f	f	t	t	2021-06-25 04:00:53.0407
177	5	1	2	2021-06-24 02:33:34.781096	2021-06-24 02:33:38.307043	1	f	f	t	t	1970-01-01 00:00:00
178	2	1	4	2021-06-24 07:44:07.534816	2021-06-24 07:44:15.430948	5	f	f	t	t	1970-01-01 00:00:00
238	10	1	1	2021-06-25 06:12:58.735365	2021-06-25 06:13:00.189015	0	f	f	t	t	2021-06-25 06:30:09.190898
209	2	3	6	2021-06-25 04:13:48.169571	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
242	3	2	7	2021-06-25 06:28:47.267929	2021-06-25 06:28:55.748756	2	f	f	t	t	2021-06-25 06:30:09.934161
211	2	3	6	2021-06-25 04:16:04.430142	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
207	2	2	7	2021-06-25 04:08:18.094183	2021-06-25 04:08:25.650179	1	f	f	t	t	2021-06-25 04:30:55.958888
213	2	3	6	2021-06-25 04:44:27.435022	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
241	3	2	7	2021-06-25 06:28:47.256579	2021-06-25 06:28:54.64538	1	f	f	t	t	2021-06-25 06:30:10.011458
180	2	1	1	2021-06-24 08:13:50.8003	2021-06-24 08:13:58.464466	5	f	f	t	t	1970-01-01 00:00:00
185	2	1	1	2021-06-24 08:19:11.806264	2021-06-24 08:19:14.297568	2	f	f	t	t	1970-01-01 00:00:00
184	2	1	1	2021-06-24 08:19:01.923019	2021-06-24 08:19:07.09582	1	f	f	t	t	1970-01-01 00:00:00
187	2	1	1	2021-06-24 08:19:23.938728	2021-06-24 08:19:28.990072	1	f	f	t	t	1970-01-01 00:00:00
183	2	1	1	2021-06-24 08:18:57.936802	2021-06-24 08:18:59.568836	0	f	f	t	t	1970-01-01 00:00:00
186	2	1	1	2021-06-24 08:19:18.72751	2021-06-24 08:19:21.783648	0	f	f	t	t	1970-01-01 00:00:00
182	6	2	7	2021-06-24 08:15:52.669941	2021-06-24 08:16:07.736911	5	f	f	t	t	1970-01-01 00:00:00
181	6	2	7	2021-06-24 08:15:43.147798	2021-06-24 08:15:50.622985	2	f	f	t	t	1970-01-01 00:00:00
191	2	3	4	2021-06-24 08:20:42.241212	2021-06-24 08:20:49.825946	7	f	f	t	t	1970-01-01 00:00:00
188	2	3	4	2021-06-24 08:20:21.976239	2021-06-24 08:20:26.428259	3	f	f	t	t	1970-01-01 00:00:00
189	2	3	4	2021-06-24 08:20:32.069726	2021-06-24 08:20:35.40383	1	f	f	t	t	1970-01-01 00:00:00
179	6	3	4	2021-06-24 08:10:38.33884	2021-06-24 08:10:40.629439	0	f	f	t	t	1970-01-01 00:00:00
190	2	3	4	2021-06-24 08:20:37.691902	2021-06-24 08:20:40.257179	0	f	f	t	t	1970-01-01 00:00:00
215	2	3	6	2021-06-25 04:58:41.582373	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
192	6	2	3	2021-06-24 09:44:02.788658	2021-06-24 09:44:37.202073	0	f	f	t	t	1970-01-01 00:00:00
194	2	3	4	2021-06-25 03:51:55.999152	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
252	2	7	5	2021-06-25 07:38:32.504804	2021-06-25 07:38:39.29671	1	f	t	t	t	2021-06-25 08:00:22.281756
197	2	3	4	2021-06-25 03:55:42.859493	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
208	2	3	4	2021-06-25 04:08:36.448779	2021-06-25 04:08:46.052254	0	f	f	t	t	2021-06-25 05:00:57.900035
199	2	3	4	2021-06-25 03:55:57.115294	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
214	2	3	6	2021-06-25 04:44:33.22862	2021-06-25 04:44:54.193204	11	f	t	t	t	2021-06-25 05:00:58.861414
201	2	3	4	2021-06-25 03:56:06.179363	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
212	2	3	6	2021-06-25 04:16:12.298376	2021-06-25 04:16:30.023656	8	f	t	t	t	2021-06-25 05:00:58.959487
203	2	3	6	2021-06-25 03:56:24.340072	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
216	2	3	6	2021-06-25 04:58:45.504608	2021-06-25 04:59:04.571898	5	f	t	t	t	2021-06-25 05:00:59.062876
205	2	3	6	2021-06-25 03:58:32.334011	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
210	2	3	6	2021-06-25 04:13:56.52395	2021-06-25 04:14:06.317751	4	f	t	t	t	2021-06-25 05:00:59.179695
196	2	3	4	2021-06-25 03:54:59.449863	2021-06-25 03:55:05.927479	5	f	f	t	t	2021-06-25 04:00:51.397778
195	2	3	4	2021-06-25 03:52:08.819095	2021-06-25 03:52:12.851418	0	f	t	t	t	2021-06-25 04:00:51.481915
198	2	3	4	2021-06-25 03:55:47.512788	2021-06-25 03:55:50.033408	0	f	t	t	t	2021-06-25 04:00:51.553961
200	2	3	4	2021-06-25 03:56:01.069705	2021-06-25 03:56:02.859255	0	f	t	t	t	2021-06-25 04:00:51.818863
202	2	3	4	2021-06-25 03:56:10.688555	2021-06-25 03:56:13.415577	0	f	t	t	t	2021-06-25 04:00:51.917477
206	2	3	6	2021-06-25 03:58:35.402093	2021-06-25 03:58:46.177966	8	f	t	t	t	2021-06-25 04:00:52.805488
204	2	3	6	2021-06-25 03:56:27.318508	2021-06-25 03:57:26.96192	6	f	t	t	t	2021-06-25 04:00:52.923121
217	2	3	6	2021-06-25 05:02:28.225551	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
219	2	3	6	2021-06-25 05:03:15.493892	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
247	2	7	5	2021-06-25 07:37:46.27292	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
221	2	1	4	2021-06-25 05:37:13.783066	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
223	2	1	4	2021-06-25 05:37:43.613989	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
225	2	1	4	2021-06-25 05:38:37.590592	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
234	3	1	1	2021-06-25 06:08:27.128014	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
226	2	1	4	2021-06-25 05:38:44.870903	2021-06-25 05:38:53.939311	6	f	t	t	t	2021-06-25 06:00:03.930812
224	2	1	4	2021-06-25 05:37:46.387544	2021-06-25 05:37:51.521045	4	f	t	t	t	2021-06-25 06:00:04.010053
222	2	1	4	2021-06-25 05:37:18.657573	2021-06-25 05:37:24.703821	1	f	t	t	t	2021-06-25 06:00:04.138158
220	2	3	6	2021-06-25 05:03:19.271692	2021-06-25 05:03:36.571263	11	f	t	t	t	2021-06-25 06:00:05.719876
218	2	3	6	2021-06-25 05:02:32.332211	2021-06-25 05:02:43.413205	1	f	t	t	t	2021-06-25 06:00:05.801931
232	3	3	4	2021-06-25 06:06:39.978352	2021-06-25 06:06:47.410547	5	f	f	t	t	2021-06-25 07:00:11.198317
231	3	3	4	2021-06-25 06:06:29.534165	2021-06-25 06:06:36.580062	0	f	f	t	t	2021-06-25 07:00:11.281722
236	3	1	1	2021-06-25 06:08:40.381039	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
237	3	1	1	2021-06-25 06:11:21.144402	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
250	2	7	5	2021-06-25 07:38:19.0959	2021-06-25 07:38:22.776675	0	f	t	t	t	2021-06-25 08:00:22.438269
233	3	3	6	2021-06-25 06:06:53.715857	2021-06-25 06:07:07.987098	8	f	f	t	t	2021-06-25 07:00:12.110059
243	2	1	4	2021-06-25 07:35:00.979274	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
249	2	7	5	2021-06-25 07:38:16.708905	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
228	3	1	1	2021-06-25 06:05:38.816033	2021-06-25 06:05:59.21984	20	f	f	t	t	2021-06-25 06:30:08.569684
230	3	1	1	2021-06-25 06:06:10.267821	2021-06-25 06:06:18.394017	6	f	f	t	t	2021-06-25 06:30:08.669978
229	3	1	1	2021-06-25 06:06:02.314559	2021-06-25 06:06:07.922847	5	f	f	t	t	2021-06-25 06:30:08.7742
239	10	1	1	2021-06-25 06:14:40.338861	2021-06-25 06:14:45.503131	3	f	f	t	t	2021-06-25 06:30:08.886963
240	10	1	1	2021-06-25 06:14:48.353116	2021-06-25 06:14:52.051498	2	f	f	t	t	2021-06-25 06:30:08.954126
227	3	1	1	2021-06-25 06:05:31.025037	2021-06-25 06:05:36.233233	2	f	f	t	t	2021-06-25 06:30:09.034488
235	3	1	1	2021-06-25 06:08:30.947797	2021-06-25 06:08:33.929021	1	f	t	t	t	2021-06-25 06:30:09.110088
256	2	1	4	2021-06-25 07:40:34.909148	2021-06-25 07:40:48.755006	10	f	t	t	t	2021-06-25 08:00:16.761933
245	2	3	6	2021-06-25 07:36:16.796656	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
254	2	7	5	2021-06-25 07:39:53.238193	2021-06-25 07:39:56.666232	0	f	t	t	t	2021-06-25 08:00:22.513838
251	2	7	5	2021-06-25 07:38:29.627777	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
248	2	7	5	2021-06-25 07:37:52.798002	2021-06-25 07:37:56.794371	0	f	t	t	t	2021-06-25 08:00:22.358202
253	2	7	5	2021-06-25 07:39:48.737429	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
255	2	1	4	2021-06-25 07:40:31.502451	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
258	2	1	4	2021-06-25 07:44:03.807139	2021-06-25 07:44:07.545459	0	f	t	t	t	2021-06-25 08:00:17.09972
257	2	1	4	2021-06-25 07:43:59.375396	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
246	2	3	6	2021-06-25 07:36:23.249082	2021-06-25 07:36:43.926642	10	f	t	t	t	2021-06-25 08:00:20.738172
259	2	1	4	2021-06-25 07:44:12.268547	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
263	2	1	4	2021-06-25 07:44:42.881122	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
267	2	3	6	2021-06-25 07:48:46.552295	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
260	2	1	4	2021-06-25 07:44:15.902162	2021-06-25 07:44:19.855498	3	f	t	t	t	2021-06-25 08:00:16.97022
261	2	1	4	2021-06-25 07:44:25.417168	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
265	2	3	6	2021-06-25 07:45:18.986825	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
262	2	1	4	2021-06-25 07:44:29.795687	2021-06-25 07:44:34.099497	1	f	t	t	t	2021-06-25 08:00:17.092199
269	2	3	4	2021-06-25 07:50:17.086225	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
264	2	1	4	2021-06-25 07:44:45.837689	2021-06-25 07:44:58.69542	10	f	t	t	t	2021-06-25 08:00:16.866436
268	2	3	6	2021-06-25 07:48:51.959652	2021-06-25 07:49:17.484966	16	f	t	t	t	2021-06-25 08:00:20.485828
266	2	3	6	2021-06-25 07:45:27.852787	2021-06-25 07:45:48.538033	14	f	t	t	t	2021-06-25 08:00:20.566501
317	2	3	6	2021-06-25 10:42:39.94644	2021-06-25 10:42:59.057988	10	f	t	t	t	2021-06-25 11:00:46.498026
244	2	1	4	2021-06-25 07:35:07.344302	2021-06-25 07:35:22.443346	13	f	t	t	t	2021-06-25 08:00:16.658846
270	2	3	4	2021-06-25 07:50:25.712481	2021-06-25 07:50:32.993004	5	f	t	t	t	2021-06-25 08:00:18.29746
271	3	1	2	2021-06-25 08:32:27.3519	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
272	3	1	2	2021-06-25 08:32:31.830493	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
273	3	1	2	2021-06-25 08:32:32.441154	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
274	3	1	2	2021-06-25 08:32:34.028665	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
275	3	1	2	2021-06-25 08:32:34.191785	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
276	3	1	2	2021-06-25 08:32:34.349465	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
277	3	1	2	2021-06-25 08:32:34.507559	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
278	3	1	2	2021-06-25 08:32:34.664771	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
279	3	1	2	2021-06-25 08:32:34.822627	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
280	3	1	2	2021-06-25 08:32:34.982705	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
281	3	1	2	2021-06-25 08:32:35.152319	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
321	2	1	2	2021-06-25 10:55:52.130196	2021-06-25 10:56:06.502399	18	f	f	t	t	2021-06-25 11:00:47.518221
320	2	1	2	2021-06-25 10:55:36.086274	2021-06-25 10:55:48.43331	15	f	f	t	t	2021-06-25 11:00:47.618313
285	3	1	2	2021-06-25 08:44:08.738569	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
286	3	1	2	2021-06-25 08:44:18.965569	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
287	3	1	2	2021-06-25 08:44:19.785504	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
288	3	1	2	2021-06-25 08:44:19.989479	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
289	3	1	2	2021-06-25 08:44:20.177343	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
290	3	1	2	2021-06-25 08:44:20.354788	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
291	3	1	2	2021-06-25 08:44:20.544542	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
292	3	1	2	2021-06-25 08:44:20.721584	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
293	3	1	2	2021-06-25 08:44:20.895071	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
294	3	3	4	2021-06-25 08:44:39.067157	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
295	3	3	4	2021-06-25 08:44:47.16623	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
296	3	7	3	2021-06-25 08:45:07.648906	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
297	3	7	3	2021-06-25 08:45:08.323435	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
298	3	1	2	2021-06-25 08:46:35.2626	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
299	3	1	2	2021-06-25 08:47:38.456394	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
300	3	1	2	2021-06-25 08:47:40.116321	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
301	3	1	2	2021-06-25 08:47:40.293053	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
302	3	1	2	2021-06-25 08:47:40.448524	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
303	3	1	2	2021-06-25 08:47:40.62051	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
282	3	7	3	2021-06-25 08:33:57.887436	2021-06-25 08:34:24.343347	34	f	f	t	t	2021-06-25 09:00:30.198234
283	3	28	3	2021-06-25 08:34:33.709316	2021-06-25 08:34:51.234501	18	f	f	t	t	2021-06-25 09:00:30.978462
284	3	28	3	2021-06-25 08:34:54.206076	2021-06-25 08:35:01.322558	8	f	f	t	t	2021-06-25 09:00:31.082196
304	3	1	3	2021-06-25 09:04:58.878859	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
305	3	1	3	2021-06-25 09:05:07.597636	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
306	3	1	3	2021-06-25 09:05:29.805797	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
307	3	1	3	2021-06-25 09:05:29.965198	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
308	3	1	3	2021-06-25 09:05:30.116768	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
309	3	1	3	2021-06-25 09:05:30.284739	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
310	3	1	3	2021-06-25 09:05:30.455373	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
311	3	1	3	2021-06-25 09:05:30.613196	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
312	3	1	3	2021-06-25 09:05:30.77782	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
313	3	1	3	2021-06-25 09:05:30.96961	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
314	2	1	3	2021-06-25 09:07:36.280412	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
333	9	2	5	2021-06-28 02:44:59.777119	2021-06-28 02:45:04.874174	3	f	f	t	t	2021-06-28 03:01:00.11336
315	2	1	3	2021-06-25 09:07:40.291686	2021-06-25 09:07:50.91262	8	f	t	t	t	2021-06-25 09:30:32.897991
316	2	3	6	2021-06-25 10:42:35.208963	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
331	9	2	5	2021-06-28 02:44:50.945224	2021-06-28 02:44:55.091199	1	f	f	t	t	2021-06-28 03:01:00.159798
318	2	3	6	2021-06-25 10:43:36.205325	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
330	9	2	5	2021-06-28 02:44:45.14262	2021-06-28 02:44:48.893621	0	f	f	t	t	2021-06-28 03:01:00.2042
332	9	2	5	2021-06-28 02:44:56.831365	2021-06-28 02:44:58.357999	0	f	f	t	t	2021-06-28 03:01:00.254854
325	2	3	4	2021-06-25 10:56:38.163236	2021-06-25 10:56:44.963655	5	f	f	t	t	2021-06-25 11:00:45.323151
322	2	3	4	2021-06-25 10:56:22.769886	2021-06-25 10:56:26.367847	0	f	f	t	t	2021-06-25 11:00:45.401086
323	2	3	4	2021-06-25 10:56:29.146724	2021-06-25 10:56:31.378623	0	f	f	t	t	2021-06-25 11:00:45.482041
324	2	3	4	2021-06-25 10:56:33.410458	2021-06-25 10:56:36.16499	0	f	f	t	t	2021-06-25 11:00:45.564434
319	2	3	6	2021-06-25 10:43:38.714512	2021-06-25 10:44:15.911812	13	f	t	t	t	2021-06-25 11:00:46.392354
336	3	1	1	2021-06-28 04:26:18.606199	2021-06-28 04:26:21.734017	0	f	f	t	t	2021-06-28 04:31:06.131999
341	3	3	6	2021-06-28 04:27:56.07885	2021-06-28 04:28:05.038386	4	f	f	t	t	2021-06-28 05:00:20.889351
329	9	28	3	2021-06-28 02:43:54.096933	2021-06-28 02:44:07.024638	20	f	f	t	t	2021-06-28 03:00:55.41969
326	9	28	3	2021-06-28 02:43:32.545667	2021-06-28 02:43:38.540634	2	f	f	t	t	2021-06-28 03:00:55.465179
327	9	28	3	2021-06-28 02:43:40.3972	2021-06-28 02:43:45.526283	2	f	f	t	t	2021-06-28 03:00:55.499692
328	9	28	3	2021-06-28 02:43:47.38547	2021-06-28 02:43:51.758042	2	f	f	t	t	2021-06-28 03:00:55.545512
344	2	3	6	2021-06-28 05:52:53.25747	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
334	6	28	5	2021-06-28 03:55:01.799946	2021-06-28 03:55:07.446755	1	f	f	t	t	2021-06-28 04:00:08.239256
335	6	28	5	2021-06-28 03:55:09.176524	2021-06-28 03:55:12.747414	1	f	f	t	t	2021-06-28 04:00:08.28657
354	2	1	4	2021-06-28 06:24:43.201289	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
346	2	1	4	2021-06-28 05:55:29.238163	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
338	3	1	1	2021-06-28 04:27:14.071731	2021-06-28 04:27:24.630718	9	f	f	t	t	2021-06-28 04:30:47.274275
337	3	1	1	2021-06-28 04:27:04.967399	2021-06-28 04:27:11.225342	6	f	f	t	t	2021-06-28 04:30:47.979147
342	3	7	6	2021-06-28 04:28:15.666558	2021-06-28 04:28:31.233864	10	f	f	t	t	2021-06-28 04:30:29.846195
343	3	7	6	2021-06-28 04:28:35.771266	2021-06-28 04:28:41.125257	0	f	f	t	t	2021-06-28 04:30:36.1405
340	3	1	1	2021-06-28 04:27:31.25702	2021-06-28 04:27:36.381342	3	f	f	t	t	2021-06-28 04:30:59.031311
339	3	1	1	2021-06-28 04:27:27.080795	2021-06-28 04:27:29.293697	1	f	f	t	t	2021-06-28 04:31:00.228515
349	2	1	4	2021-06-28 05:55:45.877916	2021-06-28 05:55:49.465552	2	f	t	t	t	2021-06-28 06:00:26.993133
348	2	1	4	2021-06-28 05:55:42.10571	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
353	2	3	6	2021-06-28 05:57:38.60728	2021-06-28 05:58:11.155991	16	f	t	t	t	2021-06-28 06:00:28.616643
350	2	3	6	2021-06-28 05:55:57.039471	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
345	2	3	6	2021-06-28 05:52:57.278882	2021-06-28 05:53:17.041293	12	f	t	t	t	2021-06-28 06:00:28.829167
352	2	3	6	2021-06-28 05:57:35.338424	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
351	2	3	6	2021-06-28 05:56:00.059719	2021-06-28 05:56:27.743597	14	f	t	t	t	2021-06-28 06:00:28.749257
347	2	1	4	2021-06-28 05:55:33.447205	2021-06-28 05:55:38.15687	2	f	t	t	t	2021-06-28 06:00:26.81185
356	2	3	6	2021-06-28 06:44:48.50699	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
358	2	3	6	2021-06-28 06:47:14.985279	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
391	8	29	1	2021-06-29 05:04:29.610404	2021-06-29 05:04:33.515103	3	f	f	t	t	2021-06-29 05:10:55.322166
360	2	3	6	2021-06-28 06:48:57.75961	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
361	2	3	6	2021-06-28 06:49:02.705786	2021-06-28 06:49:27.375924	14	f	t	t	t	2021-06-28 07:00:37.491329
357	2	3	6	2021-06-28 06:44:55.219181	2021-06-28 06:45:24.058649	12	f	t	t	t	2021-06-28 07:00:37.580724
359	2	3	6	2021-06-28 06:47:16.936665	2021-06-28 06:47:40.336458	12	f	t	t	t	2021-06-28 07:00:37.670984
362	2	3	6	2021-06-28 07:01:09.327546	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
423	8	29	2	2021-06-29 05:13:59.544754	2021-06-29 05:14:04.670579	6	f	f	t	t	2021-06-29 05:20:59.738977
364	2	2	3	2021-06-28 07:30:13.236666	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
366	2	3	6	2021-06-28 07:31:05.148792	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
414	8	29	2	2021-06-29 05:13:29.844978	2021-06-29 05:13:32.038363	1	f	f	t	t	2021-06-29 05:20:59.896616
368	2	2	3	2021-06-28 07:43:43.73139	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
370	2	2	3	2021-06-28 07:44:01.446133	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
406	8	29	1	2021-06-29 05:07:04.510493	2021-06-29 05:07:07.570389	3	f	f	t	t	2021-06-29 05:10:55.326527
355	2	1	4	2021-06-28 06:24:46.884198	2021-06-28 06:25:08.832445	3	f	t	t	t	2021-06-28 08:00:44.21522
367	2	3	6	2021-06-28 07:31:09.003515	2021-06-28 07:31:36.354513	16	f	t	t	t	2021-06-28 08:00:45.89267
363	2	3	6	2021-06-28 07:01:16.464071	2021-06-28 07:01:35.96033	11	f	t	t	t	2021-06-28 08:00:45.967564
371	2	2	3	2021-06-28 07:44:05.276897	2021-06-28 07:44:15.665426	6	f	t	t	t	2021-06-28 08:00:48.238871
365	2	2	3	2021-06-28 07:30:17.840011	2021-06-28 07:30:22.927734	0	f	t	t	t	2021-06-28 08:00:48.316191
369	2	2	3	2021-06-28 07:43:48.568776	2021-06-28 07:43:58.899905	0	f	t	t	t	2021-06-28 08:00:48.39461
372	6	1	2	2021-06-28 08:45:01.548692	1970-01-01 00:00:00	0	f	f	f	f	1970-01-01 00:00:00
374	6	1	2	2021-06-28 08:45:19.948806	1970-01-01 00:00:00	0	f	f	f	f	1970-01-01 00:00:00
373	6	1	2	2021-06-28 08:45:08.341378	2021-06-28 08:45:17.631315	6	f	f	t	t	2021-06-28 09:00:55.612069
375	9	1	3	2021-06-28 09:07:20.004488	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
376	2	2	6	2021-06-28 11:09:30.655013	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
407	8	29	1	2021-06-29 05:07:08.936104	2021-06-29 05:07:13.524657	3	f	f	t	t	2021-06-29 05:10:55.330861
377	2	2	6	2021-06-28 11:09:38.367753	2021-06-28 11:10:02.731504	12	f	t	t	t	2021-06-28 11:30:18.076418
378	2	3	6	2021-06-28 11:51:42.767581	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
381	2	1	4	2021-06-28 11:54:53.781157	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
382	2	1	4	2021-06-28 11:54:58.81432	2021-06-28 11:55:04.000132	3	f	t	t	t	2021-06-28 12:00:19.906769
380	2	1	4	2021-06-28 11:53:31.062896	2021-06-28 11:53:34.0365	0	f	f	t	t	2021-06-28 12:00:19.984468
379	2	3	6	2021-06-28 11:51:47.218119	2021-06-28 11:52:13.896703	18	f	t	t	t	2021-06-28 12:00:21.650289
383	2	1	1	2021-06-28 12:11:02.422314	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
384	2	3	4	2021-06-28 12:56:07.423032	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
404	8	29	1	2021-06-29 05:06:54.579158	2021-06-29 05:07:00.034959	2	f	f	t	t	2021-06-29 05:10:55.334919
386	2	3	4	2021-06-28 12:56:48.239041	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
387	2	3	4	2021-06-28 12:56:50.218064	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
385	2	3	4	2021-06-28 12:56:25.216607	2021-06-28 12:56:32.719754	3	f	t	t	t	2021-06-28 13:00:29.986226
390	3	29	1	2021-06-29 05:04:07.371115	2021-06-29 05:04:09.939282	2	f	f	t	t	2021-06-29 05:10:55.339029
416	8	29	2	2021-06-29 05:13:34.286983	2021-06-29 05:13:36.506821	1	f	f	t	t	2021-06-29 05:20:59.885562
415	3	29	2	2021-06-29 05:13:30.080006	2021-06-29 05:13:34.863041	6	f	f	t	t	2021-06-29 05:20:59.689084
433	8	29	2	2021-06-29 05:15:02.710397	2021-06-29 05:15:05.516009	2	f	f	t	t	2021-06-29 05:20:59.801196
388	8	29	1	2021-06-29 05:03:34.328488	2021-06-29 05:03:39.187863	2	f	f	t	t	2021-06-29 05:10:55.344475
393	8	29	1	2021-06-29 05:04:44.134119	2021-06-29 05:04:46.566606	1	f	f	t	t	2021-06-29 05:10:55.348894
402	8	29	1	2021-06-29 05:06:41.704735	2021-06-29 05:06:43.61613	1	f	f	t	t	2021-06-29 05:10:55.353481
428	8	29	2	2021-06-29 05:14:40.972253	2021-06-29 05:14:44.902899	3	f	f	t	t	2021-06-29 05:20:59.770074
399	8	29	1	2021-06-29 05:06:21.502664	2021-06-29 05:06:24.091846	1	f	f	t	t	2021-06-29 05:10:55.358437
398	8	29	1	2021-06-29 05:06:18.8634	2021-06-29 05:06:20.268111	0	f	f	t	t	2021-06-29 05:10:55.362647
389	3	29	1	2021-06-29 05:03:40.673805	2021-06-29 05:04:01.296408	17	f	f	t	t	2021-06-29 05:10:54.817553
394	8	29	1	2021-06-29 05:05:20.189161	2021-06-29 05:05:30.165167	11	f	f	t	t	2021-06-29 05:10:54.872418
408	8	29	1	2021-06-29 05:07:15.345916	2021-06-29 05:07:27.803765	10	f	f	t	t	2021-06-29 05:10:54.921889
403	8	29	1	2021-06-29 05:06:44.853574	2021-06-29 05:06:52.507266	7	f	f	t	t	2021-06-29 05:10:54.971538
395	8	29	1	2021-06-29 05:05:54.860883	2021-06-29 05:06:01.1202	6	f	f	t	t	2021-06-29 05:10:55.016476
396	8	29	1	2021-06-29 05:06:04.151942	2021-06-29 05:06:09.168692	5	f	f	t	t	2021-06-29 05:10:55.127179
401	8	29	1	2021-06-29 05:06:32.85358	2021-06-29 05:06:39.905291	5	f	f	t	t	2021-06-29 05:10:55.176191
397	8	29	1	2021-06-29 05:06:11.306811	2021-06-29 05:06:16.91678	5	f	f	t	t	2021-06-29 05:10:55.227118
400	8	29	1	2021-06-29 05:06:25.31453	2021-06-29 05:06:30.480471	4	f	f	t	t	2021-06-29 05:10:55.274197
409	8	29	1	2021-06-29 05:07:30.915459	2021-06-29 05:07:35.553131	3	f	f	t	t	2021-06-29 05:10:55.317648
392	8	29	1	2021-06-29 05:04:37.593112	2021-06-29 05:04:38.978032	0	f	f	t	t	2021-06-29 05:10:55.367468
405	8	29	1	2021-06-29 05:07:01.742438	2021-06-29 05:07:03.061132	0	f	f	t	t	2021-06-29 05:10:55.371445
431	8	29	2	2021-06-29 05:14:55.883878	2021-06-29 05:14:58.068436	1	f	f	t	t	2021-06-29 05:20:59.85848
438	8	29	2	2021-06-29 05:15:18.527155	2021-06-29 05:15:25.372367	9	f	f	t	t	2021-06-29 05:20:59.299825
410	3	29	2	2021-06-29 05:13:09.736058	2021-06-29 05:13:12.753293	1	f	f	t	t	2021-06-29 05:20:59.840449
425	8	29	2	2021-06-29 05:14:09.981001	2021-06-29 05:14:12.168399	1	f	f	t	t	2021-06-29 05:20:59.830163
421	3	30	7	2021-06-29 05:13:51.893362	2021-06-29 05:14:11.417768	6	f	f	t	t	2021-06-29 05:21:03.819178
420	8	29	2	2021-06-29 05:13:49.949882	2021-06-29 05:13:53.872482	4	f	f	t	t	2021-06-29 05:20:59.760351
422	8	29	2	2021-06-29 05:13:55.270764	2021-06-29 05:13:58.385179	4	f	f	t	t	2021-06-29 05:20:59.755127
412	8	29	2	2021-06-29 05:13:25.092781	2021-06-29 05:13:27.448413	1	f	f	t	t	2021-06-29 05:20:59.824884
427	3	30	6	2021-06-29 05:14:20.326178	2021-06-29 05:14:36.853962	9	f	f	t	t	2021-06-29 05:21:05.958257
413	3	29	2	2021-06-29 05:13:25.204442	2021-06-29 05:13:27.150385	1	f	f	t	t	2021-06-29 05:20:59.835697
429	8	29	2	2021-06-29 05:14:46.177376	2021-06-29 05:14:53.949476	8	f	f	t	t	2021-06-29 05:20:59.400023
434	3	29	2	2021-06-29 05:15:06.59177	2021-06-29 05:15:08.780046	3	f	f	t	t	2021-06-29 05:20:59.779907
418	8	29	2	2021-06-29 05:13:39.274041	2021-06-29 05:13:44.614295	8	f	f	t	t	2021-06-29 05:20:59.485987
411	3	29	2	2021-06-29 05:13:14.933886	2021-06-29 05:13:23.056058	9	f	f	t	t	2021-06-29 05:20:59.247858
435	8	29	2	2021-06-29 05:15:06.939242	2021-06-29 05:15:09.137845	1	f	f	t	t	2021-06-29 05:20:59.863652
419	8	29	2	2021-06-29 05:13:46.096942	2021-06-29 05:13:48.189693	2	f	f	t	t	2021-06-29 05:20:59.795936
424	8	29	2	2021-06-29 05:14:05.843037	2021-06-29 05:14:08.891371	2	f	f	t	t	2021-06-29 05:20:59.811097
437	8	29	2	2021-06-29 05:15:14.330662	2021-06-29 05:15:17.299069	3	f	f	t	t	2021-06-29 05:20:59.785299
436	8	29	2	2021-06-29 05:15:10.815209	2021-06-29 05:15:13.01192	1	f	f	t	t	2021-06-29 05:20:59.86824
417	3	29	2	2021-06-29 05:13:37.450378	2021-06-29 05:13:39.653953	1	f	f	t	t	2021-06-29 05:20:59.880735
432	8	29	2	2021-06-29 05:14:59.548102	2021-06-29 05:15:01.676836	2	f	f	t	t	2021-06-29 05:20:59.791117
426	8	29	2	2021-06-29 05:14:13.23794	2021-06-29 05:14:20.398022	9	f	f	t	t	2021-06-29 05:20:59.348371
430	3	29	2	2021-06-29 05:14:48.821661	2021-06-29 05:14:57.786895	12	f	f	t	t	2021-06-29 05:20:59.175807
439	8	29	2	2021-06-29 05:15:26.752759	2021-06-29 05:15:28.855795	1	f	f	t	t	2021-06-29 05:20:59.875198
449	9	29	3	2021-06-29 05:20:38.065478	2021-06-29 05:20:43.263199	2	f	f	t	t	2021-06-29 05:30:10.43686
440	8	29	2	2021-06-29 05:15:30.168373	2021-06-29 05:15:32.301166	7	f	f	t	t	2021-06-29 05:20:59.588303
441	8	29	2	2021-06-29 05:15:33.792793	2021-06-29 05:15:36.317637	4	f	f	t	t	2021-06-29 05:20:59.76533
442	8	29	2	2021-06-29 05:15:37.336567	2021-06-29 05:15:41.390897	4	f	f	t	t	2021-06-29 05:20:59.749885
448	8	29	2	2021-06-29 05:16:05.914084	2021-06-29 05:16:10.806069	8	f	f	t	t	2021-06-29 05:20:59.439221
443	8	29	2	2021-06-29 05:15:42.660531	2021-06-29 05:15:45.618214	2	f	f	t	t	2021-06-29 05:20:59.805988
444	8	29	2	2021-06-29 05:15:46.900596	2021-06-29 05:15:49.885796	2	f	f	t	t	2021-06-29 05:20:59.815776
447	8	29	2	2021-06-29 05:16:02.544241	2021-06-29 05:16:04.699159	1	f	f	t	t	2021-06-29 05:20:59.891381
446	8	29	2	2021-06-29 05:15:55.695816	2021-06-29 05:16:01.139147	5	f	f	t	t	2021-06-29 05:20:59.74446
445	8	29	2	2021-06-29 05:15:51.290929	2021-06-29 05:15:54.129496	3	f	f	t	t	2021-06-29 05:20:59.775022
476	3	30	5	2021-06-29 05:44:17.171931	2021-06-29 05:44:22.576792	1	f	f	t	t	2021-06-29 05:50:20.529458
451	3	29	3	2021-06-29 05:22:10.432478	1970-01-01 00:00:00	0	f	f	f	f	1970-01-01 00:00:00
477	3	30	4	2021-06-29 05:44:27.21858	2021-06-29 05:44:33.624747	3	f	f	t	t	2021-06-29 05:50:21.349722
501	3	31	3	2021-06-29 06:06:32.740088	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
507	8	29	2	2021-06-29 06:10:24.66022	2021-06-29 06:10:27.943619	3	f	f	t	t	2021-06-29 06:20:31.41273
503	3	30	6	2021-06-29 06:06:59.078827	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
462	8	29	3	2021-06-29 05:28:04.277734	1970-01-01 00:00:00	0	f	f	f	f	1970-01-01 00:00:00
500	3	31	3	2021-06-29 06:06:25.176731	2021-06-29 06:06:28.996239	0	f	t	t	t	2021-06-29 06:10:29.679572
481	8	29	2	2021-06-29 05:58:36.362298	2021-06-29 05:58:42.408465	6	f	f	t	t	2021-06-29 06:00:23.340607
467	8	29	3	2021-06-29 05:29:49.167479	1970-01-01 00:00:00	0	f	f	f	f	1970-01-01 00:00:00
450	9	29	3	2021-06-29 05:20:45.87429	2021-06-29 05:21:08.161456	42	f	f	t	t	2021-06-29 05:30:09.969452
458	8	29	3	2021-06-29 05:26:42.238084	2021-06-29 05:26:59.674394	34	f	f	t	t	2021-06-29 05:30:10.027004
455	8	29	3	2021-06-29 05:26:00.59527	2021-06-29 05:26:18.707891	20	f	f	t	t	2021-06-29 05:30:10.088606
459	8	29	3	2021-06-29 05:27:06.651185	2021-06-29 05:27:16.757507	10	f	f	t	t	2021-06-29 05:30:10.143818
461	8	29	3	2021-06-29 05:27:50.723919	2021-06-29 05:27:59.706696	10	f	f	t	t	2021-06-29 05:30:10.204753
457	8	29	3	2021-06-29 05:26:31.272505	2021-06-29 05:26:40.546643	10	f	f	t	t	2021-06-29 05:30:10.256017
456	8	29	3	2021-06-29 05:26:21.172594	2021-06-29 05:26:29.345885	8	f	f	t	t	2021-06-29 05:30:10.295586
466	8	29	3	2021-06-29 05:29:15.075004	2021-06-29 05:29:20.965221	4	f	f	t	t	2021-06-29 05:30:10.343427
464	8	29	3	2021-06-29 05:29:01.590467	2021-06-29 05:29:07.881966	2	f	f	t	t	2021-06-29 05:30:10.388201
460	8	29	3	2021-06-29 05:27:43.110268	2021-06-29 05:27:47.601339	0	f	f	t	t	2021-06-29 05:30:10.443222
463	8	29	3	2021-06-29 05:28:56.721846	2021-06-29 05:29:00.046702	0	f	f	t	t	2021-06-29 05:30:10.44842
465	8	29	3	2021-06-29 05:29:09.525243	2021-06-29 05:29:13.507774	0	f	f	t	t	2021-06-29 05:30:10.45347
454	3	31	1	2021-06-29 05:22:31.558477	2021-06-29 05:22:41.702964	8	f	f	t	t	2021-06-29 05:30:12.843584
452	3	31	1	2021-06-29 05:22:21.79034	2021-06-29 05:22:26.756914	4	f	f	t	t	2021-06-29 05:30:12.919939
453	3	31	1	2021-06-29 05:22:28.818216	2021-06-29 05:22:29.517929	0	f	f	t	t	2021-06-29 05:30:12.999241
482	8	29	2	2021-06-29 05:58:44.179278	2021-06-29 05:58:49.376341	6	f	f	t	t	2021-06-29 06:00:23.389505
478	8	29	2	2021-06-29 05:58:19.333829	2021-06-29 05:58:24.169518	5	f	f	t	t	2021-06-29 06:00:23.437316
479	8	29	2	2021-06-29 05:58:26.051847	2021-06-29 05:58:31.087005	5	f	f	t	t	2021-06-29 06:00:23.483089
483	8	29	2	2021-06-29 05:58:50.971804	2021-06-29 05:58:55.193533	5	f	f	t	t	2021-06-29 06:00:23.522683
480	8	29	2	2021-06-29 05:58:32.400399	2021-06-29 05:58:34.772474	1	f	f	t	t	2021-06-29 06:00:23.567258
502	3	31	3	2021-06-29 06:06:35.767949	2021-06-29 06:06:39.297266	0	f	t	t	t	2021-06-29 06:10:29.731514
470	8	29	2	2021-06-29 05:30:30.024781	2021-06-29 05:30:36.896266	7	f	f	t	t	2021-06-29 05:40:13.941451
469	8	29	2	2021-06-29 05:30:25.024283	2021-06-29 05:30:28.90734	3	f	f	t	t	2021-06-29 05:40:13.991134
468	8	29	2	2021-06-29 05:30:20.236727	2021-06-29 05:30:22.418155	2	f	f	t	t	2021-06-29 05:40:14.039137
474	8	30	7	2021-06-29 05:32:11.037337	2021-06-29 05:32:26.142624	5	f	f	t	t	2021-06-29 05:40:15.40202
473	8	30	7	2021-06-29 05:31:37.03687	2021-06-29 05:31:44.939934	2	f	f	t	t	2021-06-29 05:40:15.449825
471	8	30	7	2021-06-29 05:31:20.724284	2021-06-29 05:31:27.72886	1	f	f	t	t	2021-06-29 05:40:15.504108
472	8	30	7	2021-06-29 05:31:29.514316	2021-06-29 05:31:35.558186	1	f	f	t	t	2021-06-29 05:40:15.558293
475	8	31	3	2021-06-29 05:32:48.573384	2021-06-29 05:32:51.987525	0	f	f	t	t	2021-06-29 05:40:17.565124
490	3	31	3	2021-06-29 06:04:44.806358	2021-06-29 06:04:48.599237	0	f	t	t	t	2021-06-29 06:10:29.809371
487	3	31	3	2021-06-29 06:04:34.529315	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
498	3	31	3	2021-06-29 06:06:16.142493	2021-06-29 06:06:19.612426	0	f	t	t	t	2021-06-29 06:10:29.900028
510	8	29	2	2021-06-29 06:10:39.591622	2021-06-29 06:10:41.466836	3	f	f	t	t	2021-06-29 06:20:31.445338
516	8	29	2	2021-06-29 06:11:17.086598	2021-06-29 06:11:19.44075	3	f	f	t	t	2021-06-29 06:20:31.44972
492	3	31	3	2021-06-29 06:05:00.993538	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
520	9	29	1	2021-06-29 06:23:50.620803	2021-06-29 06:23:53.369571	1	f	f	t	t	2021-06-29 06:30:34.780425
497	3	31	3	2021-06-29 06:06:11.854049	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
499	3	31	3	2021-06-29 06:06:22.695426	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
506	8	29	3	2021-06-29 06:09:49.737533	1970-01-01 00:00:00	0	f	f	f	f	1970-01-01 00:00:00
496	8	29	3	2021-06-29 06:05:14.978849	2021-06-29 06:05:40.922168	26	f	f	t	t	2021-06-29 06:10:26.566016
484	8	29	3	2021-06-29 06:04:18.71827	2021-06-29 06:04:25.630818	2	f	f	t	t	2021-06-29 06:10:26.613289
491	8	29	3	2021-06-29 06:04:50.883807	2021-06-29 06:04:55.020467	2	f	f	t	t	2021-06-29 06:10:26.655886
495	8	29	3	2021-06-29 06:05:07.129502	2021-06-29 06:05:13.470249	2	f	f	t	t	2021-06-29 06:10:26.695208
489	8	29	3	2021-06-29 06:04:44.67342	2021-06-29 06:04:49.108454	0	f	f	t	t	2021-06-29 06:10:26.731651
485	8	29	3	2021-06-29 06:04:27.566882	2021-06-29 06:04:32.32472	0	f	f	t	t	2021-06-29 06:10:26.774289
493	8	29	3	2021-06-29 06:05:01.060275	2021-06-29 06:05:05.652004	0	f	f	t	t	2021-06-29 06:10:26.817446
505	8	29	3	2021-06-29 06:09:44.111665	2021-06-29 06:09:48.347601	0	f	f	t	t	2021-06-29 06:10:26.851477
486	8	29	3	2021-06-29 06:04:33.749127	2021-06-29 06:04:37.806179	0	f	f	t	t	2021-06-29 06:10:26.904502
488	8	29	3	2021-06-29 06:04:39.196249	2021-06-29 06:04:43.242293	0	f	f	t	t	2021-06-29 06:10:26.944321
504	3	30	6	2021-06-29 06:07:22.695885	2021-06-29 06:07:46.834358	13	f	t	t	t	2021-06-29 06:10:27.937959
531	9	30	5	2021-06-29 06:27:24.69683	2021-06-29 06:27:26.834979	0	f	f	t	t	2021-06-29 06:30:35.626858
494	3	31	3	2021-06-29 06:05:04.497673	2021-06-29 06:05:15.928551	12	f	t	t	t	2021-06-29 06:10:29.621705
524	8	30	5	2021-06-29 06:25:19.271602	2021-06-29 06:25:28.574043	4	f	f	t	t	2021-06-29 06:30:35.550035
511	8	29	2	2021-06-29 06:10:46.912994	2021-06-29 06:10:53.906627	11	f	f	t	t	2021-06-29 06:20:31.013764
517	3	29	2	2021-06-29 06:13:28.057099	1970-01-01 00:00:00	0	f	f	f	f	1970-01-01 00:00:00
518	3	29	2	2021-06-29 06:13:58.000141	1970-01-01 00:00:00	0	f	f	f	f	1970-01-01 00:00:00
508	8	29	2	2021-06-29 06:10:29.364473	2021-06-29 06:10:32.586883	11	f	f	t	t	2021-06-29 06:20:31.109642
519	8	29	2	2021-06-29 06:16:38.7115	2021-06-29 06:16:48.673867	20	f	f	t	t	2021-06-29 06:20:30.905868
513	8	29	2	2021-06-29 06:11:00.876024	2021-06-29 06:11:08.055095	18	f	f	t	t	2021-06-29 06:20:30.964063
515	8	29	2	2021-06-29 06:11:13.506353	2021-06-29 06:11:15.638776	8	f	f	t	t	2021-06-29 06:20:31.15837
512	8	29	2	2021-06-29 06:10:55.32774	2021-06-29 06:10:58.493671	8	f	f	t	t	2021-06-29 06:20:31.199304
509	8	29	2	2021-06-29 06:10:33.845357	2021-06-29 06:10:38.334094	6	f	f	t	t	2021-06-29 06:20:31.339572
514	8	29	2	2021-06-29 06:11:09.382973	2021-06-29 06:11:12.357781	5	f	f	t	t	2021-06-29 06:20:31.375848
529	8	30	5	2021-06-29 06:26:02.736426	2021-06-29 06:26:10.820483	2	f	f	t	t	2021-06-29 06:30:35.60613
528	8	30	5	2021-06-29 06:25:58.167482	2021-06-29 06:26:01.311015	1	f	f	t	t	2021-06-29 06:30:35.619013
525	8	30	5	2021-06-29 06:25:34.116184	2021-06-29 06:25:37.422877	1	f	f	t	t	2021-06-29 06:30:35.614235
527	8	30	5	2021-06-29 06:25:43.983158	1970-01-01 00:00:00	0	f	f	f	f	1970-01-01 00:00:00
522	8	30	5	2021-06-29 06:25:08.242603	2021-06-29 06:25:13.78892	0	f	f	t	t	2021-06-29 06:30:35.623034
526	8	30	5	2021-06-29 06:25:38.858808	2021-06-29 06:25:42.672069	1	f	f	t	t	2021-06-29 06:30:35.610159
530	8	30	5	2021-06-29 06:26:12.176322	1970-01-01 00:00:00	0	f	f	f	f	1970-01-01 00:00:00
523	8	30	5	2021-06-29 06:25:15.644638	2021-06-29 06:25:17.745961	0	f	f	t	t	2021-06-29 06:30:35.63157
521	9	29	1	2021-06-29 06:23:55.845653	2021-06-29 06:24:00.866378	4	f	f	t	t	2021-06-29 06:30:34.726384
576	3	29	2	2021-06-29 08:18:51.094026	2021-06-29 08:18:59.942551	15	f	f	t	t	2021-06-29 08:20:07.397733
532	9	30	5	2021-06-29 06:27:28.552835	2021-06-29 06:27:34.54717	3	f	f	t	t	2021-06-29 06:30:35.60196
533	9	30	4	2021-06-29 06:27:43.027907	2021-06-29 06:27:56.30219	11	f	f	t	t	2021-06-29 06:30:36.373929
562	3	33	3	2021-06-29 07:37:48.600587	2021-06-29 07:38:00.281169	22	f	f	t	t	2021-06-29 07:40:37.643982
561	3	33	3	2021-06-29 07:37:37.343207	2021-06-29 07:37:46.929412	20	f	f	t	t	2021-06-29 07:40:37.722201
559	3	33	3	2021-06-29 07:37:14.629695	2021-06-29 07:37:24.364405	12	f	f	t	t	2021-06-29 07:40:37.849805
556	3	33	3	2021-06-29 07:36:51.115658	2021-06-29 07:37:00.996049	8	f	f	t	t	2021-06-29 07:40:37.901838
560	3	33	3	2021-06-29 07:37:27.794828	2021-06-29 07:37:35.813805	4	f	f	t	t	2021-06-29 07:40:37.980228
558	3	33	3	2021-06-29 07:37:08.097815	2021-06-29 07:37:13.056713	2	f	f	t	t	2021-06-29 07:40:38.057634
555	3	33	3	2021-06-29 07:36:44.075429	2021-06-29 07:36:49.489175	2	f	f	t	t	2021-06-29 07:40:38.134842
553	3	33	3	2021-06-29 07:36:33.002324	2021-06-29 07:36:36.477942	0	f	f	t	t	2021-06-29 07:40:38.213878
557	3	33	3	2021-06-29 07:37:02.820832	2021-06-29 07:37:06.47553	0	f	f	t	t	2021-06-29 07:40:38.292194
535	8	29	2	2021-06-29 06:32:25.995832	2021-06-29 06:32:34.8071	20	f	f	t	t	2021-06-29 06:40:37.9442
536	8	29	2	2021-06-29 06:32:36.788546	2021-06-29 06:32:41.702926	11	f	f	t	t	2021-06-29 06:40:37.98729
537	8	29	2	2021-06-29 06:32:44.083017	2021-06-29 06:32:49.376189	10	f	f	t	t	2021-06-29 06:40:38.03385
538	8	29	2	2021-06-29 06:32:50.571801	2021-06-29 06:32:53.494594	4	f	f	t	t	2021-06-29 06:40:38.081291
539	8	29	2	2021-06-29 06:32:55.00512	2021-06-29 06:32:59.398785	4	f	f	t	t	2021-06-29 06:40:38.117868
534	8	29	2	2021-06-29 06:32:22.796091	2021-06-29 06:32:24.730148	2	f	f	t	t	2021-06-29 06:40:38.15937
541	8	30	6	2021-06-29 06:33:27.33624	2021-06-29 06:34:24.126516	38	f	f	t	t	2021-06-29 06:40:39.890006
542	8	30	6	2021-06-29 06:34:28.03918	2021-06-29 06:35:12.360115	28	f	f	t	t	2021-06-29 06:40:39.934549
540	8	30	6	2021-06-29 06:33:15.31267	2021-06-29 06:33:25.437417	1	f	f	t	t	2021-06-29 06:40:39.971681
543	3	31	1	2021-06-29 06:54:52.967059	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
554	3	33	3	2021-06-29 07:36:38.890082	2021-06-29 07:36:42.448963	0	f	f	t	t	2021-06-29 07:40:38.369107
546	3	31	1	2021-06-29 06:57:40.731136	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
578	3	30	7	2021-06-29 08:19:24.759476	2021-06-29 08:19:32.420061	2	f	f	t	t	2021-06-29 08:20:08.304996
548	3	31	1	2021-06-29 06:57:50.854301	2021-06-29 06:58:02.762066	12	f	t	t	t	2021-06-29 07:00:47.379196
545	3	31	1	2021-06-29 06:55:31.345222	2021-06-29 06:55:42.655068	10	f	t	t	t	2021-06-29 07:00:47.459799
544	3	31	1	2021-06-29 06:54:56.377115	2021-06-29 06:55:00.962066	3	f	t	t	t	2021-06-29 07:00:47.534037
547	3	31	1	2021-06-29 06:57:43.168411	2021-06-29 06:57:44.063728	0	f	t	t	t	2021-06-29 07:00:47.610855
577	3	30	4	2021-06-29 08:19:14.57467	2021-06-29 08:19:18.951096	3	f	f	t	t	2021-06-29 08:20:09.789085
575	3	35	2	2021-06-29 08:18:16.995975	2021-06-29 08:18:41.3376	39	f	f	t	t	2021-06-29 08:20:15.53784
549	9	29	2	2021-06-29 07:13:53.183613	2021-06-29 07:14:04.757265	14	f	f	t	t	2021-06-29 07:21:03.774127
550	9	33	2	2021-06-29 07:17:19.405938	2021-06-29 07:17:27.603295	10	f	f	t	t	2021-06-29 07:21:20.912916
552	3	35	2	2021-06-29 07:19:07.337227	2021-06-29 07:19:16.102253	11	f	f	t	t	2021-06-29 07:21:26.004217
551	3	35	2	2021-06-29 07:18:59.624112	2021-06-29 07:19:04.801038	7	f	f	t	t	2021-06-29 07:21:26.155298
579	9	29	2	2021-06-30 06:55:28.002277	1970-01-01 00:00:00	0	f	f	f	f	1970-01-01 00:00:00
580	9	29	3	2021-06-30 07:09:28.554633	1970-01-01 00:00:00	0	f	f	f	f	1970-01-01 00:00:00
581	9	34	6	2021-06-30 07:10:10.408459	2021-06-30 07:10:27.451526	2	f	f	t	t	2021-06-30 07:10:31.306624
582	9	34	6	2021-06-30 07:10:29.168333	2021-06-30 07:11:16.517897	29	f	f	t	t	2021-06-30 07:20:36.194813
583	9	34	6	2021-06-30 07:47:58.0972	1970-01-01 00:00:00	0	f	f	f	f	1970-01-01 00:00:00
563	3	29	2	2021-06-29 07:39:58.448568	1970-01-01 00:00:00	0	f	f	f	f	1970-01-01 00:00:00
569	3	33	2	2021-06-29 07:42:35.52305	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
571	3	33	2	2021-06-29 07:42:53.175513	1970-01-01 00:00:00	0	f	t	f	f	1970-01-01 00:00:00
564	3	29	1	2021-06-29 07:40:08.347763	2021-06-29 07:40:24.478854	16	f	f	t	t	2021-06-29 07:50:41.705768
568	3	33	2	2021-06-29 07:42:12.683461	2021-06-29 07:42:26.724883	22	f	f	t	t	2021-06-29 07:50:45.083358
566	3	33	2	2021-06-29 07:41:50.618663	2021-06-29 07:41:58.756824	13	f	f	t	t	2021-06-29 07:50:45.160532
567	3	33	2	2021-06-29 07:42:00.422272	2021-06-29 07:42:08.668035	13	f	f	t	t	2021-06-29 07:50:45.240861
565	3	33	2	2021-06-29 07:41:36.741697	2021-06-29 07:41:44.785435	12	f	f	t	t	2021-06-29 07:50:45.318594
572	3	33	2	2021-06-29 07:42:55.767838	2021-06-29 07:43:00.947603	9	f	t	t	t	2021-06-29 07:50:45.396499
570	3	33	2	2021-06-29 07:42:43.835041	2021-06-29 07:42:47.834995	6	f	t	t	t	2021-06-29 07:50:45.474417
573	3	33	2	2021-06-29 07:43:04.912995	2021-06-29 07:43:08.835547	6	f	f	t	t	2021-06-29 07:50:45.552201
574	3	33	2	2021-06-29 07:43:11.78549	2021-06-29 07:43:13.666991	3	f	f	t	t	2021-06-29 07:50:45.656201
587	9	35	1	2021-06-30 07:50:27.710143	2021-06-30 07:50:51.685445	22	f	f	t	t	2021-06-30 08:00:04.908395
585	9	35	1	2021-06-30 07:50:18.686664	2021-06-30 07:50:22.517365	3	f	f	t	t	2021-06-30 08:00:04.957635
586	9	35	1	2021-06-30 07:50:24.136921	2021-06-30 07:50:26.367227	1	f	f	t	t	2021-06-30 08:00:04.999278
584	9	35	1	2021-06-30 07:50:14.609537	2021-06-30 07:50:17.033258	0	f	f	t	t	2021-06-30 08:00:05.050933
\.


--
-- Data for Name: item; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.item (id, title, subtitle, img_url, content, type_id, price, quantity, status) FROM stdin;
1	Gems Pack 1		https://wrongurl		1	0.99	100	2
2	Gems Pack 2		https://wrongurl		1	1.99	200	2
3	Gems Pack 3		https://wrongurl		1	4.99	300	2
4	Gems Pack 4		https:'//wrongurl		1	9.99	500	2
5	Gems Pack 6		https://wrongurl		1	99.99	10000	2
\.


--
-- Data for Name: item_type; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.item_type (id, title) FROM stdin;
0	Not Selected
1	Gem
\.


--
-- Data for Name: prize; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.prize (id, title, subtitle, img_url, content, type_id, tickets_required, duration_days, duration_hours, timezone, scheduled_on, is_repeat, repeated_on, status, status_progress, tickets_collected, scheduled_off, tickets_collected_on) FROM stdin;
11	abc	abc	https://abc		1	0	0	0	0	2021-06-22 09:57:00	f	{0}	1	0	0	2021-06-22 09:57:00	1970-01-01 00:00:00
4	M&H $50 Gift Card		https://esm-cdn.sgp1.digitaloceanspaces.com/prizes/M&H_GiftCard/M&H%20Gift%20Card.png		4	0	0	12	8	2021-06-28 13:40:13	t	{1,2,3,4,5,6,7}	3	9999	0	2021-06-29 01:40:13	2021-06-28 13:54:00.286572
13	eee	eee	https://eee		1	0	0	0	0	2021-06-22 10:01:00	f	{0}	1	0	0	2021-06-22 10:01:00	1970-01-01 00:00:00
14	eee	eee	https://eee		1	0	0	0	0	2021-06-22 10:02:00	f	{0}	1	0	0	2021-06-22 10:02:00	1970-01-01 00:00:00
16	abceee	abceee	https://abc		1	0	0	0	0	2021-06-22 10:15:00	f	{0}	1	0	0	2021-06-22 10:15:00	1970-01-01 00:00:00
3	iPhone 12		https://esm-cdn.sgp1.digitaloceanspaces.com/prizes/iPhone12/iphone%2012_02.png		2	7000	0	0	8	2021-06-18 12:00:00	f	{0}	3	9999	0	2021-06-18 12:00:00	2021-06-28 13:54:00.296692
2	Nintendo Switch (V2)		https://esm-cdn.sgp1.digitaloceanspaces.com/prizes/NintendoSwitch/Nintendo%20Switch%20V2.png		2	10000	0	0	0	2021-06-22 06:00:00	f	{0}	3	9999	9909	2021-06-22 06:00:00	2021-06-28 13:54:00.306768
12	aa	aa	https://abc		1	0	0	0	0	2021-06-22 09:59:00	f	{0}	1	0	0	2021-06-22 09:59:00	1970-01-01 00:00:00
20	ssee	ssee	https://ssee		3	0	0	0	0	2021-06-22 10:24:00	f	{0}	1	0	0	2021-06-22 10:24:00	1970-01-01 00:00:00
21	Test 2.0		https://test		1	0	0	0	8	2021-06-21 14:59:00	f	{0}	1	0	0	2021-06-21 14:59:00	1970-01-01 00:00:00
22	few	few	https://few		2	0	0	0	0	2021-06-22 10:25:00	f	{0}	1	0	0	2021-06-22 10:25:00	1970-01-01 00:00:00
18	eessff	eessff	https://eessff		1	0	0	0	0	2021-06-22 10:22:00	f	{0}	1	0	0	2021-06-22 10:22:00	1970-01-01 00:00:00
15	eesaa	eesaa	https://abc		1	0	0	0	0	2021-06-22 10:06:00	f	{0}	1	0	0	2021-06-22 10:06:00	1970-01-01 00:00:00
1	PlayStation 5 (Digital Edition)		https://esm-cdn.sgp1.digitaloceanspaces.com/prizes/Playstation_5/PlayStation%205.png		1	10000	0	0	8	2021-06-18 12:00:00	f	{0}	3	9999	5110	2021-06-18 12:00:00	2021-06-28 13:54:00.317796
5	Segway Kickscooter MAX		https://esm-cdn.sgp1.digitaloceanspaces.com/prizes/Segway_NinebotKickscooterMAX/Segway%20Ninebot%20KickScooter%20MAX%20Electric%20Scooter.png		3	0	0	12	8	2021-06-30 12:00:00	f	{0}	3	999	0	2021-07-01 00:00:00	2021-06-29 02:08:08.412342
17	New Test		https://test		3	0	0	0	8	2021-06-21 13:16:00	f	{0}	1	0	0	2021-06-21 13:16:00	1970-01-01 00:00:00
26	test 4.0		https://few		2	0	0	0	0	2021-06-22 10:29:00	f	{0}	1	0	0	2021-06-22 10:29:00	1970-01-01 00:00:00
28	Yamaha PAS Ami (2019)		https://esm-cdn.sgp1.digitaloceanspaces.com/prizes/Yamaha_PASAmi2019/Yamaha%20PAS%20Ami%20%282019%29.png		2	10000	0	0	8	2021-06-25 07:30:00	f	{0}	3	9999	8826	2021-06-25 07:30:00	2021-06-28 13:53:00.177675
24	test 3.0		https://few		2	0	0	0	8	2021-06-22 10:28:00	f	{0}	1	0	0	2021-06-22 10:28:00	1970-01-01 00:00:00
10	Title		https://wrongurl		2	0	0	0	8	2021-06-30 04:53:00	f	{0}	3	0	0	2021-06-30 04:53:00	1970-01-01 00:00:00
7	Tupperware Food Containers		https://esm-cdn.sgp1.digitaloceanspaces.com/prizes/Tupperware_FoodContainers/Tupperware%20food%20containers.png		2	7000	0	0	8	2021-06-25 07:30:00	f	{0}	3	9999	6333	2021-06-25 07:30:00	2021-06-28 13:53:00.188631
19	eess	eess	https://eess		2	0	0	0	0	2021-06-22 10:23:00	f	{0}	1	0	0	2021-06-22 10:23:00	1970-01-01 00:00:00
23	fewfew	fewf	https://few		1	0	0	0	0	2021-06-22 10:25:00	f	{0}	1	0	0	2021-06-22 10:25:00	1970-01-01 00:00:00
8	Test 1		https://cloud.digitalocean.com/space		1	10000	0	0	0	2021-06-30 09:49:00	f	{0}	1	0	0	2021-06-30 09:49:00	1970-01-01 00:00:00
25	sss	sss	https://sss		2	0	0	0	0	2021-06-22 10:28:00	f	{0}	1	0	0	2021-06-22 10:28:00	1970-01-01 00:00:00
34	iMac 24 inch		https://esm-cdn.sgp1.digitaloceanspaces.com/prizes/iMac_24inch/iMac%2024%20inch.png		2	7000	0	0	8	2021-06-29 07:00:00	f	{0}	2	1	600	2021-06-29 07:00:00	2021-06-30 23:44:41.506579
31	iPhone 12		https://esm-cdn.sgp1.digitaloceanspaces.com/prizes/iPhone12/iphone%2012_02.png		2	5000	0	0	8	2021-06-29 05:00:00	f	{0}	2	1	150	2021-06-29 05:00:00	2021-06-30 23:44:41.536091
32	Amazon.com $50 Gift Card		https://esm-cdn.sgp1.digitaloceanspaces.com/prizes/Amazon_GiftCard/Amazon%20$50%20voucher.png		4	0	0	2	0	2021-06-29 05:00:00	f	{0}	2	999	0	2021-06-29 07:00:00	2021-06-30 23:44:41.531338
29	PlayStation 5 (Digital)		https://esm-cdn.sgp1.digitaloceanspaces.com/prizes/Playstation_5/PlayStation%205.png		1	10000	0	0	8	2021-06-29 05:00:00	f	{0}	2	1	1500	2021-06-29 05:00:00	2021-06-30 23:44:41.57922
36	H&M $50 Gift Card		https://esm-cdn.sgp1.digitaloceanspaces.com/prizes/M&H_GiftCard/M&H%20Gift%20Card.png		4	0	0	3	8	2021-06-29 07:00:00	f	{0}	2	999	0	2021-06-29 10:00:00	2021-06-30 23:44:41.488432
30	Segway Ninebot Kickscooter		https://esm-cdn.sgp1.digitaloceanspaces.com/prizes/Segway_NinebotKickscooterMAX/Segway%20Ninebot%20KickScooter%20MAX%20Electric%20Scooter.png		2	7000	0	0	8	2021-06-29 05:00:00	f	{0}	2	1	4150	2021-06-29 05:00:00	2021-06-30 23:44:41.566571
35	Evian x Off-White Water Bottle Light Blue		https://esm-cdn.sgp1.digitaloceanspaces.com/prizes/EvianxOff_WaterBottle/%20UNCOMMON%20KL%20Evian%20x%20Off-White%20Water%20Bottle%20Light%20Blue.png		2	3000	0	0	8	2021-06-29 07:00:00	f	{0}	2	1	0	2021-06-29 07:00:00	2021-06-30 23:44:41.494257
33	Nintendo Switch (V2)		https://esm-cdn.sgp1.digitaloceanspaces.com/prizes/NintendoSwitch/Nintendo%20Switch%20V2.png		1	5000	0	0	8	2021-06-29 07:00:00	f	{0}	2	1	200	2021-06-29 07:00:00	2021-06-30 23:44:41.519151
\.


--
-- Data for Name: prize_closed; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.prize_closed (id, prize_id, tickets_collected, batch, status, created_on) FROM stdin;
1	3	0	0	1	2021-06-18 10:21:29.172718
2	5	0	0	1	2021-06-19 00:00:33.378063
3	4	0	0	1	2021-06-19 00:00:34.158767
4	4	0	1	1	2021-06-19 12:01:31.276637
5	4	0	2	1	2021-06-20 00:02:09.876216
6	4	0	3	1	2021-06-20 04:02:24.986267
7	4	0	4	1	2021-06-20 16:02:42.604558
8	4	0	5	1	2021-06-21 04:02:53.727245
9	4	0	6	1	2021-06-21 16:03:14.551814
10	4	0	7	1	2021-06-22 04:04:08.191609
11	3	7788	1	1	2021-06-22 13:10:32.262881
12	4	0	8	1	2021-06-23 02:20:31.319754
13	1	13474	0	1	2021-06-23 02:59:11.510444
14	4	0	9	1	2021-06-23 14:21:02.216213
15	4	0	10	1	2021-06-24 02:21:53.417077
16	3	8448	2	1	2021-06-24 09:01:24.197961
17	1	10112	1	1	2021-06-24 09:37:27.909566
18	4	0	11	1	2021-06-24 14:22:40.485583
19	4	0	12	1	2021-06-25 02:23:28.692018
20	3	7503	3	1	2021-06-25 06:00:44.607027
21	1	11278	2	1	2021-06-25 06:30:48.540539
22	1	10430	3	1	2021-06-25 09:31:08.729649
23	4	0	13	1	2021-06-25 14:23:40.379679
24	4	0	14	1	2021-06-26 02:23:45.392673
25	4	0	15	1	2021-06-27 05:39:58.189789
26	4	0	16	1	2021-06-27 17:40:04.51584
27	3	7311	4	1	2021-06-28 05:01:09.380063
28	4	0	17	1	2021-06-28 05:40:14.253666
29	1	10419	4	1	2021-06-28 08:01:27.579385
30	3	7256	5	1	2021-06-28 13:00:54.980122
31	36	0	0	1	2021-06-29 03:35:57.012384
32	29	10950	0	1	2021-06-29 05:41:12.111426
33	29	11385	1	1	2021-06-29 06:41:19.573024
34	32	0	0	1	2021-06-29 07:00:23.076781
35	31	5900	0	1	2021-06-29 07:01:24.0113
36	33	6375	0	1	2021-06-29 07:51:29.986412
37	35	3150	0	1	2021-06-30 08:01:00.907622
\.


--
-- Data for Name: prize_pool; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.prize_pool (id, prize_id, user_id, game_id, win_from, tickets, created_on, is_closed, closed_on) FROM stdin;
568	29	8	0	1	150	2021-06-29 05:01:27.918685	t	2021-06-29 06:41:18.875516
626	29	8	0	1	200	2021-06-29 06:02:47.897566	t	2021-06-29 06:41:18.875516
654	29	3	0	1	150	2021-06-29 06:16:37.488121	t	2021-06-29 06:41:18.875516
671	29	8	0	1	50	2021-06-29 06:31:41.288871	t	2021-06-29 06:41:18.875516
140	0	6	0	1	25	2021-06-24 09:37:42.123512	f	1970-01-01 00:00:00
687	31	3	1	3	500	2021-06-29 07:00:47.374839	t	2021-06-29 07:01:23.226086
688	31	3	1	3	450	2021-06-29 07:00:47.455354	t	2021-06-29 07:01:23.226086
689	31	3	1	3	400	2021-06-29 07:00:47.530542	t	2021-06-29 07:01:23.226086
398	3	3	6	3	520	2021-06-28 05:00:20.884356	t	2021-06-28 13:00:54.210959
27	0	2	0	1	50	2021-06-21 08:05:30.910008	f	1970-01-01 00:00:00
253	3	3	4	3	515	2021-06-25 07:00:11.192092	t	2021-06-28 13:00:54.210959
254	3	3	4	3	464	2021-06-25 07:00:11.275573	t	2021-06-28 13:00:54.210959
163	0	2	0	1	150	2021-06-24 11:15:58.728971	f	1970-01-01 00:00:00
255	3	3	6	3	515	2021-06-25 07:00:12.102003	t	2021-06-28 13:00:54.210959
167	3	2	0	1	150	2021-06-24 11:31:11.386853	t	2021-06-28 13:00:54.210959
204	3	2	4	2	0	2021-06-25 03:52:12.865757	t	2021-06-28 13:00:54.210959
166	0	2	0	1	150	2021-06-24 11:30:35.338312	f	1970-01-01 00:00:00
565	3	2	6	3	500	2021-06-28 12:00:21.645719	t	2021-06-28 13:00:54.210959
690	31	3	1	3	350	2021-06-29 07:00:47.607217	t	2021-06-29 07:01:23.226086
704	33	3	0	1	50	2021-06-29 07:39:40.077862	t	2021-06-29 07:51:29.206297
291	0	6	0	1	50	2021-06-25 07:57:42.734476	f	1970-01-01 00:00:00
308	0	6	0	1	50	2021-06-25 08:07:00.897956	f	1970-01-01 00:00:00
311	0	6	0	1	300	2021-06-25 08:15:17.486281	f	1970-01-01 00:00:00
209	3	2	6	2	0	2021-06-25 03:58:46.201182	t	2021-06-28 13:00:54.210959
715	33	3	2	2	0	2021-06-29 07:42:47.847023	t	2021-06-29 07:51:29.206297
716	33	3	2	2	0	2021-06-29 07:43:00.961116	t	2021-06-29 07:51:29.206297
201	0	2	0	1	150	2021-06-25 03:34:07.3285	f	1970-01-01 00:00:00
323	0	6	0	1	50	2021-06-25 08:23:54.30108	f	1970-01-01 00:00:00
219	3	2	6	2	0	2021-06-25 04:16:30.044474	t	2021-06-28 13:00:54.210959
223	3	2	6	2	55	2021-06-25 04:44:54.344271	t	2021-06-28 13:00:54.210959
332	0	6	0	1	200	2021-06-25 08:39:15.082474	f	1970-01-01 00:00:00
232	3	2	6	2	55	2021-06-25 05:03:36.597238	t	2021-06-28 13:00:54.210959
3	3	2	1	3	500	2021-06-21 05:00:58.322324	t	2021-06-28 13:00:54.210959
18	3	6	6	3	500	2021-06-21 08:00:11.378534	t	2021-06-28 13:00:54.210959
19	3	6	6	3	450	2021-06-21 08:00:11.450479	t	2021-06-28 13:00:54.210959
427	0	6	0	1	200	2021-06-28 06:07:11.378617	f	1970-01-01 00:00:00
430	0	6	0	1	300	2021-06-28 06:08:09.515735	f	1970-01-01 00:00:00
31	3	3	0	1	200	2021-06-21 09:22:27.162318	t	2021-06-28 13:00:54.210959
32	3	6	4	3	510	2021-06-21 10:00:07.268229	t	2021-06-28 13:00:54.210959
33	3	6	4	3	459	2021-06-21 10:00:07.362074	t	2021-06-28 13:00:54.210959
450	3	2	6	2	0	2021-06-28 06:45:24.069873	t	2021-06-28 13:00:54.210959
439	0	6	0	1	10	2021-06-28 06:19:37.330355	f	1970-01-01 00:00:00
446	0	6	0	1	50	2021-06-28 06:34:02.441406	f	1970-01-01 00:00:00
34	3	6	4	3	408	2021-06-21 10:00:07.440404	t	2021-06-28 13:00:54.210959
35	3	6	4	3	357	2021-06-21 10:00:07.517438	t	2021-06-28 13:00:54.210959
36	3	6	4	3	306	2021-06-21 10:00:07.616783	t	2021-06-28 13:00:54.210959
452	3	2	6	2	0	2021-06-28 06:49:27.386028	t	2021-06-28 13:00:54.210959
460	3	6	0	1	50	2021-06-28 06:58:19.802054	t	2021-06-28 13:00:54.210959
463	3	6	0	1	50	2021-06-28 06:59:32.807259	t	2021-06-28 13:00:54.210959
458	0	6	0	1	50	2021-06-28 06:57:11.372117	f	1970-01-01 00:00:00
474	0	6	0	1	350	2021-06-28 07:08:05.282937	f	1970-01-01 00:00:00
483	0	6	0	1	500	2021-06-28 07:16:13.802616	f	1970-01-01 00:00:00
489	0	6	0	1	500	2021-06-28 07:22:57.337613	f	1970-01-01 00:00:00
548	0	6	0	1	50	2021-06-28 08:25:53.648378	f	1970-01-01 00:00:00
285	0	6	0	1	50	2021-06-25 07:56:51.370733	f	1970-01-01 00:00:00
314	0	6	0	1	10	2021-06-25 08:16:20.061741	f	1970-01-01 00:00:00
329	0	6	0	1	25	2021-06-25 08:31:31.631403	f	1970-01-01 00:00:00
678	30	8	6	3	300	2021-06-29 06:40:39.886649	f	1970-01-01 00:00:00
679	30	8	6	3	200	2021-06-29 06:40:39.931289	f	1970-01-01 00:00:00
680	30	8	6	3	100	2021-06-29 06:40:39.968658	f	1970-01-01 00:00:00
569	29	8	0	1	150	2021-06-29 05:01:40.602228	t	2021-06-29 06:41:18.875516
672	29	8	2	3	500	2021-06-29 06:40:37.939766	t	2021-06-29 06:41:18.875516
673	29	8	2	3	450	2021-06-29 06:40:37.983666	t	2021-06-29 06:41:18.875516
674	29	8	2	3	400	2021-06-29 06:40:38.030578	t	2021-06-29 06:41:18.875516
675	29	8	2	3	350	2021-06-29 06:40:38.077816	t	2021-06-29 06:41:18.875516
676	29	8	2	3	300	2021-06-29 06:40:38.115077	t	2021-06-29 06:41:18.875516
157	0	2	0	1	250	2021-06-24 10:55:34.894903	f	1970-01-01 00:00:00
160	0	2	0	1	250	2021-06-24 10:57:42.904223	f	1970-01-01 00:00:00
279	3	2	6	2	0	2021-06-25 07:49:17.49696	t	2021-06-28 13:00:54.210959
677	29	8	2	3	100	2021-06-29 06:40:38.156294	t	2021-06-29 06:41:18.875516
627	31	3	3	2	0	2021-06-29 06:04:48.611698	t	2021-06-29 07:01:23.226086
691	31	3	0	1	150	2021-06-29 07:02:33.172236	f	1970-01-01 00:00:00
717	29	3	1	3	500	2021-06-29 07:50:41.700201	f	1970-01-01 00:00:00
280	3	2	4	2	0	2021-06-25 07:50:33.013878	t	2021-06-28 13:00:54.210959
37	3	3	6	3	500	2021-06-21 10:00:08.606645	t	2021-06-28 13:00:54.210959
38	3	3	6	3	459	2021-06-21 10:00:08.718375	t	2021-06-28 13:00:54.210959
566	3	2	4	2	0	2021-06-28 12:56:32.731557	t	2021-06-28 13:00:54.210959
39	3	6	6	3	408	2021-06-21 10:00:08.786629	t	2021-06-28 13:00:54.210959
48	3	6	4	3	515	2021-06-22 05:00:29.987634	t	2021-06-28 13:00:54.210959
49	3	6	4	3	464	2021-06-22 05:00:30.082347	t	2021-06-28 13:00:54.210959
214	3	2	4	3	315	2021-06-25 04:00:51.912693	t	2021-06-28 13:00:54.210959
215	3	2	6	3	525	2021-06-25 04:00:52.797651	t	2021-06-28 13:00:54.210959
216	3	2	6	3	473	2021-06-25 04:00:52.910997	t	2021-06-28 13:00:54.210959
217	3	2	6	3	424	2021-06-25 04:00:53.032053	t	2021-06-28 13:00:54.210959
220	3	2	6	2	40	2021-06-25 04:16:30.053393	t	2021-06-28 13:00:54.210959
222	3	2	6	2	55	2021-06-25 04:44:54.334587	t	2021-06-28 13:00:54.210959
224	3	2	6	2	0	2021-06-25 04:59:04.590733	t	2021-06-28 13:00:54.210959
226	3	2	4	3	530	2021-06-25 05:00:57.894578	t	2021-06-28 13:00:54.210959
227	3	2	6	3	530	2021-06-25 05:00:58.852229	t	2021-06-28 13:00:54.210959
228	3	2	6	3	477	2021-06-25 05:00:58.950163	t	2021-06-28 13:00:54.210959
229	3	2	6	3	424	2021-06-25 05:00:59.055308	t	2021-06-28 13:00:54.210959
230	3	2	6	3	371	2021-06-25 05:00:59.16273	t	2021-06-28 13:00:54.210959
231	3	2	6	2	0	2021-06-25 05:02:43.425879	t	2021-06-28 13:00:54.210959
233	3	2	6	2	55	2021-06-25 05:03:36.607692	t	2021-06-28 13:00:54.210959
240	3	2	6	3	530	2021-06-25 06:00:05.713694	t	2021-06-28 13:00:54.210959
241	3	2	6	3	477	2021-06-25 06:00:05.796671	t	2021-06-28 13:00:54.210959
350	1	5	0	1	350	2021-06-25 10:07:49.468354	t	2021-06-28 08:01:26.770659
389	1	3	1	3	520	2021-06-28 04:30:47.270096	t	2021-06-28 08:01:26.770659
390	1	3	1	3	468	2021-06-28 04:30:47.975459	t	2021-06-28 08:01:26.770659
391	1	3	1	3	416	2021-06-28 04:30:59.0274	t	2021-06-28 08:01:26.770659
392	1	3	1	3	364	2021-06-28 04:31:00.224366	t	2021-06-28 08:01:26.770659
393	1	3	1	3	312	2021-06-28 04:31:06.128031	t	2021-06-28 08:01:26.770659
173	1	5	0	1	25	2021-06-24 12:33:34.714336	t	2021-06-28 08:01:26.770659
66	3	2	4	3	515	2021-06-23 03:00:09.013176	t	2021-06-28 13:00:54.210959
67	3	2	4	3	464	2021-06-23 03:00:09.091999	t	2021-06-28 13:00:54.210959
68	3	2	4	3	412	2021-06-23 03:00:09.171433	t	2021-06-28 13:00:54.210959
718	33	3	2	3	500	2021-06-29 07:50:45.079575	t	2021-06-29 07:51:29.206297
719	33	3	2	3	450	2021-06-29 07:50:45.156634	t	2021-06-29 07:51:29.206297
720	33	3	2	3	400	2021-06-29 07:50:45.236986	t	2021-06-29 07:51:29.206297
721	33	3	2	3	350	2021-06-29 07:50:45.314173	t	2021-06-29 07:51:29.206297
722	33	3	2	3	300	2021-06-29 07:50:45.392612	t	2021-06-29 07:51:29.206297
723	33	3	2	3	100	2021-06-29 07:50:45.470753	t	2021-06-29 07:51:29.206297
724	33	3	2	3	100	2021-06-29 07:50:45.548215	t	2021-06-29 07:51:29.206297
725	33	3	2	3	100	2021-06-29 07:50:45.652129	t	2021-06-29 07:51:29.206297
262	0	6	0	1	10	2021-06-25 07:37:48.890559	f	1970-01-01 00:00:00
288	0	6	0	1	10	2021-06-25 07:57:19.743634	f	1970-01-01 00:00:00
134	0	6	0	1	500	2021-06-24 09:30:55.810338	f	1970-01-01 00:00:00
137	0	6	0	1	50	2021-06-24 09:33:24.279613	f	1970-01-01 00:00:00
320	0	6	0	1	50	2021-06-25 08:23:29.928351	f	1970-01-01 00:00:00
590	30	3	7	3	300	2021-06-29 05:21:03.813637	f	1970-01-01 00:00:00
591	30	3	6	3	300	2021-06-29 05:21:05.954059	f	1970-01-01 00:00:00
606	31	3	1	3	500	2021-06-29 05:30:12.839584	t	2021-06-29 07:01:23.226086
607	31	3	1	3	450	2021-06-29 05:30:12.916054	t	2021-06-29 07:01:23.226086
351	3	2	6	2	0	2021-06-25 10:42:59.07961	t	2021-06-28 13:00:54.210959
352	3	2	6	2	0	2021-06-25 10:44:15.935815	t	2021-06-28 13:00:54.210959
277	3	2	6	2	0	2021-06-25 07:45:48.551417	t	2021-06-28 13:00:54.210959
282	3	2	0	1	250	2021-06-25 07:52:34.049457	t	2021-06-28 13:00:54.210959
298	3	2	4	3	530	2021-06-25 08:00:18.290302	t	2021-06-28 13:00:54.210959
299	3	2	6	3	530	2021-06-25 08:00:20.478854	t	2021-06-28 13:00:54.210959
300	3	2	6	3	482	2021-06-25 08:00:20.557472	t	2021-06-28 13:00:54.210959
301	3	2	6	3	428	2021-06-25 08:00:20.73159	t	2021-06-28 13:00:54.210959
334	3	2	0	1	25	2021-06-25 08:43:09.251114	t	2021-06-28 13:00:54.210959
69	3	7	4	3	350	2021-06-23 03:00:09.295156	t	2021-06-28 13:00:54.210959
70	3	2	4	3	309	2021-06-23 03:00:09.381218	t	2021-06-28 13:00:54.210959
310	1	6	0	1	200	2021-06-25 08:15:04.599778	t	2021-06-28 08:01:26.770659
178	0	5	0	1	500	2021-06-24 14:16:15.417241	f	1970-01-01 00:00:00
312	1	6	0	1	50	2021-06-25 08:16:05.276142	t	2021-06-28 08:01:26.770659
608	31	3	1	3	400	2021-06-29 05:30:12.995581	t	2021-06-29 07:01:23.226086
628	31	3	3	2	0	2021-06-29 06:05:15.942466	t	2021-06-29 07:01:23.226086
325	1	6	0	1	400	2021-06-25 08:26:22.294199	t	2021-06-28 08:01:26.770659
333	1	2	0	1	350	2021-06-25 08:40:00.101843	t	2021-06-28 08:01:26.770659
336	1	6	0	1	350	2021-06-25 08:48:02.903262	t	2021-06-28 08:01:26.770659
198	0	2	0	1	200	2021-06-25 03:24:38.724311	f	1970-01-01 00:00:00
141	1	6	0	1	250	2021-06-24 09:37:48.045188	t	2021-06-28 08:01:26.770659
144	1	2	0	1	300	2021-06-24 10:13:07.880086	t	2021-06-28 08:01:26.770659
147	1	2	0	1	50	2021-06-24 10:16:52.98528	t	2021-06-28 08:01:26.770659
149	1	2	0	1	10	2021-06-24 10:18:23.78277	t	2021-06-28 08:01:26.770659
71	3	2	6	3	515	2021-06-23 03:00:10.288811	t	2021-06-28 13:00:54.210959
76	3	2	0	1	25	2021-06-23 06:49:00.214525	t	2021-06-28 13:00:54.210959
77	3	2	0	1	250	2021-06-23 06:49:24.798415	t	2021-06-28 13:00:54.210959
78	3	6	6	2	0	2021-06-23 08:15:28.964471	t	2021-06-28 13:00:54.210959
79	3	6	6	2	45	2021-06-23 08:27:17.89053	t	2021-06-28 13:00:54.210959
80	3	6	6	3	520	2021-06-23 09:00:35.729486	t	2021-06-28 13:00:54.210959
81	3	6	6	3	468	2021-06-23 09:00:35.789414	t	2021-06-28 13:00:54.210959
82	3	6	3	2	0	2021-06-23 09:06:59.076466	t	2021-06-28 13:00:54.210959
93	3	6	3	3	520	2021-06-23 10:00:41.31067	t	2021-06-28 13:00:54.210959
570	29	3	1	3	500	2021-06-29 05:10:54.812446	t	2021-06-29 06:41:18.875516
571	29	8	1	3	450	2021-06-29 05:10:54.867887	t	2021-06-29 06:41:18.875516
572	29	8	1	3	400	2021-06-29 05:10:54.918212	t	2021-06-29 06:41:18.875516
573	29	8	1	3	350	2021-06-29 05:10:54.968081	t	2021-06-29 06:41:18.875516
574	29	8	1	3	300	2021-06-29 05:10:55.012912	t	2021-06-29 06:41:18.875516
575	29	8	1	3	200	2021-06-29 05:10:55.122974	t	2021-06-29 06:41:18.875516
576	29	8	1	3	200	2021-06-29 05:10:55.172198	t	2021-06-29 06:41:18.875516
577	29	8	1	3	200	2021-06-29 05:10:55.223672	t	2021-06-29 06:41:18.875516
578	29	8	1	3	200	2021-06-29 05:10:55.270967	t	2021-06-29 06:41:18.875516
579	29	8	1	3	200	2021-06-29 05:10:55.314054	t	2021-06-29 06:41:18.875516
580	29	3	2	3	500	2021-06-29 05:20:59.171373	t	2021-06-29 06:41:18.875516
581	29	3	2	3	450	2021-06-29 05:20:59.243768	t	2021-06-29 06:41:18.875516
582	29	8	2	3	400	2021-06-29 05:20:59.295874	t	2021-06-29 06:41:18.875516
583	29	8	2	3	350	2021-06-29 05:20:59.344424	t	2021-06-29 06:41:18.875516
584	29	8	2	3	300	2021-06-29 05:20:59.396085	t	2021-06-29 06:41:18.875516
585	29	8	2	3	100	2021-06-29 05:20:59.435659	t	2021-06-29 06:41:18.875516
649	29	3	0	1	250	2021-06-29 06:15:37.294238	t	2021-06-29 06:41:18.875516
650	29	3	0	1	25	2021-06-29 06:15:43.385175	t	2021-06-29 06:41:18.875516
651	29	3	0	1	25	2021-06-29 06:15:48.53705	t	2021-06-29 06:41:18.875516
652	29	3	0	1	25	2021-06-29 06:15:53.365603	t	2021-06-29 06:41:18.875516
660	29	8	2	3	100	2021-06-29 06:20:31.195671	t	2021-06-29 06:41:18.875516
661	29	8	2	3	100	2021-06-29 06:20:31.335625	t	2021-06-29 06:41:18.875516
662	29	8	2	3	100	2021-06-29 06:20:31.372377	t	2021-06-29 06:41:18.875516
663	29	8	2	3	100	2021-06-29 06:20:31.40941	t	2021-06-29 06:41:18.875516
536	0	6	0	1	50	2021-06-28 08:19:22.390838	f	1970-01-01 00:00:00
545	0	6	0	1	10	2021-06-28 08:25:41.448038	f	1970-01-01 00:00:00
551	0	6	0	1	10	2021-06-28 08:26:06.177758	f	1970-01-01 00:00:00
632	30	3	6	2	0	2021-06-29 06:07:46.848892	f	1970-01-01 00:00:00
468	3	2	6	2	0	2021-06-28 07:01:35.975799	t	2021-06-28 13:00:54.210959
96	3	2	4	2	0	2021-06-23 10:57:27.755206	t	2021-06-28 13:00:54.210959
97	3	2	4	2	0	2021-06-23 10:58:21.897028	t	2021-06-28 13:00:54.210959
98	3	2	4	3	520	2021-06-23 11:00:46.033847	t	2021-06-28 13:00:54.210959
99	3	2	4	3	468	2021-06-23 11:00:46.111145	t	2021-06-28 13:00:54.210959
107	3	2	0	1	150	2021-06-23 13:30:35.980188	t	2021-06-28 13:00:54.210959
111	3	6	0	1	50	2021-06-24 08:10:56.364142	t	2021-06-28 13:00:54.210959
125	3	2	4	3	525	2021-06-24 09:00:55.350433	t	2021-06-28 13:00:54.210959
126	3	2	4	3	473	2021-06-24 09:00:55.427474	t	2021-06-28 13:00:54.210959
127	3	2	4	3	420	2021-06-24 09:00:55.530801	t	2021-06-28 13:00:54.210959
128	3	6	4	3	364	2021-06-24 09:00:55.59822	t	2021-06-28 13:00:54.210959
567	3	2	4	3	500	2021-06-28 13:00:29.981775	t	2021-06-28 13:00:54.210959
50	3	6	4	3	412	2021-06-22 05:00:30.165741	t	2021-06-28 13:00:54.210959
51	3	6	4	3	361	2021-06-22 05:00:30.245963	t	2021-06-28 13:00:54.210959
57	3	2	6	2	0	2021-06-22 12:34:36.97837	t	2021-06-28 13:00:54.210959
58	3	2	6	2	0	2021-06-22 12:46:24.966213	t	2021-06-28 13:00:54.210959
59	3	2	6	3	515	2021-06-22 13:00:04.04019	t	2021-06-28 13:00:54.210959
60	3	2	6	3	464	2021-06-22 13:00:04.145326	t	2021-06-28 13:00:54.210959
63	3	5	4	3	760	2021-06-22 15:00:31.98511	t	2021-06-28 13:00:54.210959
64	3	2	6	2	0	2021-06-23 02:53:21.671037	t	2021-06-28 13:00:54.210959
65	3	2	6	2	10	2021-06-23 02:53:21.675313	t	2021-06-28 13:00:54.210959
180	3	2	0	1	50	2021-06-25 02:31:02.350555	t	2021-06-28 13:00:54.210959
205	3	2	4	2	0	2021-06-25 03:55:50.047938	t	2021-06-28 13:00:54.210959
206	3	2	4	2	0	2021-06-25 03:56:02.874482	t	2021-06-28 13:00:54.210959
207	3	2	4	2	0	2021-06-25 03:56:13.429159	t	2021-06-28 13:00:54.210959
210	3	2	4	3	525	2021-06-25 04:00:51.392154	t	2021-06-28 13:00:54.210959
211	3	2	4	3	473	2021-06-25 04:00:51.475138	t	2021-06-28 13:00:54.210959
212	3	2	4	3	420	2021-06-25 04:00:51.548023	t	2021-06-28 13:00:54.210959
213	3	2	4	3	368	2021-06-25 04:00:51.814339	t	2021-06-28 13:00:54.210959
592	29	9	0	1	150	2021-06-29 05:23:56.385223	t	2021-06-29 06:41:18.875516
653	29	3	0	1	10	2021-06-29 06:16:27.283006	t	2021-06-29 06:41:18.875516
664	29	8	2	3	100	2021-06-29 06:20:31.442004	t	2021-06-29 06:41:18.875516
665	29	9	1	3	500	2021-06-29 06:30:34.722861	t	2021-06-29 06:41:18.875516
666	29	9	1	3	450	2021-06-29 06:30:34.776941	t	2021-06-29 06:41:18.875516
629	31	3	3	2	0	2021-06-29 06:06:19.624549	t	2021-06-29 07:01:23.226086
693	29	9	2	3	500	2021-06-29 07:21:03.769386	f	1970-01-01 00:00:00
694	33	9	2	3	500	2021-06-29 07:21:20.909003	t	2021-06-29 07:51:29.206297
705	33	3	3	3	500	2021-06-29 07:40:37.63945	t	2021-06-29 07:51:29.206297
706	33	3	3	3	450	2021-06-29 07:40:37.718298	t	2021-06-29 07:51:29.206297
707	33	3	3	3	400	2021-06-29 07:40:37.846253	t	2021-06-29 07:51:29.206297
708	33	3	3	3	350	2021-06-29 07:40:37.898326	t	2021-06-29 07:51:29.206297
709	33	3	3	3	300	2021-06-29 07:40:37.976681	t	2021-06-29 07:51:29.206297
710	33	3	3	3	100	2021-06-29 07:40:38.05437	t	2021-06-29 07:51:29.206297
711	33	3	3	3	100	2021-06-29 07:40:38.131536	t	2021-06-29 07:51:29.206297
712	33	3	3	3	100	2021-06-29 07:40:38.21026	t	2021-06-29 07:51:29.206297
713	33	3	3	3	100	2021-06-29 07:40:38.288362	t	2021-06-29 07:51:29.206297
714	33	3	3	3	100	2021-06-29 07:40:38.365533	t	2021-06-29 07:51:29.206297
726	29	3	2	3	500	2021-06-29 08:20:07.392427	f	1970-01-01 00:00:00
727	30	3	7	3	300	2021-06-29 08:20:08.301231	f	1970-01-01 00:00:00
395	1	2	0	1	250	2021-06-28 04:51:02.990384	t	2021-06-28 08:01:26.770659
728	30	3	4	3	300	2021-06-29 08:20:09.785621	f	1970-01-01 00:00:00
695	35	3	2	3	500	2021-06-29 07:21:25.999442	t	2021-06-30 08:01:00.102935
696	35	3	2	3	450	2021-06-29 07:21:26.151983	t	2021-06-30 08:01:00.102935
729	35	3	2	3	500	2021-06-29 08:20:15.534059	t	2021-06-30 08:01:00.102935
129	3	2	4	3	315	2021-06-24 09:00:55.723941	t	2021-06-28 13:00:54.210959
593	29	9	0	1	50	2021-06-29 05:27:06.395488	t	2021-06-29 06:41:18.875516
594	29	8	0	1	500	2021-06-29 05:28:30.304211	t	2021-06-29 06:41:18.875516
595	29	8	0	1	350	2021-06-29 05:28:45.711807	t	2021-06-29 06:41:18.875516
190	3	6	0	1	150	2021-06-25 03:03:34.999294	t	2021-06-28 13:00:54.210959
405	0	6	0	1	10	2021-06-28 05:48:54.658783	f	1970-01-01 00:00:00
408	0	6	0	1	400	2021-06-28 05:49:15.826625	f	1970-01-01 00:00:00
208	3	2	6	2	31	2021-06-25 03:57:26.984894	t	2021-06-28 13:00:54.210959
218	3	2	6	2	0	2021-06-25 04:14:06.337511	t	2021-06-28 13:00:54.210959
258	3	2	6	2	0	2021-06-25 07:36:43.949545	t	2021-06-28 13:00:54.210959
353	3	2	6	2	65	2021-06-25 10:44:15.951236	t	2021-06-28 13:00:54.210959
306	3	2	0	1	150	2021-06-25 08:04:57.082202	t	2021-06-28 13:00:54.210959
433	0	6	0	1	150	2021-06-28 06:13:20.37937	f	1970-01-01 00:00:00
436	0	6	0	1	250	2021-06-28 06:13:32.473522	f	1970-01-01 00:00:00
354	3	2	4	3	535	2021-06-25 11:00:45.317696	t	2021-06-28 13:00:54.210959
355	3	2	4	3	482	2021-06-25 11:00:45.39461	t	2021-06-28 13:00:54.210959
449	0	6	0	1	500	2021-06-28 06:39:41.190356	f	1970-01-01 00:00:00
630	31	3	3	2	0	2021-06-29 06:06:29.008011	t	2021-06-29 07:01:23.226086
681	31	3	1	2	0	2021-06-29 06:55:00.976582	t	2021-06-29 07:01:23.226086
464	0	6	0	1	10	2021-06-28 07:00:11.055575	f	1970-01-01 00:00:00
685	31	3	1	2	0	2021-06-29 06:57:44.074635	t	2021-06-29 07:01:23.226086
697	33	3	0	1	25	2021-06-29 07:38:43.61443	t	2021-06-29 07:51:29.206297
477	0	6	0	1	25	2021-06-28 07:13:55.460195	f	1970-01-01 00:00:00
700	33	3	0	1	150	2021-06-29 07:39:11.130347	t	2021-06-29 07:51:29.206297
730	34	9	6	3	300	2021-06-30 07:10:31.299649	f	1970-01-01 00:00:00
480	0	6	0	1	400	2021-06-28 07:15:52.355442	f	1970-01-01 00:00:00
270	0	2	0	1	50	2021-06-25 07:42:02.058315	f	1970-01-01 00:00:00
278	0	6	0	1	250	2021-06-25 07:48:18.291331	f	1970-01-01 00:00:00
281	0	2	0	1	50	2021-06-25 07:51:54.800221	f	1970-01-01 00:00:00
731	34	9	6	3	300	2021-06-30 07:20:36.188625	f	1970-01-01 00:00:00
317	0	6	0	1	50	2021-06-25 08:23:12.484503	f	1970-01-01 00:00:00
486	0	6	0	1	25	2021-06-28 07:17:57.666243	f	1970-01-01 00:00:00
326	0	6	0	1	250	2021-06-25 08:26:28.059856	f	1970-01-01 00:00:00
495	0	6	0	1	300	2021-06-28 07:34:43.299281	f	1970-01-01 00:00:00
340	0	6	0	1	500	2021-06-25 08:56:33.494078	f	1970-01-01 00:00:00
356	3	2	4	3	428	2021-06-25 11:00:45.471984	t	2021-06-28 13:00:54.210959
357	3	2	4	3	375	2021-06-25 11:00:45.551588	t	2021-06-28 13:00:54.210959
358	3	2	6	3	535	2021-06-25 11:00:46.386028	t	2021-06-28 13:00:54.210959
359	3	2	6	3	482	2021-06-25 11:00:46.491147	t	2021-06-28 13:00:54.210959
415	3	2	6	2	0	2021-06-28 05:56:27.754321	t	2021-06-28 13:00:54.210959
416	3	2	6	2	0	2021-06-28 05:58:11.167109	t	2021-06-28 13:00:54.210959
493	3	2	6	2	0	2021-06-28 07:31:36.388445	t	2021-06-28 13:00:54.210959
496	3	6	0	1	25	2021-06-28 07:34:51.100677	t	2021-06-28 13:00:54.210959
497	3	6	0	1	10	2021-06-28 07:34:57.116103	t	2021-06-28 13:00:54.210959
499	3	6	0	1	50	2021-06-28 07:35:10.541225	t	2021-06-28 13:00:54.210959
500	3	6	0	1	25	2021-06-28 07:35:17.020098	t	2021-06-28 13:00:54.210959
508	3	6	0	1	300	2021-06-28 07:50:49.478364	t	2021-06-28 13:00:54.210959
498	0	6	0	1	50	2021-06-28 07:35:03.703116	f	1970-01-01 00:00:00
539	0	6	0	1	250	2021-06-28 08:23:26.872355	f	1970-01-01 00:00:00
560	3	2	6	2	0	2021-06-28 11:52:13.925756	t	2021-06-28 13:00:54.210959
612	30	8	7	3	300	2021-06-29 05:40:15.397642	f	1970-01-01 00:00:00
613	30	8	7	3	200	2021-06-29 05:40:15.445808	f	1970-01-01 00:00:00
614	30	8	7	3	100	2021-06-29 05:40:15.500513	f	1970-01-01 00:00:00
615	30	8	7	3	50	2021-06-29 05:40:15.550639	f	1970-01-01 00:00:00
618	30	3	5	3	300	2021-06-29 05:50:20.525322	f	1970-01-01 00:00:00
619	30	3	4	3	300	2021-06-29 05:50:21.346027	f	1970-01-01 00:00:00
609	29	8	2	3	500	2021-06-29 05:40:13.936138	t	2021-06-29 06:41:18.875516
610	29	8	2	3	450	2021-06-29 05:40:13.987496	t	2021-06-29 06:41:18.875516
611	29	8	2	3	400	2021-06-29 05:40:14.035693	t	2021-06-29 06:41:18.875516
620	29	8	2	3	500	2021-06-29 06:00:23.336594	t	2021-06-29 06:41:18.875516
621	29	8	2	3	450	2021-06-29 06:00:23.383865	t	2021-06-29 06:41:18.875516
622	29	8	2	3	400	2021-06-29 06:00:23.433746	t	2021-06-29 06:41:18.875516
623	29	8	2	3	350	2021-06-29 06:00:23.479831	t	2021-06-29 06:41:18.875516
624	29	8	2	3	300	2021-06-29 06:00:23.518491	t	2021-06-29 06:41:18.875516
625	29	8	2	3	100	2021-06-29 06:00:23.563523	t	2021-06-29 06:41:18.875516
616	31	8	3	3	500	2021-06-29 05:40:17.561117	t	2021-06-29 07:01:23.226086
631	31	3	3	2	0	2021-06-29 06:06:39.308091	t	2021-06-29 07:01:23.226086
682	31	3	0	1	150	2021-06-29 06:55:13.882406	t	2021-06-29 07:01:23.226086
698	33	3	0	1	200	2021-06-29 07:38:47.659695	t	2021-06-29 07:51:29.206297
701	33	3	0	1	350	2021-06-29 07:39:15.450058	t	2021-06-29 07:51:29.206297
732	35	9	1	3	500	2021-06-30 08:00:04.903253	t	2021-06-30 08:01:00.102935
733	35	9	1	3	450	2021-06-30 08:00:04.954125	t	2021-06-30 08:01:00.102935
734	35	9	1	3	400	2021-06-30 08:00:04.99579	t	2021-06-30 08:01:00.102935
735	35	9	1	3	350	2021-06-30 08:00:05.046482	t	2021-06-30 08:01:00.102935
554	0	6	0	1	500	2021-06-28 08:35:40.033373	f	1970-01-01 00:00:00
561	3	2	6	2	90	2021-06-28 11:52:13.941452	t	2021-06-28 13:00:54.210959
410	3	2	6	2	0	2021-06-28 05:53:17.052965	t	2021-06-28 13:00:54.210959
421	3	2	6	3	535	2021-06-28 06:00:28.611394	t	2021-06-28 13:00:54.210959
422	3	2	6	3	482	2021-06-28 06:00:28.745337	t	2021-06-28 13:00:54.210959
423	3	2	6	3	428	2021-06-28 06:00:28.824778	t	2021-06-28 13:00:54.210959
451	3	2	6	2	0	2021-06-28 06:47:40.373511	t	2021-06-28 13:00:54.210959
462	3	6	0	1	25	2021-06-28 06:59:16.2415	t	2021-06-28 13:00:54.210959
465	3	2	6	3	535	2021-06-28 07:00:37.486911	t	2021-06-28 13:00:54.210959
466	3	2	6	3	482	2021-06-28 07:00:37.57695	t	2021-06-28 13:00:54.210959
467	3	2	6	3	428	2021-06-28 07:00:37.667024	t	2021-06-28 13:00:54.210959
494	3	2	6	2	80	2021-06-28 07:31:36.396745	t	2021-06-28 13:00:54.210959
502	3	6	0	1	400	2021-06-28 07:35:33.958017	t	2021-06-28 13:00:54.210959
507	3	6	0	1	150	2021-06-28 07:48:50.909251	t	2021-06-28 13:00:54.210959
510	3	6	0	1	500	2021-06-28 07:50:58.644361	t	2021-06-28 13:00:54.210959
511	3	6	0	1	25	2021-06-28 07:51:02.453365	t	2021-06-28 13:00:54.210959
513	3	6	0	1	25	2021-06-28 07:51:11.043106	t	2021-06-28 13:00:54.210959
514	3	6	0	1	250	2021-06-28 07:51:52.626092	t	2021-06-28 13:00:54.210959
516	3	6	0	1	25	2021-06-28 07:52:09.689991	t	2021-06-28 13:00:54.210959
522	3	6	0	1	50	2021-06-28 07:58:50.117458	t	2021-06-28 13:00:54.210959
523	3	6	0	1	200	2021-06-28 07:58:53.90026	t	2021-06-28 13:00:54.210959
402	0	6	0	1	150	2021-06-28 05:16:08.640027	f	1970-01-01 00:00:00
525	3	6	0	1	10	2021-06-28 07:59:02.748887	t	2021-06-28 13:00:54.210959
527	3	2	6	3	540	2021-06-28 08:00:45.889051	t	2021-06-28 13:00:54.210959
528	3	2	6	3	486	2021-06-28 08:00:45.964193	t	2021-06-28 13:00:54.210959
414	0	6	0	1	25	2021-06-28 05:56:15.012567	f	1970-01-01 00:00:00
442	0	6	0	1	250	2021-06-28 06:25:01.946203	f	1970-01-01 00:00:00
643	30	3	6	3	300	2021-06-29 06:10:27.934242	f	1970-01-01 00:00:00
455	0	6	0	1	500	2021-06-28 06:55:23.361279	f	1970-01-01 00:00:00
461	0	6	0	1	10	2021-06-28 06:58:36.72179	f	1970-01-01 00:00:00
471	0	6	0	1	200	2021-06-28 07:06:29.130481	f	1970-01-01 00:00:00
501	0	6	0	1	250	2021-06-28 07:35:27.58848	f	1970-01-01 00:00:00
506	0	6	0	1	50	2021-06-28 07:48:17.117427	f	1970-01-01 00:00:00
509	0	6	0	1	150	2021-06-28 07:50:54.71415	f	1970-01-01 00:00:00
512	0	6	0	1	150	2021-06-28 07:51:07.210457	f	1970-01-01 00:00:00
515	0	6	0	1	200	2021-06-28 07:52:04.452794	f	1970-01-01 00:00:00
518	0	6	0	1	10	2021-06-28 07:58:06.151646	f	1970-01-01 00:00:00
521	0	6	0	1	25	2021-06-28 07:58:17.469872	f	1970-01-01 00:00:00
524	0	6	0	1	250	2021-06-28 07:58:58.772034	f	1970-01-01 00:00:00
667	30	8	5	3	300	2021-06-29 06:30:35.546309	f	1970-01-01 00:00:00
668	30	9	5	3	200	2021-06-29 06:30:35.598663	f	1970-01-01 00:00:00
669	30	9	4	3	300	2021-06-29 06:30:36.36979	f	1970-01-01 00:00:00
617	29	3	0	1	250	2021-06-29 05:41:10.894064	t	2021-06-29 06:41:18.875516
633	29	8	3	3	500	2021-06-29 06:10:26.562417	t	2021-06-29 06:41:18.875516
634	29	8	3	3	450	2021-06-29 06:10:26.609873	t	2021-06-29 06:41:18.875516
635	29	8	3	3	400	2021-06-29 06:10:26.652972	t	2021-06-29 06:41:18.875516
636	29	8	3	3	350	2021-06-29 06:10:26.691628	t	2021-06-29 06:41:18.875516
637	29	8	3	3	300	2021-06-29 06:10:26.728378	t	2021-06-29 06:41:18.875516
638	29	8	3	3	100	2021-06-29 06:10:26.771264	t	2021-06-29 06:41:18.875516
639	29	8	3	3	100	2021-06-29 06:10:26.814095	t	2021-06-29 06:41:18.875516
640	29	8	3	3	100	2021-06-29 06:10:26.848192	t	2021-06-29 06:41:18.875516
641	29	8	3	3	100	2021-06-29 06:10:26.901102	t	2021-06-29 06:41:18.875516
642	29	8	3	3	100	2021-06-29 06:10:26.941229	t	2021-06-29 06:41:18.875516
655	29	8	2	3	500	2021-06-29 06:20:30.900566	t	2021-06-29 06:41:18.875516
656	29	8	2	3	450	2021-06-29 06:20:30.959688	t	2021-06-29 06:41:18.875516
657	29	8	2	3	400	2021-06-29 06:20:31.009269	t	2021-06-29 06:41:18.875516
658	29	8	2	3	350	2021-06-29 06:20:31.105416	t	2021-06-29 06:41:18.875516
659	29	8	2	3	300	2021-06-29 06:20:31.154597	t	2021-06-29 06:41:18.875516
683	31	3	0	1	200	2021-06-29 06:55:18.741383	t	2021-06-29 07:01:23.226086
644	31	3	3	3	500	2021-06-29 06:10:29.61802	t	2021-06-29 07:01:23.226086
645	31	3	3	3	450	2021-06-29 06:10:29.674731	t	2021-06-29 07:01:23.226086
646	31	3	3	3	400	2021-06-29 06:10:29.728004	t	2021-06-29 07:01:23.226086
647	31	3	3	3	350	2021-06-29 06:10:29.805434	t	2021-06-29 07:01:23.226086
648	31	3	3	3	300	2021-06-29 06:10:29.896518	t	2021-06-29 07:01:23.226086
692	0	3	0	1	300	2021-06-29 07:02:41.523136	f	1970-01-01 00:00:00
699	0	3	0	1	400	2021-06-29 07:39:05.329846	f	1970-01-01 00:00:00
702	0	3	0	1	10	2021-06-29 07:39:20.081996	f	1970-01-01 00:00:00
736	33	9	0	1	200	2021-06-30 08:08:57.433123	f	1970-01-01 00:00:00
349	1	5	0	1	500	2021-06-25 10:07:39.096993	t	2021-06-28 08:01:26.770659
412	1	2	4	2	0	2021-06-28 05:55:38.170572	t	2021-06-28 08:01:26.770659
417	1	6	0	1	200	2021-06-28 05:58:41.892829	t	2021-06-28 08:01:26.770659
424	1	6	0	1	300	2021-06-28 06:04:26.68783	t	2021-06-28 08:01:26.770659
425	1	6	0	1	150	2021-06-28 06:06:01.578297	t	2021-06-28 08:01:26.770659
431	1	6	0	1	500	2021-06-28 06:10:47.828898	t	2021-06-28 08:01:26.770659
432	1	6	0	1	150	2021-06-28 06:11:42.979997	t	2021-06-28 08:01:26.770659
435	1	6	0	1	300	2021-06-28 06:13:28.177014	t	2021-06-28 08:01:26.770659
438	1	6	0	1	400	2021-06-28 06:19:28.22127	t	2021-06-28 08:01:26.770659
271	1	2	0	1	200	2021-06-25 07:43:05.925072	t	2021-06-28 08:01:26.770659
400	1	6	0	1	10	2021-06-28 05:15:43.573386	t	2021-06-28 08:01:26.770659
404	1	6	0	1	150	2021-06-28 05:48:49.344393	t	2021-06-28 08:01:26.770659
407	1	6	0	1	250	2021-06-28 05:49:09.042071	t	2021-06-28 08:01:26.770659
409	1	6	0	1	150	2021-06-28 05:51:19.351136	t	2021-06-28 08:01:26.770659
273	1	2	4	2	0	2021-06-25 07:44:07.573904	t	2021-06-28 08:01:26.770659
276	1	2	4	2	0	2021-06-25 07:44:58.712235	t	2021-06-28 08:01:26.770659
287	1	6	0	1	50	2021-06-25 07:57:11.768454	t	2021-06-28 08:01:26.770659
322	1	6	0	1	400	2021-06-25 08:23:48.704136	t	2021-06-28 08:01:26.770659
327	1	6	0	1	150	2021-06-25 08:26:37.025152	t	2021-06-28 08:01:26.770659
328	1	6	0	1	300	2021-06-25 08:27:12.724446	t	2021-06-28 08:01:26.770659
342	1	6	0	1	150	2021-06-25 08:56:44.967434	t	2021-06-28 08:01:26.770659
348	1	2	3	3	535	2021-06-25 09:30:32.890111	t	2021-06-28 08:01:26.770659
146	1	2	0	1	50	2021-06-24 10:15:19.937109	t	2021-06-28 08:01:26.770659
148	1	2	0	1	150	2021-06-24 10:17:46.842441	t	2021-06-28 08:01:26.770659
150	1	2	0	1	25	2021-06-24 10:18:43.030228	t	2021-06-28 08:01:26.770659
153	1	2	0	1	50	2021-06-24 10:19:57.893292	t	2021-06-28 08:01:26.770659
154	1	2	0	1	10	2021-06-24 10:30:42.21263	t	2021-06-28 08:01:26.770659
159	1	2	0	1	300	2021-06-24 10:56:25.562235	t	2021-06-28 08:01:26.770659
170	1	5	0	1	50	2021-06-24 12:31:59.502226	t	2021-06-28 08:01:26.770659
175	1	5	0	1	150	2021-06-24 12:34:51.913529	t	2021-06-28 08:01:26.770659
179	1	5	0	1	500	2021-06-24 14:16:25.529513	t	2021-06-28 08:01:26.770659
182	1	5	0	1	25	2021-06-25 02:41:50.269321	t	2021-06-28 08:01:26.770659
189	1	2	0	1	150	2021-06-25 03:03:00.873395	t	2021-06-28 08:01:26.770659
192	1	2	0	1	10	2021-06-25 03:04:25.42289	t	2021-06-28 08:01:26.770659
196	1	2	0	1	250	2021-06-25 03:20:36.685011	t	2021-06-28 08:01:26.770659
225	1	6	0	1	150	2021-06-25 05:00:44.703733	t	2021-06-28 08:01:26.770659
235	1	2	4	2	0	2021-06-25 05:37:51.552445	t	2021-06-28 08:01:26.770659
236	1	2	4	2	0	2021-06-25 05:38:53.950968	t	2021-06-28 08:01:26.770659
1	1	3	1	3	500	2021-06-18 12:30:30.10415	t	2021-06-28 08:01:26.770659
2	1	5	3	3	750	2021-06-20 05:30:09.465195	t	2021-06-28 08:01:26.770659
4	1	2	0	1	500	2021-06-21 07:19:55.286679	t	2021-06-28 08:01:26.770659
5	1	2	3	3	500	2021-06-21 07:30:07.950437	t	2021-06-28 08:01:26.770659
6	1	2	3	3	459	2021-06-21 07:30:08.074816	t	2021-06-28 08:01:26.770659
7	1	2	3	3	408	2021-06-21 07:30:08.181936	t	2021-06-28 08:01:26.770659
8	1	2	3	3	357	2021-06-21 07:30:08.306224	t	2021-06-28 08:01:26.770659
9	1	6	3	3	300	2021-06-21 07:30:08.378157	t	2021-06-28 08:01:26.770659
10	1	6	3	3	100	2021-06-21 07:30:08.480129	t	2021-06-28 08:01:26.770659
11	1	2	0	1	50	2021-06-21 07:40:12.869143	t	2021-06-28 08:01:26.770659
12	1	2	0	1	500	2021-06-21 07:46:00.994513	t	2021-06-28 08:01:26.770659
13	1	2	0	1	250	2021-06-21 07:49:01.68001	t	2021-06-28 08:01:26.770659
256	1	6	0	1	50	2021-06-25 07:23:58.083924	t	2021-06-28 08:01:26.770659
264	1	6	0	1	25	2021-06-25 07:38:05.068698	t	2021-06-28 08:01:26.770659
275	1	2	4	2	0	2021-06-25 07:44:34.115804	t	2021-06-28 08:01:26.770659
290	1	6	0	1	300	2021-06-25 07:57:34.719081	t	2021-06-28 08:01:26.770659
152	1	2	0	1	350	2021-06-24 10:19:47.831249	t	2021-06-28 08:01:26.770659
156	1	2	0	1	250	2021-06-24 10:54:21.237148	t	2021-06-28 08:01:26.770659
162	1	2	0	1	50	2021-06-24 11:10:24.626537	t	2021-06-28 08:01:26.770659
164	1	2	0	1	350	2021-06-24 11:16:19.416551	t	2021-06-28 08:01:26.770659
171	1	5	0	1	50	2021-06-24 12:33:08.311179	t	2021-06-28 08:01:26.770659
177	1	5	0	1	10	2021-06-24 14:11:17.302329	t	2021-06-28 08:01:26.770659
183	1	5	0	1	50	2021-06-25 02:44:38.929398	t	2021-06-28 08:01:26.770659
191	1	2	0	1	250	2021-06-25 03:04:03.22148	t	2021-06-28 08:01:26.770659
194	1	2	0	1	300	2021-06-25 03:16:01.147867	t	2021-06-28 08:01:26.770659
195	1	2	0	1	400	2021-06-25 03:19:04.063792	t	2021-06-28 08:01:26.770659
202	1	2	0	1	25	2021-06-25 03:34:22.013021	t	2021-06-28 08:01:26.770659
234	1	2	4	2	0	2021-06-25 05:37:24.723906	t	2021-06-28 08:01:26.770659
237	1	2	4	3	530	2021-06-25 06:00:03.923989	t	2021-06-28 08:01:26.770659
238	1	2	4	3	477	2021-06-25 06:00:04.001108	t	2021-06-28 08:01:26.770659
360	1	2	2	3	535	2021-06-25 11:00:47.512004	t	2021-06-28 08:01:26.770659
361	1	2	2	3	482	2021-06-25 11:00:47.612087	t	2021-06-28 08:01:26.770659
396	1	6	0	1	250	2021-06-28 04:56:58.332339	t	2021-06-28 08:01:26.770659
401	1	6	0	1	50	2021-06-28 05:16:02.821976	t	2021-06-28 08:01:26.770659
411	1	6	0	1	25	2021-06-28 05:55:16.031654	t	2021-06-28 08:01:26.770659
418	1	6	0	1	150	2021-06-28 05:58:46.691982	t	2021-06-28 08:01:26.770659
426	1	6	0	1	10	2021-06-28 06:07:05.081138	t	2021-06-28 08:01:26.770659
428	1	6	0	1	150	2021-06-28 06:07:59.0324	t	2021-06-28 08:01:26.770659
429	1	6	0	1	200	2021-06-28 06:08:03.975783	t	2021-06-28 08:01:26.770659
443	1	2	4	2	0	2021-06-28 06:25:08.846128	t	2021-06-28 08:01:26.770659
447	1	6	0	1	150	2021-06-28 06:38:51.498653	t	2021-06-28 08:01:26.770659
239	1	2	4	3	424	2021-06-25 06:00:04.131978	t	2021-06-28 08:01:26.770659
26	1	3	0	1	200	2021-06-21 08:05:24.569866	t	2021-06-28 08:01:26.770659
28	1	3	0	1	10	2021-06-21 08:05:40.812873	t	2021-06-28 08:01:26.770659
29	1	2	0	1	10	2021-06-21 08:05:48.25936	t	2021-06-28 08:01:26.770659
30	1	2	0	1	10	2021-06-21 08:05:59.71395	t	2021-06-28 08:01:26.770659
40	1	2	3	2	0	2021-06-22 03:04:51.987356	t	2021-06-28 08:01:26.770659
41	1	6	3	3	515	2021-06-22 03:30:17.805604	t	2021-06-28 08:01:26.770659
42	1	2	3	3	459	2021-06-22 03:30:17.913999	t	2021-06-28 08:01:26.770659
43	1	6	3	3	412	2021-06-22 03:30:17.978335	t	2021-06-28 08:01:26.770659
44	1	6	3	3	361	2021-06-22 03:30:18.044707	t	2021-06-28 08:01:26.770659
257	1	2	4	2	0	2021-06-25 07:35:22.466211	t	2021-06-28 08:01:26.770659
260	1	6	0	1	200	2021-06-25 07:37:20.66407	t	2021-06-28 08:01:26.770659
274	1	2	4	2	0	2021-06-25 07:44:19.868738	t	2021-06-28 08:01:26.770659
283	1	6	0	1	10	2021-06-25 07:55:14.795168	t	2021-06-28 08:01:26.770659
284	1	6	0	1	150	2021-06-25 07:55:24.511747	t	2021-06-28 08:01:26.770659
292	1	6	0	1	250	2021-06-25 07:57:55.039431	t	2021-06-28 08:01:26.770659
293	1	2	4	3	530	2021-06-25 08:00:16.650695	t	2021-06-28 08:01:26.770659
294	1	2	4	3	477	2021-06-25 08:00:16.755713	t	2021-06-28 08:01:26.770659
295	1	2	4	3	424	2021-06-25 08:00:16.859729	t	2021-06-28 08:01:26.770659
296	1	2	4	3	371	2021-06-25 08:00:16.964294	t	2021-06-28 08:01:26.770659
297	1	2	4	3	318	2021-06-25 08:00:17.087236	t	2021-06-28 08:01:26.770659
315	1	6	0	1	25	2021-06-25 08:16:30.123871	t	2021-06-28 08:01:26.770659
316	1	6	0	1	350	2021-06-25 08:23:05.697467	t	2021-06-28 08:01:26.770659
318	1	6	0	1	50	2021-06-25 08:23:18.312562	t	2021-06-28 08:01:26.770659
324	1	6	0	1	200	2021-06-25 08:23:59.892559	t	2021-06-28 08:01:26.770659
330	1	6	0	1	500	2021-06-25 08:36:59.213017	t	2021-06-28 08:01:26.770659
337	1	6	0	1	200	2021-06-25 08:54:54.449511	t	2021-06-28 08:01:26.770659
338	1	6	0	1	10	2021-06-25 08:56:18.57338	t	2021-06-28 08:01:26.770659
339	1	6	0	1	150	2021-06-25 08:56:26.955484	t	2021-06-28 08:01:26.770659
346	1	2	0	1	250	2021-06-25 09:07:07.692989	t	2021-06-28 08:01:26.770659
21	1	3	0	1	200	2021-06-21 08:03:00.11444	t	2021-06-28 08:01:26.770659
22	1	3	0	1	25	2021-06-21 08:03:49.435271	t	2021-06-28 08:01:26.770659
23	1	3	0	1	50	2021-06-21 08:04:09.255833	t	2021-06-28 08:01:26.770659
24	1	2	0	1	50	2021-06-21 08:04:31.232892	t	2021-06-28 08:01:26.770659
25	1	2	0	1	150	2021-06-21 08:04:54.109644	t	2021-06-28 08:01:26.770659
84	1	2	3	2	0	2021-06-23 09:28:05.207568	t	2021-06-28 08:01:26.770659
87	1	2	3	3	520	2021-06-23 09:30:38.476014	t	2021-06-28 08:01:26.770659
88	1	5	3	3	689	2021-06-23 09:30:38.586681	t	2021-06-28 08:01:26.770659
89	1	2	3	3	416	2021-06-23 09:30:38.678529	t	2021-06-28 08:01:26.770659
91	1	2	0	1	250	2021-06-23 09:31:21.787376	t	2021-06-28 08:01:26.770659
92	1	2	4	2	0	2021-06-23 09:53:23.849779	t	2021-06-28 08:01:26.770659
94	1	2	4	3	520	2021-06-23 10:00:42.096976	t	2021-06-28 08:01:26.770659
95	1	2	4	3	468	2021-06-23 10:00:42.382855	t	2021-06-28 08:01:26.770659
100	1	2	3	2	0	2021-06-23 11:04:27.596399	t	2021-06-28 08:01:26.770659
101	1	2	3	2	0	2021-06-23 11:05:36.950084	t	2021-06-28 08:01:26.770659
102	1	2	3	3	520	2021-06-23 11:30:49.334876	t	2021-06-28 08:01:26.770659
103	1	2	3	3	473	2021-06-23 11:30:49.411373	t	2021-06-28 08:01:26.770659
104	1	2	0	1	200	2021-06-23 13:28:49.960512	t	2021-06-28 08:01:26.770659
105	1	2	0	1	25	2021-06-23 13:29:29.19036	t	2021-06-28 08:01:26.770659
106	1	2	0	1	10	2021-06-23 13:29:44.832339	t	2021-06-28 08:01:26.770659
108	1	5	0	1	150	2021-06-24 02:35:19.23996	t	2021-06-28 08:01:26.770659
109	1	5	2	3	765	2021-06-24 03:00:14.831096	t	2021-06-28 08:01:26.770659
261	1	6	0	1	250	2021-06-25 07:37:42.940016	t	2021-06-28 08:01:26.770659
265	1	6	0	1	250	2021-06-25 07:38:13.835547	t	2021-06-28 08:01:26.770659
272	1	2	0	1	10	2021-06-25 07:43:41.204719	t	2021-06-28 08:01:26.770659
286	1	6	0	1	25	2021-06-25 07:57:03.848987	t	2021-06-28 08:01:26.770659
289	1	6	0	1	300	2021-06-25 07:57:27.526383	t	2021-06-28 08:01:26.770659
313	1	6	0	1	300	2021-06-25 08:16:13.971908	t	2021-06-28 08:01:26.770659
14	1	2	0	1	300	2021-06-21 07:49:56.14258	t	2021-06-28 08:01:26.770659
15	1	2	0	1	300	2021-06-21 07:50:31.745476	t	2021-06-28 08:01:26.770659
16	1	2	0	1	10	2021-06-21 07:50:50.777698	t	2021-06-28 08:01:26.770659
17	1	2	0	1	200	2021-06-21 07:51:18.416681	t	2021-06-28 08:01:26.770659
20	1	3	0	1	250	2021-06-21 08:02:18.099411	t	2021-06-28 08:01:26.770659
45	1	6	3	3	309	2021-06-22 03:30:18.112476	t	2021-06-28 08:01:26.770659
46	1	2	4	2	0	2021-06-22 03:41:49.479535	t	2021-06-28 08:01:26.770659
47	1	2	4	3	510	2021-06-22 04:00:19.203032	t	2021-06-28 08:01:26.770659
52	1	6	2	3	515	2021-06-22 05:00:31.752128	t	2021-06-28 08:01:26.770659
53	1	6	2	3	468	2021-06-22 05:00:31.829566	t	2021-06-28 08:01:26.770659
54	1	5	4	3	750	2021-06-22 12:00:57.934565	t	2021-06-28 08:01:26.770659
55	1	5	4	3	684	2021-06-22 12:00:58.047927	t	2021-06-28 08:01:26.770659
56	1	5	4	3	608	2021-06-22 12:00:58.143085	t	2021-06-28 08:01:26.770659
61	1	5	4	3	760	2021-06-22 14:00:28.959251	t	2021-06-28 08:01:26.770659
62	1	5	4	3	684	2021-06-22 14:00:29.06352	t	2021-06-28 08:01:26.770659
72	1	2	3	2	0	2021-06-23 03:23:26.064789	t	2021-06-28 08:01:26.770659
73	1	2	3	3	520	2021-06-23 03:30:08.266476	t	2021-06-28 08:01:26.770659
74	1	2	0	1	50	2021-06-23 03:39:17.2067	t	2021-06-28 08:01:26.770659
75	1	2	0	1	400	2021-06-23 03:39:33.49709	t	2021-06-28 08:01:26.770659
83	1	2	3	2	0	2021-06-23 09:27:21.884801	t	2021-06-28 08:01:26.770659
110	1	2	4	3	525	2021-06-24 08:00:49.203031	t	2021-06-28 08:01:26.770659
112	1	2	1	3	525	2021-06-24 08:30:52.785691	t	2021-06-28 08:01:26.770659
113	1	2	1	3	473	2021-06-24 08:30:52.865666	t	2021-06-28 08:01:26.770659
114	1	2	1	3	420	2021-06-24 08:30:52.995006	t	2021-06-28 08:01:26.770659
115	1	2	1	3	368	2021-06-24 08:30:53.073966	t	2021-06-28 08:01:26.770659
116	1	2	1	3	315	2021-06-24 08:30:53.152406	t	2021-06-28 08:01:26.770659
117	1	2	1	3	105	2021-06-24 08:30:53.230666	t	2021-06-28 08:01:26.770659
120	1	6	0	1	50	2021-06-24 08:32:38.148482	t	2021-06-28 08:01:26.770659
121	1	6	0	1	50	2021-06-24 08:32:43.855214	t	2021-06-28 08:01:26.770659
122	1	6	0	1	350	2021-06-24 08:32:49.594887	t	2021-06-28 08:01:26.770659
123	1	6	0	1	25	2021-06-24 08:53:20.21988	t	2021-06-28 08:01:26.770659
124	1	6	0	1	10	2021-06-24 08:53:25.52353	t	2021-06-28 08:01:26.770659
130	1	6	0	1	25	2021-06-24 09:30:23.401335	t	2021-06-28 08:01:26.770659
131	1	6	0	1	10	2021-06-24 09:30:29.142044	t	2021-06-28 08:01:26.770659
132	1	6	0	1	150	2021-06-24 09:30:37.865498	t	2021-06-28 08:01:26.770659
133	1	6	0	1	25	2021-06-24 09:30:47.654056	t	2021-06-28 08:01:26.770659
135	1	6	0	1	10	2021-06-24 09:31:01.476489	t	2021-06-28 08:01:26.770659
136	1	6	0	1	50	2021-06-24 09:31:21.552001	t	2021-06-28 08:01:26.770659
138	1	6	0	1	500	2021-06-24 09:37:20.633175	t	2021-06-28 08:01:26.770659
139	1	6	0	1	150	2021-06-24 09:37:26.532149	t	2021-06-28 08:01:26.770659
142	1	6	0	1	300	2021-06-24 09:38:00.164399	t	2021-06-28 08:01:26.770659
145	1	2	0	1	350	2021-06-24 10:14:28.878757	t	2021-06-28 08:01:26.770659
151	1	2	0	1	50	2021-06-24 10:19:30.627914	t	2021-06-28 08:01:26.770659
155	1	2	0	1	50	2021-06-24 10:31:20.969074	t	2021-06-28 08:01:26.770659
158	1	2	0	1	25	2021-06-24 10:56:06.890263	t	2021-06-28 08:01:26.770659
161	1	2	0	1	250	2021-06-24 10:58:00.086755	t	2021-06-28 08:01:26.770659
165	1	2	0	1	350	2021-06-24 11:16:49.466089	t	2021-06-28 08:01:26.770659
169	1	5	0	1	10	2021-06-24 12:31:43.815452	t	2021-06-28 08:01:26.770659
172	1	5	0	1	10	2021-06-24 12:33:22.387557	t	2021-06-28 08:01:26.770659
174	1	5	0	1	25	2021-06-24 12:34:39.771121	t	2021-06-28 08:01:26.770659
176	1	5	0	1	150	2021-06-24 12:35:06.390329	t	2021-06-28 08:01:26.770659
181	1	2	0	1	150	2021-06-25 02:31:43.418826	t	2021-06-28 08:01:26.770659
188	1	5	0	1	50	2021-06-25 02:53:06.93264	t	2021-06-28 08:01:26.770659
197	1	2	0	1	50	2021-06-25 03:22:52.714199	t	2021-06-28 08:01:26.770659
200	1	2	0	1	400	2021-06-25 03:28:09.782979	t	2021-06-28 08:01:26.770659
203	1	2	0	1	400	2021-06-25 03:34:35.226894	t	2021-06-28 08:01:26.770659
242	1	3	1	2	0	2021-06-25 06:08:33.942231	t	2021-06-28 08:01:26.770659
243	1	3	1	3	510	2021-06-25 06:30:08.562625	t	2021-06-28 08:01:26.770659
244	1	3	1	3	459	2021-06-25 06:30:08.663313	t	2021-06-28 08:01:26.770659
245	1	3	1	3	408	2021-06-25 06:30:08.767595	t	2021-06-28 08:01:26.770659
246	1	10	1	3	350	2021-06-25 06:30:08.879211	t	2021-06-28 08:01:26.770659
247	1	10	1	3	300	2021-06-25 06:30:08.948216	t	2021-06-28 08:01:26.770659
248	1	3	1	3	204	2021-06-25 06:30:09.026582	t	2021-06-28 08:01:26.770659
249	1	3	1	3	206	2021-06-25 06:30:09.103423	t	2021-06-28 08:01:26.770659
250	1	10	1	3	200	2021-06-25 06:30:09.181208	t	2021-06-28 08:01:26.770659
259	1	6	0	1	500	2021-06-25 07:37:12.804491	t	2021-06-28 08:01:26.770659
269	1	2	4	2	0	2021-06-25 07:40:48.773805	t	2021-06-28 08:01:26.770659
307	1	6	0	1	10	2021-06-25 08:06:29.242426	t	2021-06-28 08:01:26.770659
309	1	6	0	1	150	2021-06-25 08:07:30.486683	t	2021-06-28 08:01:26.770659
319	1	6	0	1	200	2021-06-25 08:23:24.217059	t	2021-06-28 08:01:26.770659
321	1	6	0	1	50	2021-06-25 08:23:43.095155	t	2021-06-28 08:01:26.770659
331	1	6	0	1	250	2021-06-25 08:38:51.229986	t	2021-06-28 08:01:26.770659
335	1	6	0	1	10	2021-06-25 08:47:33.030131	t	2021-06-28 08:01:26.770659
341	1	6	0	1	150	2021-06-25 08:56:39.134348	t	2021-06-28 08:01:26.770659
347	1	2	3	2	0	2021-06-25 09:07:50.931252	t	2021-06-28 08:01:26.770659
362	1	5	0	1	200	2021-06-26 04:45:41.461393	t	2021-06-28 08:01:26.770659
397	1	6	0	1	10	2021-06-28 05:00:08.833017	t	2021-06-28 08:01:26.770659
399	1	6	0	1	300	2021-06-28 05:07:10.569985	t	2021-06-28 08:01:26.770659
403	1	6	0	1	25	2021-06-28 05:48:45.68346	t	2021-06-28 08:01:26.770659
406	1	6	0	1	350	2021-06-28 05:49:03.627032	t	2021-06-28 08:01:26.770659
413	1	2	4	2	0	2021-06-28 05:55:49.475214	t	2021-06-28 08:01:26.770659
419	1	2	4	3	535	2021-06-28 06:00:26.807386	t	2021-06-28 08:01:26.770659
420	1	2	4	3	482	2021-06-28 06:00:26.988397	t	2021-06-28 08:01:26.770659
434	1	6	0	1	200	2021-06-28 06:13:24.553763	t	2021-06-28 08:01:26.770659
437	1	6	0	1	25	2021-06-28 06:13:38.512789	t	2021-06-28 08:01:26.770659
448	1	6	0	1	10	2021-06-28 06:38:58.030418	t	2021-06-28 08:01:26.770659
526	1	2	4	3	540	2021-06-28 08:00:44.210284	t	2021-06-28 08:01:26.770659
542	0	6	0	1	200	2021-06-28 08:23:39.883686	f	1970-01-01 00:00:00
586	29	8	2	3	100	2021-06-29 05:20:59.482428	t	2021-06-29 06:41:18.875516
587	29	8	2	3	100	2021-06-29 05:20:59.579689	t	2021-06-29 06:41:18.875516
588	29	3	2	3	100	2021-06-29 05:20:59.685091	t	2021-06-29 06:41:18.875516
589	29	8	2	3	100	2021-06-29 05:20:59.734955	t	2021-06-29 06:41:18.875516
596	29	9	3	3	500	2021-06-29 05:30:09.965441	t	2021-06-29 06:41:18.875516
597	29	8	3	3	450	2021-06-29 05:30:10.022767	t	2021-06-29 06:41:18.875516
598	29	8	3	3	400	2021-06-29 05:30:10.082653	t	2021-06-29 06:41:18.875516
599	29	8	3	3	350	2021-06-29 05:30:10.139324	t	2021-06-29 06:41:18.875516
600	29	8	3	3	300	2021-06-29 05:30:10.200426	t	2021-06-29 06:41:18.875516
601	29	8	3	3	100	2021-06-29 05:30:10.251725	t	2021-06-29 06:41:18.875516
602	29	8	3	3	100	2021-06-29 05:30:10.291819	t	2021-06-29 06:41:18.875516
603	29	8	3	3	100	2021-06-29 05:30:10.339796	t	2021-06-29 06:41:18.875516
604	29	8	3	3	100	2021-06-29 05:30:10.384094	t	2021-06-29 06:41:18.875516
605	29	9	3	3	100	2021-06-29 05:30:10.433233	t	2021-06-29 06:41:18.875516
670	29	8	0	1	500	2021-06-29 06:31:35.185034	t	2021-06-29 06:41:18.875516
684	31	3	1	2	0	2021-06-29 06:55:42.67253	t	2021-06-29 07:01:23.226086
686	31	3	1	2	0	2021-06-29 06:58:02.773003	t	2021-06-29 07:01:23.226086
703	33	3	0	1	300	2021-06-29 07:39:36.165518	t	2021-06-29 07:51:29.206297
\.


--
-- Data for Name: prize_tour; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.prize_tour (id, prize_id, tour_id, status) FROM stdin;
1	1	1	0
4	3	4	0
5	5	5	0
12	7	3	0
13	8	5	0
14	0	3	0
15	9	3	0
16	0	3	0
17	12	3	0
18	15	5	0
19	16	2	0
20	0	1	0
21	18	5	0
22	19	1	0
23	20	2	0
24	0	2	0
25	23	1	0
26	24	1	0
27	25	2	0
28	26	3	0
29	2	3	0
30	28	3	0
31	29	9	0
32	30	10	0
33	31	11	0
34	33	12	0
35	34	13	0
36	35	11	0
\.


--
-- Data for Name: prize_type; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.prize_type (id, title) FROM stdin;
0	Not Selected
4	Automated Entry
3	Time Sensitive
1	Featured
2	Premium
\.


--
-- Data for Name: rank; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.rank (id, title, exp, gem, multiplier) FROM stdin;
3	Level 3	50	0	0
4	Level 4	100	0	0
5	Level 5	180	0	0
6	Level 6	300	0	0
7	Level 7	450	0	0
8	Level 8	630	0	0
9	Level 9	850	0	0
1	Level 1	0	0	0
2	Level 2	15	0	0
\.


--
-- Data for Name: shop_buy; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.shop_buy (id, item_type_id, item_id, user_id, payment_id, sub_id, price, created_on) FROM stdin;
1	201	1	5	pi_1J3yZSBGCaV2oEVpxOV9OWWp		0.99	2021-06-19 07:26:44.410102
2	101	1	5	pi_1J3yaKBGCaV2oEVpFgaAs0WF	sub_JhNLRuVefERSsN	19.99	2021-06-19 07:27:22.366956
5	201	1	5	pi_1J5iUaBGCaV2oEVp4rFptXlq		0.99	2021-06-24 02:40:51.636347
6	201	1	2	pi_1J7KG9BGCaV2oEVpUDMILf7N		0.99	2021-06-28 13:12:36.78385
7	201	1	3	pi_1J7bBUBGCaV2oEVp92XAvVJH		0.99	2021-06-29 07:16:58.554021
8	201	1	2	pi_1J7yGMBGCaV2oEVpWKawpuAG		0.99	2021-06-30 07:55:26.313093
\.


--
-- Data for Name: spinner_extra_log; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.spinner_extra_log (id, free_spins, created_on, user_id) FROM stdin;
1	3	2021-06-21 08:05:20.053631	2
2	3	2021-06-24 09:30:54.320243	6
3	3	2021-06-24 09:33:21.391143	6
4	3	2021-06-24 09:37:36.940245	6
5	3	2021-06-24 10:30:23.154328	2
6	3	2021-06-24 10:55:02.623254	2
7	3	2021-06-24 10:57:33.795353	2
8	3	2021-06-24 11:15:56.900374	2
9	3	2021-06-24 11:30:33.009053	2
10	3	2021-06-24 14:11:32.971091	5
11	3	2021-06-25 03:24:36.715972	2
12	3	2021-06-25 03:34:04.04196	2
13	3	2021-06-25 07:37:47.042858	6
14	3	2021-06-25 07:42:00.105327	2
15	3	2021-06-25 07:46:32.893203	6
16	3	2021-06-25 07:51:51.39247	2
17	3	2021-06-25 07:56:47.172313	6
18	3	2021-06-25 07:57:16.997872	6
19	3	2021-06-25 07:57:38.802784	6
20	3	2021-06-25 08:06:53.165908	6
21	3	2021-06-25 08:15:13.621882	6
22	3	2021-06-25 08:16:18.014356	6
23	3	2021-06-25 08:23:09.866959	6
24	3	2021-06-25 08:23:28.08138	6
25	3	2021-06-25 08:23:52.332531	6
26	3	2021-06-25 08:26:26.974256	6
27	3	2021-06-25 08:27:18.297656	6
28	3	2021-06-25 08:39:03.0134	6
29	3	2021-06-25 08:39:38.309779	2
30	3	2021-06-25 08:49:22.306572	6
31	3	2021-06-25 08:56:32.154244	6
32	0	2021-06-25 08:56:51.098531	6
33	0	2021-06-28 02:42:02.129053	9
34	0	2021-06-28 02:54:43.278037	9
35	3	2021-06-28 05:16:07.28128	6
36	3	2021-06-28 05:48:53.578817	6
37	3	2021-06-28 05:49:14.697694	6
38	3	2021-06-28 05:56:10.291602	6
39	3	2021-06-28 05:58:51.787606	6
40	3	2021-06-28 06:07:10.075891	6
41	3	2021-06-28 06:08:08.532149	6
42	3	2021-06-28 06:13:18.978461	6
43	3	2021-06-28 06:13:31.746885	6
44	3	2021-06-28 06:19:36.19761	6
45	3	2021-06-28 06:25:00.784777	6
46	3	2021-06-28 06:34:01.49071	6
47	3	2021-06-28 06:39:39.847328	6
48	3	2021-06-28 06:55:22.338975	6
49	3	2021-06-28 06:57:10.144632	6
50	3	2021-06-28 06:58:30.82343	6
51	3	2021-06-28 07:00:10.040424	6
52	3	2021-06-28 07:06:28.115453	6
53	3	2021-06-28 07:08:03.978762	6
54	3	2021-06-28 07:13:52.612289	6
55	3	2021-06-28 07:15:51.203744	6
56	3	2021-06-28 07:16:12.217858	6
57	3	2021-06-28 07:17:56.603734	6
58	3	2021-06-28 07:22:53.318621	6
59	3	2021-06-28 07:34:40.054861	6
60	3	2021-06-28 07:35:02.798323	6
61	3	2021-06-28 07:35:26.509983	6
62	3	2021-06-28 07:48:15.364214	6
63	3	2021-06-28 07:50:53.627891	6
64	3	2021-06-28 07:51:06.225727	6
65	3	2021-06-28 07:52:01.969435	6
66	3	2021-06-28 07:58:05.109205	6
67	3	2021-06-28 07:58:16.475989	6
68	3	2021-06-28 07:58:57.637774	6
69	3	2021-06-28 08:18:01.937276	6
70	3	2021-06-28 08:19:21.18888	6
71	3	2021-06-28 08:23:25.276923	6
72	3	2021-06-28 08:23:38.873702	6
73	3	2021-06-28 08:25:40.441319	6
74	3	2021-06-28 08:25:52.68865	6
75	3	2021-06-28 08:26:05.233476	6
76	3	2021-06-28 08:35:39.210875	6
77	3	2021-06-29 07:02:38.804803	3
78	3	2021-06-29 07:39:04.235922	3
79	3	2021-06-29 07:39:19.307632	3
\.


--
-- Data for Name: spinner_log; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.spinner_log (id, user_id, prize_id, win_type, win_amount, enter_timestamp, leave_timestamp, is_logged_leave, is_watched_ad, is_used_gem) FROM stdin;
1	2	1	1	500	2021-06-21 07:19:53.990243	2021-06-21 07:19:55.277473	t	f	f
2	2	1	1	0	2021-06-21 07:19:55.381695	1970-01-01 00:00:00	f	f	f
3	2	1	1	50	2021-06-21 07:40:10.594916	2021-06-21 07:40:12.857142	t	f	f
4	2	1	1	0	2021-06-21 07:40:12.983312	1970-01-01 00:00:00	f	f	f
5	2	1	1	500	2021-06-21 07:45:57.222756	2021-06-21 07:46:00.984641	t	f	f
6	2	1	1	0	2021-06-21 07:46:01.114535	1970-01-01 00:00:00	f	f	f
7	2	1	1	250	2021-06-21 07:48:54.820871	2021-06-21 07:49:01.669734	t	f	f
8	2	1	1	0	2021-06-21 07:49:01.790166	1970-01-01 00:00:00	f	f	f
9	2	1	1	300	2021-06-21 07:49:48.590886	2021-06-21 07:49:56.134356	t	f	f
10	2	1	1	0	2021-06-21 07:49:56.253985	1970-01-01 00:00:00	f	f	f
11	2	1	1	300	2021-06-21 07:50:28.04515	2021-06-21 07:50:31.733772	t	f	f
12	2	1	1	0	2021-06-21 07:50:31.825183	1970-01-01 00:00:00	f	f	f
13	2	1	1	10	2021-06-21 07:50:49.075376	2021-06-21 07:50:50.766544	t	f	f
14	2	1	1	0	2021-06-21 07:50:50.883908	1970-01-01 00:00:00	f	f	f
15	2	1	1	200	2021-06-21 07:51:16.234304	2021-06-21 07:51:18.407094	t	f	f
16	2	1	1	0	2021-06-21 07:51:18.513843	1970-01-01 00:00:00	f	f	f
17	3	1	1	250	2021-06-21 08:02:15.792758	2021-06-21 08:02:18.090518	t	f	f
18	3	1	1	0	2021-06-21 08:02:18.146214	1970-01-01 00:00:00	f	f	f
19	3	1	1	200	2021-06-21 08:02:55.461415	2021-06-21 08:03:00.102732	t	f	f
20	3	1	1	0	2021-06-21 08:03:00.171789	1970-01-01 00:00:00	f	f	f
21	3	1	1	25	2021-06-21 08:03:47.545381	2021-06-21 08:03:49.427933	t	f	f
22	3	1	1	0	2021-06-21 08:03:49.489811	1970-01-01 00:00:00	f	f	f
23	3	1	1	50	2021-06-21 08:04:07.402662	2021-06-21 08:04:09.245576	t	f	f
24	3	1	1	0	2021-06-21 08:04:09.312905	1970-01-01 00:00:00	f	f	f
25	2	1	1	50	2021-06-21 08:04:29.317285	2021-06-21 08:04:31.224762	t	f	f
26	2	1	1	0	2021-06-21 08:04:31.322797	1970-01-01 00:00:00	f	f	f
27	2	1	1	150	2021-06-21 08:04:52.007446	2021-06-21 08:04:54.099297	t	f	f
28	3	1	1	0	2021-06-21 08:05:14.575578	1970-01-01 00:00:00	f	f	f
30	3	1	1	200	2021-06-21 08:05:21.269643	2021-06-21 08:05:24.558315	t	f	f
31	3	1	1	0	2021-06-21 08:05:24.617229	1970-01-01 00:00:00	f	f	f
29	2	0	1	50	2021-06-21 08:05:20.100448	2021-06-21 08:05:30.898692	t	f	f
32	2	1	1	0	2021-06-21 08:05:31.008311	1970-01-01 00:00:00	f	f	f
33	3	1	1	0	2021-06-21 08:05:33.162331	1970-01-01 00:00:00	f	f	f
34	3	1	1	10	2021-06-21 08:05:39.498741	2021-06-21 08:05:40.802149	t	f	f
35	3	1	1	0	2021-06-21 08:05:40.859971	1970-01-01 00:00:00	f	f	f
36	2	1	1	10	2021-06-21 08:05:45.010761	2021-06-21 08:05:48.246404	t	f	f
37	2	1	1	0	2021-06-21 08:05:48.351114	1970-01-01 00:00:00	f	f	f
38	2	1	1	10	2021-06-21 08:05:57.734443	2021-06-21 08:05:59.706191	t	f	f
39	3	1	1	0	2021-06-21 09:15:59.293402	1970-01-01 00:00:00	f	f	f
40	3	3	1	200	2021-06-21 09:22:24.827359	2021-06-21 09:22:27.145254	t	f	f
41	3	3	1	0	2021-06-21 09:22:27.240574	1970-01-01 00:00:00	f	f	f
42	2	1	1	50	2021-06-23 03:39:15.032638	2021-06-23 03:39:17.199379	t	f	f
43	2	1	1	0	2021-06-23 03:39:17.283608	1970-01-01 00:00:00	f	f	f
44	2	1	1	400	2021-06-23 03:39:31.05102	2021-06-23 03:39:33.487789	t	f	f
45	2	1	1	0	2021-06-23 03:39:33.579938	1970-01-01 00:00:00	f	f	f
46	2	3	1	0	2021-06-23 06:48:51.410611	1970-01-01 00:00:00	f	f	f
47	2	3	1	25	2021-06-23 06:48:57.772251	2021-06-23 06:49:00.20231	t	f	f
48	2	3	1	0	2021-06-23 06:49:00.296856	1970-01-01 00:00:00	f	f	f
49	2	3	1	250	2021-06-23 06:49:19.642399	2021-06-23 06:49:24.794043	t	f	f
50	2	3	1	0	2021-06-23 06:49:24.881229	1970-01-01 00:00:00	f	f	f
51	2	1	1	250	2021-06-23 09:31:18.45227	2021-06-23 09:31:21.774471	t	f	f
52	2	1	1	0	2021-06-23 09:31:21.870689	1970-01-01 00:00:00	f	f	f
53	2	1	1	0	2021-06-23 09:32:15.22753	1970-01-01 00:00:00	f	f	f
54	2	1	1	0	2021-06-23 10:56:48.537192	1970-01-01 00:00:00	f	f	f
55	2	1	1	200	2021-06-23 13:28:44.18498	2021-06-23 13:28:49.953405	t	f	f
56	2	1	1	0	2021-06-23 13:28:50.041078	1970-01-01 00:00:00	f	f	f
57	2	1	1	25	2021-06-23 13:29:26.052498	2021-06-23 13:29:29.181806	t	f	f
58	2	1	1	0	2021-06-23 13:29:29.276262	1970-01-01 00:00:00	f	f	f
59	2	1	1	10	2021-06-23 13:29:40.804932	2021-06-23 13:29:44.826012	t	f	f
60	2	1	1	0	2021-06-23 13:29:44.919364	1970-01-01 00:00:00	f	f	f
61	2	3	1	150	2021-06-23 13:30:33.582255	2021-06-23 13:30:35.974572	t	f	f
62	2	3	1	0	2021-06-23 13:30:36.057098	1970-01-01 00:00:00	f	f	f
63	5	1	1	150	2021-06-24 02:35:13.488538	2021-06-24 02:35:19.223335	t	f	f
64	5	1	1	0	2021-06-24 02:35:19.299959	1970-01-01 00:00:00	f	f	f
65	9	1	1	0	2021-06-24 05:30:48.53023	1970-01-01 00:00:00	f	f	f
66	9	3	1	0	2021-06-24 07:08:38.72526	1970-01-01 00:00:00	f	f	f
67	6	3	1	50	2021-06-24 08:10:54.697057	2021-06-24 08:10:56.355617	t	f	f
68	6	3	1	0	2021-06-24 08:10:56.412482	1970-01-01 00:00:00	f	f	f
69	6	1	1	0	2021-06-24 08:29:09.511826	1970-01-01 00:00:00	f	f	f
70	6	1	1	50	2021-06-24 08:32:33.325115	2021-06-24 08:32:38.141129	t	f	f
71	6	1	1	50	2021-06-24 08:32:38.217291	2021-06-24 08:32:43.845563	t	f	f
72	6	1	1	350	2021-06-24 08:32:43.906406	2021-06-24 08:32:49.59002	t	f	f
73	6	1	1	0	2021-06-24 08:32:49.650363	1970-01-01 00:00:00	f	f	f
74	6	1	1	0	2021-06-24 08:33:19.430058	1970-01-01 00:00:00	f	f	f
75	6	2	1	0	2021-06-24 08:41:15.445752	1970-01-01 00:00:00	f	f	f
76	6	1	1	25	2021-06-24 08:43:50.99054	2021-06-24 08:53:20.210234	t	f	f
77	6	1	1	10	2021-06-24 08:53:20.26823	2021-06-24 08:53:25.515419	t	f	f
78	6	1	1	0	2021-06-24 08:53:25.582239	1970-01-01 00:00:00	f	f	f
79	6	1	1	0	2021-06-24 08:55:02.347714	1970-01-01 00:00:00	f	f	f
80	6	1	1	25	2021-06-24 09:30:20.988347	2021-06-24 09:30:23.395259	t	f	f
81	6	1	1	10	2021-06-24 09:30:23.45393	2021-06-24 09:30:29.133504	t	f	f
82	6	1	1	150	2021-06-24 09:30:29.20466	2021-06-24 09:30:37.860815	t	f	f
83	6	1	1	25	2021-06-24 09:30:37.922336	2021-06-24 09:30:47.648706	t	f	f
84	6	0	1	500	2021-06-24 09:30:54.345991	2021-06-24 09:30:55.794741	t	f	f
85	6	1	1	10	2021-06-24 09:30:55.863825	2021-06-24 09:31:01.466748	t	f	f
86	6	1	1	50	2021-06-24 09:31:01.535424	2021-06-24 09:31:21.54465	t	f	f
87	6	0	1	50	2021-06-24 09:33:21.413477	2021-06-24 09:33:24.271526	t	f	f
88	6	1	1	0	2021-06-24 09:33:24.330642	1970-01-01 00:00:00	f	f	f
89	6	1	1	500	2021-06-24 09:37:16.317734	2021-06-24 09:37:20.622102	t	f	f
90	6	1	1	150	2021-06-24 09:37:20.702309	2021-06-24 09:37:26.525219	t	f	f
91	6	0	1	25	2021-06-24 09:37:36.963426	2021-06-24 09:37:42.117988	t	f	f
92	6	1	1	250	2021-06-24 09:37:42.178629	2021-06-24 09:37:48.036888	t	f	f
93	6	1	1	300	2021-06-24 09:37:48.094464	2021-06-24 09:38:00.156922	t	f	f
94	2	1	1	0	2021-06-24 10:12:59.177142	1970-01-01 00:00:00	f	f	f
95	2	1	1	300	2021-06-24 10:13:06.3555	2021-06-24 10:13:07.873892	t	f	f
96	2	1	1	0	2021-06-24 10:13:08.008279	1970-01-01 00:00:00	f	f	f
97	2	1	1	350	2021-06-24 10:14:26.574607	2021-06-24 10:14:28.871446	t	f	f
98	2	1	1	0	2021-06-24 10:14:28.959785	1970-01-01 00:00:00	f	f	f
99	2	1	1	50	2021-06-24 10:15:17.678151	2021-06-24 10:15:19.932412	t	f	f
100	2	1	1	0	2021-06-24 10:15:20.02039	1970-01-01 00:00:00	f	f	f
101	2	1	1	50	2021-06-24 10:16:49.410399	2021-06-24 10:16:52.978104	t	f	f
102	2	1	1	0	2021-06-24 10:16:53.182093	1970-01-01 00:00:00	f	f	f
104	2	1	1	0	2021-06-24 10:17:46.922206	1970-01-01 00:00:00	f	f	f
105	2	1	1	10	2021-06-24 10:18:22.411756	2021-06-24 10:18:23.772594	t	f	f
106	2	1	1	0	2021-06-24 10:18:23.862972	1970-01-01 00:00:00	f	f	f
108	2	1	1	0	2021-06-24 10:18:43.109963	1970-01-01 00:00:00	f	f	f
110	2	1	1	50	2021-06-24 10:19:27.655617	2021-06-24 10:19:30.619745	t	f	f
112	2	1	1	350	2021-06-24 10:19:45.667513	2021-06-24 10:19:47.825242	t	f	f
113	2	1	1	50	2021-06-24 10:19:47.907038	2021-06-24 10:19:57.883368	t	f	f
103	2	1	1	150	2021-06-24 10:17:44.076595	2021-06-24 10:17:46.835431	t	f	f
107	2	1	1	25	2021-06-24 10:18:39.884627	2021-06-24 10:18:43.024475	t	f	f
109	2	1	1	0	2021-06-24 10:19:09.265215	1970-01-01 00:00:00	f	f	f
111	2	1	1	0	2021-06-24 10:19:30.727588	1970-01-01 00:00:00	f	f	f
114	2	0	1	0	2021-06-24 10:30:23.193395	1970-01-01 00:00:00	f	f	f
115	2	1	1	10	2021-06-24 10:30:40.19853	2021-06-24 10:30:42.198858	t	f	f
116	2	1	1	0	2021-06-24 10:30:42.302028	1970-01-01 00:00:00	f	f	f
117	2	1	1	50	2021-06-24 10:31:17.278557	2021-06-24 10:31:20.953012	t	f	f
118	2	1	1	0	2021-06-24 10:31:21.135803	1970-01-01 00:00:00	f	f	f
119	2	1	1	0	2021-06-24 10:46:48.322416	1970-01-01 00:00:00	f	f	f
120	2	1	1	250	2021-06-24 10:54:16.091565	2021-06-24 10:54:21.230855	t	f	f
121	2	0	1	250	2021-06-24 10:55:02.668574	2021-06-24 10:55:34.888188	t	f	f
122	2	1	1	25	2021-06-24 10:55:34.984794	2021-06-24 10:56:06.883143	t	f	f
123	2	1	1	300	2021-06-24 10:56:06.979344	2021-06-24 10:56:25.548783	t	f	f
124	2	0	1	250	2021-06-24 10:57:33.835873	2021-06-24 10:57:42.898429	t	f	f
125	2	1	1	0	2021-06-24 10:57:42.988445	1970-01-01 00:00:00	f	f	f
126	2	1	1	250	2021-06-24 10:57:57.351848	2021-06-24 10:58:00.079827	t	f	f
127	2	1	1	0	2021-06-24 10:58:00.168706	1970-01-01 00:00:00	f	f	f
128	2	1	1	50	2021-06-24 11:09:59.904448	2021-06-24 11:10:24.62051	t	f	f
129	2	0	1	150	2021-06-24 11:15:56.944564	2021-06-24 11:15:58.719998	t	f	f
130	2	1	1	0	2021-06-24 11:15:58.842605	1970-01-01 00:00:00	f	f	f
131	2	1	1	350	2021-06-24 11:16:16.167363	2021-06-24 11:16:19.409033	t	f	f
132	2	1	1	350	2021-06-24 11:16:19.499033	2021-06-24 11:16:49.458706	t	f	f
133	2	0	1	150	2021-06-24 11:30:33.048849	2021-06-24 11:30:35.331636	t	f	f
134	2	3	1	0	2021-06-24 11:30:35.415808	1970-01-01 00:00:00	f	f	f
135	2	3	1	0	2021-06-24 11:31:01.576481	1970-01-01 00:00:00	f	f	f
136	2	3	1	150	2021-06-24 11:31:08.825841	2021-06-24 11:31:11.383138	t	f	f
137	2	3	1	0	2021-06-24 11:31:11.46692	1970-01-01 00:00:00	f	f	f
138	2	2	1	0	2021-06-24 11:54:49.414219	1970-01-01 00:00:00	f	f	f
139	2	2	1	300	2021-06-24 11:54:57.310487	2021-06-24 11:54:58.314317	t	f	f
140	5	1	1	10	2021-06-24 12:31:38.165883	2021-06-24 12:31:43.807958	t	f	f
141	5	1	1	0	2021-06-24 12:31:43.884697	1970-01-01 00:00:00	f	f	f
142	5	1	1	50	2021-06-24 12:31:57.447639	2021-06-24 12:31:59.494573	t	f	f
143	5	1	1	0	2021-06-24 12:31:59.566799	1970-01-01 00:00:00	f	f	f
144	5	1	1	50	2021-06-24 12:33:05.868429	2021-06-24 12:33:08.305253	t	f	f
145	5	1	1	0	2021-06-24 12:33:08.371379	1970-01-01 00:00:00	f	f	f
146	5	1	1	10	2021-06-24 12:33:20.496296	2021-06-24 12:33:22.380584	t	f	f
147	5	1	1	0	2021-06-24 12:33:22.452483	1970-01-01 00:00:00	f	f	f
148	5	1	1	25	2021-06-24 12:33:32.765024	2021-06-24 12:33:34.70759	t	f	f
149	5	1	1	0	2021-06-24 12:33:34.775629	1970-01-01 00:00:00	f	f	f
150	5	1	1	25	2021-06-24 12:34:37.266044	2021-06-24 12:34:39.767213	t	f	f
151	5	1	1	0	2021-06-24 12:34:39.84348	1970-01-01 00:00:00	f	f	f
152	5	1	1	150	2021-06-24 12:34:49.758283	2021-06-24 12:34:51.908095	t	f	f
153	5	1	1	0	2021-06-24 12:34:51.976565	1970-01-01 00:00:00	f	f	f
154	5	1	1	150	2021-06-24 12:35:01.743579	2021-06-24 12:35:06.383557	t	f	f
155	5	1	1	0	2021-06-24 12:35:06.462944	1970-01-01 00:00:00	f	f	f
156	5	1	1	10	2021-06-24 14:11:13.680967	2021-06-24 14:11:17.296774	t	f	f
157	5	0	1	500	2021-06-24 14:11:33.025105	2021-06-24 14:16:15.411139	t	f	f
158	5	1	1	500	2021-06-24 14:16:15.483877	2021-06-24 14:16:25.525409	t	f	f
159	5	1	1	0	2021-06-24 14:16:25.595849	1970-01-01 00:00:00	f	f	f
160	5	1	1	0	2021-06-24 14:18:03.266006	1970-01-01 00:00:00	f	f	f
161	6	1	1	0	2021-06-25 01:38:26.892382	1970-01-01 00:00:00	f	f	f
162	6	1	1	0	2021-06-25 02:06:42.018578	1970-01-01 00:00:00	f	f	f
163	6	3	1	0	2021-06-25 02:09:03.633918	1970-01-01 00:00:00	f	f	f
164	2	3	1	50	2021-06-25 02:30:57.702881	2021-06-25 02:31:02.342922	t	f	f
165	2	3	1	0	2021-06-25 02:31:02.436981	1970-01-01 00:00:00	f	f	f
166	2	1	1	150	2021-06-25 02:31:39.596002	2021-06-25 02:31:43.413098	t	f	f
167	2	1	1	0	2021-06-25 02:31:43.502498	1970-01-01 00:00:00	f	f	f
168	6	2	1	0	2021-06-25 02:40:37.850162	1970-01-01 00:00:00	f	f	f
169	6	2	1	0	2021-06-25 02:41:12.575716	1970-01-01 00:00:00	f	f	f
170	5	1	1	25	2021-06-25 02:41:47.853386	2021-06-25 02:41:50.261707	t	f	f
172	6	2	1	0	2021-06-25 02:43:52.988493	1970-01-01 00:00:00	f	f	f
171	5	1	1	50	2021-06-25 02:41:50.41944	2021-06-25 02:44:38.923584	t	f	f
174	6	2	1	10	2021-06-25 02:48:30.712783	2021-06-25 02:48:36.274885	t	f	f
175	6	2	1	300	2021-06-25 02:48:36.328362	2021-06-25 02:48:48.382003	t	f	f
176	6	2	1	0	2021-06-25 02:48:48.449881	1970-01-01 00:00:00	f	f	f
177	6	2	1	150	2021-06-25 02:49:03.622601	2021-06-25 02:49:07.340449	t	f	f
178	6	2	1	200	2021-06-25 02:49:07.396219	2021-06-25 02:49:20.932776	t	f	f
179	6	2	1	0	2021-06-25 02:49:21.001849	1970-01-01 00:00:00	f	f	f
180	6	1	1	0	2021-06-25 02:50:01.691415	1970-01-01 00:00:00	f	f	f
173	5	1	1	50	2021-06-25 02:44:39.051147	2021-06-25 02:53:06.922434	t	f	f
181	5	1	1	0	2021-06-25 02:53:11.254789	1970-01-01 00:00:00	f	f	f
182	6	2	1	0	2021-06-25 02:56:39.837216	1970-01-01 00:00:00	f	f	f
183	2	1	1	150	2021-06-25 03:02:57.624427	2021-06-25 03:03:00.86681	t	f	f
184	2	1	1	0	2021-06-25 03:03:00.953791	1970-01-01 00:00:00	f	f	f
185	6	3	1	150	2021-06-25 03:03:10.407343	2021-06-25 03:03:34.992777	t	f	f
186	6	3	1	0	2021-06-25 03:03:35.068497	1970-01-01 00:00:00	f	f	f
187	2	1	1	250	2021-06-25 03:03:59.653239	2021-06-25 03:04:03.212015	t	f	f
188	2	1	1	0	2021-06-25 03:04:03.305989	1970-01-01 00:00:00	f	f	f
189	2	1	1	10	2021-06-25 03:04:23.796447	2021-06-25 03:04:25.413963	t	f	f
190	2	1	1	0	2021-06-25 03:04:25.504845	1970-01-01 00:00:00	f	f	f
191	6	3	1	0	2021-06-25 03:11:58.273471	1970-01-01 00:00:00	f	f	f
192	6	3	1	0	2021-06-25 03:14:20.527404	1970-01-01 00:00:00	f	f	f
193	6	3	1	0	2021-06-25 03:14:27.95073	1970-01-01 00:00:00	f	f	f
194	2	2	1	150	2021-06-25 03:15:09.787095	2021-06-25 03:15:13.734183	t	f	f
195	2	2	1	0	2021-06-25 03:15:13.823967	1970-01-01 00:00:00	f	f	f
196	2	1	1	300	2021-06-25 03:15:58.122086	2021-06-25 03:16:01.14176	t	f	f
197	2	1	1	0	2021-06-25 03:16:01.229977	1970-01-01 00:00:00	f	f	f
198	2	1	1	400	2021-06-25 03:19:01.820679	2021-06-25 03:19:04.046646	t	f	f
199	2	1	1	0	2021-06-25 03:19:04.144908	1970-01-01 00:00:00	f	f	f
200	2	1	1	250	2021-06-25 03:20:33.23704	2021-06-25 03:20:36.678066	t	f	f
201	2	1	1	0	2021-06-25 03:20:36.770432	1970-01-01 00:00:00	f	f	f
202	2	1	1	50	2021-06-25 03:22:49.729659	2021-06-25 03:22:52.705353	t	f	f
203	2	0	1	200	2021-06-25 03:24:36.763113	2021-06-25 03:24:38.715546	t	f	f
204	2	2	1	0	2021-06-25 03:24:38.809092	1970-01-01 00:00:00	f	f	f
205	2	2	1	300	2021-06-25 03:24:48.822777	2021-06-25 03:24:52.869938	t	f	f
206	2	2	1	0	2021-06-25 03:24:53.017816	1970-01-01 00:00:00	f	f	f
207	6	3	1	0	2021-06-25 03:27:53.957889	1970-01-01 00:00:00	f	f	f
208	2	1	1	400	2021-06-25 03:28:05.921758	2021-06-25 03:28:09.776205	t	f	f
209	2	0	1	150	2021-06-25 03:34:04.084646	2021-06-25 03:34:07.319193	t	f	f
210	2	1	1	0	2021-06-25 03:34:07.41751	1970-01-01 00:00:00	f	f	f
211	2	1	1	25	2021-06-25 03:34:16.427596	2021-06-25 03:34:22.005631	t	f	f
212	2	1	1	0	2021-06-25 03:34:22.093884	1970-01-01 00:00:00	f	f	f
213	2	1	1	400	2021-06-25 03:34:33.437261	2021-06-25 03:34:35.220918	t	f	f
214	6	2	1	0	2021-06-25 03:35:25.73535	1970-01-01 00:00:00	f	f	f
215	6	1	1	150	2021-06-25 05:00:09.155434	2021-06-25 05:00:44.697905	t	f	f
216	6	1	1	0	2021-06-25 05:00:44.752661	1970-01-01 00:00:00	f	f	f
217	6	1	1	0	2021-06-25 05:02:11.192549	1970-01-01 00:00:00	f	f	f
218	6	1	1	0	2021-06-25 05:06:14.565543	1970-01-01 00:00:00	f	f	f
219	6	3	1	0	2021-06-25 05:26:01.259673	1970-01-01 00:00:00	f	f	f
220	6	1	1	0	2021-06-25 05:29:44.736241	1970-01-01 00:00:00	f	f	f
221	6	2	1	0	2021-06-25 05:49:20.828227	1970-01-01 00:00:00	f	f	f
222	6	1	1	0	2021-06-25 05:59:20.569391	1970-01-01 00:00:00	f	f	f
223	6	3	1	0	2021-06-25 06:31:51.395542	1970-01-01 00:00:00	f	f	f
224	6	1	1	0	2021-06-25 06:36:47.139687	1970-01-01 00:00:00	f	f	f
225	6	1	1	0	2021-06-25 07:01:49.972476	1970-01-01 00:00:00	f	f	f
226	6	1	1	0	2021-06-25 07:09:54.756506	1970-01-01 00:00:00	f	f	f
227	6	1	1	0	2021-06-25 07:19:57.754156	1970-01-01 00:00:00	f	f	f
228	6	1	1	50	2021-06-25 07:23:53.363065	2021-06-25 07:23:58.076359	t	f	f
229	6	1	1	0	2021-06-25 07:23:58.133118	1970-01-01 00:00:00	f	f	f
230	6	1	1	0	2021-06-25 07:26:25.655212	1970-01-01 00:00:00	f	f	f
231	6	1	1	0	2021-06-25 07:30:02.389688	1970-01-01 00:00:00	f	f	f
232	6	1	1	500	2021-06-25 07:37:10.58318	2021-06-25 07:37:12.794772	t	f	f
233	6	1	1	200	2021-06-25 07:37:12.865136	2021-06-25 07:37:20.656452	t	f	f
234	6	1	1	0	2021-06-25 07:37:20.713558	1970-01-01 00:00:00	f	f	f
235	6	1	1	250	2021-06-25 07:37:39.582563	2021-06-25 07:37:42.933954	t	f	f
236	6	0	1	10	2021-06-25 07:37:47.06294	2021-06-25 07:37:48.883457	t	f	f
237	6	1	1	0	2021-06-25 07:37:48.933259	1970-01-01 00:00:00	f	f	f
238	6	1	1	25	2021-06-25 07:38:02.911144	2021-06-25 07:38:05.063271	t	f	f
239	6	1	1	250	2021-06-25 07:38:05.153709	2021-06-25 07:38:13.827557	t	f	f
240	2	0	1	50	2021-06-25 07:42:00.145163	2021-06-25 07:42:02.04957	t	f	f
241	2	1	1	0	2021-06-25 07:42:02.144735	1970-01-01 00:00:00	f	f	f
242	2	1	1	0	2021-06-25 07:42:57.271483	1970-01-01 00:00:00	f	f	f
243	2	1	1	200	2021-06-25 07:43:03.558776	2021-06-25 07:43:05.917441	t	f	f
244	2	1	1	0	2021-06-25 07:43:06.02026	1970-01-01 00:00:00	f	f	f
245	2	1	1	10	2021-06-25 07:43:37.586794	2021-06-25 07:43:41.197391	t	f	f
246	6	0	1	250	2021-06-25 07:46:32.915231	2021-06-25 07:48:18.283921	t	f	f
247	6	1	1	0	2021-06-25 07:48:18.358619	1970-01-01 00:00:00	f	f	f
248	2	0	1	50	2021-06-25 07:51:51.434502	2021-06-25 07:51:54.793978	t	f	f
249	2	3	1	0	2021-06-25 07:51:54.878903	1970-01-01 00:00:00	f	f	f
250	2	3	1	250	2021-06-25 07:52:30.207071	2021-06-25 07:52:34.043643	t	f	f
251	2	3	1	0	2021-06-25 07:52:34.135969	1970-01-01 00:00:00	f	f	f
252	6	1	1	10	2021-06-25 07:55:06.38642	2021-06-25 07:55:14.787524	t	f	f
253	6	1	1	150	2021-06-25 07:55:14.880312	2021-06-25 07:55:24.505261	t	f	f
254	6	0	1	50	2021-06-25 07:56:47.195752	2021-06-25 07:56:51.365204	t	f	f
255	6	1	1	25	2021-06-25 07:56:51.449337	2021-06-25 07:57:03.842319	t	f	f
256	6	1	1	50	2021-06-25 07:57:03.918754	2021-06-25 07:57:11.762575	t	f	f
257	6	0	1	10	2021-06-25 07:57:17.017746	2021-06-25 07:57:19.736228	t	f	f
258	6	1	1	300	2021-06-25 07:57:19.810559	2021-06-25 07:57:27.51996	t	f	f
259	6	1	1	300	2021-06-25 07:57:27.58911	2021-06-25 07:57:34.71348	t	f	f
260	6	0	1	50	2021-06-25 07:57:38.822845	2021-06-25 07:57:42.726856	t	f	f
261	6	1	1	250	2021-06-25 07:57:42.797698	2021-06-25 07:57:55.03488	t	f	f
262	6	1	1	0	2021-06-25 07:57:55.11821	1970-01-01 00:00:00	f	f	f
263	2	3	1	0	2021-06-25 07:59:25.722931	1970-01-01 00:00:00	f	f	f
264	2	3	1	150	2021-06-25 08:04:53.723186	2021-06-25 08:04:57.07429	t	f	f
265	6	1	1	10	2021-06-25 08:05:55.561115	2021-06-25 08:06:29.236293	t	f	f
266	6	0	1	50	2021-06-25 08:06:53.18911	2021-06-25 08:07:00.890937	t	f	f
267	6	1	1	150	2021-06-25 08:07:00.950145	2021-06-25 08:07:30.468586	t	f	f
268	6	1	1	0	2021-06-25 08:07:30.554257	1970-01-01 00:00:00	f	f	f
269	6	1	1	200	2021-06-25 08:14:48.908118	2021-06-25 08:15:04.590641	t	f	f
270	6	0	1	300	2021-06-25 08:15:13.644751	2021-06-25 08:15:17.476673	t	f	f
271	6	1	1	50	2021-06-25 08:15:17.536571	2021-06-25 08:16:05.269357	t	f	f
272	6	1	1	300	2021-06-25 08:16:05.333913	2021-06-25 08:16:13.964132	t	f	f
273	6	0	1	10	2021-06-25 08:16:18.0336	2021-06-25 08:16:20.054279	t	f	f
274	6	1	1	25	2021-06-25 08:16:20.121158	2021-06-25 08:16:30.115433	t	f	f
275	6	1	1	0	2021-06-25 08:16:30.173137	1970-01-01 00:00:00	f	f	f
276	6	1	1	350	2021-06-25 08:23:03.814063	2021-06-25 08:23:05.688584	t	f	f
277	6	0	1	50	2021-06-25 08:23:09.889056	2021-06-25 08:23:12.479685	t	f	f
278	6	1	1	50	2021-06-25 08:23:12.546677	2021-06-25 08:23:18.303117	t	f	f
279	6	1	1	200	2021-06-25 08:23:18.371495	2021-06-25 08:23:24.209833	t	f	f
280	6	0	1	50	2021-06-25 08:23:28.102124	2021-06-25 08:23:29.919697	t	f	f
281	6	1	1	50	2021-06-25 08:23:29.977797	2021-06-25 08:23:43.086465	t	f	f
282	6	1	1	400	2021-06-25 08:23:43.153564	2021-06-25 08:23:48.696866	t	f	f
283	6	0	1	50	2021-06-25 08:23:52.354684	2021-06-25 08:23:54.294981	t	f	f
284	6	1	1	200	2021-06-25 08:23:54.351571	2021-06-25 08:23:59.886069	t	f	f
285	6	1	1	400	2021-06-25 08:23:59.946057	2021-06-25 08:26:22.284764	t	f	f
286	6	0	1	250	2021-06-25 08:26:26.994794	2021-06-25 08:26:28.05154	t	f	f
287	6	1	1	150	2021-06-25 08:26:28.110544	2021-06-25 08:26:37.020375	t	f	f
288	6	1	1	0	2021-06-25 08:26:37.075534	1970-01-01 00:00:00	f	f	f
289	6	1	1	300	2021-06-25 08:26:51.258721	2021-06-25 08:27:12.717476	t	f	f
290	6	0	1	25	2021-06-25 08:27:18.319085	2021-06-25 08:31:31.624296	t	f	f
291	6	1	1	500	2021-06-25 08:31:31.693554	2021-06-25 08:36:59.206573	t	f	f
292	6	1	1	0	2021-06-25 08:36:59.261943	1970-01-01 00:00:00	f	f	f
293	6	1	1	250	2021-06-25 08:38:36.584379	2021-06-25 08:38:51.214501	t	f	f
294	6	0	1	200	2021-06-25 08:39:03.036921	2021-06-25 08:39:15.076733	t	f	f
296	2	0	1	0	2021-06-25 08:39:38.353428	1970-01-01 00:00:00	f	f	f
297	2	1	1	350	2021-06-25 08:39:57.415613	2021-06-25 08:40:00.095251	t	f	f
298	2	1	1	0	2021-06-25 08:40:00.185342	1970-01-01 00:00:00	f	f	f
303	6	0	1	0	2021-06-25 08:49:22.32859	1970-01-01 00:00:00	f	f	f
299	2	3	1	25	2021-06-25 08:43:05.756227	2021-06-25 08:43:09.247043	t	f	f
300	2	3	1	0	2021-06-25 08:43:09.59345	1970-01-01 00:00:00	f	f	f
306	6	1	1	150	2021-06-25 08:56:18.629595	2021-06-25 08:56:26.950236	t	f	f
307	6	0	1	500	2021-06-25 08:56:32.177522	2021-06-25 08:56:33.478083	t	f	f
301	3	1	1	0	2021-06-25 08:46:26.904623	1970-01-01 00:00:00	f	f	f
295	6	1	1	10	2021-06-25 08:39:15.145944	2021-06-25 08:47:33.01968	t	f	f
302	6	1	1	350	2021-06-25 08:47:33.079554	2021-06-25 08:48:02.895213	t	f	f
304	6	1	1	200	2021-06-25 08:54:44.157201	2021-06-25 08:54:54.44495	t	f	f
309	6	1	1	150	2021-06-25 08:56:39.190718	2021-06-25 08:56:44.960551	t	f	f
305	6	1	1	10	2021-06-25 08:54:54.528328	2021-06-25 08:56:18.569125	t	f	f
308	6	1	1	150	2021-06-25 08:56:33.549257	2021-06-25 08:56:39.127621	t	f	f
310	9	28	1	0	2021-06-25 09:06:12.363309	1970-01-01 00:00:00	f	f	f
311	2	1	1	250	2021-06-25 09:07:04.871608	2021-06-25 09:07:07.683959	t	f	f
312	9	28	1	0	2021-06-25 09:09:11.442966	1970-01-01 00:00:00	f	f	f
313	9	28	1	0	2021-06-25 09:10:15.458762	1970-01-01 00:00:00	f	f	f
314	5	1	1	500	2021-06-25 10:07:35.794139	2021-06-25 10:07:39.090856	t	f	f
315	5	1	1	350	2021-06-25 10:07:39.16489	2021-06-25 10:07:49.46123	t	f	f
316	5	1	1	0	2021-06-25 10:07:49.532453	1970-01-01 00:00:00	f	f	f
317	5	1	1	200	2021-06-26 04:45:38.282714	2021-06-26 04:45:41.455448	t	f	f
318	5	1	1	0	2021-06-26 04:45:41.527074	1970-01-01 00:00:00	f	f	f
319	9	28	1	10	2021-06-28 01:56:08.055075	2021-06-28 01:56:38.956946	t	f	f
320	9	28	1	0	2021-06-28 01:56:39.039696	1970-01-01 00:00:00	f	f	f
321	9	28	1	50	2021-06-28 02:00:14.676209	2021-06-28 02:00:24.581116	t	f	f
322	9	28	1	0	2021-06-28 02:00:24.66307	1970-01-01 00:00:00	f	f	f
323	9	28	1	50	2021-06-28 02:08:57.887366	2021-06-28 02:10:43.151468	t	f	f
324	9	28	1	0	2021-06-28 02:10:43.216738	1970-01-01 00:00:00	f	f	f
325	9	28	1	0	2021-06-28 02:17:39.932837	1970-01-01 00:00:00	f	f	f
326	9	28	1	500	2021-06-28 02:18:56.485502	2021-06-28 02:19:08.061537	t	f	f
327	9	28	1	10	2021-06-28 02:19:08.123393	2021-06-28 02:19:14.837347	t	f	f
328	9	28	1	0	2021-06-28 02:19:14.906122	1970-01-01 00:00:00	f	f	f
329	9	28	1	250	2021-06-28 02:25:11.92012	2021-06-28 02:30:07.631815	t	f	f
330	9	28	1	0	2021-06-28 02:30:07.703544	1970-01-01 00:00:00	f	f	f
331	9	28	1	150	2021-06-28 02:37:25.722698	2021-06-28 02:37:45.706397	t	f	f
332	9	28	1	500	2021-06-28 02:37:45.783172	2021-06-28 02:37:51.305181	t	f	f
333	9	28	1	25	2021-06-28 02:37:51.366009	2021-06-28 02:37:57.161795	t	f	f
334	9	28	1	0	2021-06-28 02:37:57.216385	1970-01-01 00:00:00	f	f	f
335	9	28	1	350	2021-06-28 02:41:40.500146	2021-06-28 02:41:58.358844	t	f	f
336	6	28	1	250	2021-06-28 03:50:23.210544	2021-06-28 03:51:07.154829	t	f	f
337	6	28	1	25	2021-06-28 03:51:07.221687	2021-06-28 03:51:18.08428	t	f	f
338	6	28	1	400	2021-06-28 03:51:18.153925	2021-06-28 03:51:24.86715	t	f	f
339	6	28	1	50	2021-06-28 03:51:24.947781	2021-06-28 03:51:34.821853	t	f	f
340	6	28	1	0	2021-06-28 03:51:34.88382	1970-01-01 00:00:00	f	f	f
341	6	28	1	0	2021-06-28 03:55:19.088549	1970-01-01 00:00:00	f	f	f
342	6	1	1	0	2021-06-28 03:59:50.220652	1970-01-01 00:00:00	f	f	f
343	6	28	1	400	2021-06-28 04:30:47.84334	2021-06-28 04:31:30.745893	t	f	f
344	6	28	1	0	2021-06-28 04:31:30.841774	1970-01-01 00:00:00	f	f	f
345	6	28	1	0	2021-06-28 04:33:50.946935	1970-01-01 00:00:00	f	f	f
346	2	1	1	250	2021-06-28 04:51:00.499399	2021-06-28 04:51:02.984292	t	f	f
347	2	1	1	0	2021-06-28 04:51:03.084295	1970-01-01 00:00:00	f	f	f
348	6	28	1	0	2021-06-28 04:53:18.380612	1970-01-01 00:00:00	f	f	f
349	6	1	1	250	2021-06-28 04:56:41.77097	2021-06-28 04:56:58.326052	t	f	f
350	6	1	1	0	2021-06-28 04:56:58.398332	1970-01-01 00:00:00	f	f	f
351	6	1	1	10	2021-06-28 05:00:06.807951	2021-06-28 05:00:08.824017	t	f	f
352	6	1	1	0	2021-06-28 05:00:08.907921	1970-01-01 00:00:00	f	f	f
353	6	1	1	0	2021-06-28 05:04:29.122363	1970-01-01 00:00:00	f	f	f
354	6	1	1	300	2021-06-28 05:06:33.483782	2021-06-28 05:07:10.566118	t	f	f
355	6	1	1	0	2021-06-28 05:07:10.651891	1970-01-01 00:00:00	f	f	f
356	6	1	1	10	2021-06-28 05:14:28.532356	2021-06-28 05:15:43.558952	t	f	f
357	6	1	1	50	2021-06-28 05:15:49.460238	2021-06-28 05:16:02.813723	t	f	f
358	6	0	1	150	2021-06-28 05:16:07.301751	2021-06-28 05:16:08.635151	t	f	f
359	6	1	1	0	2021-06-28 05:16:08.695585	1970-01-01 00:00:00	f	f	f
360	6	1	1	0	2021-06-28 05:27:56.319942	1970-01-01 00:00:00	f	f	f
361	6	1	1	0	2021-06-28 05:36:40.6603	1970-01-01 00:00:00	f	f	f
362	6	1	1	25	2021-06-28 05:48:32.117838	2021-06-28 05:48:45.677454	t	f	f
363	6	1	1	150	2021-06-28 05:48:45.742233	2021-06-28 05:48:49.340099	t	f	f
364	6	0	1	10	2021-06-28 05:48:53.598504	2021-06-28 05:48:54.65286	t	f	f
365	6	1	1	350	2021-06-28 05:48:54.71645	2021-06-28 05:49:03.621201	t	f	f
366	6	1	1	250	2021-06-28 05:49:03.678455	2021-06-28 05:49:09.037021	t	f	f
367	6	0	1	400	2021-06-28 05:49:14.71777	2021-06-28 05:49:15.821301	t	f	f
368	6	1	1	0	2021-06-28 05:49:15.888686	1970-01-01 00:00:00	f	f	f
369	6	1	1	150	2021-06-28 05:51:13.984738	2021-06-28 05:51:19.346268	t	f	f
370	6	1	1	0	2021-06-28 05:51:19.40561	1970-01-01 00:00:00	f	f	f
371	6	1	1	25	2021-06-28 05:55:07.464748	2021-06-28 05:55:16.027381	t	f	f
372	6	0	1	25	2021-06-28 05:56:10.311749	2021-06-28 05:56:15.007829	t	f	f
373	6	1	1	0	2021-06-28 05:56:15.081778	1970-01-01 00:00:00	f	f	f
374	6	1	1	200	2021-06-28 05:58:29.653878	2021-06-28 05:58:41.88621	t	f	f
375	6	1	1	150	2021-06-28 05:58:41.965931	2021-06-28 05:58:46.677584	t	f	f
376	6	0	1	0	2021-06-28 05:58:51.808347	1970-01-01 00:00:00	f	f	f
377	6	1	1	300	2021-06-28 06:04:21.297313	2021-06-28 06:04:26.68299	t	f	f
378	6	1	1	150	2021-06-28 06:04:26.754838	2021-06-28 06:06:01.565055	t	f	f
379	6	1	1	0	2021-06-28 06:06:01.631638	1970-01-01 00:00:00	f	f	f
380	6	1	1	10	2021-06-28 06:06:59.310235	2021-06-28 06:07:05.075241	t	f	f
381	6	0	1	200	2021-06-28 06:07:10.095821	2021-06-28 06:07:11.374618	t	f	f
382	6	1	1	150	2021-06-28 06:07:11.432783	2021-06-28 06:07:59.025772	t	f	f
383	6	1	1	200	2021-06-28 06:07:59.081825	2021-06-28 06:08:03.971179	t	f	f
384	6	0	1	300	2021-06-28 06:08:08.553345	2021-06-28 06:08:09.511577	t	f	f
385	6	1	1	0	2021-06-28 06:08:09.56498	1970-01-01 00:00:00	f	f	f
386	6	1	1	500	2021-06-28 06:10:45.501769	2021-06-28 06:10:47.82409	t	f	f
387	6	1	1	0	2021-06-28 06:10:47.897672	1970-01-01 00:00:00	f	f	f
388	6	1	1	150	2021-06-28 06:11:39.765153	2021-06-28 06:11:42.974565	t	f	f
389	6	0	1	150	2021-06-28 06:13:18.999519	2021-06-28 06:13:20.372762	t	f	f
390	6	1	1	200	2021-06-28 06:13:20.461962	2021-06-28 06:13:24.549826	t	f	f
391	6	1	1	300	2021-06-28 06:13:24.605849	2021-06-28 06:13:28.172097	t	f	f
392	6	0	1	250	2021-06-28 06:13:31.77053	2021-06-28 06:13:32.468786	t	f	f
393	6	1	1	25	2021-06-28 06:13:32.523865	2021-06-28 06:13:38.50777	t	f	f
394	6	1	1	0	2021-06-28 06:13:38.562028	1970-01-01 00:00:00	f	f	f
395	6	1	1	400	2021-06-28 06:19:26.542503	2021-06-28 06:19:28.215258	t	f	f
396	6	0	1	10	2021-06-28 06:19:36.217746	2021-06-28 06:19:37.326305	t	f	f
397	6	1	1	0	2021-06-28 06:19:37.388914	1970-01-01 00:00:00	f	f	f
398	6	1	1	0	2021-06-28 06:22:21.572654	1970-01-01 00:00:00	f	f	f
399	6	28	1	300	2021-06-28 06:22:31.284584	2021-06-28 06:22:34.068453	t	f	f
400	6	28	1	0	2021-06-28 06:22:34.127754	1970-01-01 00:00:00	f	f	f
401	6	28	1	10	2021-06-28 06:23:59.30125	2021-06-28 06:24:54.97316	t	f	f
403	6	28	1	0	2021-06-28 06:25:02.008521	1970-01-01 00:00:00	f	f	f
402	6	0	1	250	2021-06-28 06:25:00.811959	2021-06-28 06:25:01.939862	t	f	f
404	6	28	1	300	2021-06-28 06:30:55.1254	2021-06-28 06:30:57.272591	t	f	f
405	6	28	1	400	2021-06-28 06:30:57.353749	2021-06-28 06:33:39.582737	t	f	f
406	6	0	1	50	2021-06-28 06:34:01.514642	2021-06-28 06:34:02.436658	t	f	f
407	6	28	1	0	2021-06-28 06:34:08.75363	1970-01-01 00:00:00	f	f	f
408	6	1	1	150	2021-06-28 06:38:49.856801	2021-06-28 06:38:51.491786	t	f	f
409	6	1	1	10	2021-06-28 06:38:51.565317	2021-06-28 06:38:58.024709	t	f	f
410	6	0	1	500	2021-06-28 06:39:39.869268	2021-06-28 06:39:41.185627	t	f	f
411	6	28	1	0	2021-06-28 06:39:47.139059	1970-01-01 00:00:00	f	f	f
412	6	28	1	50	2021-06-28 06:54:58.317061	2021-06-28 06:55:00.933483	t	f	f
413	6	28	1	300	2021-06-28 06:55:04.691485	2021-06-28 06:55:11.140731	t	f	f
414	6	0	1	500	2021-06-28 06:55:22.361964	2021-06-28 06:55:23.35646	t	f	f
415	6	28	1	150	2021-06-28 06:55:23.412941	2021-06-28 06:55:29.412998	t	f	f
416	6	28	1	25	2021-06-28 06:55:29.467248	2021-06-28 06:55:34.965748	t	f	f
417	6	0	1	50	2021-06-28 06:57:10.165518	2021-06-28 06:57:11.36685	t	f	f
418	6	28	1	50	2021-06-28 06:57:11.442604	2021-06-28 06:57:19.531997	t	f	f
419	6	28	1	0	2021-06-28 06:57:19.596365	1970-01-01 00:00:00	f	f	f
420	6	3	1	50	2021-06-28 06:58:15.77135	2021-06-28 06:58:19.797248	t	f	f
421	6	0	1	10	2021-06-28 06:58:30.844529	2021-06-28 06:58:36.718133	t	f	f
422	6	3	1	25	2021-06-28 06:58:36.773918	2021-06-28 06:59:16.236587	t	f	f
423	6	3	1	50	2021-06-28 06:59:21.137829	2021-06-28 06:59:32.80207	t	f	f
424	6	0	1	10	2021-06-28 07:00:10.06644	2021-06-28 07:00:11.048923	t	f	f
425	6	7	1	300	2021-06-28 07:04:36.038732	2021-06-28 07:04:53.52771	t	f	f
426	6	7	1	500	2021-06-28 07:05:37.770417	2021-06-28 07:05:44.151205	t	f	f
427	6	0	1	200	2021-06-28 07:06:28.138028	2021-06-28 07:06:29.126236	t	f	f
428	6	7	1	10	2021-06-28 07:06:32.224402	2021-06-28 07:06:45.553845	t	f	f
429	6	7	1	0	2021-06-28 07:06:48.034758	1970-01-01 00:00:00	f	f	f
430	6	7	1	250	2021-06-28 07:07:52.915505	2021-06-28 07:07:58.204782	t	f	f
431	6	0	1	350	2021-06-28 07:08:04.006318	2021-06-28 07:08:05.277731	t	f	f
432	6	7	1	0	2021-06-28 07:08:05.341965	1970-01-01 00:00:00	f	f	f
433	6	7	1	50	2021-06-28 07:13:32.111932	2021-06-28 07:13:34.38736	t	f	f
434	6	7	1	25	2021-06-28 07:13:34.45897	2021-06-28 07:13:40.622939	t	f	f
435	6	0	1	25	2021-06-28 07:13:52.633741	2021-06-28 07:13:55.454999	t	f	f
436	6	7	1	0	2021-06-28 07:13:55.504964	1970-01-01 00:00:00	f	f	f
437	6	7	1	25	2021-06-28 07:15:19.666367	2021-06-28 07:15:21.752305	t	f	f
438	6	7	1	500	2021-06-28 07:15:21.806032	2021-06-28 07:15:27.337036	t	f	f
439	6	0	1	400	2021-06-28 07:15:51.222977	2021-06-28 07:15:52.350666	t	f	f
440	6	7	1	150	2021-06-28 07:15:52.402205	2021-06-28 07:15:58.680491	t	f	f
441	6	7	1	200	2021-06-28 07:15:58.735751	2021-06-28 07:16:04.235519	t	f	f
442	6	0	1	500	2021-06-28 07:16:12.243512	2021-06-28 07:16:13.798117	t	f	f
443	6	7	1	500	2021-06-28 07:16:13.852089	2021-06-28 07:16:19.829555	t	f	f
444	6	7	1	200	2021-06-28 07:16:19.885016	2021-06-28 07:16:25.36067	t	f	f
445	6	0	1	25	2021-06-28 07:17:56.624262	2021-06-28 07:17:57.661468	t	f	f
446	6	28	1	0	2021-06-28 07:17:57.72059	1970-01-01 00:00:00	f	f	f
447	6	28	1	25	2021-06-28 07:20:14.091225	2021-06-28 07:20:19.531985	t	f	f
448	6	28	1	500	2021-06-28 07:20:19.592721	2021-06-28 07:20:25.366752	t	f	f
449	6	0	1	500	2021-06-28 07:22:53.33997	2021-06-28 07:22:57.332095	t	f	f
450	6	3	1	0	2021-06-28 07:22:57.41706	1970-01-01 00:00:00	f	f	f
451	6	2	1	250	2021-06-28 07:23:54.960798	2021-06-28 07:23:56.729401	t	f	f
452	6	2	1	350	2021-06-28 07:23:56.787466	2021-06-28 07:24:03.31578	t	f	f
453	6	0	1	300	2021-06-28 07:34:40.103761	2021-06-28 07:34:43.293616	t	f	f
454	6	3	1	25	2021-06-28 07:34:43.366203	2021-06-28 07:34:51.096587	t	f	f
455	6	3	1	10	2021-06-28 07:34:51.154521	2021-06-28 07:34:57.111789	t	f	f
456	6	0	1	50	2021-06-28 07:35:02.81967	2021-06-28 07:35:03.697123	t	f	f
457	6	3	1	50	2021-06-28 07:35:03.760954	2021-06-28 07:35:10.536581	t	f	f
458	6	3	1	25	2021-06-28 07:35:10.594421	2021-06-28 07:35:17.015878	t	f	f
459	6	0	1	250	2021-06-28 07:35:26.531034	2021-06-28 07:35:27.583949	t	f	f
460	6	3	1	400	2021-06-28 07:35:27.645602	2021-06-28 07:35:33.951965	t	f	f
461	6	3	1	0	2021-06-28 07:35:34.006556	1970-01-01 00:00:00	f	f	f
462	6	2	1	50	2021-06-28 07:48:02.241048	2021-06-28 07:48:03.856143	t	f	f
463	6	0	1	50	2021-06-28 07:48:15.384221	2021-06-28 07:48:17.112223	t	f	f
464	6	2	1	0	2021-06-28 07:48:17.17437	1970-01-01 00:00:00	f	f	f
465	6	3	1	0	2021-06-28 07:48:37.287272	1970-01-01 00:00:00	f	f	f
466	6	3	1	150	2021-06-28 07:48:49.558902	2021-06-28 07:48:50.904102	t	f	f
467	6	3	1	0	2021-06-28 07:48:50.964689	1970-01-01 00:00:00	f	f	f
468	6	3	1	300	2021-06-28 07:50:48.550528	2021-06-28 07:50:49.471034	t	f	f
469	6	0	1	150	2021-06-28 07:50:53.650614	2021-06-28 07:50:54.710359	t	f	f
470	6	3	1	500	2021-06-28 07:50:54.76961	2021-06-28 07:50:58.639756	t	f	f
471	6	3	1	25	2021-06-28 07:50:58.698472	2021-06-28 07:51:02.447981	t	f	f
472	6	0	1	150	2021-06-28 07:51:06.246258	2021-06-28 07:51:07.205711	t	f	f
473	6	3	1	25	2021-06-28 07:51:07.258054	2021-06-28 07:51:11.037717	t	f	f
474	6	3	1	0	2021-06-28 07:51:11.100139	1970-01-01 00:00:00	f	f	f
475	6	3	1	250	2021-06-28 07:51:30.843318	2021-06-28 07:51:52.620267	t	f	f
476	6	0	1	200	2021-06-28 07:52:01.989684	2021-06-28 07:52:04.449297	t	f	f
477	6	3	1	25	2021-06-28 07:52:04.513305	2021-06-28 07:52:09.686181	t	f	f
478	6	3	1	0	2021-06-28 07:52:09.75944	1970-01-01 00:00:00	f	f	f
479	6	7	1	300	2021-06-28 07:54:55.482046	2021-06-28 07:54:57.347124	t	f	f
480	6	0	1	10	2021-06-28 07:58:05.131053	2021-06-28 07:58:06.1464	t	f	f
481	6	2	1	250	2021-06-28 07:58:06.223931	2021-06-28 07:58:09.481202	t	f	f
482	6	2	1	250	2021-06-28 07:58:09.548382	2021-06-28 07:58:13.0491	t	f	f
483	6	0	1	25	2021-06-28 07:58:16.496928	2021-06-28 07:58:17.464645	t	f	f
484	6	2	1	0	2021-06-28 07:58:17.530931	1970-01-01 00:00:00	f	f	f
485	6	3	1	50	2021-06-28 07:58:49.383437	2021-06-28 07:58:50.112622	t	f	f
486	6	3	1	200	2021-06-28 07:58:50.19143	2021-06-28 07:58:53.895532	t	f	f
487	6	0	1	250	2021-06-28 07:58:57.658345	2021-06-28 07:58:58.768017	t	f	f
488	6	3	1	10	2021-06-28 07:58:58.826503	2021-06-28 07:59:02.744188	t	f	f
489	6	3	1	0	2021-06-28 07:59:02.802524	1970-01-01 00:00:00	f	f	f
490	6	1	1	200	2021-06-28 08:17:47.122004	2021-06-28 08:17:50.996867	t	f	f
491	6	1	1	150	2021-06-28 08:19:07.31334	2021-06-28 08:19:08.889362	t	f	f
492	6	1	1	25	2021-06-28 08:19:08.96793	2021-06-28 08:19:13.184902	t	f	f
493	6	1	1	150	2021-06-28 08:19:13.248293	2021-06-28 08:19:17.165966	t	f	f
494	6	0	1	50	2021-06-28 08:19:21.213084	2021-06-28 08:19:22.385658	t	f	f
495	6	1	1	0	2021-06-28 08:19:22.45074	1970-01-01 00:00:00	f	f	f
496	6	1	1	400	2021-06-28 08:23:16.062152	2021-06-28 08:23:17.630662	t	f	f
497	6	1	1	25	2021-06-28 08:23:17.701892	2021-06-28 08:23:21.406672	t	f	f
498	6	0	1	250	2021-06-28 08:23:25.298025	2021-06-28 08:23:26.862442	t	f	f
499	6	1	1	400	2021-06-28 08:23:26.927373	2021-06-28 08:23:30.88549	t	f	f
500	6	1	1	250	2021-06-28 08:23:30.942498	2021-06-28 08:23:35.095724	t	f	f
502	6	1	1	0	2021-06-28 08:23:39.930733	1970-01-01 00:00:00	f	f	f
501	6	0	1	200	2021-06-28 08:23:38.898332	2021-06-28 08:23:39.878323	t	f	f
503	6	1	1	250	2021-06-28 08:25:30.644023	2021-06-28 08:25:32.792401	t	f	f
504	6	1	1	350	2021-06-28 08:25:32.864398	2021-06-28 08:25:36.676537	t	f	f
505	6	0	1	10	2021-06-28 08:25:40.460637	2021-06-28 08:25:41.444341	t	f	f
506	6	1	1	300	2021-06-28 08:25:41.495512	2021-06-28 08:25:45.222987	t	f	f
507	6	1	1	150	2021-06-28 08:25:45.293037	2021-06-28 08:25:48.996305	t	f	f
508	6	0	1	50	2021-06-28 08:25:52.708153	2021-06-28 08:25:53.643943	t	f	f
509	6	1	1	350	2021-06-28 08:25:53.696345	2021-06-28 08:25:57.455171	t	f	f
510	6	1	1	10	2021-06-28 08:25:57.514339	2021-06-28 08:26:01.309564	t	f	f
511	6	0	1	10	2021-06-28 08:26:05.257938	2021-06-28 08:26:06.172307	t	f	f
512	6	1	1	0	2021-06-28 08:26:06.230817	1970-01-01 00:00:00	f	f	f
513	6	1	1	50	2021-06-28 08:35:28.973203	2021-06-28 08:35:30.597761	t	f	f
514	6	1	1	250	2021-06-28 08:35:30.674505	2021-06-28 08:35:35.319458	t	f	f
515	6	0	1	500	2021-06-28 08:35:39.230765	2021-06-28 08:35:40.029295	t	f	f
516	6	1	1	0	2021-06-28 08:35:40.090563	1970-01-01 00:00:00	f	f	f
517	2	1	1	300	2021-06-28 10:16:33.479345	2021-06-28 10:16:37.036689	t	f	f
518	2	1	1	25	2021-06-28 10:16:37.123105	2021-06-28 10:16:45.648125	t	f	f
519	2	1	1	0	2021-06-28 10:16:45.739006	1970-01-01 00:00:00	f	f	f
520	8	29	1	150	2021-06-29 05:01:22.687251	2021-06-29 05:01:27.912901	t	f	f
521	8	29	1	150	2021-06-29 05:01:27.968063	2021-06-29 05:01:40.597809	t	f	f
522	8	29	1	0	2021-06-29 05:01:40.829269	1970-01-01 00:00:00	f	f	f
523	9	29	1	150	2021-06-29 05:21:36.608965	2021-06-29 05:23:56.37736	t	f	f
524	9	29	1	0	2021-06-29 05:23:56.450534	1970-01-01 00:00:00	f	f	f
525	9	29	1	50	2021-06-29 05:26:56.507839	2021-06-29 05:27:06.387808	t	f	f
526	9	29	1	0	2021-06-29 05:27:06.466418	1970-01-01 00:00:00	f	f	f
527	8	29	1	500	2021-06-29 05:28:25.77926	2021-06-29 05:28:30.298808	t	f	f
528	8	29	1	0	2021-06-29 05:28:30.357692	1970-01-01 00:00:00	f	f	f
529	8	29	1	350	2021-06-29 05:28:42.515421	2021-06-29 05:28:45.707908	t	f	f
530	8	29	1	0	2021-06-29 05:28:45.773679	1970-01-01 00:00:00	f	f	f
531	9	29	1	0	2021-06-29 05:32:23.757578	1970-01-01 00:00:00	f	f	f
532	3	29	1	250	2021-06-29 05:41:08.8636	2021-06-29 05:41:10.886184	t	f	f
533	3	29	1	0	2021-06-29 05:41:10.94151	1970-01-01 00:00:00	f	f	f
534	8	29	1	200	2021-06-29 06:02:44.540809	2021-06-29 06:02:47.892363	t	f	f
535	8	29	1	0	2021-06-29 06:02:48.191514	1970-01-01 00:00:00	f	f	f
536	3	29	1	250	2021-06-29 06:15:35.357273	2021-06-29 06:15:37.288531	t	f	f
537	3	29	1	25	2021-06-29 06:15:37.357884	2021-06-29 06:15:43.381466	t	f	f
538	3	29	1	25	2021-06-29 06:15:43.434857	2021-06-29 06:15:48.533138	t	f	f
539	3	29	1	25	2021-06-29 06:15:48.59224	2021-06-29 06:15:53.361979	t	f	f
540	3	29	1	0	2021-06-29 06:15:53.415656	1970-01-01 00:00:00	f	f	f
541	3	29	1	10	2021-06-29 06:16:25.237491	2021-06-29 06:16:27.277499	t	f	f
542	3	29	1	0	2021-06-29 06:16:27.332458	1970-01-01 00:00:00	f	f	f
543	3	29	1	150	2021-06-29 06:16:35.879842	2021-06-29 06:16:37.482752	t	f	f
544	3	29	1	0	2021-06-29 06:16:37.535496	1970-01-01 00:00:00	f	f	f
545	9	29	1	0	2021-06-29 06:19:59.467941	1970-01-01 00:00:00	f	f	f
546	9	29	1	0	2021-06-29 06:22:18.322263	1970-01-01 00:00:00	f	f	f
547	9	31	1	0	2021-06-29 06:25:53.432546	1970-01-01 00:00:00	f	f	f
548	9	31	1	0	2021-06-29 06:29:45.627642	1970-01-01 00:00:00	f	f	f
549	8	29	1	500	2021-06-29 06:31:32.503806	2021-06-29 06:31:35.178329	t	f	f
550	8	29	1	50	2021-06-29 06:31:35.236101	2021-06-29 06:31:41.283519	t	f	f
551	8	29	1	0	2021-06-29 06:31:41.33345	1970-01-01 00:00:00	f	f	f
552	3	31	1	150	2021-06-29 06:55:11.907474	2021-06-29 06:55:13.87688	t	f	f
553	3	31	1	200	2021-06-29 06:55:13.93504	2021-06-29 06:55:18.736749	t	f	f
554	3	31	1	0	2021-06-29 06:55:18.85037	1970-01-01 00:00:00	f	f	f
555	3	31	1	150	2021-06-29 07:02:31.887745	2021-06-29 07:02:33.167565	t	f	f
556	3	0	1	300	2021-06-29 07:02:38.829855	2021-06-29 07:02:41.518865	t	f	f
557	3	31	1	0	2021-06-29 07:02:41.569555	1970-01-01 00:00:00	f	f	f
558	9	29	1	0	2021-06-29 07:14:14.571437	1970-01-01 00:00:00	f	f	f
559	3	33	1	25	2021-06-29 07:38:42.277701	2021-06-29 07:38:43.607628	t	f	f
560	3	33	1	200	2021-06-29 07:38:43.668793	2021-06-29 07:38:47.654299	t	f	f
561	3	0	1	400	2021-06-29 07:39:04.259342	2021-06-29 07:39:05.323954	t	f	f
562	3	33	1	150	2021-06-29 07:39:05.386371	2021-06-29 07:39:11.125533	t	f	f
563	3	33	1	350	2021-06-29 07:39:11.182786	2021-06-29 07:39:15.446281	t	f	f
564	3	0	1	10	2021-06-29 07:39:19.330334	2021-06-29 07:39:20.076659	t	f	f
565	3	33	1	0	2021-06-29 07:39:20.130809	1970-01-01 00:00:00	f	f	f
566	3	33	1	300	2021-06-29 07:39:33.99738	2021-06-29 07:39:36.159168	t	f	f
567	3	33	1	50	2021-06-29 07:39:36.217623	2021-06-29 07:39:40.070887	t	f	f
568	9	29	1	0	2021-06-30 03:30:51.368266	1970-01-01 00:00:00	f	f	f
569	9	29	1	0	2021-06-30 03:30:55.729021	1970-01-01 00:00:00	f	f	f
570	9	29	1	0	2021-06-30 05:36:01.890434	1970-01-01 00:00:00	f	f	f
571	9	29	1	0	2021-06-30 05:36:18.953971	1970-01-01 00:00:00	f	f	f
572	9	31	1	0	2021-06-30 05:37:01.424714	1970-01-01 00:00:00	f	f	f
573	9	29	1	0	2021-06-30 05:39:09.487363	1970-01-01 00:00:00	f	f	f
574	9	29	1	0	2021-06-30 05:43:32.124427	1970-01-01 00:00:00	f	f	f
575	9	29	1	0	2021-06-30 05:50:33.590425	1970-01-01 00:00:00	f	f	f
576	9	29	1	0	2021-06-30 06:20:40.880756	1970-01-01 00:00:00	f	f	f
577	9	29	1	0	2021-06-30 06:26:18.876797	1970-01-01 00:00:00	f	f	f
578	9	30	1	0	2021-06-30 08:01:10.072836	1970-01-01 00:00:00	f	f	f
579	9	33	1	200	2021-06-30 08:08:56.111312	2021-06-30 08:08:57.429228	t	f	f
580	9	33	1	0	2021-06-30 08:08:57.481636	1970-01-01 00:00:00	f	f	f
581	9	29	1	0	2021-06-30 10:12:24.729918	1970-01-01 00:00:00	f	f	f
\.


--
-- Data for Name: spinner_rule; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.spinner_rule (id, probability, win, type_id) FROM stdin;
1	5	500	1
2	5	400	1
3	5	350	1
4	10	300	1
5	10	250	1
6	12	200	1
7	12	150	1
8	15	50	1
9	15	25	1
10	11	10	1
\.


--
-- Data for Name: spinner_win_type; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.spinner_win_type (id, title) FROM stdin;
1	Tickets
2	Gems
3	Cash
4	Free Spin
\.


--
-- Data for Name: status_progress_type; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.status_progress_type (id, title) FROM stdin;
0	Inactive
1	Running
666	Bad Link
999	Ended
9999	SOS Stopped
\.


--
-- Data for Name: status_type; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.status_type (id, title) FROM stdin;
0	Not Selected
1	Draft
2	Published
3	Archived/Disabled
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.subscription (id, title, subtitle, img_url, content, type_id, price, quantity, status, one_time_gem, one_time_multiplier, daily_gem, daily_multiplier, one_time_is_firstonly) FROM stdin;
1	VIP Subscription		https://wrongurl		1	19.99	30	2	0	0	0	0.5	f
\.


--
-- Data for Name: subscription_type; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.subscription_type (id, title) FROM stdin;
0	Not Selected
1	Day
2	Week
3	Month
4	Year
\.


--
-- Data for Name: timezones; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.timezones (id, "offset", stext, ltext) FROM stdin;
1	-12	GMT -12:00	(GMT -12:00) Eniwetok, Kwajalein
2	-11	GMT -11:00	(GMT -11:00) Midway Island, Samoa
3	-10	GMT -10:00	(GMT -10:00) Hawaii
4	-9	GMT -9:00	(GMT -9:00) Alaska
5	-8	GMT -8:00	(GMT -8:00) Pacific Time (US & Canada)
6	-7	GMT -7:00	(GMT -7:00) Mountain Time (US & Canada)
7	-6	GMT -6:00	(GMT -6:00) Central Time (US & Canada), Mexico City
8	-5	GMT -5:00	(GMT -5:00) Eastern Time (US & Canada), Bogota, Lima
9	-4	GMT -4:00	(GMT -4:00) Atlantic Time (Canada), Caracas, La Paz
10	-3.5	GMT -3:30	(GMT -3:30) Newfoundland
11	-3	GMT -3:00	(GMT -3:00) Brazil, Buenos Aires, Georgetown
12	-2	GMT -2:00	(GMT -2:00) Mid-Atlantic
13	-1	GMT -1:00	(GMT -1:00) Azores, Cape Verde Islands
14	0	GMT -0:00	(GMT) Western Europe Time, London, Lisbon, Casablanca
15	1	GMT +1:00	(GMT +1:00) Brussels, Copenhagen, Madrid, Paris
16	2	GMT +2:00	(GMT +2:00) Kaliningrad, South Africa
17	3	GMT +3:00	(GMT +3:00) Baghdad, Riyadh, Moscow, St. Petersburg
18	3.5	GMT +3:30	(GMT +3:30) Tehran
19	4	GMT +4:00	(GMT +4:00) Abu Dhabi, Muscat, Baku, Tbilisi
20	4.5	GMT +4:30	(GMT +4:30) Kabul
21	5	GMT +5:00	(GMT +5:00) Ekaterinburg, Islamabad, Karachi, Tashkent
22	5.5	GMT +5:30	(GMT +5:30) Bombay, Calcutta, Madras, New Delhi
23	5.75	GMT +5:45	(GMT +5:45) Kathmandu
24	6	GMT +6:00	(GMT +6:00) Almaty, Dhaka, Colombo
25	7	GMT +7:00	(GMT +7:00) Bangkok, Hanoi, Jakarta
26	8	GMT +8:00	(GMT +8:00) Beijing, Perth, Singapore, Hong Kong
27	9	GMT +9:00	(GMT +9:00) Tokyo, Seoul, Osaka, Sapporo, Yakutsk
28	9.5	GMT +9:30	(GMT +9:30) Adelaide, Darwin
29	10	GMT +10:00	(GMT +10:00) Eastern Australia, Guam, Vladivostok
30	11	GMT +11:00	(GMT +11:00) Magadan, Solomon Islands, New Caledonia
31	12	GMT +12:00	(GMT +12:00) Auckland, Wellington, Fiji, Kamchatka
\.


--
-- Data for Name: tour_set; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.tour_set (id, tour_id, set_id, status) FROM stdin;
1	0	1	0
3	0	2	0
5	0	3	0
6	0	3	0
7	1	1	0
8	2	1	0
9	2	2	0
11	3	2	0
12	4	3	0
13	5	3	0
14	8	2	0
15	6	3	0
16	9	5	0
17	9	6	0
18	10	7	0
19	10	8	0
20	11	9	0
21	12	9	0
22	13	7	0
\.


--
-- Data for Name: tournament; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.tournament (id, title, status) FROM stdin;
7	aee	1
8	aeee	1
6	aaa	1
5	210618_TimeSensitiveTournament_GroupFormat_1Set	3
4	210618_PremiumTournament_GroupFormat_1Set	3
3	210618_PremiumTournament_SingleFormat_1Set	3
2	210618_PremiumTournament_SingleFormat_2Set	3
1	210618_FeaturedTournament_SingleFormat_1Set	3
10	210629_PremiumTournament_GroupFormat_2Set	2
9	210618_FeaturedTournament_SingleFormat_2Set	2
11	210629_PremiumTournament_SingleFormat_1Set	2
12	210629_FeaturedTournament_SingleFormat_1Set	2
13	210629_PremiumTournament_GroupFormat_1Set	2
\.


--
-- Data for Name: tournament_set; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.tournament_set (id, title, duration_days, duration_hours, is_group) FROM stdin;
1	210618_SingleFormat_4Games_Set1	0	12	f
2	210618_SingleFormat_4Games_Set2	0	12	f
3	210618_GroupFormat_2Groups_Set1	0	12	t
4	210623_GroupFormat_2Groups_Set2	1	0	t
5	210629_SingleFormat_2Games_Set1	0	1	f
6	210629_SingleFormat_2Games_Set2	0	1	f
7	210629_GroupFormat_2Groups_Set1	0	1	t
8	210629_GroupFormat_2Groups_Set2	0	1	t
9	210629_SingleFormat_3Games	0	1	f
\.


--
-- Data for Name: tournament_set_game_rule; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.tournament_set_game_rule (id, set_id, game_id, duration_days, duration_hours, duration_minutes, group_id) FROM stdin;
1	1	1	0	0	30	0
2	1	2	0	0	30	0
3	1	3	0	0	30	0
4	1	4	0	0	30	0
5	2	5	0	0	30	0
6	2	6	0	0	30	0
7	2	3	0	0	30	0
8	2	7	0	0	30	0
22	4	6	0	0	30	1
23	4	5	0	0	30	1
24	4	7	0	0	30	1
25	4	2	0	0	30	2
26	4	3	0	0	30	2
27	4	1	0	0	30	2
28	5	1	0	0	10	0
29	5	2	0	0	10	0
30	6	3	0	0	10	0
32	6	2	0	0	10	0
33	7	4	0	0	10	1
34	7	5	0	0	10	1
35	7	6	0	0	10	2
36	7	7	0	0	10	2
38	8	6	0	0	10	1
39	8	5	0	0	10	1
40	8	4	0	0	10	2
41	8	7	0	0	10	2
42	9	1	0	0	10	0
43	9	2	0	0	10	0
44	9	3	0	0	10	0
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public."user" (id, username, passhash, email, phone, firstname, lastname, created_on, last_login, role_id, status, gem_balance, social_link_fb, social_link_google, avatar_url, exp, full_name, country_code, address, city, state, zip_code, country, is_email_confirmed, is_notify_allowed, is_notify_new_reward, is_notify_new_tournament, is_notify_tour_ending, nick_name, rank, msg_token, subscription_id, one_time_multiplier, daily_gem, daily_multiplier, one_time_is_firstonly, sub_daily_timestamp, exp_timestamp, msg_token_timestamp, sub_id) FROM stdin;
3	tNQg2zRLfRWFpncwU8d7nPggNc93	$argon2id$v=19$m=64,t=1,p=1$xDkeHvbGlSFXBgVMag4mwJC0c7DJjjMv5sqff5iuxfI$mVgvb5qtHMAbDBlFnRJxr4puuNio5QjgZTahoVasDSA	heman@esportsmini.com		Heman	Ling	2021-06-18 08:16:45.283407	2021-06-30 08:44:15.015059	200	1	107			https://esm-cdn.sgp1.cdn.digitaloceanspaces.com/app/images/avatars/avatar-19.svg	320	Jonny Woo	60	No. 15 Jalan Cempaka\nDasar Laut	Petaling Jaya	Selangor	48900	Malaysia	f	t	t	t	t	Pablo Mano	0	cZWgqpu73siD_QUGpbUDSF:APA91bG9OyTCVKbzZkbj4Yyaymg-MR0X_CNnv9ddgQ9fkp4iodedVHNTFg7DJOewPSI-YscUKiS3IEFlAc2Tbzsknz6obDmua9uVMm1hCfNT92NhtkitdRqnrOGY4e5-0e_3bdmwk-Oe	0	0	0	0	f	2021-06-29 08:20:15.467865	2021-06-29 08:20:15.471898	2021-06-25 06:29:15.086138	
8	CbKPpK6OBlbzzHR6NBXGr0SyzqB3	$argon2id$v=19$m=64,t=1,p=1$tSiGHXDpA7gfl2oe7AxR5iRqlVVHTTmEcRzusRL3Wpk$7+mkVf/C/g7Wiq7mTTdZy5ocB+TqhWJrMojKmiXET8I	desmondlee@gmail.com		Desmond	Lee	2021-06-23 12:56:33.718705	2021-06-30 00:51:57.899973	200	1	0			https://lh3.googleusercontent.com/a-/AOh14Gg8e5DRmMKooHAxmrJnFkHzKPGVePUdn52ufM_I4g=s96-c	134		0						f	t	t	t	t		0		0	0	0	0	f	2021-06-29 06:40:39.938729	2021-06-29 06:40:39.941401	1970-01-01 00:00:00	
9	EYE3pYr4wNSC3oXYH9LZLTfOFNf1	$argon2id$v=19$m=64,t=1,p=1$tTd8wxI6HyuVf/bKTi0hHSivERI6+aCseXsp3OQYhb0$09I3GZQv0RbkuBlcjISDbaSbINZhgEflETroq5ltkyI	keanneng@esportsmini.com		Kean	Neng	2021-06-24 02:18:37.435255	2021-06-30 10:22:27.088977	200	1	0			https://lh3.googleusercontent.com/a/AATXAJwyDlAMlYg9YfC6pJJaSaYQ51SYGYIgVhy7fee-=s96-c	107		0						f	t	t	t	t	Kean	0		0	0	0	0	f	2021-06-30 08:00:05.003901	2021-06-30 08:00:05.00667	1970-01-01 00:00:00	
4	2QaDrnAiLANzFSa9MTrR7M7ZOuw1	$argon2id$v=19$m=64,t=1,p=1$2VOCbuNx0z61YbbMRkRS56ESaI6/kMU9oERJRnSBwII$wk1EsfufEp3hKsQIsK+V2X0X3lFkjp2hU6escqW0Vig	ojitshirt@gmail.com		Carol	Kung	2021-06-18 10:20:25.407714	2021-06-30 11:42:26.75916	200	1	0			https://lh3.googleusercontent.com/a-/AOh14Gh16Vm7RhfsoLXsurpS8lTqWnt25BL3eCr3RIgd=s96-c	0		0						f	t	t	t	t		0		0	0	0	0	f	1970-01-01 00:00:00	1970-01-01 00:00:00	1970-01-01 00:00:00	
7	byOCz921tRRXogXmIy0czl9lF5v2	$argon2id$v=19$m=64,t=1,p=1$r6/HDat8hU389jLn1NGfedL/Hh3dGeAOcuJLg/VKJoM$IpLpqrFMUdGgYBrMp6Izuest9868vvF4ekkL3tJqNH8	rohail384@gmail.com		Rohail	Tariq	2021-06-21 09:18:01.761976	2021-06-23 03:03:43.072593	200	1	0			https://lh3.googleusercontent.com/a-/AOh14GibA0bY_IRJW--Nn9Q8GISaLlZi3wPeyO8zHrBYlg=s96-c	3		0						f	t	t	t	t		0	foxk_M3ZCm4jWHOQOttHPB:APA91bGJzQikhS07vtvdXPusxj1ZnEeF028enxaZLbp_d1X1FPU2nMnsXw7VoBkcgAbUMXI42Y8wX8of98ISg6egjl0OIWvobW1uEU8BTEWQtZKqg1t1U7W7dvf4kyfiTUGuaT3Lut1i	0	0	0	0	f	2021-06-23 03:00:09.185915	2021-06-23 03:00:09.191843	2021-06-23 02:55:09.794847	
11	3EqNRkEuRKWgIb5EITdtii9jvUx2	$argon2id$v=19$m=64,t=1,p=1$uuL+qHU7PcwSBDdppNb3fXQlHf9XtUEa46Ir0wYl+pU$8ixB55Nm1AOGeUI7H6bRHQdx7M2Sh9Yuo75n8MRDEN0	sizling_rohail@hotmail.com		Rohail	Tariq	2021-06-30 12:17:06.695365	2021-06-30 12:17:06.779493	200	1	0			https://graph.facebook.com/10158352856183355/picture	0		0						f	t	t	t	t		0	fbL-uqlo40UTxZ4rhs4rbu:APA91bEbJKwSf2RY-cstQrzv2Io_a-ONLxfZoM_Pp-5EZ4mVWJpjC1265ABg5RPaBwLGS1QBQSJOZaUWT76gmXu1OR3z8kmra6s28ks49OIDbA4vOLOZY2zFcp1GDR1V6RaUNSBgeX08	0	0	0	0	f	1970-01-01 00:00:00	1970-01-01 00:00:00	2021-06-30 12:17:10.359869	
5	S77rrH8NhafvYaXTVsg0LWe8sPv1	$argon2id$v=19$m=64,t=1,p=1$VDbAIeXNeJf591oNcPDU22dmmgEnnmQfUiVTw7QD4uc$zK/FGIByjsBB61xroLEIJjX7Uc3jC0ObrAlP5PToFgQ	thienpow@gmail.com		Thien	Pow	2021-06-18 11:48:15.205028	2021-06-29 04:59:22.14674	200	1	206			https://lh3.googleusercontent.com/a-/AOh14Ghsl0s_wBX-p53LJEbYmN52w9Bu4CkrY7vf3boNAg=s96-c	76		0						f	t	t	t	t	Ken Chong	0	cwMnjiE6D-rl18szGufHYW:APA91bGdpvyhDGoUl7nSgPkJUhGWOgn25R-Ue0k_QhsoSqaG0YSIlHWHf43UWLZskPPlrKu_re_LwbLi9P0LUTw4c5ptUlXgixHja-0BnTVOuYc6M8eB7PNwjNXhrWvbGl9s2-Zzl9YX	1	0	0	0.5	f	2021-06-30 00:00:59.596736	2021-06-24 03:00:14.730655	2021-06-25 10:09:05.761393	sub_JhNLRuVefERSsN
2	psUVq2ELAGWnZztUIVruvx8nOeG3	$argon2id$v=19$m=64,t=1,p=1$ogoLo5YEBbTT5QlrDpZd1IUIQupK0hxHd9la6gxov+M$FiUWXdhhumAdX5PGKdaan2CVuJGR1FSVYbbb3MsbqV0	rohail@esportsmini.com		Rohail	T	2021-06-18 08:04:31.408399	2021-06-30 16:35:36.470493	200	1	261			https://lh3.googleusercontent.com/a/AATXAJyRmfrUCKPLZ4IBiA-8_bpKc85wMPKoxpA1fSnL=s96-c	739		0						f	t	t	t	t		0	e_tUmsE54Xxx-Ujd6RdgXe:APA91bEyTNVT4SspRAKGCTrgU6f2eC5IJRaKaB9LUHzLb57ngc27TsQRleaWv5ogtdlJcDyL-r390cYChnYUK6dFzGJgO79XAqjeCFKeAK-q-sBDrvT-zrdRLoHERzi69n89jYe4CFFY	0	0	0	0	f	2021-06-30 07:55:26.318632	2021-06-28 13:00:29.903737	2021-06-30 07:54:58.916811	
6	aUURl6UhtnNEcsOn1YCs03NfnFR2	$argon2id$v=19$m=64,t=1,p=1$O2HtBlwImU6gS93obXjxjcjy6H3AO6Z8OAAGeJF7L3A$UNAnWwO2I5mqzLb592/xkeR93g+miUcJ72y9F/2ef8c	knlim36appxplore@gmail.com		knlim36	appxplore	2021-06-21 07:19:38.889715	2021-06-28 08:45:58.688342	200	1	61			https://lh3.googleusercontent.com/a/AATXAJyLgEaVBNPr1xiAdYOXIA3x1BNlqPo3Qw80VVz8=s96-c	201		0						f	t	t	t	t		0		0	0	0	0	f	2021-06-28 09:00:55.566769	2021-06-28 09:00:55.572723	1970-01-01 00:00:00	
1	wukong	$argon2id$v=19$m=64,t=1,p=1$pb7+cdRKchBGWxfmx6nHinqmLY4ir5vc4+LSsPwbpDg$kwfH/p8iEmxcTjKqzyWs8sekvIns2Qt4vSvbS/Pxz9U	esmadmin@aadi.my	0188888888	Black	Myth	2020-12-31 15:07:54.239332	2021-06-30 23:14:12.79055	1	1	0				2		0						f	f	f	f	f		0		1	0	0	0	f	2021-05-24 12:07:26.856779	1970-01-01 00:00:00	1970-01-01 00:00:00	
10	Oaxv7w25YzUrCsVYkGn8WPh4T7U2	$argon2id$v=19$m=64,t=1,p=1$a/MA2/SVCaijrwe7L4smAeS0Wq0htuXRSmMKwb+zgZs$dGYJoch3sNe7WjpMgIWMIaBpW5VweR9B+IfA+hRtPf8	junkazoid88@gmail.com		junkaroo	nom	2021-06-25 06:12:49.358866	2021-06-25 06:25:21.697551	200	1	0			https://esm-cdn.sgp1.cdn.digitaloceanspaces.com/app/images/avatars/avatar-13.svg	6		0						f	t	t	t	t	Pickle Pecker	0	cZWgqpu73siD_QUGpbUDSF:APA91bG9OyTCVKbzZkbj4Yyaymg-MR0X_CNnv9ddgQ9fkp4iodedVHNTFg7DJOewPSI-YscUKiS3IEFlAc2Tbzsknz6obDmua9uVMm1hCfNT92NhtkitdRqnrOGY4e5-0e_3bdmwk-Oe	0	0	0	0	f	2021-06-25 06:30:09.120064	2021-06-25 06:30:09.125848	2021-06-25 06:12:53.115919	
\.


--
-- Data for Name: user_admin_change_log; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.user_admin_change_log (id, user_id, old_status, new_status, old_gem_balance, new_gem_balance, created_on, changed_by) FROM stdin;
1	4	1	2	0	0	2021-06-18 10:56:26.557559+00	1
2	4	2	1	0	0	2021-06-18 10:56:44.318254+00	1
3	4	1	1	0	0	2021-06-20 10:22:45.297781+00	1
4	4	1	2	0	0	2021-06-20 10:22:59.337352+00	1
5	4	2	4	0	0	2021-06-20 10:23:09.872737+00	1
6	4	4	1	0	0	2021-06-20 10:23:16.603298+00	1
7	2	1	1	2	10	2021-06-21 08:07:09.630787+00	1
8	2	1	1	24	0	2021-06-24 09:36:19.098142+00	1
9	2	1	1	0	24	2021-06-24 09:37:05.592143+00	1
10	6	1	1	1	100	2021-06-28 02:51:11.915625+00	1
11	9	1	1	6	100	2021-06-28 03:01:37.771643+00	1
12	9	1	1	100	0	2021-06-28 03:01:46.999744+00	1
\.


--
-- Data for Name: user_invites; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.user_invites (id, user_id, invited_by, invited_date) FROM stdin;
\.


--
-- Data for Name: user_status_type; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.user_status_type (id, title) FROM stdin;
0	Not Selected
1	Active
2	Blocked
3	Pending Delete
4	Archived
\.


--
-- Data for Name: winner; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.winner (id, prize_id, user_id, created_on, status, ship_tracking, claimed_on) FROM stdin;
1	4	3	2021-06-19 00:00:33.400408	1		1970-01-01 00:00:00
2	4	2	2021-06-22 04:04:07.476202	1		1970-01-01 00:00:00
5	1	5	2021-06-23 02:59:08.952927	1		1970-01-01 00:00:00
3	3	3	2021-06-22 13:10:31.053717	2		2021-06-24 08:34:25.93207
4	4	2	2021-06-23 02:20:30.55349	4		1970-01-01 00:00:00
7	3	6	2021-06-24 09:01:23.197556	1		1970-01-01 00:00:00
8	1	2	2021-06-24 09:37:27.105171	1		1970-01-01 00:00:00
9	4	2	2021-06-24 14:22:39.727093	1		1970-01-01 00:00:00
10	3	2	2021-06-25 06:00:43.739974	1		1970-01-01 00:00:00
11	1	2	2021-06-25 06:30:47.62932	1		1970-01-01 00:00:00
12	1	6	2021-06-25 09:31:07.744115	1		1970-01-01 00:00:00
13	4	2	2021-06-25 14:23:37.15221	1		1970-01-01 00:00:00
14	3	2	2021-06-28 05:01:08.559055	1		1970-01-01 00:00:00
15	4	3	2021-06-28 05:40:13.441347	1		1970-01-01 00:00:00
16	1	3	2021-06-28 08:01:26.779594	1		1970-01-01 00:00:00
17	3	6	2021-06-28 13:00:54.217366	1		1970-01-01 00:00:00
18	29	9	2021-06-29 05:41:11.010031	1		1970-01-01 00:00:00
19	29	9	2021-06-29 06:41:18.885727	1		1970-01-01 00:00:00
20	32	8	2021-06-29 07:00:22.146925	1		1970-01-01 00:00:00
6	4	2	2021-06-23 14:21:01.048811	3		1970-01-01 00:00:00
22	33	3	2021-06-29 07:51:29.211402	1		1970-01-01 00:00:00
21	31	3	2021-06-29 07:01:23.230531	1		2021-06-29 07:04:13.599797
23	35	9	2021-06-30 08:01:00.10692	1		1970-01-01 00:00:00
\.


--
-- Data for Name: winner_change_log; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.winner_change_log (id, winner_id, old_status, new_status, old_ship_tracking, new_ship_tracking, created_on, changed_by) FROM stdin;
1	6	1	4			2021-06-24 08:37:19.242181+00	1
2	4	1	4			2021-06-24 08:37:29.809672+00	1
3	6	4	3			2021-06-24 08:37:35.142758+00	1
4	21	2	3			2021-06-29 07:19:28.200983+00	1
5	6	3	3			2021-06-29 07:19:33.737532+00	1
6	21	3	1			2021-06-30 07:52:44.687199+00	1
\.


--
-- Data for Name: winner_status_type; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.winner_status_type (id, title) FROM stdin;
1	Unclaimed
2	Claimed
3	Delivered
4	Expired
\.


--
-- Name: checker_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.checker_log_id_seq', 1, false);


--
-- Name: current_game_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.current_game_id_seq', 4307, true);


--
-- Name: error_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.error_log_id_seq', 1, false);


--
-- Name: game_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.game_id_seq', 7, true);


--
-- Name: gplayer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.gplayer_id_seq', 615, true);


--
-- Name: item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.item_id_seq', 5, true);


--
-- Name: prize_closed_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.prize_closed_id_seq', 69, true);


--
-- Name: prize_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.prize_id_seq', 68, true);


--
-- Name: prize_pool_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.prize_pool_id_seq', 768, true);


--
-- Name: prize_tour_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.prize_tour_id_seq', 68, true);


--
-- Name: shop_buy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.shop_buy_id_seq', 40, true);


--
-- Name: spinner_extra_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.spinner_extra_log_id_seq', 110, true);


--
-- Name: spinner_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.spinner_log_id_seq', 613, true);


--
-- Name: spinner_rule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.spinner_rule_id_seq', 10, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.subscription_id_seq', 1, true);


--
-- Name: timezones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.timezones_id_seq', 1, false);


--
-- Name: tour_set_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.tour_set_id_seq', 54, true);


--
-- Name: tournament_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.tournament_id_seq', 44, true);


--
-- Name: tournament_set_game_rule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.tournament_set_game_rule_id_seq', 74, true);


--
-- Name: tournament_set_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.tournament_set_id_seq', 41, true);


--
-- Name: user_admin_change_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.user_admin_change_log_id_seq', 43, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.user_id_seq', 1, false);


--
-- Name: user_invites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.user_invites_id_seq', 1, false);


--
-- Name: winner_change_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.winner_change_log_id_seq', 38, true);


--
-- Name: winner_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.winner_id_seq', 55, true);


--
-- Name: checker_log checker_log_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.checker_log
    ADD CONSTRAINT checker_log_pkey PRIMARY KEY (id);


--
-- Name: config config_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.config
    ADD CONSTRAINT config_pkey PRIMARY KEY (id);


--
-- Name: current_game current_game_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.current_game
    ADD CONSTRAINT current_game_pkey PRIMARY KEY (id);


--
-- Name: error_log error_log_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.error_log
    ADD CONSTRAINT error_log_pkey PRIMARY KEY (id);


--
-- Name: game game_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.game
    ADD CONSTRAINT game_pkey PRIMARY KEY (id);


--
-- Name: gplayer gplayer_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.gplayer
    ADD CONSTRAINT gplayer_pkey PRIMARY KEY (id);


--
-- Name: item item_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.item
    ADD CONSTRAINT item_pkey PRIMARY KEY (id);


--
-- Name: item_type item_type_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.item_type
    ADD CONSTRAINT item_type_pkey PRIMARY KEY (id);


--
-- Name: prize_closed prize_closed_log_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.prize_closed
    ADD CONSTRAINT prize_closed_log_pkey PRIMARY KEY (id);


--
-- Name: prize prize_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.prize
    ADD CONSTRAINT prize_pkey PRIMARY KEY (id);


--
-- Name: prize_pool prize_pool_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.prize_pool
    ADD CONSTRAINT prize_pool_pkey PRIMARY KEY (id);


--
-- Name: prize_tour prize_tour_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.prize_tour
    ADD CONSTRAINT prize_tour_pkey PRIMARY KEY (id);


--
-- Name: prize_type prize_type_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.prize_type
    ADD CONSTRAINT prize_type_pkey PRIMARY KEY (id);


--
-- Name: rank rank_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.rank
    ADD CONSTRAINT rank_pkey PRIMARY KEY (id);


--
-- Name: shop_buy shop_buy_payment_id_key; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.shop_buy
    ADD CONSTRAINT shop_buy_payment_id_key UNIQUE (payment_id, sub_id);


--
-- Name: shop_buy shop_buy_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.shop_buy
    ADD CONSTRAINT shop_buy_pkey PRIMARY KEY (id);


--
-- Name: spinner_extra_log spinner_extra_log_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.spinner_extra_log
    ADD CONSTRAINT spinner_extra_log_pkey PRIMARY KEY (id);


--
-- Name: spinner_log spinner_log_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.spinner_log
    ADD CONSTRAINT spinner_log_pkey PRIMARY KEY (id);


--
-- Name: spinner_rule spinner_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.spinner_rule
    ADD CONSTRAINT spinner_rule_pkey PRIMARY KEY (id);


--
-- Name: spinner_win_type spinner_win_type_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.spinner_win_type
    ADD CONSTRAINT spinner_win_type_pkey PRIMARY KEY (id);


--
-- Name: status_progress_type status_progress_type_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.status_progress_type
    ADD CONSTRAINT status_progress_type_pkey PRIMARY KEY (id);


--
-- Name: status_type status_type_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.status_type
    ADD CONSTRAINT status_type_pkey PRIMARY KEY (id);


--
-- Name: subscription subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.subscription
    ADD CONSTRAINT subscription_pkey PRIMARY KEY (id);


--
-- Name: subscription_type subscription_type_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.subscription_type
    ADD CONSTRAINT subscription_type_pkey PRIMARY KEY (id);


--
-- Name: timezones timezones_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.timezones
    ADD CONSTRAINT timezones_pkey PRIMARY KEY (id);


--
-- Name: tour_set tour_set_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.tour_set
    ADD CONSTRAINT tour_set_pkey PRIMARY KEY (id);


--
-- Name: tournament tournament_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.tournament
    ADD CONSTRAINT tournament_pkey PRIMARY KEY (id);


--
-- Name: tournament_set_game_rule tournament_set_game_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.tournament_set_game_rule
    ADD CONSTRAINT tournament_set_game_rule_pkey PRIMARY KEY (id);


--
-- Name: tournament_set tournament_set_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.tournament_set
    ADD CONSTRAINT tournament_set_pkey PRIMARY KEY (id);


--
-- Name: user_admin_change_log user_admin_change_log_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.user_admin_change_log
    ADD CONSTRAINT user_admin_change_log_pkey PRIMARY KEY (id);


--
-- Name: user user_email_key; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_email_key UNIQUE (email);


--
-- Name: user_invites user_invites_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.user_invites
    ADD CONSTRAINT user_invites_pkey PRIMARY KEY (id);


--
-- Name: user_invites user_invites_user_id_key; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.user_invites
    ADD CONSTRAINT user_invites_user_id_key UNIQUE (user_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: user_status_type user_status_type_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.user_status_type
    ADD CONSTRAINT user_status_type_pkey PRIMARY KEY (id);


--
-- Name: user user_username_key; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_username_key UNIQUE (username);


--
-- Name: winner_change_log winner_change_log_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.winner_change_log
    ADD CONSTRAINT winner_change_log_pkey PRIMARY KEY (id);


--
-- Name: winner winner_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.winner
    ADD CONSTRAINT winner_pkey PRIMARY KEY (id);


--
-- Name: winner_status_type winner_status_type_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.winner_status_type
    ADD CONSTRAINT winner_status_type_pkey PRIMARY KEY (id);


--
-- Name: game_lower_idx; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX game_lower_idx ON public.game USING btree (lower((title)::text));


--
-- Name: idx_user_email; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX idx_user_email ON public."user" USING btree (email);


--
-- Name: idx_user_firstname; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX idx_user_firstname ON public."user" USING btree (firstname);


--
-- Name: idx_user_lastname; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX idx_user_lastname ON public."user" USING btree (lastname);


--
-- Name: idx_user_phone; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX idx_user_phone ON public."user" USING btree (phone);


--
-- Name: idx_user_username; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX idx_user_username ON public."user" USING btree (username);


--
-- Name: item_lower_idx; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX item_lower_idx ON public.item USING btree (lower((title)::text));


--
-- Name: prize_lower_idx; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX prize_lower_idx ON public.prize USING btree (lower((title)::text));


--
-- Name: subscription_lower_idx; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX subscription_lower_idx ON public.subscription USING btree (lower((title)::text));


--
-- Name: tournament_lower_idx; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX tournament_lower_idx ON public.tournament USING btree (lower((title)::text));


--
-- Name: tournament_set_lower_idx; Type: INDEX; Schema: public; Owner: doadmin
--

CREATE INDEX tournament_set_lower_idx ON public.tournament_set USING btree (lower((title)::text));


--
-- PostgreSQL database dump complete
--

